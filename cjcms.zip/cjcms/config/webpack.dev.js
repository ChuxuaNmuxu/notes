var webpackMerge = require('webpack-merge');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var commonConfig = require('./webpack.common.js');
const config = require('./config');

module.exports = webpackMerge(commonConfig, {
  // devtool: 'cheap-module-eval-source-map',
  output: {
      path: config.dir_dist,
      publicPath: config.siteResolve(),
      filename: '[name].js',
      chunkFilename: '[id].chunk.js'
  },

  plugins: [
    new ExtractTextPlugin('[name].css')
  ],

  devServer: {
      // hot: true,
      historyApiFallback: true,
      // stats: 'minimal',
  }
});
