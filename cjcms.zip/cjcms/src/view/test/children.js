import React, {Component} from 'react';
import Container from './Container';

class Test extends Component {
    render () {
        return <div>
            <Container>
                {{
                    left: <div>left</div>,
                    right: <div>right</div>
                }}
            </Container>
        </div>
    }
}

export default Test;
