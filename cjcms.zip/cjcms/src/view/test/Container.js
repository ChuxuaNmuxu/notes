import React, {Component} from 'react';

class Container extends Component {
    render () {
        return <div>
            {this.props.children.left}
            <span>
                {this.props.children.right}
            </span>
        </div>
    }
}

export default Container;