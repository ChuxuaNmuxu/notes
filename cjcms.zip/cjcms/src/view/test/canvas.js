import React, { Component } from 'react';
import CSSModules from 'react-css-modules';
import styles from './test.scss';
import imgUrl from './pic.jpg';

class Test extends Component {
    constructor (props) {
      super(props);
      this.state = {
        img: ''
      }
    }
    componentDidMount () {
      const context = this.source.getContext('2d');
      let img = new Image();
      img.src = imgUrl;
      img.onload = () => {
          context.save();
          context.drawImage(img, 50, 50, 100, 100, 0, 0, 100, 100);
          this.setState({
            img:  this.source.toDataURL()
          })
      }

    }
    render () {
      return <div>
        <canvas ref={(ref)=> {this.source = ref}} width='600' height='600' style={{background: '#fff'}}></canvas>
        <canvas ref={(ref)=> {this.target = ref}} width='600' height='600' style={{background: '#fff'}}></canvas>
        <div>
          <img src={this.state.img} alt="a"/>
        </div>
      </div>
    }
}

export default CSSModules(Test, styles);
