import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';

class Layout extends Component {
    static propTypes = {
        children: PropTypes.node
    }

    render () {
        const children = this.props.children;
        return (
            <div>
                <main>
                    <div>
                        {children}
                    </div>
                </main>
            </div>
        );
    }
}

export default connect()(Layout);
