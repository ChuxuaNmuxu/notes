import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { Menu, Icon, Modal, Form, Row, Col, Button } from 'antd';
const FormItem = Form.Item;
import { addBlock } from '../../../actions/courseware';
const SubMenu = Menu.SubMenu;
import { ActionCreators as UndoActionCreators } from 'redux-undo'

class PPTHeader extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            showModal: false
        }
        this.handleClick = this.handleClick.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleUpload = this.handleUpload.bind(this);
        this.handleMouseDown = this.handleMouseDown.bind(this);
    }

    handleClick (e) {
        const { dispatch } = this.props;
        if (e.key === 'image') {
            this.setState({
                showModal: true
            })
        } else if (e.key === 'line') {
             dispatch(UndoActionCreators.undo())
        } else {
            dispatch(addBlock({
                type: e.key
            }))
        } 
    }

    handleCancel () {
        this.setState({
            showModal: false
        })
    }

    handleUpload (e) {
        const { dispatch } = this.props;
        const image = this.refs.upload.files[0];
        var reader = new FileReader();
        reader.readAsDataURL(image);
        reader.onload = function (e) {
            dispatch(addBlock({
                type: 'image',
                imgUrl: this.result
            }))
        }
        this.setState({
            showModal: false
        })
    }

    handleMouseDown (e) {
        e.stopPropagation();
    }

    render () {
        return (
            <div className='ppt-header' onMouseDown={this.handleMouseDown} >
                <Menu
                  mode='horizontal'
                  theme='dark'
                  onClick={this.handleClick}
                >
                    <Menu.Item key='text' >
                        <Icon type='mail' />文本框
                    </Menu.Item>
                    <Menu.Item key='image' >
                        <Icon type='appstore' />图片
                    </Menu.Item>
                    <SubMenu title={<span><Icon type='shape' />形状</span>} >
                        <Menu.Item key='rect'>矩形</Menu.Item>
                        <Menu.Item key='circle'>圆形</Menu.Item>
                        <Menu.Item key='triangle'>三角</Menu.Item>
                    </SubMenu>
                    <Menu.Item key='line' >
                        <Icon type='appstore' />线条
                    </Menu.Item>
                    <Menu.Item key='table' >
                        <Icon type='appstore' />表格
                    </Menu.Item>
                </Menu>
                <Modal
                  styleName='course-modal'
                  visible={this.state.showModal}
                  title='上传图片'
                  onOk={this.handleOk}
                  onCancel={this.handleCancel}
                  wrapClassName='course-modal'
                  width='800px'
                  footer={false}
                  maskClosable={this.state.maskClosable}
                >
                    <div>
                        <Row className='move-t uploadFile'>
                            <Col span={4} htmlFor='upFile'><span className='modal-key'>图片</span></Col>
                            <Col span={16}>
                                <FormItem
                            >
                                    <input type='file' accept='image' onChange={this.handleUpload} ref='upload' />
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col offset={1} span={8}><Button onClick={this.handleCancel} size='large'>取消</Button></Col>
                        </Row>
                    </div>
                </Modal>
            </div>
        )
    }
}

PPTHeader.propTypes = {
    dispatch: PropTypes.func.isRequired,
    property: PropTypes.object.isRequired,
    slides: PropTypes.array.isRequired
}

const mapStateToProps = (props) => {
    const { courseware } = props;
    return {
        property: courseware.present.ppt.property,
        slides: courseware.present.ppt.slides
    }
}

export default connect(mapStateToProps)(PPTHeader);
