import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import Text from './editorItem/text';
import Image from './editorItem/image';
import Rect from './editorItem/rect';
import Table from './editorItem/table';

class BlockEditor extends Component {
    render () {
        const { block } = this.props;
        switch (block.type) {
        case 'text':
            return <Text />;
        case 'image':
            return <Image block={block} />;
        case 'rect':
            return <Rect />
        case 'table':
            return <Table />
        default:
            return <div> wrong! </div>
        }
    }
}

BlockEditor.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired,
    block: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.present.ppt
    }
}

export default connect(mapStateToProps)(BlockEditor);
