import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import Text from './text';

class Table extends Component {
    onChange (content) {
        console.log('Recieved content', content);
    }
    onblur () {
        console.log(1)
    }
    render () {
        const cols = 3;
        const rows = 3;
        const table = new Array(cols).fill(new Array(rows).fill(0));
        return <table>
                {
                    table.map((th, index) => {
                        if (0 === index) {
                            return <th>{th.map((td, index) => <td style={{width: '50px', height: '20px', border: '1px solid'}}><Text /></td>)}</th> 
                        } else {
                            return <tr>{th.map((td, index) => <td style={{width: '50px', height: '20px',  border: '1px solid'}}><Text /></td>)}</tr>  
                        }
                        
                    })
                }
        </table>
    }
}

Table.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(Table);
