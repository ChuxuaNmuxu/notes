import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';

class Image extends Component {
    render () {
        const { block } = this.props;
        return (
            <div>
                <img src={block.imgUrl} onClick={this.onclick} />
            </div>
        )
    }
}

Image.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired,
    block: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.present.ppt
    }
}

export default connect(mapStateToProps)(Image);
