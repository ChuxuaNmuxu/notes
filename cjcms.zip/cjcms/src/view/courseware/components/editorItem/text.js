import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class Text extends Component {
    onChange (content) {
        console.log('Recieved content', content);
    }
    onblur () {
        console.log(1)
    }
    render () {
        return (
            <Editor
              textAlignment='center'
              toolbarClassName='editor-toolbar'
              wrapperClassName='editor-wrapper'
              editorClassName='editor-editor'
              toolbarOnFocus
                />
        )
    }
}

Text.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(Text);
