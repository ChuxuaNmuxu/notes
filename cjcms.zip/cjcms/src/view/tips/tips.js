import React, {Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './tips.scss';
import config from '../../../config/config'

class Tips extends Component {
    render () {
        return (
            <div className='tips' styleName='tips'>
                <div className='tipsContent'>
                    <div className='title'>
                        对不起,云课件平台暂时仅支持教师用户访问
                    </div>
                    <div className='tipDetail'>
                        <div className='tipsItem'>您是否访问</div>
                        <div className='tipsItem'>
                            <a href={config.siteResolve('cjhmp')}>云作业系统</a>
                        </div>
                        <div className='tipsItem'>
                            <a href={config.siteResolve('cjtlis')}>学情系统</a>
                        </div>
                    </div>
                    <button className='tipBtn' onClick={() => { window.location.href = config.siteResolve('cjbis') }}>返回云平台首页</button>
                </div>
            </div>
        )
    }
}
export default CSSModules(Tips, styles);

