import React, {PropTypes} from 'react';
import {Menu} from 'antd';

import config from '../../../../config';
import logoYun from '../../../public/images/logo-yun.png';

const Header = (props) => {
    return (
        <div className='home-header'>
            <div className='home-ceiling'>
                <div className='ui container home-ceiling-wrapper'>
                    <div className='yun-logo'>
                        <a href={config.siteResolve('cjbis')} target='_blank'><img src={logoYun} alt='logo' /></a>
                    </div>
                    <Menu mode='horizontal' className='right'>
                        <Menu.Item key='cjcloud'>
                            <a href={config.siteResolve('cjbis')} target='_blank'>云平台首页</a>
                        </Menu.Item>
                        <Menu.Item key='cjcmp' >
                            <a href={config.siteResolve('cjcmp')} target='_blank'>云课件平台</a>
                        </Menu.Item>
                        <Menu.Item key='cjhmp' >
                            <a href={config.siteResolve('cjhmp')} target='_blank'>云作业平台</a>
                        </Menu.Item>
                        <Menu.Item key='cjtlis'>
                            <a href={config.siteResolve('cjtlis')} target='_blank'>学情管理</a>
                        </Menu.Item>
                    </Menu>
                </div>
            </div>
        </div>
    );
};

Header.propTypes = {
    visitor: PropTypes.object
}

export default Header;
