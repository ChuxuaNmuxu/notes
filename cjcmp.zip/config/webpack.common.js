const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const cssnano = require('cssnano');
const StyleLintPlugin = require('stylelint-webpack-plugin');
const config = require('./config');

const ENV = process.env.NODE_ENV = process.env.ENV;
const isProd = ENV === 'production';

const babelConfig = Object.assign({}, config.compiler_babel, {
  babelrc: false,
//   cacheDirectory: useHMR,
});

const APP_ENTRY = config.pathResolve.src('index.js');
const POLYFILL = config.pathResolve.src('polyfill.js');

const webpackConfig = {
    context: config.root,

    entry: {
        app: [APP_ENTRY],
        vendor: config.vendors,
        polyfill: [POLYFILL],
    },

    resolve: {
        root: config.dir_src,
        extensions: ['', '.js', '.jsx', '.json']
    },

    module: {
        preLoaders: [{
            test: /\.js$/,
            exclude: /node_modules/,
            loader: 'eslint'
        }],
        loaders: [{
            test: /\.(js|jsx)$/,
            exclude: /node_modules/,
            loader: 'babel',
            query: config.compiler_babel
        }]
    },

    plugins: [
        new StyleLintPlugin({}),
        new webpack.optimize.CommonsChunkPlugin({
            name: ['app', 'vendor', 'polyfill']
        }),
        new HtmlWebpackPlugin({
            template: 'src/index.html',
            favicon: './favicon.ico'
        })
    ],

    eslint: {
        configFile: config.pathResolve.root('.eslintrc.js')
    }
};

webpackConfig.module.loaders.push(
  { test: /\.woff(\?.*)?$/, loader: 'url?prefix=fonts/&name=[path][name].[ext]&limit=10000&mimetype=application/font-woff' },
  { test: /\.woff2(\?.*)?$/, loader: 'url?prefix=fonts/&name=[path][name].[ext]&limit=10000&mimetype=application/font-woff2' },
  { test: /\.otf(\?.*)?$/, loader: 'file?prefix=fonts/&name=[path][name].[ext]&limit=10000&mimetype=font/opentype' },
  { test: /\.ttf(\?.*)?$/, loader: 'url?prefix=fonts/&name=[path][name].[ext]&limit=10000&mimetype=application/octet-stream' },
  { test: /\.eot(\?.*)?$/, loader: 'file?prefix=fonts/&name=[path][name].[ext]' },
  { test: /\.svg(\?.*)?$/, loader: 'url?prefix=fonts/&name=[path][name].[ext]&limit=10000&mimetype=image/svg+xml' },
  { test: /\.(png|jpg)$/, loader: 'url?limit=8192' }
)

const BASE_CSS_LOADER_CONFIG = {
    sourceMap: !isProd,
    minimize: isProd
}
const BASE_CSS_LOADER = `css?${JSON.stringify(BASE_CSS_LOADER_CONFIG)}`
const MODULE_CSS_LOADER_CONFIG = {
    modules: true,
    importLoaders: 1,
    localIdentName: isProd ? '[hash:base64:4]' : '[name]_[local]_[hash:base64:3]',
}
const MODULE_CSS_LOADER = `css?${JSON.stringify(Object.assign({}, BASE_CSS_LOADER_CONFIG, MODULE_CSS_LOADER_CONFIG))}`
webpackConfig.module.loaders.push({
    test: /\.scss$/,
    include: [
        config.pathResolve.src('public/'),
        config.pathResolve.root('node_modules/')
    ],
    loaders: [
        'style',
        BASE_CSS_LOADER,
        'postcss',
        'sass?sourceMap'
    ]
});
webpackConfig.module.loaders.push({
    test: /\.scss$/,
    exclude: [
        config.pathResolve.src('public/'),
        config.pathResolve.root('node_modules/')
    ],
    loaders: [
        'style',
        MODULE_CSS_LOADER,
        'postcss',
        'sass?sourceMap'
    ]
});

webpackConfig.module.loaders.push({
    test: /\.css$/,
    include: [
        config.pathResolve.src('public/'),
        config.pathResolve.root('node_modules/')
    ],
    loaders: [
        'style',
        BASE_CSS_LOADER,
        'postcss',
    ]
});
webpackConfig.module.loaders.push({
    test: /\.css$/,
    exclude: [
        config.pathResolve.src('public/'),
        config.pathResolve.root('node_modules/')
    ],
    loaders: [
        'style',
        MODULE_CSS_LOADER,
        'postcss',
    ]
});

webpackConfig.postcss = [
    cssnano({
        autoprefixer: {
            add: true,
            remove: true,
            browsers: ['last 2 versions']
        },
        discardComments: {
            removeAll: true
        },
        discardUnused: false,
        mergeIdents: false,
        reduceIdents: false,
        safe: true,
        sourcemap: !isProd
    })
];

module.exports = webpackConfig;