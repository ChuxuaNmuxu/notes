// import 'babel-polyfill';
import 'es6-promise/auto';
import fetch from 'isomorphic-fetch';
import qs from 'qs';
import { Modal } from 'antd';
import { browserHistory } from 'react-router';
import isEmpty from 'lodash/isEmpty';
import {Base64} from 'js-base64';

import utils from './utils';

const errorMessages = (res) => `${res.status} ${res.statusText}`;

function check401 (res) {
    Modal.error({
        title: '登陆验证过期',
        content: '您的登陆验证已过期，请重新登陆',
        onOk: () => {
            utils.removeCookie('isLoggedIn');
            browserHistory.push({
                pathname: 'account/login',
                query: {
                    url: browserHistory.getCurrentLocation().pathname,
                    relogin: true
                }
            });
        }
    });
    return Promise.reject(errorMessages(res));
}

function check703 (json) {
    Modal.error({
        title: '登陆验证过期',
        content: json.data,
        onOk: () => {
            browserHistory.push({
                pathname: '/account/login',
                query: {
                    url: browserHistory.getCurrentLocation().pathname,
                    relogin: true
                }
            });
        }
    });
    return Promise.reject(`${json.code} ${json.data}`);
}

function checkRes (res) {
    switch (res.status) {
    case 401:
        return check401();
    }
    return res;
}

function checkData (json) {
    switch (json.code) {
    case 703:
        if (json.data !== '您已成功退出！') {
            return check703(json);
        }
    }
    return json;
}

const api = {
    fetch: function (url, params = {}, method = 'GET', type = '') {
        const token = utils.getCookie('token');
        const headers = {
            token: token && Base64.decode(token)
        };
        if (type !== 'file') {
            headers['Content-Type'] = (type === 'json' ? 'application/json' : 'application/x-www-form-urlencoded') + '; charset=UTF-8';
        }

        let options = {
            method: method,
            headers: headers,
            credentials: 'same-origin'
        };

        if (type === 'file') {
            options.body = params;
        } else if (type === 'json') {
            options.body = JSON.stringify(params);
        } else if (method !== 'GET') {
            options.body = qs.stringify(params);
        }
        return fetch(url, options)
        .then(checkRes)
        .then(res => res.text())
        .then(text => text ? JSON.parse(text) : {})
        .then(checkData)
        .catch((error) => {
            // TODO 这里定义通用的错误处理方式
            console.log('request failed：', error);
            return {error};
        });
    },

    get: function (url, params = {}) {
        let cacheUrl = url;
        if (!isEmpty(params)) {
            cacheUrl = url + (/\?/.test(url) ? '&' : '?') + qs.stringify(params)
        }
        return this.fetch(cacheUrl);
    },

    post: function (url, params, type = '') {
        return this.fetch(url, params, 'POST', type);
    },

    put: function (url, params, type = '') {
        return this.fetch(url, params, 'PUT', type);
    },

    delete: function (url, params = {}) {
        let cacheUrl = url;
        if (!isEmpty(params)) {
            cacheUrl = url + (/\?/.test(url) ? '&' : '?') + qs.stringify(params)
        }
        return this.fetch(cacheUrl, params, 'DELETE');
    }
};

export default api;
