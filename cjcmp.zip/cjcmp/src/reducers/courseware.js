import initialstate from './initialstate';
import merge from 'lodash/merge';
import cloneDeep from 'lodash/cloneDeep';
import {
    COURSEWARE_ADD_PPT_SLIDE,
    COURSEWARE_ADD_PPT_BLOCKS,
    COURSEWARE_CHANGE_SLIDE_PROPERTY,
    COURSEWARE_CHANGE_PPT_PROPERTY,
    COURSEWARE_CHANGE_BLOCK_PROPERTY,
    COURSEWARE_BLOCK_CLICK,
    COURSEWARE_SLIDE_MOUSEDOWN,
    COURSEWARE_MOUSE_MOVE_ON_SLIDE
 } from '../actions/actionTypes';

const courseware = (state = initialstate.courseware, action) => {
    const { type, data } = action
    let s = cloneDeep(state);

    switch (type) {
    case COURSEWARE_ADD_PPT_BLOCKS:
        switch (action.data.type) {
        case 'text':
            getCurrentSlide(s).blocks.push({
                type: 'text',
                property: {
                    isFocused: true,
                    style: {
                        width: 600,
                        height: 80,
                        top: 322,
                        left: 180,
                        angel: 0
                    }
                }
            })
            break;
        case 'image':
            getCurrentSlide(s).blocks.push({
                type: 'image',
                imgUrl: action.data.imgUrl,
                property: {
                    isFocused: true,
                    style: {
                        width: 200,
                        height: 200,
                        top: 322,
                        left: 180,
                        angel: 0
                    }
                }
            })
            break;
        case 'rect':
            getCurrentSlide(s).blocks.push({
                type: 'rect',
                property: {
                    isFocused: true,
                    style: {
                        width: 300,
                        height: 300,
                        top: 322,
                        left: 180,
                        angel: 0
                    }
                }
            })
            break;
        default:
            break;
        }
        return s;

    case COURSEWARE_ADD_PPT_SLIDE:
        s.ppt.slides.push(action.data);
        s.ppt.property.currentSlide = s.ppt.slides.length - 1
        return s;

    case COURSEWARE_CHANGE_SLIDE_PROPERTY:
        merge(s.ppt.slides[action.data.index], action.data.block);
        return s;

    case COURSEWARE_CHANGE_PPT_PROPERTY:
        merge(s.ppt.property, action.data);
        return s;

    case COURSEWARE_CHANGE_BLOCK_PROPERTY:
        merge(s.ppt.slides[currentSlide].blocks[currentBlock].property.style, action.data);
        return s;

    case COURSEWARE_BLOCK_CLICK:
        if (!data.newProperty.shiftKey) {
            getBlockFocused(s, (block) => {
                block.property.isFocused = false;
            })
            let { property } = getCurBlock(s, data.indexOfBlock);
            property.isFocused = true;
            property.initStyle = cloneDeep(property.style);
        } else {
            // todo: shiftkey
            let { property } = getCurBlock(s, data.indexOfBlock);
            property.isFocused = true;
            property.initStyle = cloneDeep(property.style);
        }
        merge(s.ppt.property, data.newProperty);
        return s;

    case COURSEWARE_SLIDE_MOUSEDOWN:
        getBlockFocused(s, (block) => {
            block.property.isFocused = false;
            block.property.initStyle.angel = block.property.style.angel;
        })
        return s;

    case COURSEWARE_MOUSE_MOVE_ON_SLIDE:
        const { isDraging, isResizing, isRotating, resizeDirection } = s.ppt.property;
        const { moveX, moveY } = data;
        if (isDraging) {
            getBlockFocused(s, (block) => {
                const { top, left } = block.property.initStyle;
                const { style } = block.property;
                style.left = left + moveX,
                style.top = top + moveY
            })
        } else if (isResizing) {
            getBlockFocused(s, (block) => {
                const { style } = block.property;
                switch (resizeDirection) {
                case 'e' :
                    style.width = block.property.initStyle.width + moveX
                    break;
                case 'w':
                    const { width, left } = block.property.initStyle;
                    style.width = width - moveX;
                    style.left = left + moveX;
                    break;
                default:
                    break;
                }
            })
        } else if (isRotating) {
            getBlockFocused(s, (block) => {
                let angel = Math.atan(moveY / moveX) / Math.PI * 180;
                // if (moveX > 0 && moveY > 0 ) {
                //     angel = 180 - angel;
                // }
                // if (moveX < 0 && moveY > 0) {
                //     angel = -180 - angel;
                // }
                console.log(angel)
                const { style, initStyle } = block.property;
                style.angel = initStyle.angel + angel * 2;
            })
        }
        return s;

    default:
        return state;
    }
}

const getSlideIndex = (s) => {
    return s.ppt.property.currentSlide;
}

const getCurrentSlide = (s) => {
    return s.ppt.slides[getSlideIndex(s)]
}

const getCurBlock = (s, currentBlock) => {
    const curSlide = getSlideIndex(s);
    const curBlock = s.ppt.slides[curSlide].blocks[currentBlock];
    return curBlock;
}

const getBlockFocused = (s, fn) => {
    const curSlide = getSlideIndex(s);
    for (let block of s.ppt.slides[curSlide].blocks) {
        if (block.property.isFocused) {
            fn(block);
        }
    }
}

export default courseware;
