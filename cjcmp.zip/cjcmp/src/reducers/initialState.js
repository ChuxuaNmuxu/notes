import Utils from '../utils';
import {Base64} from 'js-base64';

const token = Utils.getCookie('token');
let visitor = Utils.getCookie('visitor');
visitor = visitor && JSON.parse(Base64.decode(visitor.replace(/ /g, '+')));
window.visitor = visitor;
export default {
    // 账号
    account: {
        isLoggedIn: !!token,
        isLoggedOut: false,
        token: token && Base64.decode(token),
        visitor: visitor
    },

    course: {
        // 这里存放科目
        subject: {
            isFetching: false,
            meta: {
                firstValue: undefined,
                firstValueId: undefined
            },
            data: []
        },
        // 对应科目的章节
        knowledge: {
            isFetching: false,
            meta: {
                subjectId: 0
            },
            data: []
        },
        // 这里存放具体的课件,内容是根据所选科目的章节确定的(具体实现应该传对应科目的ID,和对应具体节的ID)
        courseData: {
            isFetching: false,
            meta: {
                subjectId: 0
            },
            data: {
                items: []
            }
        },
        // 这里存放上传课件所需的知识点数据，在第一次请求时拿到所有的知识点数据，处理后供上传课件部分使用
        uploadKnowledge: {
            isFetching: false,
            data: [],
            lastKnowledge: []
        },
        // 这里放上传课件后的返回情况
        uploadCourse: {
            isFetching: false,
            data: null
        }
    },

    courseware: {
        ppt: {
            // 当前属性
            property: {
                totalSlides: 1,  // 总的slide数
                isDraging: false,   // 是否有block正在在被拖拽
                isResizing: false,  // 是否有block正在改变block大小
                isRotating: false,  // 是否有block可旋转
                currentSlide: 0,  // 当前操作的slide页数
                initPageX: 0,   // 鼠标位置
                initPageY: 0,
                shiftKey: false
            },
            // 所有ppt信息
            slides: [{
                property: {
                    thumnail: null, // 缩略图
                    style: {} // 当前slide的属性
                },
                blocks: [{
                    type: 'text',
                    property: {
                        isFocused: false,
                        style: {
                            width: 600,
                            height: 80,
                            top: 322,
                            left: 180,
                            angel: 0
                        }
                    }
                }]
            }]
        },
        list: {}
    }
};
