import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';

class Rect extends Component {
    constructor (props) {
        super(props);
    }
    onChange (content) {
        console.log('Recieved content', content);
    }
    onblur () {
        console.log(1)
    }
    render () {
        return <div style={{background: 'rgb(0, 0, 0)', width: '100%', height: '100%'}} />
    }
}

Rect.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(Rect);
