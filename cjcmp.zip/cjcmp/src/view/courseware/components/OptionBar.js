import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { Button, Input, Checkbox, Row, Col, Select } from 'antd';
const Option = Select.Option;
import ColorPicker from 'rc-color-picker';
import 'rc-color-picker/assets/index.css';

class OptionBar extends Component {
    constructor (props) {
        super(props);
        this.state = {
            borderDetailHeight: 0
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange (e) {
        this.setState({
            borderDetailHeight: e.target.checked ? '235px' : 0
        })
    }

    handleColorPickerChange (color) {
        console.log(color)
    }

    handleColorPickerClose (color) {
        console.log(color)
    }

    componentWillReceiveProps () {
        const { ppt } = this.props;
        let focusedNum = 0;
        let shiftKey = false;
        const slideIndex = ppt.property.currentSlide;
        for (let block of ppt.slides[slideIndex].blocks) {
            if (block.property.isFocused) {
                this.setState({
                    blockFocused: block
                })
                focusedNum++;
            }
        }
        if (focusedNum > 1) {
            this.setState({
                shiftKey: true
            })
        }
    }

    render () {
        console.log('rightBar', this.state)
        return <div className='option-bar'>
            <dl className='item'>
                <dt className='title'>透明度</dt>
                <dd className='content-input'>
                    <Input placeholder='100' />
                </dd>
            </dl>

            <dl className='item'>
                <dt className='title'>内边距</dt>
                <dd className='content-input'>
                    <Input placeholder='100' />
                </dd>
            </dl>
            <Row gutter={32} type='flex' justify='space-between' className='item'>
                <Col span={8}>边框</Col>
                <Col span={8}><Checkbox onChange={this.handleChange} /></Col>
            </Row>
            <div className='border-detail' style={{height: this.state.borderDetailHeight}} >
                <dl className='item'>
                    <dt className='title'>样式</dt>
                    <dd className='content-input'>
                        <Select defaultValue='实线框' style={{ width: 120 }}>
                            <Option value='solid'>实线框</Option>
                            <Option value='dashed'>虚线框</Option>
                            <Option value='dot' >点框</Option>
                        </Select>
                    </dd>
                </dl>
                <dl className='item'>
                    <dt className='title'>宽度</dt>
                    <dd className='content-input'>
                        <Input placeholder='100' />
                    </dd>
                </dl>
                <dl className='item'>
                    <dt className='title'>颜色</dt>
                    <dd className='content-input'>
                        <ColorPicker
                          color={'#36c'}
                          alpha={30}
                          onChange={this.handleColorPickerChange}
                          onClose={this.handleColorPickerClose}
                          placement='bottomLeft'
                        >
                            <span className='rc-color-picker-trigger' />
                        </ColorPicker>

                    </dd>
                </dl>
            </div>
            <dl className='item'>
                <dt className='title'>层级</dt>
                <dd className='content'>
                    <Row type='flex' justify='center'>
                        <Col span={12}><Button type='primary' >向上吧层级</Button></Col>
                        <Col span={12}><Button type='primary' >向下吧层级</Button></Col>
                    </Row>
                </dd>
            </dl>
            <dl className='item'>
                <dt className='title'>操作</dt>
                <dd className='content'>
                    <Row gutter={16} type='flex' justify='center'>
                        <Col span={4} ><Button type='primary' icon='delete' /></Col>
                        <Col span={4} ><Button type='primary' icon='delete' /></Col>
                        <Col span={4} ><Button type='primary' icon='delete' /></Col>
                        <Col span={4} ><Button type='primary' icon='delete' /></Col>
                    </Row>
                </dd>
            </dl>
        </div>
    }
}

OptionBar.propTypes = {
    dispatch: PropTypes.func.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(OptionBar);
