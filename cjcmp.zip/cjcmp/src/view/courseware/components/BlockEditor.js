import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import Text from './editorItem/text';
import Image from './editorItem/image';
import Rect from './editorItem/rect';

class BlockEditor extends Component {
    constructor (props) {
        super(props);
    }

    render () {
        const { block } = this.props;
        switch (block.type) {
        case 'text':
            return <Text />;
        case 'image':
            return <Image block={block} />;
        case 'rect':
            return <Rect />
        default:
            return <div> wrong! </div>
        }
        return <div>a</div>
    }
}

BlockEditor.propTypes = {
    dispatch: PropTypes.func.isRequired,
    ppt: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(BlockEditor);
