import React, {PropTypes} from 'react';
import { connect } from 'react-redux';
import update from 'react/lib/update';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import {flow} from 'lodash';
import { Scrollbars } from 'react-custom-scrollbars';

import PageItem from './PageItem';
import { addBlock } from '../../../actions/courseware'

class PageList extends React.Component {
    constructor (props) {
        super(props);
        this.movePage = this.movePage.bind(this);
    }

    movePage (dragIndex, hoverIndex) {
        const { slides, dispatch } = this.props;
        const dragPage = slides[dragIndex];

        dispatch(addBlock(update(slides, {
            $splice: [
                    [dragIndex, 1],
                    [hoverIndex, 0, dragPage]
            ]
        })))

        // this.setState(update(this.state, {
        //     pages: {
        //         $splice: [
        //             [dragIndex, 1],
        //             [hoverIndex, 0, dragPage]
        //         ]
        //     }
        // }));
    }

    renderThumb ({ style, ...props }) {
        const thumbStyle = {
            backgroundColor: '#4b5155',
            borderRadius: '3px'
        };
        return (
            <div
              style={{ ...style, ...thumbStyle }}
              {...props} />
        );
    }

    render () {
        const {onPageItemClick, onPageItemContextMenu, slides} = this.props;
        return (
            <Scrollbars renderThumbVertical={this.renderThumb}>
                <ul className='page-list'>
                    {slides.map((item, index) =>
                        <PageItem key={index} item={item} index={index} onClick={onPageItemClick} onContextMenu={onPageItemContextMenu} movePage={this.movePage} />
                    )}
                </ul>
            </Scrollbars>
        )
    }
}

PageList.propTypes = {
    onPageItemClick: PropTypes.func,
    onPageItemContextMenu: PropTypes.func,
    slides: PropTypes.array.isRequired,
    dispatch: PropTypes.func.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        slides: courseware.ppt.slides
    }
}

export default connect(mapStateToProps)(flow(
    DragDropContext(HTML5Backend)
)(PageList));
