import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { changePPTProperty } from '../../../actions/courseware';

class BlockTransform extends Component {
    // constructor (props) {
    //     super(props);

    // }

    render () {
        const { block } = this.props;
        return <div className='eb-transform'>
            { block.property.isFocused ? (
                <div>
                    <div className='eb-rotatable' data-rotation='rotation'>
                        <div className='eb-rotatable-line' />
                    </div>
                    <div className='eb-draggable-up' data-draggable='up'>
                        <div className='eb-resizable-n eb-resizable' data-direction='n' />
                        <div className='eb-resizable-nw eb-resizable' data-direction='nw' />
                        <div className='eb-resizable-ne eb-resizable' data-direction='ne' />
                    </div>
                    <div className='eb-draggable-right' data-draggable='right'>
                        <div className='eb-resizable-e eb-resizable' data-direction='e' />
                    </div>
                    <div className='eb-draggable-bottom' data-draggable='bottom'>
                        <div className='eb-resizable-s eb-resizable' data-direction='s' />
                        <div className='eb-resizable-sw eb-resizable' data-direction='sw' />
                        <div className='eb-resizable-se eb-resizable' data-direction='se' />
                    </div>
                    <div className='eb-draggable-left' data-draggable='left'>
                        <div className='eb-resizable-w eb-resizable' data-direction='w' />
                    </div>
                </div>
            ) : (
                <div>
                    <div className='eb-draggable-up' data-draggable='up' />
                    <div className='eb-draggable-right' data-draggable='right' />
                    <div className='eb-draggable-bottom' data-draggable='bottom' />
                    <div className='eb-draggable-left' data-draggable='left' />
                </div>
            ) }

        </div>
    }
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default connect(mapStateToProps)(BlockTransform);
