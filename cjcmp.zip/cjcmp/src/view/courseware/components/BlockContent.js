import React, {PropTypes, Component} from 'react';
import BlockEditor from './BlockEditor';
import BlockTransform from './BlockTransform';
import { connect } from 'react-redux';
import { clickBlock, changePPTProperty } from '../../../actions/courseware';
import cloneDeep from 'lodash/cloneDeep';

class BlockContent extends Component {
    constructor (props) {
        super(props);
        this.handleMouseUp = this.handleMouseUp.bind(this);
    }

    handleMouseDown (indexOfBlock, e) {
        e.stopPropagation();
        const { dispatch, slides, index } = this.props;  // index: slide的索引  bIndex: block的索引
        const newProperty = {
            initPageX: e.pageX,
            initPageY: e.pageY,
            shiftKey: e.shiftKey
        }

        if (e.target.dataset.hasOwnProperty('direction')) {
            newProperty.isResizing = true;
            newProperty.resizeDirection = e.target.dataset.direction;
        } else if (e.target.dataset.hasOwnProperty('draggable')) {
            newProperty.isDraging = true;
        } else if (e.target.dataset.hasOwnProperty('rotation')) {
            newProperty.isRotating = true;
        }
        dispatch(clickBlock({
            indexOfBlock,
            newProperty
        }));
    }

    handleMouseUp (e) {
        e.stopPropagation();
        const { dispatch, ppt } = this.props;
        const { isDraging, isResizing, isRotating } = ppt.property;
        if (isDraging || isResizing || isRotating) {
            const newProperty = {
                isDraging: false,
                isResizing: false,
                isRotating: false
            }
            dispatch(changePPTProperty(newProperty));
        }
    }

    render () {
        const { item, slides, index } = this.props;
        return <div>
            {
                item.blocks.map((block, bIndex) => {
                    const blockStyle = slides[index].blocks[bIndex].property.style;
                    const blockStyleAddedPx = cloneDeep(blockStyle);
                    for (let key of Object.keys(blockStyle)) {
                        if (/top|bottom|left|right/.test(key)) {
                            blockStyleAddedPx[key] = blockStyle[key] + 'px';
                        } else if (key === 'angel') {
                            blockStyleAddedPx.transform = 'rotate(' + blockStyle[key] + 'deg)'
                        }
                    }
                    return <div className='cj-block' key={bIndex} style={blockStyleAddedPx} onMouseDown={this.handleMouseDown.bind(this, bIndex)} onMouseUp={this.handleMouseUp} >
                        <BlockEditor block={block} />
                        <BlockTransform block={block} />
                    </div>
                })
            }
        </div>
    }
}

BlockContent.propTypes = {
    item: PropTypes.object.isRequired,
    slides: PropTypes.array.isRequired,
    dispatch: PropTypes.func.isRequired,
    index: PropTypes.number.isRequired,
    ppt: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt,
        slides: courseware.ppt.slides
    }
}
export default connect(mapStateToProps)(BlockContent);
