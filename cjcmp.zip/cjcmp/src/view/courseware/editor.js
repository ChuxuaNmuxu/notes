import React, { PropTypes } from 'react';
import { Button } from 'antd';
import { connect } from 'react-redux';
import Reveal from 'reveal.js';
import 'reveal.js/css/reveal.css';
import 'reveal.js/css/theme/black.css';
import CSSModules from 'react-css-modules';
import html2canvas from 'html2canvas';

import styles from './editor.scss';
import PPTHeader from './components/Header';
import PageList from './components/PageList';
import BlockContent from './components/BlockContent';
import OptionBar from './components/OptionBar'
window.html2canvas = html2canvas;

import { addSlide, changeSlideProperty, changePPTProperty, changeBlockProperty, clickSlide, mouseMoveOnSlide } from '../../actions/courseware';

class PPTEditor extends React.Component {
    constructor (props) {
        super(props);
        this.state = {
            test: [
                'aaaaaaaaa'
            ],
            test2: []
        }

        this.handleTest = this.handleTest.bind(this);
        this.handleAddPage = this.handleAddPage.bind(this);
        this.addCanvasToThumnail = this.addCanvasToThumnail.bind(this);
        this.handleMouseMove = this.handleMouseMove.bind(this);
        this.handleMouseUp = this.handleMouseUp.bind(this);
        this.handlePageItemClick = this.handlePageItemClick.bind(this);
        this.handleMouseDown = this.handleMouseDown.bind(this);
    }

    componentDidMount () {
        Reveal.initialize({
            minScale: 1,
            maxScale: 1
        });
        this.addCanvasToThumnail();
    }

    componentWillReceiveProps (nextProps) {

    }

    componentDidUpdate (prevProps) {
        const curTotalSlides = this.props.ppt.slides.length;
        const prevTotalSlides = prevProps.ppt.slides.length;
        if (curTotalSlides !== prevTotalSlides) {
            Reveal.slide(curTotalSlides);
            Reveal.sync();
            this.addCanvasToThumnail();
        }
    }

    addCanvasToThumnail () {
        const { dispatch } = this.props;
        const curSlide = Reveal.getIndices().h;
        html2canvas(document.querySelector('.slides')).then(canvas => {
            dispatch(changeSlideProperty({
                index: curSlide,
                block: {
                    property: {
                        thumnail: canvas
                    }
                }
            }))
        });
    }

    handleTest () {
        this.setState({
            test: this.state.test.concat(['<p>bbbbbbbbbb</p>'])
        })
    }

    handleTest2 () {
        this.setState({
            test2: this.state.test2.concat(['1'])
        })
    }

    handleAddPage () {
        const { dispatch } = this.props;
        const newSlide = {
            property: { thumnail: null },
            blocks: [{
                type: 'text',
                property: {
                    style: {
                        width: 600,
                        height: 80,
                        top: 322,
                        left: 180,
                        angel: 0
                    }
                }
            }]
        }
        dispatch(addSlide(newSlide));
    }

    handlePageItemClick (index) {
        const { dispatch } = this.props;
        Reveal.slide(index);
        dispatch(changePPTProperty({ currentSlide: index }))
    }

    handlePageItemContextMenu (e) {
        e.preventDefault();
        alert(1)
    }

    handleMouseMove (e) {
        const { ppt, dispatch } = this.props;
        const { initPageX, initPageY, isDraging, isResizing, isRotating } = ppt.property;

        if (isDraging || isResizing || isRotating) {
            e.preventDefault();
            const moveX = e.pageX - initPageX;
            const moveY = e.pageY - initPageY;

            dispatch(mouseMoveOnSlide({
                moveX,
                moveY
            }));
        }
    }

    handleMouseUp (e) {
        const { dispatch, ppt } = this.props;
        const { isDraging, isResizing, isRotating } = ppt.property;
        if (isDraging || isResizing || isRotating) {
            const newProperty = {
                isDraging: false,
                isResizing: false,
                isRotating: false
            }
            dispatch(changePPTProperty(newProperty));
            this.addCanvasToThumnail();
        }
    }

    handleMouseDown (e) {
        const { dispatch } = this.props;
        dispatch(clickSlide());
    }

    render () {
        const { slides } = this.props.ppt;
        return (
            <div className='ppt-editor' styleName='ppt-editor' >
                <PPTHeader />
                <div className='ppt-main'>
                    <div className='sidebar-left style2'>
                        <div className='wrap-pages' ref={(wrapPages) => { this.wrapPages = wrapPages }}>
                            <PageList onPageItemClick={this.handlePageItemClick} onPageItemContextMenu={this.handlePageItemContextMenu} />
                        </div>
                        <div className='wrap-add-page'>
                            <Button size='large' className='btn-add-page' onClick={this.handleAddPage} icon='plus'>添加页面</Button>
                        </div>
                    </div>
                    <div className='ppt-viewport' onMouseMove={this.handleMouseMove} onMouseUp={this.handleMouseUp} onMouseDown={this.handleMouseDown}>
                        <div className='reveal'>
                            <div className='slides'>
                                {
                                    slides.map((item, index) => <section className='overflowing' key={index}><BlockContent item={item} index={index} /></section>)
                                }
                            </div>
                        </div>
                    </div>
                    <div className='sidebar-right'>
                        <OptionBar />
                    </div>
                </div>
            </div>
        )
    }
}

PPTEditor.propTypes = {
    ppt: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired
}

const mapStateToProps = (state) => {
    const { courseware } = state;
    return {
        ppt: courseware.ppt
    }
}

export default module.exports = connect(mapStateToProps)(CSSModules(PPTEditor, styles));
