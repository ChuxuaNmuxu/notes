import {
    COURSEWARE_ADD_PPT_SLIDE,
    COURSEWARE_ADD_PPT_BLOCKS,
    COURSEWARE_CHANGE_SLIDE_PROPERTY,
    COURSEWARE_CHANGE_PPT_PROPERTY,
    COURSEWARE_CHANGE_BLOCK_PROPERTY,
    COURSEWARE_BLOCK_CLICK,
    COURSEWARE_SLIDE_MOUSEDOWN,
    COURSEWARE_MOUSE_MOVE_ON_SLIDE
 } from './actionTypes';

export const addBlock = (data) => {
    return {
        type: COURSEWARE_ADD_PPT_BLOCKS,
        data
    }
}

export const addSlide = (data) => {
    return {
        type: COURSEWARE_ADD_PPT_SLIDE,
        data
    }
}

export const changeSlideProperty = (data) => {
    return {
        type: COURSEWARE_CHANGE_SLIDE_PROPERTY,
        data
    }
}

export const changePPTProperty = (data) => {
    return {
        type: COURSEWARE_CHANGE_PPT_PROPERTY,
        data
    }
}

export const changeBlockProperty = (data) => {
    return {
        type: COURSEWARE_CHANGE_BLOCK_PROPERTY,
        data
    }
}

export const clickBlock = (data) => {
    return {
        type: COURSEWARE_BLOCK_CLICK,
        data
    }
}

export const clickSlide = (data) => {
    return {
        type: COURSEWARE_SLIDE_MOUSEDOWN,
        data
    }
}

export const mouseMoveOnSlide = (data) => {
    return {
        type: COURSEWARE_MOUSE_MOVE_ON_SLIDE,
        data
    }
}

