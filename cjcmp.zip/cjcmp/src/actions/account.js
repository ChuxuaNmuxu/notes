import {Base64} from 'js-base64';

import Utils from '../utils';
import { LOGIN, LOGOUT } from './actionTypes';

export const login = (token, visitor) => {
    Utils.setCookie('token', token);
    Utils.setCookie('visitor', visitor);
    visitor = visitor && JSON.parse(Base64.decode(visitor.replace(/ /g, '+')));
    window.visitor = visitor;
    return {
        type: LOGIN,
        token: token && Base64.decode(token),
        visitor: visitor
    }
}

export const logout = () => {
    Utils.removeCookie('token');
    Utils.removeCookie('visitor');
    return {
        type: LOGOUT
    }
}
