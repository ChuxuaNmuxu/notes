import merge from 'lodash/merge';
import {LOGIN, LOGOUT} from '../actions/actionTypes';
import initialState from './initialState';

const account = (state = initialState.account, action) => {
    let type = action.type;
    if (type === LOGIN) {
        // 登录
        return merge({}, state, {
            isLoggedIn: true,
            isLoggedOut: false,
            token: action.token,
            visitor: action.visitor
        });
    } else if (type === LOGOUT) {
        // 退出
        return merge({}, state, {
            isLoggedIn: false,
            isLoggedOut: true,
            token: null,
            visitor: null
        });
    }
    return state;
}

export default account;
