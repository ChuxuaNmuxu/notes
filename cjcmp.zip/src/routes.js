import React from 'react';
import { Route, IndexRedirect } from 'react-router';
import App from './containers/App';
import Login from './view/account/login';
import Logout from './view/account/logout';
import Home from './containers/Home';
import HomeIndex from './view/home/index';
import PPTEditor from './view/courseware/editor';

const config = require('../config');
console.log(config.dir_dist)

export default <Route path='/'>
    <IndexRedirect to='index' />
    <Route path='account'>
        <Route path='login' component={Login} />
        <Route path='logout' component={Logout} />
    </Route>
    <Route component={App}>
        <Route component={Home}>
            <Route path='index' component={HomeIndex} />
        </Route>
        <Route path='ppt' component={PPTEditor} />
    </Route>
</Route>
