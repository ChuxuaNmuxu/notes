import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';
import { logout } from '../../actions/account';

class Login extends Component {
    componentDidMount () {
        const { dispatch } = this.props;
        dispatch(logout());
    }

    render () {
        return (
            <div className='logout' />
        )
    }
}

Login.propTypes = {
    dispatch: PropTypes.func
}

export default connect()(Login);
