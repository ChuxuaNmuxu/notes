import React from 'react';
import {Button} from 'antd';
import Reveal from 'reveal.js';
import 'reveal.js/css/reveal.css';
import 'reveal.js/css/theme/black.css';
import CSSModules from 'react-css-modules';
import html2canvas from 'html2canvas';

import styles from './editor.scss';
import PPTHeader from './components/Header';
import PageList from './components/PageList';
window.html2canvas = html2canvas;

class PPTEditor extends React.Component {
    constructor (props) {
        super(props);

        this.state = {
            test: [
                'aaaaaaaaa'
            ],
            test2: [],
            pages: [
                {
                    thumnail: null,
                    content: '第1页'
                },
                {
                    thumnail: null,
                    content: '第2页'
                },
                {
                    thumnail: null,
                    content: '第3页'
                },
                {
                    thumnail: null,
                    content: '第4页'
                },
                {
                    thumnail: null,
                    content: '第5页'
                }
            ]
        }

        this.handleTest = this.handleTest.bind(this);
        this.handleAddPage = this.handleAddPage.bind(this);
    }

    componentDidMount () {
        Reveal.initialize({
            minScale: 1,
            maxScale: 1
        });
        Reveal.addEventListener('slidechanged', (e) => {
            if (!this.state.pages[e.indexh].thumnail) {
                html2canvas(document.querySelector('.slides')).then(canvas => {
                    console.log(61, canvas)
                    this.state.pages[e.indexh].thumnail = canvas;
                    this.setState({
                        pages: this.state.pages
                    }, () => console.log(this.state.pages))
                });
            }
        });
    }

    componentDidUpdate () {
        console.log(52)
    }

    handleTest () {
        this.setState({
            test: this.state.test.concat(['<p>bbbbbbbbbb</p>'])
        })
    }

    handleTest2 () {
        this.setState({
            test2: this.state.test2.concat(['1'])
        })
    }

    handleAddPage () {
        const {pages} = this.state;
        this.setState({
            // pages: pages.concat([<section className='future'>{'第' + (pages.length + 1) + '页'}</section>])
            pages: pages.concat([{
                thumnail: null,
                content: '第' + (pages.length + 1) + '页'
            }])
        }, () => {
            Reveal.slide(this.state.pages.length - 1);
            Reveal.sync();
        })
    }

    handlePageItemClick (index) {
        Reveal.slide(index);
    }

    handlePageItemContextMenu (e) {
        e.preventDefault();
        alert(1)
    }

    render () {
        return (
            <div className='ppt-editor' styleName='ppt-editor'>
                <PPTHeader />
                <div className='ppt-main'>
                    <div className='sidebar-left style2'>
                        <div className='wrap-pages' ref={(wrapPages) => { this.wrapPages = wrapPages }}>
                            <PageList pages={this.state.pages} onPageItemClick={this.handlePageItemClick} onPageItemContextMenu={this.handlePageItemContextMenu} />
                        </div>
                        <div className='wrap-add-page'>
                            <Button size='large' className='btn-add-page' onClick={this.handleAddPage} icon='plus'>添加页面</Button>
                        </div>
                    </div>
                    <div className='ppt-viewport'>
                        <div className='reveal'>
                            <div className='slides'>
                                {
                                    this.state.pages.map((item, index) => <section key={index}>{item.content}</section>)
                                }
                            </div>
                        </div>
                    </div>
                    <div className='sidebar-right'>
                        右边
                    </div>
                </div>
            </div>
        )
    }
}

export default module.exports = CSSModules(PPTEditor, styles);
