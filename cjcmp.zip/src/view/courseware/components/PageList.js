import React, {PropTypes} from 'react';
import update from 'react/lib/update';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import {flow} from 'lodash';
import { Scrollbars } from 'react-custom-scrollbars';

import PageItem from './PageItem';

class PageList extends React.Component {
    constructor (props) {
        super(props);

        this.state = {
            pages: this.props.pages
        }
        this.movePage = this.movePage.bind(this);
    }

    componentWillReceiveProps (nextProps) {
        this.setState({
            pages: nextProps.pages
        })
    }

    movePage (dragIndex, hoverIndex) {
        console.log(25)
        const { pages } = this.state;
        const dragPage = pages[dragIndex];

        this.setState(update(this.state, {
            pages: {
                $splice: [
                    [dragIndex, 1],
                    [hoverIndex, 0, dragPage]
                ]
            }
        }));
    }

    renderThumb ({ style, ...props }) {
        const thumbStyle = {
            backgroundColor: '#4b5155',
            borderRadius: '3px'
        };
        return (
            <div
              style={{ ...style, ...thumbStyle }}
              {...props} />
        );
    }

    render () {
        const {onPageItemClick, onPageItemContextMenu} = this.props;
        return (
            <Scrollbars renderThumbVertical={this.renderThumb}>
                <ul className='page-list'>
                    {this.state.pages.map((item, index) =>
                        <PageItem key={index} item={item} index={index} onClick={onPageItemClick} onContextMenu={onPageItemContextMenu} movePage={this.movePage} />
                    )}
                </ul>
            </Scrollbars>
        )
    }
}

PageList.propTypes = {
    pages: PropTypes.array.isRequired,
    onPageItemClick: PropTypes.func,
    onPageItemContextMenu: PropTypes.func
}

export default flow(
    DragDropContext(HTML5Backend)
)(PageList);
