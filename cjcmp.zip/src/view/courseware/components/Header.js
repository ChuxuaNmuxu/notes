import React from 'react'

class PPTHeader extends React.Component {
    render () {
        return (
            <div className='ppt-header'>
                页面头部
            </div>
        )
    }
}

export default PPTHeader;
