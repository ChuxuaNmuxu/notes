import qs from 'qs';
import isEmpty from 'lodash/isEmpty';
import cookie from 'js-cookie';

import config from '../../config';

const utils = {
    /**
     * 生成url，根据参数和可变的dist根目录生成对应的url
     */
    url: function (url, params = {}) {
        let root = config.dir_dist;
        let cacheUrl = root + '/' + url;
        if (!isEmpty(params)) {
            cacheUrl = cacheUrl + (/\?/.test(cacheUrl) ? '&' : '?') + qs.stringify(params)
        }
        return cacheUrl;
    },

    getCookie: function (name) {
        // if (localStorage) {
        //     return localStorage.getItem(name);
        // } else {
        //     return cookie.get(name);
        // }
        return cookie.get(name);
    },

    setCookie: function (name, value) {
        // if (localStorage) {
        //     localStorage.setItem(name, value);
        // } else {
        //     cookie.set(name, value);
        // }
        cookie.set(name, value);
    },

    removeCookie: function (name) {
        // if (localStorage) {
        //     localStorage.removeItem(name);
        // } else {
        //     cookie.remove(name);
        // }
        cookie.remove(name);
    }
};

export default utils;
