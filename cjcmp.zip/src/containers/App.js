import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { browserHistory } from 'react-router';
import { Base64 } from 'js-base64';
import CSSModules from 'react-css-modules';
import { indexOf } from 'lodash';
import Tips from '../view/tips/tips'
import Utils from '../utils';
import styles from './App.scss';
import { login } from '../actions/account';

class App extends Component {
    constructor (props) {
        super(props);

        this.state = {
            isLoggedIn: this.props.isLoggedIn
        };
    }
    componentWillMount () {
        this.checkLogin();
    }

    componentWillReceiveProps (nextProps) {
        this.checkLogin(nextProps);
    }

    checkLogin (nextProps = null) {
        const props = nextProps || this.props;
        let token = props.location.query.t || Utils.getCookie('token') || (props.token && Base64.encode(props.token));
        let visitor = props.location.query.u || Utils.getCookie('visitor') || Base64.encode(JSON.stringify(props.visitor));
        if (token) {
            if (!props.isLoggedIn || (token !== Base64.encode(props.token))) {
                const { dispatch } = props;
                dispatch(login(token, visitor));
            }
        } else {
            browserHistory.push({
                pathname: '/account/login',
                query: {
                    url: browserHistory.getCurrentLocation().pathname
                }
            });
        }
        this.setState({
            isLoggedIn: !!token
        })
    }

    render () {
        let content = this.props.children;
        if (this.props.isLoggedIn) {
            if (indexOf(['TEACHER'], this.props.visitor.currentSchoolRole) < 0) {
                // content = '您的角色不允许访问该系统';
                content = <Tips />;
            }
        } else {
            content = '';
        }
        return (
            <div className='app' styleName='app'>
                {content}
            </div>
        );
    }
}

App.propTypes = {
    dispatch: PropTypes.func,
    location: PropTypes.object,
    children: PropTypes.element,
    isLoggedIn: PropTypes.bool,
    token: PropTypes.string,
    visitor: PropTypes.object,
    routing: PropTypes.object
};

function mapStateToProps (state) {
    const { routing, account: { isLoggedIn, token, visitor } } = state;
    return {
        isLoggedIn,
        token,
        visitor,
        routing
    };
}

export default connect(mapStateToProps)(CSSModules(App, styles));
