const webpack = require('webpack');
const path = require('path');
console.log(3, __dirname)
module.exports = {
    entry: './src/SL/index.js',

    output: {
        publicPath: __dirname,
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js'
    },

    resolve: {
        modules: [
            path.join(__dirname, 'src'),
            'node_modules'
        ],
        extensions: ['.js', '.jsx', '.json']
    },

    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: [
                    {
                        loader: "babel-loader"
                    }
                ]
            }
        ]
    },

    devtool: 'cheap-eval-source-map'
}