!function (t) {
	var e = {};
	e.sync = function () {
		$("[data-placement]").each(function () {
			var t = $(this),
			i = t.attr("data-placement");
			"function" == typeof e[i] ? e[i](t) : console.log('No matching layout found for "' + i + '"')
		})
	},
	e.hcenter = function (t) {
		var e = t.parent();
		e && t.css("left", (e.width() - t.outerWidth()) / 2)
	},
	e.vcenter = function (t) {
		var e = t.parent();
		e && t.css("top", (e.height() - t.outerHeight()) / 2)
	},
	e.center = function (t) {
		var e = t.parent();
		if (e) {
			var i = e.width(),
			n = e.height(),
			s = t.outerWidth(),
			o = t.outerHeight();
			t.css({
				left : (i - s) / 2,
				top : (n - o) / 2
			})
		}
	},
	e.sync(),
	$(t).on("resize", e.sync),
	t.Placement = e
}(window);