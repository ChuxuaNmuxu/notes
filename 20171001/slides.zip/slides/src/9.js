jQuery.extend({
    highlight: function(t, e, i, n) {
        if (3 === t.nodeType) {
            var s = t.data.match(e);
            if (s) {
                var o = document.createElement(i || "span");
                o.className = n || "highlight";
                var a = t.splitText(s.index);
                a.splitText(s[0].length);
                var r = a.cloneNode(!0);
                return o.appendChild(r),
                a.parentNode.replaceChild(o, a),
                1
            }
        } else if (1 === t.nodeType && t.childNodes && !/(script|style)/i.test(t.tagName) && (t.tagName !== i.toUpperCase() || t.className !== n)) for (var l = 0; l < t.childNodes.length; l++) l += jQuery.highlight(t.childNodes[l], e, i, n);
        return 0
    }
});

jQuery.fn.unhighlight = function(t) {
    var e = {
        className: "highlight",
        element: "span"
    };
    return jQuery.extend(e, t),
    this.find(e.element + "." + e.className).each(function() {
        var t = this.parentNode;
        t.replaceChild(this.firstChild, this),
        t.normalize()
    }).end()
};

jQuery.fn.highlight = function(t, e) {
    var i = {
        className: "highlight",
        element: "span",
        caseSensitive: !1,
        wordsOnly: !1
    };
    if (jQuery.extend(i, e), t.constructor === String && (t = [t]), t = jQuery.grep(t,
    function(t) {
        return "" != t
    }), t = jQuery.map(t,
    function(t) {
        return t.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
    }), 0 == t.length) return this;
    var n = i.caseSensitive ? "": "i",
    s = "(" + t.join("|") + ")";
    i.wordsOnly && (s = "\\b" + s + "\\b");
    var o = new RegExp(s, n);
    return this.each(function() {
        jQuery.highlight(this, o, i.element, i.className)
    })
};