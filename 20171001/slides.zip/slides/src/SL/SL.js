const SL = function (t) {
	t = t.split(".");
	for (var e = SL; t.length; ) {
		var i = t.shift();
		e[i] || (e[i] = {}),
		e = e[i]
	}
	return e
};

export default SL;