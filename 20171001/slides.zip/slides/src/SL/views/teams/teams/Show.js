import SL from '../../../SL';

SL("views.teams.teams").Show = SL.views.Base.extend({
    init : function () {
        this._super(),
        new SL.components.Search({
            url : SL.config.AJAX_SEARCH_ORGANIZATION
        })
    }
});