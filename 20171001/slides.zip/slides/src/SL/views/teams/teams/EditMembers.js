import SL from '../../../SL';

SL("views.teams.teams").EditMembers = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.strings = {
            loadMoreMembers : "Load more",
            loadingMoreMembers : "Loading..."
        },
        this.render(),
        this.bind(),
        this.load().then(this.afterLoad.bind(this),
            function () {
            this.preloaderElement.remove(),
            this.contentElement.html("<strong>Sorry but we ran into an issue. Try reloading the page.</strong>").show()
        }
            .bind(this))
    },
    render : function () {
        this.preloaderElement = $(".users-preloader"),
        this.contentElement = $(".users-content"),
        this.activeMembersTable = this.contentElement.find(".users-group-active-members tbody"),
        this.inactiveMembersTable = this.contentElement.find(".users-group-inactive-members tbody"),
        this.invitesTable = this.contentElement.find(".users-group-invites tbody"),
        this.inviteDescription = this.contentElement.find(".invite-description"),
        this.inviteForm = this.contentElement.find(".invite-form"),
        this.bindLadda(this.inviteForm),
        this.submitButton = this.inviteForm.find("[type=submit]"),
        this.emailInput = this.inviteForm.find("[name=email]"),
        this.roleInput = this.inviteForm.find("[name=role]"),
        this.loadMoreMembers = $('<div class="load-more">'),
        this.loadMoreMembers.appendTo(this.contentElement.find(".users-group-active-members")),
        this.loadMoreMembersLabel = $('<span class="load-more-label"></span>'),
        this.loadMoreMembersLabel.appendTo(this.loadMoreMembers),
        this.loadMoreMembersButton = $('<button class="load-more-button">' + this.strings.loadMoreMembers + "</button>"),
        this.loadMoreMembersButton.on("vclick", this.onLoadMoreMembersClicked.bind(this)),
        this.loadMoreMembersButton.appendTo(this.loadMoreMembers)
    },
    bind : function () {
        this.inviteForm.on("submit", this.onInviteSubmit.bind(this)),
        this.emailInput.on("input", this.onEmailInput.bind(this))
    },
    bindLadda : function (t) {
        t.find(".ladda-button").each(function (t, e) {
            e = $(e),
            e.data("ladda") || e.data("ladda", Ladda.create(e.get(0)))
        })
    },
    load : function () {
        return this.membersCollection = new SL.collections.TeamMembers,
        this.invitesCollection = new SL.collections.TeamInvites,
        Promise.all([this.loadSubscriptionDetails(), this.membersCollection.load(), this.invitesCollection.load()])
    },
    loadSubscriptionDetails : function () {
        return $.ajax({
            url : SL.config.AJAX_SUBSCRIPTION_DETAILS,
            type : "GET",
            context : this
        }).done(function (t) {
            this.subscriptionDetails = t
        })
    },
    afterLoad : function () {
        this.preloaderElement.remove(),
        this.contentElement.show(),
        this.membersCollection.forEach(this.renderMember.bind(this)),
        this.invitesCollection.forEach(this.renderInvitee.bind(this)),
        this.refreshLoadMore(),
        this.refreshTableVisibility(),
        this.refreshInviteDescription()
    },
    refreshLoadMore : function () {
        this.loadMoreMembers.toggleClass("visible", !this.membersCollection.isLoading() && this.membersCollection.isLoaded() && this.membersCollection.hasNextPage()),
        this.loadMoreMembersLabel.text("Showing " + this.membersCollection.getLoadedResults() + "/" + this.membersCollection.getTotalResults() + " members")
    },
    refreshTableVisibility : function () {
        this.activeMembersTable.parents(".users-group").toggleClass("visible", this.getActiveMemberCount() > 0),
        this.inactiveMembersTable.parents(".users-group").toggleClass("visible", this.getInactiveMemberCount() > 0),
        this.invitesTable.parents(".users-group").toggleClass("visible", this.getInvitedMemberCount() > 0)
    },
    refreshInviteDescription : function () {
        var t = "";
        this.subscriptionDetails.manually_upgraded ? t = "Invited members will receive instructions via email." : this.subscriptionDetails.free_invites_remaining > 0 ? t = 'Invited members will receive instructions via email. <span class="badge">' + this.subscriptionDetails.free_invites_remaining + " free " + SL.util.string.pluralize("invite", "s", this.subscriptionDetails.free_invites_remaining > 1) + " remaining</span>" : this.subscriptionDetails.billed_yearly ? t = "They'll receive instructions via email. You will be charged the prorated amount for the remainder of your current yearly billing cycle. At the start of your next billing cycle you are charged <strong>$" + this.subscriptionDetails.price_per_account + " per team member</strong>." : this.subscriptionDetails.billed_monthly && (t = "They'll receive instructions via email. You will be charged the prorated amount for the remainder of your current monthly billing cycle. At the start of your next billing cycle you are charged <strong>$" + this.subscriptionDetails.price_per_account + " per team member</strong>."),
        this.inviteDescription.html(t)
    },
    refreshInviteDescriptionAfterReload : function () {
        this.loadSubscriptionDetails().then(this.refreshInviteDescription.bind(this))
    },
    renderMember : function (t) {
        t.hasMembership() && t.membership.get("activated") ? this.renderActiveMember(t) : this.renderInactiveMember(t)
    },
    renderActiveMember : function (t) {
        var e = $("<tr>").attr("data-id", t.get("id")),
        i = '<div class="avatar" style="background-image: url(' + t.get("thumbnail_url") + ')" data-tooltip="View profile"></div>';
        e.append('<td><a href="/' + t.get("username") + '" target="_blank">' + i + "</a>" + t.get("email") + "</td>"),
        e.append('<td class="role"></td>'),
        e.append('<td class="actions"></td>');
        var n = this.renderRoleSelector(t, !0);
        n.appendTo(e.find(".role")),
        n.on("change", this.onRoleChanged.bind(this, t, e));
        var s = SL.current_user.get("id") === t.get("id"),
        o = t.hasMembership() && t.membership.isOwner();
        s || o || (e.find(".actions").append('<button class="button outline ladda-button deactivate" data-style="zoom-out" data-spinner-color="#222" data-tooltip="Deactivate"><span class="i-x"></span></button>'), e.find(".deactivate").on("click", this.onDeactivateUserClicked.bind(this, t, e))),
        e.appendTo(this.activeMembersTable)
    },
    renderInactiveMember : function (t) {
        var e = $("<tr>").attr("data-id", t.get("id"));
        e.append("<td>" + t.get("email") + "</td>"),
        e.append('<td class="role"></td>'),
        e.append('<td class="actions"></td>'),
        e.find(".role").append(this.renderRoleSelector(t, !1)),
        e.find(".actions").html(['<button class="button outline ladda-button delete" data-style="zoom-out" data-spinner-color="#222" data-tooltip="Delete permanently"><span class="i-trash-stroke"></span></button>', '<button class="button outline ladda-button reactivate" data-style="zoom-out" data-spinner-color="#222" data-tooltip="Reactivate account"><span class="i-plus"></span></button>'].join("")),
        e.find(".reactivate").on("click", this.onReactivateUserClicked.bind(this, t, e)),
        e.find(".delete").on("click", this.onDeleteUserClicked.bind(this, t, e)),
        e.appendTo(this.inactiveMembersTable)
    },
    renderInvitee : function (t) {
        var e = $("<tr>").attr("data-id", t.get("id"));
        e.append("<td>" + t.get("email") + "</td>"),
        e.append('<td class="role"></td>'),
        e.append('<td class="actions"></td>'),
        e.find(".role").append(this.renderRoleSelector(t, !1)),
        e.find(".actions").html(['<button class="button outline ladda-button resend-invite" data-style="zoom-out" data-spinner-color="#222" data-tooltip="Resend invite"><span class="i-mail"></span></button>', '<button class="button outline ladda-button delete-invite" data-style="zoom-out" data-spinner-color="#222" data-tooltip="Cancel invite"><span class="i-x"></span></button>'].join("")),
        e.find(".resend-invite").on("click", this.resendInvite.bind(this, t, e)),
        e.find(".delete-invite").on("click", this.deleteInvite.bind(this, t, e)),
        e.appendTo(this.invitesTable)
    },
    renderRoleSelector : function (t, e) {
        var i = $('<select class="sl-select s role-selector"></select>'),
        n = SL.models.UserMembership.ROLE_MEMBER;
        return n = t.hasMembership && t.hasMembership() ? t.membership.get("role") : t.get("team_role"),
        n === SL.models.UserMembership.ROLE_OWNER ? i.append(['<option value="' + SL.models.UserMembership.ROLE_OWNER + '" selected>Owner</option>'].join("")) : (i.append(['<option value="' + SL.models.UserMembership.ROLE_MEMBER + '">Member</option>', '<option value="' + SL.models.UserMembership.ROLE_ADMIN + '">Admin</option>'].join("")), i.find('[value="' + n + '"]').prop("selected", !0)),
        e && SL.current_user.get("id") !== t.get("id") && n !== SL.models.UserMembership.ROLE_OWNER || i.attr("disabled", !0),
        i
    },
    onRoleChanged : function (t, e, i) {
        $.ajax({
            type : "PUT",
            url : SL.config.AJAX_TEAM_MEMBER_UPDATE(t.get("id")),
            data : {
                user : {
                    role : i.target.value
                }
            },
            context : this
        }).done(function () {
            SL.notify("Role saved")
        }).fail(function () {
            SL.notify("Failed to change role", "negative")
        })
    },
    deactivateUser : function (t, e) {
        this.bindLadda(e);
        var i = e.find("button.deactivate").data("ladda");
        i && i.start(),
        $.ajax({
            type : "DELETE",
            url : SL.config.AJAX_TEAM_MEMBER_DEACTIVATE(t.get("id")),
            context : this
        }).done(function () {
            SL.notify("User deactivated"),
            e.remove(),
            t.membership.set("activated", !1),
            this.renderInactiveMember(t),
            this.refreshTableVisibility(),
            this.refreshInviteDescriptionAfterReload()
        }).fail(function () {
            SL.notify("Failed to deactivate member", "negative")
        }).always(function () {
            i && i.stop()
        })
    },
    onDeactivateUserClicked : function (t, e, i) {
        SL.prompt({
            type : "select",
            anchor : i.currentTarget,
            title : "Are you sure you want to deactivate this account?",
            subtitle : "This person will no longer be able to sign in to Slides. You are not charged for deactivated accounts and can reactivate any time.",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Deactivate</h3>",
                    selected : !0,
                    className : "negative",
                    callback : this.deactivateUser.bind(this, t, e)
                }
            ]
        })
    },
    reactivateUser : function (t, e) {
        this.bindLadda(e);
        var i = e.find("button.reactivate").data("ladda");
        i && i.start(),
        $.ajax({
            type : "POST",
            url : SL.config.AJAX_TEAM_MEMBER_REACTIVATE(t.get("id")),
            context : this
        }).done(function () {
            SL.notify("User activated"),
            e.remove(),
            t.membership.set("activated", !0),
            this.renderActiveMember(t),
            this.refreshTableVisibility(),
            this.refreshInviteDescriptionAfterReload()
        }).fail(function () {
            SL.notify("Failed to activate member", "negative")
        }).always(function () {
            i && i.stop()
        })
    },
    onReactivateUserClicked : function (t, e) {
        this.reactivateUser(t, e)
    },
    deleteUser : function (t, e, i) {
        this.bindLadda(e);
        var n = e.find("button.delete").data("ladda");
        n && n.start(),
        $.ajax({
            type : "DELETE",
            url : SL.config.AJAX_TEAM_MEMBER_DELETE(t.get("id")),
            data : {
                absorb_decks : i
            },
            context : this
        }).done(function () {
            SL.notify("User deleted"),
            e.remove(),
            this.refreshTableVisibility(),
            this.refreshInviteDescriptionAfterReload()
        }).fail(function () {
            SL.notify("Failed to delete member", "negative")
        }).always(function () {
            n && n.stop()
        })
    },
    onDeleteUserClicked : function (t, e, i) {
        SL.prompt({
            type : "select",
            anchor : i.currentTarget,
            title : "Do you want to permanently delete this account?",
            subtitle : "All settings and slide decks associated with the account will be removed. This can not be undone.",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Delete</h3>",
                    selected : !0,
                    className : "negative",
                    callback : this.deleteUser.bind(this, t, e)
                }, {
                    html : "<h3>Delete but keep decks</h3>",
                    selected : !0,
                    className : "negative",
                    callback : this.deleteUser.bind(this, t, e, !0)
                }
            ]
        })
    },
    sendInvite : function () {
        var t = this.emailInput.val().trim(),
        e = this.roleInput.val();
        if (t && t.length > 1) {
            var i = this.inviteForm.find(".ladda-button").data("ladda");
            i && i.start(),
            $.ajax({
                type : "POST",
                url : SL.config.AJAX_TEAM_INVITATIONS_CREATE,
                data : {
                    invitation : {
                        email : t,
                        team_role : e
                    }
                },
                context : this
            }).done(function (t) {
                this.renderInvitee(this.invitesCollection.createModel(t)),
                this.refreshTableVisibility(),
                this.refreshInviteDescriptionAfterReload(),
                this.emailInput.val(""),
                SL.notify("Invite sent!")
            }).fail(function (t) {
                var e = "Failed to send invite";
                t && t.responseJSON && t.responseJSON.email && t.responseJSON.email.length > 0 && "string" == typeof t.responseJSON.email[0] && (e = t.responseJSON.email[0]),
                SL.notify(e, "negative")
            }).always(function () {
                i && i.stop()
            })
        }
    },
    resendInvite : function (t, e) {
        this.bindLadda(e);
        var i = e.find("button.resend-invite").data("ladda");
        i && i.start(),
        $.ajax({
            type : "POST",
            url : SL.config.AJAX_TEAM_INVITATIONS_RESEND(t.get("id")),
            context : this
        }).done(function () {
            SL.notify("Invite sent!")
        }).fail(function () {
            SL.notify("Failed to send invite", "negative")
        }).always(function () {
            i && i.stop()
        })
    },
    deleteInvite : function (t, e) {
        this.bindLadda(e);
        var i = e.find("button.delete-invite").data("ladda");
        i && i.start(),
        $.ajax({
            type : "DELETE",
            url : SL.config.AJAX_TEAM_INVITATIONS_DELETE(t.get("id")),
            context : this
        }).done(function () {
            SL.notify("Invite deleted"),
            e.remove(),
            this.refreshTableVisibility(),
            this.refreshInviteDescriptionAfterReload()
        }).fail(function () {
            SL.notify("Failed to delete invite", "negative")
        }).always(function () {
            i && i.stop()
        })
    },
    getActiveMemberCount : function () {
        return this.activeMembersTable.find("tr").length - 1
    },
    getInactiveMemberCount : function () {
        return this.inactiveMembersTable.find("tr").length - 1
    },
    getInvitedMemberCount : function () {
        return this.invitesTable.find("tr").length - 1
    },
    onInviteSubmit : function (t) {
        t.preventDefault(),
        this.sendInvite()
    },
    onEmailInput : function () {
        this.submitButton.prop("disabled", 0 == this.emailInput.val().trim().length)
    },
    onLoadMoreMembersClicked : function () {
        this.loadMoreMembersButton.prop("disabled", !0).text(this.strings.loadingMoreMembers),
        this.membersCollection.loadNextPage().then(function (t) {
            t.forEach(this.renderMember.bind(this))
        }
            .bind(this)).catch (function () {
            SL.notify("Failed to load members", "negative")
        }
            .bind(this))
            .then(function () {
                this.loadMoreMembersButton.prop("disabled", !1).text(this.strings.loadMoreMembers),
                this.refreshLoadMore()
            }
                .bind(this))
    }
});