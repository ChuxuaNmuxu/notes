import SL from '../../../SL';

SL("views.teams.teams").Edit = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.render()
    },
    render : function () {
        if (this.formElement = $("form"), this.formElement.length) {
            this.formElement.find(".unit[data-factory]").each(function (t, e) {
                var i = null;
                $(e).attr("data-factory").split(".").forEach(function (t) {
                    i = i ? i[t] : window[t]
                }),
                "function" == typeof i && new i(e)
            }),
            this.formElement.find(".unit[data-validate]:not([data-factory])").each(function (t, e) {
                new SL.components.FormUnit(e)
            });
            var t = this.formElement.find("button[type=submit]");
            if (t.length) {
                var e = Ladda.create(t.get(0));
                this.formElement.on("submit",
                    function (t) {
                    t.isDefaultPrevented() || e.start()
                }
                    .bind(this))
            }
        }
    }
});