import SL from '../../../SL';

SL("views.teams.subscriptions").Reactivate = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.formElement = $("#payment-form"),
        this.formSubmitButton = this.formElement.find("button[type=submit]"),
        this.formSubmitLoader = Ladda.create(this.formSubmitButton.get(0)),
        this.bind(),
        this.summarize()
    },
    bind : function () {
        this.summarize = this.summarize.bind(this),
        this.formElement.on("keydown", this.onFormKeyDown.bind(this)),
        this.formSubmitButton.on("click", this.onFormSubmitClicked.bind(this)),
        this.formElement.find('input[name="billing-period"]').on("change", this.summarize),
        $("#stripe-card-number").payment("formatCardNumber"),
        $("#stripe-card-cvc").payment("formatCardCVC"),
        $("#stripe-month").payment("restrictNumeric"),
        $("#stripe-year").payment("restrictNumeric")
    },
    summarize : function () {
        var t = this.formElement.find(".purchase-summary"),
        e = "monthly" === this.formElement.find('input[name="billing-period"]:checked').val();
        t.attr("data-period", e ? "monthly" : "yearly")
    },
    submitToStripe : function () {
        this.formSubmitLoader.start(),
        Stripe.createToken(this.formElement, this.onStripeResponse.bind(this))
    },
    submitToApp : function (t) {
        var e = {
            subscription : {
                token : t,
                billing_period : this.formElement.find('input[name="billing-period"]:checked').val()
            }
        };
        $.ajax({
            type : "POST",
            url : SL.config.AJAX_TEAMS_REACTIVATE,
            data : JSON.stringify(e),
            dataType : "json",
            context : this,
            contentType : "application/json"
        }).done(function (t) {
            window.location = t.team && "string" == typeof t.team.root_url ? window.location.protocol + "//" + t.team.root_url : "/"
        }).fail(function () {
            SL.notify(SL.locale.get("GENERIC_ERROR"), "negative"),
            this.formSubmitLoader.stop()
        })
    },
    onStripeResponse : function (t, e) {
        e.error ? (SL.notify(e.error.message, "negative"), this.formSubmitLoader.stop()) : this.submitToApp(e.id)
    },
    onFormKeyDown : function (t) {
        return 13 === t.keyCode ? (this.submitToStripe(), t.preventDefault(), !1) : void 0
    },
    onFormSubmitClicked : function (t) {
        return this.submitToStripe(),
        t.preventDefault(),
        !1
    }
});