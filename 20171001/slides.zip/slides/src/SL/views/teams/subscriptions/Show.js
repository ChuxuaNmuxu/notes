import SL from '../../../SL';

SL("views.teams.subscriptions").Show = SL.views.subscriptions.Show.extend({
    init : function () {
        this._super()
    },
    render : function () {
        this.data.isTrial() ? (this.strings.CONFIRM_UNSUBSCRIBE_ACTION = "Cancel subscription and deactivate my team", this.strings.CONFIRM_UNSUBSCRIBE_DESCRIPTION = "Your trial will be canceled immediately and this team will no longer be accessible.") : (this.strings.CONFIRM_UNSUBSCRIBE_ACTION = "Cancel subscription and deactivate my team", this.strings.CONFIRM_UNSUBSCRIBE_DESCRIPTION = "Your subscription will be terminated and this team will be inaccessible after the end of the current billing cycle."),
        this._super()
    },
    renderDetails : function () {
        var t = $('<section class="billing-details"><h2>Billing details</h2></section>').appendTo(".billing-wrapper"),
        e = this.data.hasActiveSubscription(),
        i = this.data.isTrial();
        if (e) {
            if (t.append(i ? '<div class="field status"><span class="label">Status</span><span class="value">Trial</span></div>' : '<div class="field status"><span class="label">Status</span><span class="value">Active</span></div>'), SL.current_team.has("user_count") && t.append('<div class="field active-users"><span class="label" data-tooltip="The current number of users that you have invited to the team." data-tooltip-maxwidth="260">Team members</span><span class="value">' + SL.current_team.get("user_count") + "</span></div>"), this.data.has("subscription.period") && t.append('<div class="field period"><span class="label">Billing period</span><span class="value">' + ("year" === this.data.get("subscription.period") ? "Yearly" : "Monthly") + "</span></div>"), this.data.has("active_card") && t.append('<div class="field card"><span class="label">Card</span><span class="value">' + this.DOTTED_CARD_PREFIX + this.data.get("active_card.last4") + "</span></div>"), this.data.hasActiveSubscription() && this.data.hasCoupon()) {
                var n = this.data.get("subscription.coupon_code").toUpperCase(),
                s = this.data.get("subscription.percent_off");
                s > 0 && (n += " / " + s + "% off"),
                t.append('<div class="field"><span class="label">Coupon</span><span class="value">' + n + "</span></div>")
            }
            if (this.data.has("subscription")) {
                var o = moment.unix(this.data.getNextInvoiceDate()).format("MMMM Do, YYYY"),
                a = i ? "First invoice" : "Next invoice",
                r = "$" + this.data.getNextInvoiceSum();
                t.append('<div class="field payment-cycle"><span class="label">' + a + '</span><span class="value">' + r + " on " + o + "</span></div>")
            }
            t.append('<footer class="actions"><a class="button outline thin" href="' + SL.routes.SUBSCRIPTIONS_EDIT_CARD + '">Change credit card</a><button class="button negative outline thin cancel-subscription ladda-button" data-style="expand-right" data-spinner-color="#222">' + this.strings.CONFIRM_UNSUBSCRIBE_ACTION + "</button></footer>"),
            this.data.get("can_change_period") && t.find(".actions").prepend('<a class="button outline thin" href="' + SL.routes.SUBSCRIPTIONS_EDIT_PERIOD + '">Switch to annual billing</a>'),
            t.find(".actions").prepend('<p class="title">Options</p>')
        } else {
            var l = moment.unix(this.data.get("subscription.current_period_end")).format("MMM Do, YYYY");
            t.append('<div class="field status"><span class="label">Status</span><span class="value">Canceled, available until ' + l + "</span></div>"),
            SL.current_team.has("user_count") && t.append('<div class="field active-users"><span class="label" data-tooltip="The current number of users that you have invited to the team." data-tooltip-maxwidth="260">Team members</span><span class="value">' + SL.current_team.get("user_count") + "</span></div>"),
            this.data.has("active_card") && t.append('<div class="field card"><span class="label">Card</span><span class="value">' + this.DOTTED_CARD_PREFIX + this.data.get("active_card.last4") + "</span></div>")
        }
        this.cancelButton = $(".billing-details .cancel-subscription"),
        this.cancelButton.length && (this.cancelButton.on("click", this.onCancelSubscriptionClicked.bind(this)), this.cancelLoader = Ladda.create(this.cancelButton.get(0)))
    },
    onCancelSubscriptionSuccess : function () {
        SL.notify("Subscription canceled"),
        window.location = "http://slides.com"
    }
});