import SL from '../../SL';

SL("views.teams").New = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.formElement = $("#payment-form"),
        this.formSubmitButton = this.formElement.find("button[type=submit]"),
        this.formSubmitLoader = Ladda.create(this.formSubmitButton.get(0)),
        this.bind(),
        this.summarize()
    },
    bind : function () {
        this.summarize = this.summarize.bind(this),
        this.formElement.on("keydown", this.onFormKeyDown.bind(this)),
        this.formSubmitButton.on("click", this.onFormSubmitClicked.bind(this)),
        this.formElement.find("#team-name").on("input", this.onTeamNameChange.bind(this)),
        this.formElement.find('input[name="billing-period"]').on("change", this.summarize),
        $("#stripe-card-number").payment("formatCardNumber"),
        $("#stripe-card-cvc").payment("formatCardCVC"),
        $("#stripe-month").payment("restrictNumeric"),
        $("#stripe-year").payment("restrictNumeric"),
        this.formElement.find(".unit[data-validate], .unit[data-required]").each(function (t, e) {
            new SL.components.FormUnit(e)
        })
    },
    summarize : function () {
        var t = this.formElement.find(".purchase-summary"),
        e = "monthly" === this.formElement.find('input[name="billing-period"]:checked').val();
        t.attr("data-period", e ? "monthly" : "yearly")
    },
    validate : function () {
        var t = !0;
        return this.formElement.find(".unit[data-validate], .unit[data-required]").each(function (e, i) {
            var n = $(i).data("controller");
            n.validate(!0) === !1 && (t && n.focus(), t = !1)
        }),
        t
    },
    captureData : function () {
        this.formData = {
            team : {
                name : this.formElement.find("#team-name").val(),
                slug : this.formElement.find("#team-slug").val()
            },
            user : {
                username : this.formElement.find("#user-name").val(),
                email : this.formElement.find("#user-email").val(),
                password : this.formElement.find("#user-password").val()
            },
            subscription : {
                billing_period : this.formElement.find('input[name="billing-period"]:checked').val(),
                coupon : this.formElement.find('input[name="coupon"]').val()
            }
        }
    },
    submitToStripe : function () {
        this.validate() && (this.captureData(), this.formSubmitLoader.start(), SL.current_user && SL.current_user.isPaid() && 0 === $("#stripe-card-number").length ? this.submitToApp() : Stripe.createToken(this.formElement, this.onStripeResponse.bind(this)))
    },
    submitToApp : function (t) {
        t && (this.formData.subscription.token = t),
        $.ajax({
            type : "POST",
            url : SL.config.AJAX_TEAMS_CREATE,
            data : JSON.stringify(this.formData),
            dataType : "json",
            context : this,
            contentType : "application/json"
        }).done(function (t) {
            window.location = t.team && "string" == typeof t.team.root_url ? window.location.protocol + "//" + t.team.root_url : window.location.protocol + "//" + this.formData.team.slug + "." + window.location.host
        }).fail(function (t) {
            var e = SL.locale.get("GENERIC_ERROR"),
            i = JSON.parse(t.responseText);
            i && (i.user && i.user.email && i.user.email.length ? e = "Email error: " + i.user.email[0] : i.team && i.team.name && i.team.name.length ? e = "Team name error: " + i.team.name[0] : i.team && i.team.slug && i.team.slug.length && (e = "Team name error: " + i.team.slug[0])),
            SL.notify(e, "negative"),
            this.formSubmitLoader.stop()
        })
    },
    onStripeResponse : function (t, e) {
        e.error ? (SL.notify(e.error.message, "negative"), this.formSubmitLoader.stop()) : this.submitToApp(e.id)
    },
    onFormKeyDown : function (t) {
        return 13 === t.keyCode ? (this.submitToStripe(), t.preventDefault(), !1) : void 0
    },
    onFormSubmitClicked : function (t) {
        return this.submitToStripe(),
        t.preventDefault(),
        !1
    },
    onTeamNameChange : function () {
        var t = this.formElement.find("#team-name"),
        e = this.formElement.find("#team-slug");
        e.val(SL.util.string.slug(t.val()));
        var i = e.parent(".unit").data("controller");
        i && i.validateAfterTimeout()
    }
});