import SL from '../SL';

SL("views").Base = Class.extend({
    init : function () {
        this.header = new SL.components.Header,
        this.setupAce(),
        this.setupSocial(),
        this.setupToC(),
        this.handleLogos(),
        this.handleOutlines(),
        this.handleFeedback(),
        this.handleWindowClose(),
        this.handleAutoRefresh(),
        this.parseTimes(),
        this.parseLinks(),
        this.parseMeters(),
        this.parseSpinners(),
        this.parseNotifications(),
        this.parseScrollLinks(),
        setInterval(this.parseTimes.bind(this), 12e4)
    },
    setupAce : function () {
        "object" == typeof window.ace && "object" == typeof window.ace.config && "function" == typeof window.ace.config.set && ace.config.set("workerPath", "/ace")
    },
    setupSocial : function () {
        $(window).on("load",
            function () {
            var t = $(".facebook-share-button"),
            e = $(".twitter-share-button"),
            i = $(".google-share-button"),
            n = {
                url : window.location.protocol + "//" + window.location.hostname + window.location.pathname,
                title : $('meta[property="og:title"]').attr("content"),
                description : $('meta[property="og:description"]').attr("content"),
                thumbnail : $('meta[property="og:image"]').attr("content")
            };
            t.length && (t.attr("href", SL.util.social.getFacebookShareLink(n.url, n.title, n.description, n.thumbnail)), t.on("vclick",
                    function (t) {
                    SL.util.openPopupWindow($(this).attr("href"), "Share on Facebook", 600, 400),
                    t.preventDefault()
                })),
            e.length && (e.attr("href", SL.util.social.getTwitterShareLink(n.url, n.title)), e.on("vclick",
                    function (t) {
                    SL.util.openPopupWindow($(this).attr("href"), "Share on Twitter", 600, 400),
                    t.preventDefault()
                })),
            i.length && (i.attr("href", SL.util.social.getGoogleShareLink(n.url)), i.on("vclick",
                    function (t) {
                    SL.util.openPopupWindow($(this).attr("href"), "Share on Google+", 600, 400),
                    t.preventDefault()
                }))
        })
    },
    setupToC : function () {
        function t() {
            n = o.find("li").toArray(),
            n = n.map(function (t) {
                    var e = t.querySelector("a"),
                    i = document.getElementById(e.getAttribute("href").slice(1));
                    return {
                        listItem : t,
                        anchor : e,
                        target : i
                    }
                }),
            n = n.filter(function (t) {
                    return !!t.target
                });
            var t,
            i = [];
            n.forEach(function (e, n) {
                var s = e.anchor.offsetLeft,
                o = e.anchor.offsetTop,
                a = e.anchor.offsetHeight;
                0 === n ? (i.push("M", s, o, "L", s, o + a), e.pathStart = 0) : (t !== s && i.push("L", t, o), i.push("L", s, o), l.setAttribute("d", i.join(" ")), e.pathStart = l.getTotalLength(), i.push("L", s, o + a)),
                t = s,
                l.setAttribute("d", i.join(" ")),
                e.pathEnd = l.getTotalLength()
            }),
            s = l.getTotalLength(),
            e()
        }
        function e() {
            var t = window.innerHeight,
            e = $(window).scrollTop();
            o.toggleClass("fixed", e > a);
            var i = s;
            pathEnd = 0;
            var r = 0;
            n.forEach(function (e) {
                var n = e.target.getBoundingClientRect();
                n.bottom > t * d && n.top < t * (1 - c) ? (i = Math.min(e.pathStart, i), pathEnd = Math.max(e.pathEnd, pathEnd), r += 1, e.listItem.classList.add("sl-scroll-anchor-selected")) : e.listItem.classList.remove("sl-scroll-anchor-selected")
            }),
            r > 0 ? (l.setAttribute("stroke-dashoffset", "1"), l.setAttribute("stroke-dasharray", "1, " + i + ", " + (pathEnd - i) + ", " + s), l.setAttribute("opacity", 1)) : l.setAttribute("opacity", 0)
        }
        var i = $('.sl-scroll-anchor[href^="#"]');
        if (i.length) {
            var n,
            s,
            o = $(".sl-scroll-toc"),
            a = o.position().top,
            r = $(['<svg class="sl-scroll-toc-marker" width="200" height="200" xmlns="http://www.w3.org/2000/svg">', '<path stroke="#444" stroke-width="2" fill="transparent" stroke-dasharray="0, 0, 0, 1000" stroke-linecap="round" stroke-linejoin="round" />', "</svg>"].join("")).appendTo(o),
            l = r.find("path").get(0),
            d = .1,
            c = .2;
            $(window).on("resize", $.throttle(t.bind(this), 100)),
            $(window).on("scroll", $.throttle(e.bind(this), 100)),
            setTimeout(t, 1)
        }
    },
    handleLogos : function () {
        setTimeout(function () {
            $(".logo-animation").addClass("open")
        },
            600)
    },
    handleOutlines : function () {
        var t = $("<style>").appendTo("head").get(0),
        e = function (e) {
            t.styleSheet ? t.styleSheet.cssText = e : t.innerHTML = e
        };
        $(document).on("mousedown",
            function () {
            e("a, button, .sl-select, .sl-checkbox label, .radio label { outline: none !important; }")
        }),
        $(document).on("keydown",
            function () {
            e("")
        })
    },
    handleFeedback : function () {
        $("html").on("click", "[data-feedback-mode]",
            function (t) {
            if (UserVoice && "function" == typeof UserVoice.show) {
                var e = $(this),
                i = {
                    target : this,
                    mode : e.attr("data-feedback-mode") || "contact",
                    position : e.attr("data-feedback-position") || "top",
                    screenshot_enabled : e.attr("data-feedback-screenshot_enabled") || "true",
                    smartvote_enabled : e.attr("data-feedback-smartvote-enabled") || "true",
                    ticket_custom_fields : {}
                };
                SL.current_deck && (i.ticket_custom_fields["Deck ID"] = SL.current_deck.get("id"), i.ticket_custom_fields["Deck Slug"] = SL.current_deck.get("slug"), i.ticket_custom_fields["Deck Version"] = SL.current_deck.get("version"), i.ticket_custom_fields["Deck Font"] = SL.current_deck.get("theme_font"), i.ticket_custom_fields["Deck Color"] = SL.current_deck.get("theme_color"), i.ticket_custom_fields["Deck Transition"] = SL.current_deck.get("transition"), i.ticket_custom_fields["Deck Background Transition"] = SL.current_deck.get("backgroundTransition"));
                var n = e.attr("data-feedback-type");
                n && n.length && (i.ticket_custom_fields.Type = n);
                var s = e.attr("data-feedback-contact-title");
                s && s.length && (i.contact_title = s),
                UserVoice.show(i),
                t.preventDefault()
            }
        })
    },
    handleWindowClose : function () {
        var t = SL.util.getQuery();
        if (t && t.autoclose && window.opener) {
            var e = parseInt(t.autoclose, 10) || 0;
            setTimeout(function () {
                try {
                    window.close()
                } catch (t) {}
            },
                e)
        }
    },
    handleAutoRefresh : function () {
        var t = SL.util.getQuery();
        if (t && t.autoRefresh) {
            var e = parseInt(t.autoRefresh, 10);
            !isNaN(e) && e > 0 && setTimeout(function () {
                window.location.reload()
            },
                e)
        }
    },
    parseTimes : function () {
        $("time.ago").each(function () {
            var t = $(this).attr("datetime");
            t && $(this).text(moment.utc(t).fromNow())
        }),
        $("time.date").each(function () {
            var t = $(this).attr("datetime");
            t && $(this).text(moment.utc(t).format("MMM Do, YYYY"))
        })
    },
    parseLinks : function () {
        $(".linkify").each(function () {
            $(this).html(SL.util.string.linkify($(this).text()))
        })
    },
    parseMeters : function () {
        $(".sl-meter").each(function () {
            new SL.components.Meter($(this))
        })
    },
    parseSpinners : function () {
        SL.util.html.generateSpinners()
    },
    parseNotifications : function () {
        var t = $(".flash-notification");
        t.length && SL.notify(t.remove().text(), t.attr("data-notification-type"))
    },
    parseScrollLinks : function () {
        $(document).delegate("a[data-scroll-to]", "click",
            function (t) {
            var e = t.currentTarget,
            i = $(e.getAttribute("href")),
            n = parseInt(e.getAttribute("data-scroll-to-offset"), 10),
            s = parseInt(e.getAttribute("data-scroll-to-duration"), 10);
            isNaN(n) && (n = -20),
            isNaN(s) && (s = 1e3),
            i.length && $("html, body").animate({
                scrollTop : i.offset().top + n
            },
                s),
            t.preventDefault()
        })
    }
});