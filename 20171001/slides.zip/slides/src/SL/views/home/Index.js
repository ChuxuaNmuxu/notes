import SL from '../../SL';

SL("views.home").Index = SL.views.Base.extend({
    MARQUEE_MIN_HEIGHT : 600,
    init : function () {
        this._super(),
        this.learnMoreButton = $(".marquee .description-cta-secondary"),
        this.scrollPromotion = $(".marquee .scroll-promotion"),
        this.scrollPromotionArrow = $(".marquee .scroll-promotion-arrow"),
        this.setupVideo(),
        this.bind(),
        this.startScrollPromotion()
    },
    setupVideo : function () {
        (SL.util.device.IS_PHONE || SL.util.device.IS_TABLET) && ($(".media-item video").each(function () {
                $(this).prop("controls", !0)
            }), $(".features .media-item").each(function () {
                var t = $(this),
                e = t.find(".image-wrapper"),
                i = t.find(".video-wrapper");
                i.length && (i.appendTo(t), e.appendTo(t), t.addClass("manually-triggered"), t.find(".browser-frame").remove(), t.find(".browser-content").remove())
            })),
        $(".media-item video").each(function (t, e) {
            var i = "";
            e = $(e),
            SL.util.device.IS_PHONE || SL.util.device.IS_TABLET ? e.parents(".media-item").addClass("loaded") : e.on("loadeddata",
                function () {
                e.parents(".media-item").addClass("loaded")
            }),
            e.find("span[data-src]").each(function (t, e) {
                e = $(e),
                i += '<source src="' + e.attr("data-src") + '" type="' + e.attr("data-type") + '">'
            }),
            i && e.html(i)
        })
    },
    bind : function () {
        this.learnMoreButton.on("click", this.onLearnMoreClicked.bind(this)),
        this.scrollPromotion.on("click", this.onLearnMoreClicked.bind(this)),
        this.scrollPromotionArrow.on("mouseover", this.onScrollPromotionOver.bind(this)),
        this.syncScrolling = $.debounce(this.syncScrolling, 300),
        this.trackScrolling = $.throttle(this.trackScrolling, 500),
        $(window).on("resize", this.onWindowResize.bind(this)),
        $(window).on("scroll", this.onWindowScroll.bind(this))
    },
    trackScrolling : function () {
        this.scrollTracking = this.scrollTracking || {};
        var t = $(window).scrollTop(),
        e = window.innerHeight,
        i = $(document).height(),
        n = Math.max(Math.min(t / (i - e), 1), 0);
        n > .1 && !this.scrollTracking[.1] && (this.scrollTracking[.1] = !0, SL.analytics.track("Home: Scrolled", "10%")),
        n > .5 && !this.scrollTracking[.5] && (this.scrollTracking[.5] = !0, SL.analytics.track("Home: Scrolled", "50%")),
        n > .95 && !this.scrollTracking[.95] && (this.scrollTracking[.95] = !0, SL.analytics.track("Home: Scrolled", "100%"))
    },
    syncScrolling : function () {
        var t = $(window).scrollTop();
        if (!SL.util.device.IS_PHONE && !SL.util.device.IS_TABLET) {
            var e,
            i = Number.MAX_VALUE;
            $(".media-item .video-wrapper, .media-item .animation-wrapper").each(function (n, s) {
                s = $(s);
                var o = s.offset().top,
                a = o - t;
                a > -100 && 500 > a && i > a && (i = a, e = s)
            }),
            this.activeFeature && !this.activeFeature.is(e) && this.stopFeatureAnimation(),
            e && !e.hasClass("playing") && (this.activeFeature = e, this.startFeatureAnimation())
        }
        t > 20 && this.scrollPromotion.addClass("hidden")
    },
    startFeatureAnimation : function () {
        if (this.activeFeature.addClass("playing"), this.activeFeature.is(".video-wrapper"))
            this.activeFeature.find("video").get(0).play();
        else if (this.activeFeature.is(".animation-wrapper")) {
            var t = parseInt(this.activeFeature.attr("data-animation-steps"), 10),
            e = parseInt(this.activeFeature.attr("data-animation-duration"), 10),
            i = 1;
            this.activeFeature.attr("data-animation-step", i),
            this.activeFeatureInterval = setInterval(function () {
                    i += 1,
                    i = i > t ? 1 : i,
                    this.activeFeature.attr("data-animation-step", i)
                }
                    .bind(this), e / t)
        }
        SL.analytics.track("Home: Start feature animation")
    },
    stopFeatureAnimation : function () {
        this.activeFeature.removeClass("playing"),
        this.activeFeature.removeAttr("data-animation-step"),
        clearInterval(this.activeFeatureInterval),
        this.activeFeature.is(".video-wrapper") && this.activeFeature.find("video").get(0).pause()
    },
    startScrollPromotion : function () {
        clearInterval(this.scrollPromotionInterval),
        this.scrollPromotionInterval = setInterval(this.promoteScrolling.bind(this), 2500)
    },
    stopScrollPromotion : function () {
        clearInterval(this.scrollPromotionInterval),
        this.scrollPromotionInterval = null
    },
    promoteScrolling : function () {
        this.scrollPromotionArrow.removeClass("bounce"),
        setTimeout(function () {
            this.scrollPromotionArrow.addClass("bounce")
        }
            .bind(this), 1)
    },
    onScrollPromotionOver : function () {
        this.stopScrollPromotion()
    },
    onLearnMoreClicked : function () {
        SL.analytics.track("Home: Learn more clicked"),
        this.stopScrollPromotion()
    },
    onWindowResize : function () {
        this.syncScrolling()
    },
    onWindowScroll : function () {
        this.scrollPromotionInterval && this.stopScrollPromotion(),
        this.syncScrolling(),
        this.trackScrolling()
    }
});