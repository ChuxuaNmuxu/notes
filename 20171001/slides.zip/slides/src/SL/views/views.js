import SL from '../SL';

import './Base';
import './decks/EditRequiresUpgrade';
import './decks/Embed';
import './decks/Export';
import './decks/Fullscreen';
import './decks/LiveClient';
import './decks/LiveServer';
import './decks/Password';
import './decks/Review';
import './decks/Show';
import './decks/Speaker';

import './devise/All';
import './devise/Edit';

import './home/Explore';
import './home/Index';

import './statik/All';
import './statik/Pricing';

import './subscriptions/EditPeriod';
import './subscriptions/New';
import './subscriptions/Show';

import './teams/New';
import './teams/subscriptions/Reactivate';
import './teams/subscriptions/Show';
import './teams/teams/Edit';
import './teams/teams/EditMembers';
import './teams/teams/Show';

import './themes/Edit';
import './themes/edit/Panel';
import './themes/edit/GlobalCSSPanel';
import './themes/edit/pages/CSS';
import './themes/edit/pages/HTML';
import './themes/edit/pages/JS';
import './themes/edit/pages/Palette';
import './themes/edit/pages/Snippets';
import './themes/Preview';

import './users/Show';