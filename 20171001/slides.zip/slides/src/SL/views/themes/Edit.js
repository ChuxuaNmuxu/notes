import SL from '../../SL';

SL("views.themes").Edit = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.themeData = new SL.collections.Collection,
        this.listElement = $(".theme-list"),
        this.editorElement = $(".theme-editor"),
        this.editorInnerElement = $(".theme-editor-inner"),
        this.VERSION = parseInt($(".theme-editor").attr("data-editor-version"), 10),
        this.load(),
        this.bindLadda(),
        this.setupPreview(),
        $("body").on("click", ".global-css-button", this.onGlobalCSSClicked.bind(this)),
        $("body").on("click", ".create-theme-button", this.onCreateThemeClicked.bind(this)),
        $(window).on("beforeunload", this.onWindowBeforeUnload.bind(this)),
        hljs.initHighlightingOnLoad()
    },
    bindLadda : function () {
        $(".page-wrapper .ladda-button").each(function (t, e) {
            e = $(e),
            e.data("ladda") || e.data("ladda", Ladda.create(e.get(0)))
        })
    },
    setupPreview : function () {
        this.previewFrame = $(".preview .preview-frame"),
        this.previewReloader = $(".preview .preview-reloader"),
        this.previewReloader.on("click", this.reloadPreview.bind(this)),
        window.addEventListener("message",
            function (t) {
            t.data && "theme-preview-ready" === t.data.type && this.refreshPreview()
        }
            .bind(this))
    },
    load : function () {
        SL.helpers.PageLoader.show({
            message : "Loading themes"
        }),
        $.ajax({
            type : "GET",
            url : SL.config.AJAX_THEMES_LIST,
            context : this
        }).done(function (t) {
            this.themeData.clear(),
            t.results.forEach(function (t) {
                this.themeData.push(new SL.models.Theme(t))
            }
                .bind(this))
        }).fail(function () {
            SL.notify(SL.locale.get("THEME_LIST_LOAD_ERROR"), "negative")
        }).always(function () {
            this.renderList(),
            SL.helpers.PageLoader.hide()
        })
    },
    renderList : function () {
        this.listElement.empty(),
        this.themeData.isEmpty() ? this.listElement.html('<p class="theme-list-empty">' + SL.locale.get("THEME_LIST_EMPTY") + "</p>") : (this.themeData.forEach(this.renderListItem.bind(this)), SL.view.parseTimes()),
        this.updateListDefault()
    },
    renderListItem : function (t, e) {
        e = $.extend({
                prepend : !1,
                showDelay : 0
            },
                e);
        var i = this.listElement.find('[data-theme-id="' + t.get("id") + '"]');
        if (i.length ? i.find(".theme-list-item-title").text(t.get("name")).attr("title", t.get("name")) : (i = $(['<div class="theme-list-item" data-theme-id="' + t.get("id") + '">', '<div class="theme-list-item-thumbnail"></div>', '<h2 class="theme-list-item-title" title="' + t.get("name") + '">' + t.get("name") + "</h2>", '<div class="theme-list-item-metadata">', '<div class="theme-list-item-metadata-field">Created <time class="date" datetime="' + t.get("created_at") + '"></time></div>', '<div class="theme-list-item-metadata-field">Updated <time class="ago" datetime="' + t.get("updated_at") + '"></time></div>', "</div>", '<div class="theme-list-item-controls">', '<button class="button outline l delete" data-tooltip="' + SL.locale.get("THEME_DELETE_TOOLTIP") + '">', '<span class="icon i-trash-stroke"></span>', "</button>", '<button class="button outline l edit" data-tooltip="' + SL.locale.get("THEME_EDIT_TOOLTIP") + '">', '<span class="icon i-pen-alt2"></span>', "</button>", '<button class="button outline l default" data-tooltip="' + SL.locale.get("THEME_MAKE_DEFAULT_TOOLTIP") + '">', '<span class="icon i-checkmark"></span>', "</button>", "</div>", "</div>"].join("")), e.prepend === !0 ? i.prependTo(this.listElement) : i.appendTo(this.listElement), e.showDelay > 0 && (i.hide(), setTimeout(function () {
                        i.show()
                    },
                        e.showDelay))), t.hasThumbnail()) {
            var n = t.get("thumbnail_url");
            i.find(".theme-list-item-thumbnail").css("background-image", 'url("' + n + '")').attr("data-thumb-url", n)
        }
        return i.off("click").on("click",
            function (e) {
            $(e.target).closest(".theme-list-item-controls .delete").length ? this.removeTheme(t, null, $(e.target).closest(".theme-list-item-controls .delete")) : $(e.target).closest(".theme-list-item-controls .default").length ? i.hasClass("default") ? this.unmakeDefaultTheme() : this.makeDefaultTheme(t) : this.editTheme(t)
        }
            .bind(this)),
        i
    },
    refreshListItemThumb : function (t) {
        if (t && t.length) {
            var e = t.find(".theme-list-item-thumbnail"),
            i = e.attr("data-thumb-url");
            i && (i = i + "?" + Math.round(1e4 * Math.random()), e.css("background-image", 'url("' + i + '")'))
        }
    },
    updateListDefault : function () {
        this.listElement.find(".theme-list-item").each(function (t, e) {
            e = $(e),
            e.toggleClass("default", e.attr("data-theme-id") == SL.current_team.get("default_theme_id")),
            e.find(".theme-list-item-controls .default").attr("data-tooltip", SL.locale.get(e.hasClass("default") ? "THEME_IS_DEFAULT_TOOLTIP" : "THEME_MAKE_DEFAULT_TOOLTIP"))
        })
    },
    editTheme : function (t) {
        if (this.panel)
            return this.panel.close(this.editTheme.bind(this, t)),
            !1;
        $("html").addClass("is-editing-theme");
        var e = {};
        e = 1 === this.VERSION ? {
            colors : SL.config.V1.THEME_COLORS,
            fonts : SL.config.V1.THEME_FONTS,
            center : !0,
            rollingLinks : !0
        }
            : {
            colors : SL.config.THEME_COLORS,
            fonts : SL.config.THEME_FONTS,
            center : !1,
            rollingLinks : !1
        },
        this.panel = new SL.views.themes.edit.Panel(this, t, e),
        this.panel.destroyed.add(function () {
            $("html").removeClass("is-editing-theme"),
            this.panel = null
        }
            .bind(this)),
        this.bindLadda()
    },
    createTheme : function () {
        $.ajax({
            type : "POST",
            url : SL.config.AJAX_THEMES_CREATE,
            data : {
                theme : {
                    font : SL.config.DEFAULT_THEME_FONT,
                    color : SL.config.DEFAULT_THEME_COLOR,
                    transition : SL.config.DEFAULT_THEME_TRANSITION,
                    background_transition : SL.config.DEFAULT_THEME_BACKGROUND_TRANSITION
                }
            },
            context : this
        }).done(function (t) {
            var e = new SL.models.Theme(t);
            this.themeData.isEmpty() ? (this.themeData.push(e), this.renderList(), this.makeDefaultTheme(e, null, !0)) : (this.themeData.push(e), this.renderListItem(e, {
                    prepend : !0,
                    showDelay : 3e3
                }), SL.view.parseTimes()),
            this.editTheme(e)
        }).fail(function () {
            SL.notify(SL.locale.get("THEME_CREATE_ERROR"), "negative")
        })
    },
    saveTheme : function (t, e, i) {
        $.ajax({
            type : "PUT",
            url : SL.config.AJAX_THEMES_UPDATE(t.get("id")),
            data : {
                theme : t.toJSON()
            },
            context : this
        }).done(function (t) {
            var i = this.renderListItem(new SL.models.Theme(t));
            SL.view.parseTimes(),
            t && t.sanitize_messages && t.sanitize_messages.length ? SL.notify(t.sanitize_messages[0], "negative") : SL.notify(SL.locale.get("THEME_SAVE_SUCCESS")),
            SL.util.callback(e),
            setTimeout(function () {
                this.refreshListItemThumb(i)
            }
                .bind(this), 2500),
            setTimeout(function () {
                this.refreshListItemThumb(i)
            }
                .bind(this), 5e3)
        }).fail(function () {
            SL.notify(SL.locale.get("THEME_SAVE_ERROR"), "negative"),
            SL.util.callback(i)
        })
    },
    removeTheme : function (t, e, i) {
        var n = this.getListItem(t);
        SL.prompt({
            anchor : i,
            title : SL.locale.get("THEME_REMOVE_CONFIRM"),
            type : "select",
            offsetX : 15,
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Delete</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        var i = t.get("id");
                        $.ajax({
                            type : "DELETE",
                            url : SL.config.AJAX_THEMES_DELETE(i),
                            context : this
                        }).done(function () {
                            SL.util.anim.collapseListItem(n,
                                function () {
                                n.remove()
                            }),
                            SL.util.callback(e),
                            this.themeData.removeByProperties({
                                id : i
                            }),
                            this.panel && this.panel.getTheme().get("id") === i && this.panel.destroy(),
                            SL.notify(SL.locale.get("THEME_REMOVE_SUCCESS"))
                        }).fail(function () {
                            SL.notify(SL.locale.get("THEME_REMOVE_ERROR"), "negative")
                        })
                    }
                    .bind(this)
                }
            ]
        })
    },
    makeDefaultTheme : function (t, e, i) {
        $.ajax({
            type : "PUT",
            url : SL.config.AJAX_UPDATE_TEAM,
            data : {
                team : {
                    default_theme_id : t.get("id")
                }
            },
            context : this
        }).done(function () {
            SL.current_team.set("default_theme_id", t.get("id")),
            this.updateListDefault(),
            i || SL.notify(SL.locale.get("THEME_DEFAULT_SAVE_SUCCESS")),
            SL.util.callback(e)
        }).fail(function () {
            i || SL.notify(SL.locale.get("THEME_DEFAULT_SAVE_ERROR"), "negative")
        })
    },
    unmakeDefaultTheme : function (t, e) {
        $.ajax({
            type : "PUT",
            url : SL.config.AJAX_UPDATE_TEAM,
            data : {
                team : {
                    default_theme_id : null
                }
            },
            context : this
        }).done(function () {
            SL.current_team.set("default_theme_id", null),
            this.updateListDefault(),
            e || SL.notify(SL.locale.get("THEME_DEFAULT_SAVE_SUCCESS")),
            SL.util.callback(t)
        }).fail(function () {
            e || SL.notify(SL.locale.get("THEME_DEFAULT_SAVE_ERROR"), "negative")
        })
    },
    getListItem : function (t) {
        return this.listElement.find('[data-theme-id="' + (t ? t.get("id") : null) + '"]')
    },
    refreshPreview : function (t, e) {
        t = t || this.previewTheme,
        t || (t = new SL.models.Theme),
        "undefined" == typeof e && (e = SL.current_team.get("global_css_output"));
        var i = this.getPreviewWindow();
        i && t && (i.SL && i.SL.helpers && i.SL.helpers.ThemeController.paint(t, {
                center : 1 === this.VERSION,
                globalCSS : e
            }), t.has("font_typekit") && i.SL.fonts.loadTypekitFont(t.get("font_typekit")), t.has("font_google") && i.SL.fonts.loadGoogleFont(t.get("font_google")), this.previewTheme = t)
    },
    reloadPreview : function () {
        var t = this.getPreviewWindow();
        t && t.location.reload()
    },
    getPreviewWindow : function () {
        return this.previewFrame.length ? this.previewFrame.get(0).contentWindow : null
    },
    onWindowBeforeUnload : function () {
        return this.panel && this.panel.hasUnsavedChanges() ? SL.locale.get("LEAVE_UNSAVED_THEME") : void 0
    },
    onCreateThemeClicked : function (t) {
        t.preventDefault(),
        this.createTheme()
    },
    onGlobalCSSClicked : function () {
        return this.panel ? (this.panel.close(this.editTheme.bind(this, theme)), !1) : ($("html").addClass("is-editing-theme"), this.panel = new SL.views.themes.edit.GlobalCSSPanel(this, SL.current_team), this.panel.destroyed.add(function () {
                $("html").removeClass("is-editing-theme"),
                this.panel = null
            }
                .bind(this)), void this.bindLadda())
    }
});