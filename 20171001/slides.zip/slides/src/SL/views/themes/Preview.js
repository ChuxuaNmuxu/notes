import SL from '../../SL';

SL("views.themes").Preview = SL.views.Base.extend({
    init : function () {
        this._super(),
        SL.util.setupReveal({
            openLinksInTabs : !0
        }),
        window.parent !== window.self && window.parent.postMessage({
            type : "theme-preview-ready"
        },
            window.location.origin)
    }
});