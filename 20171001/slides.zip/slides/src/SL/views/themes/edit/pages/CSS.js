import SL from '../../../../SL';

SL("views.themes.edit.pages").CSS = Class.extend({
    init : function (t, e, i) {
        this.config = $.extend({
                customClasses : !0,
                title : "CSS",
                description : "Specify custom styles using LESS or standard CSS. All selectors are automatically prefixed with .reveal when saved.",
                setInput : function (t) {
                    this.theme.set("less", t)
                }
                .bind(this),
                getInput : function () {
                    return this.theme.get("less")
                }
                .bind(this),
                setOutput : function (t) {
                    this.theme.set("css", t)
                }
                .bind(this),
                getOutput : function () {
                    return this.theme.get("css")
                }
                .bind(this)
            },
                i),
        this.panel = t,
        this.theme = e,
        this.changed = new signals.Signal,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="page" data-page-id="css">'),
        this.domElement.html(['<div class="page-header page-header-absolute">', "<h4>" + this.config.title + "</h4>", "<p>" + this.config.description + "</p>", '<div class="header-buttons">', '<button class="button outline documentation-link">More info</button>', '<button class="button outline float-right insert-image hide-from-global-css" data-tooltip="Insert image URL"><span class="icon i-picture"></span></button>', '<button class="button outline float-right custom-fonts hide-from-global-css" data-tooltip="Load custom fonts"><span class="icon i-type"></span></button>', "</div>", '<div class="documentation">', $("#css-panel-documentation").html(), "</div>", "</div>", '<div class="editor-wrapper">', '<div id="ace-less" class="editor"></div>', '<div class="error"></div>', '<div class="info positive" data-tooltip="" data-tooltip-maxwidth="300" data-tooltip-align="left"><span class="icon i-info"></span></div>', "</div>"].join("")),
        this.insertImageButton = this.domElement.find(".insert-image"),
        this.customFontsButton = this.domElement.find(".custom-fonts"),
        this.errorElement = this.domElement.find(".error"),
        this.domElement.find(".info").hide()
    },
    setupAce : function () {
        if (!this.ace)
            try {
                this.ace = ace.edit("ace-less"),
                SL.util.setAceEditorDefaults(this.ace),
                this.ace.getSession().setMode("ace/mode/less"),
                this.ace.getSession().setValue(this.config.getInput() || ""),
                this.ace.getSession().on("change", this.onInputChanged.bind(this)),
                this.sync()
            } catch (t) {
                console.log("An error occurred while initializing the Ace CSS editor.")
            }
    },
    bind : function () {
        this.insertImageButton.on("click", this.onInsertImageClicked.bind(this)),
        this.customFontsButton.on("click", this.onCustomFontsClicked.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.setupAce()
    },
    focus : function () {
        this.ace.focus()
    },
    sync : function () {
        var t = SL.util.string.getCustomClassesFromLESS(this.ace.getSession().getValue());
        if (t.length && this.config.customClasses) {
            var e = "Found custom slide classes:<br>- " + t.join("<br>- ");
            this.domElement.find(".info").attr("data-tooltip", e).show()
        } else
            this.domElement.find(".info").attr("data-tooltip", "").hide()
    },
    preprocess : function () {
        return this.lessParser || (this.lessParser = new less.Parser),
        new Promise(function (t, e) {
            var i = this.getValue();
            i ? this.lessParser.parse(".reveal { " + i + " }",
                function (n, s) {
                if (n)
                    this.errorElement.addClass("visible"),
                    this.errorElement.html(n.message),
                    e(n);
                else {
                    this.errorElement.removeClass("visible");
                    try {
                        var o = s.toCSS()
                    } catch (a) {
                        console.log(a)
                    }
                    if (o) {
                        var r = "";
                        o = o.replace(/@import url\(["'\s]*(http:|https:)?\/\/(.*)\);?/gi,
                                function (t) {
                                return r += t + "\n",
                                ""
                            }),
                        o = r + o,
                        this.config.setInput(i),
                        this.config.setOutput(o),
                        t()
                    } else
                        e()
                }
                this.changed && this.changed.dispatch()
            }
                .bind(this)) : (this.config.setInput(""), this.config.setOutput(""), t())
        }
            .bind(this))
    },
    persist : function () {
        return this.preprocess()
    },
    getValue : function () {
        return this.ace ? this.ace.getSession().getValue() : ""
    },
    destroy : function () {
        this.changed && (this.changed.dispose(), this.changed = null),
        this.ace && (this.ace.destroy(), this.ace = null),
        this.panel = null,
        this.theme = null
    },
    onInputChanged : function () {
        this.sync(),
        this.panel.updatePreview()
    },
    onInsertImageClicked : function () {
        var t = SL.popup.open(SL.components.medialibrary.MediaLibrary, {
                select : SL.models.Media.IMAGE
            });
        t.selected.addOnce(function (t) {
            t.isUploaded() ? (this.ace.insert(t.get("url")), this.focus()) : t.uploadCompleted.add(function () {
                this.ace.insert(t.get("url"))
            }
                .bind(this))
        }
            .bind(this))
    },
    onCustomFontsClicked : function () {
        var t = SL.popup.openOne(SL.components.popup.CustomFonts, {
                theme : this.theme
            });
        t.closed.addOnce(function () {
            this.panel.updatePreview(),
            this.changed.dispatch()
        }
            .bind(this))
    }
});