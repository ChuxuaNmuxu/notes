import SL from '../../../../SL';

SL("views.themes.edit.pages").HTML = Class.extend({
    init : function (t, e) {
        this.panel = t,
        this.theme = e,
        this.changed = new signals.Signal,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="page" data-page-id="html">'),
        this.domElement.html(['<div class="page-header page-header-absolute">', "<h4>HTML</h4>", "<p>Markup is inserted outside of individual slides. This is great for things like a company logo which is fixed on top of the presentation.</p>", '<div class="header-buttons">', '<button class="button outline documentation-link">More info</button>', '<button class="button outline float-right insert-image" data-tooltip="Insert image URL"><span class="icon i-picture"></span></button>', "</div>", '<div class="documentation">', $("#html-panel-documentation").html(), "</div>", "</div>", '<div class="editor-wrapper">', '<div id="ace-html" class="editor"></div>', "</div>"].join("")),
        this.insertImageButton = this.domElement.find(".insert-image")
    },
    setupAce : function () {
        if (!this.ace)
            try {
                this.ace = ace.edit("ace-html"),
                SL.util.setAceEditorDefaults(this.ace),
                this.ace.getSession().setMode("ace/mode/html"),
                this.ace.getSession().setValue(this.theme.get("html") || ""),
                this.ace.getSession().on("change", this.onInputChanged.bind(this))
            } catch (t) {
                console.log("An error occurred while initializing the Ace HTML editor.")
            }
    },
    bind : function () {
        this.insertImageButton.on("click", this.onInsertImageClicked.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.setupAce()
    },
    focus : function () {
        this.ace.focus()
    },
    persist : function () {
        return this.theme.set("html", this.getValue()),
        Promise.resolve()
    },
    getValue : function () {
        return this.ace ? this.ace.getSession().getValue() : ""
    },
    destroy : function () {
        this.changed.dispose(),
        this.ace && (this.ace.destroy(), this.ace = null),
        this.panel = null,
        this.theme = null
    },
    onInputChanged : function () {
        this.panel.updatePreview()
    },
    onInsertImageClicked : function () {
        var t = SL.popup.open(SL.components.medialibrary.MediaLibrary, {
                select : SL.models.Media.IMAGE
            });
        t.selected.addOnce(function (t) {
            t.isUploaded() ? (this.ace.insert(t.get("url")), this.focus()) : t.uploadCompleted.add(function () {
                this.ace.insert(t.get("url"))
            }
                .bind(this))
        }
            .bind(this))
    }
});