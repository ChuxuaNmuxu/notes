import SL from '../../../../SL';

SL("views.themes.edit.pages").Palette = Class.extend({
    init : function (t, e) {
        this.panel = t,
        this.theme = e,
        this.changed = new signals.Signal,
        this.onDocumentMouseUp = this.onDocumentMouseUp.bind(this),
        this.onDocumentMouseMove = this.onDocumentMouseMove.bind(this),
        this.onSaveButtonClicked = this.onSaveButtonClicked.bind(this),
        this.onListItemDelete = this.onListItemDelete.bind(this),
        this.onListItemMouseDown = this.onListItemMouseDown.bind(this),
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="page" data-page-id="palette">'),
        this.domElement.html(['<div class="page-header">', "<h4>Color Palette</h4>", "<p>Replace the default color options that we offer throughout the deck editor with your own custom color palette.</p>", '<div class="header-buttons">', '<button class="button outline documentation-link">More info</button>', "</div>", '<div class="documentation">', $("#palette-panel-documentation").html(), "</div>", "</div>", '<div class="page-body">', '<div class="palette-picker">', '<div class="palette-picker-api"></div>', "</div>", '<ul class="palette-list"></ul>', "</div>"].join("")),
        this.innerElement = this.domElement.find(".page-body"),
        this.pickerElement = this.domElement.find(".palette-picker"),
        this.pickerAPIElement = this.domElement.find(".palette-picker-api"),
        this.listElement = this.domElement.find(".palette-list"),
        this.renderPicker(),
        this.renderList(),
        this.checkIfEmpty()
    },
    renderPicker : function () {
        this.pickerAPIElement.spectrum({
            flat : !0,
            showInput : !0,
            showButtons : !1,
            showInitial : !1,
            showPalette : !1,
            showSelectionPalette : !1,
            preferredFormat : "hex",
            className : "palette-picker-spectrum",
            move : function (t) {
                this.setPreviewColor(t.toHexString())
            }
            .bind(this),
            change : function (t) {
                this.setPreviewColor(t.toHexString())
            }
            .bind(this)
        }),
        this.domElement.find(".palette-picker-spectrum .sp-input-container").append('<div class="palette-picker-save-button"><span class="icon i-plus"></span>Save color</div>'),
        this.pickerSaveButton = this.domElement.find(".palette-picker-save-button")
    },
    renderList : function () {
        this.listElement.empty(),
        this.theme.get("palette").forEach(this.renderListItem.bind(this))
    },
    renderListItem : function (t) {
        var e = $('<li class="palette-list-item sl-form">');
        return e.data("color", t),
        e.html(['<div class="palette-list-item-color"></div>', '<div class="palette-list-item-label">' + t + "</div>", '<div class="palette-list-item-delete"><span class="icon i-trash-stroke"></span></div>'].join("")),
        e.appendTo(this.listElement),
        e.toggleClass("is-light", tinycolor(t).isLight()),
        e.find(".palette-list-item-color").css("background-color", t),
        e.find(".palette-list-item-delete").on("click", this.onListItemDelete),
        e.on("mousedown", this.onListItemMouseDown),
        e
    },
    bind : function () {
        this.pickerSaveButton.on("click", this.onSaveButtonClicked.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    setPreviewColor : function (t) {
        this.pickerSaveButton.css({
            color : tinycolor(t).isLight() ? "#222222" : "#ffffff",
            backgroundColor : t
        })
    },
    checkIfEmpty : function () {
        0 === this.listElement.find(".palette-list-item").length ? this.listElement.append('<span class="palette-list-empty">No custom colors have been added to the palette. Click "Save color" to add one now.</span>') : this.listElement.find(".palette-list-empty").remove()
    },
    refresh : function () {
        this.pickerAPIElement.spectrum("set", "#000000"),
        this.pickerAPIElement.spectrum("reflow"),
        this.setPreviewColor("#000000")
    },
    persist : function () {
        var t = this.listElement.find(".palette-list-item:not(.element)").map(function () {
                return $(this).data("color")
            }).toArray();
        this.theme.set("palette", t),
        this.checkIfEmpty(),
        this.changed.dispatch()
    },
    destroy : function () {
        this.changed.dispose(),
        this.listElement.find(".palette-list-item").off(),
        this.panel = null,
        this.theme = null
    },
    onSaveButtonClicked : function () {
        var t = this.renderListItem(this.pickerAPIElement.spectrum("get"));
        this.listElement.prepend(t),
        this.persist()
    },
    onListItemDelete : function (t) {
        var e = $(t.target).closest(".palette-list-item");
        e.length ? (e.remove(), this.persist()) : SL.notify("An error occured while deleting this color")
    },
    onListItemMouseDown : function (t) {
        var e = $(t.currentTarget);
        e.length && e.is(".palette-list-item") && 0 === $(t.target).closest(".palette-list-item-delete").length && (this.dragTarget = e, this.dragGhost = e.clone().appendTo(this.listElement), this.dragGhost.addClass("drag-ghost"), this.dragTarget.addClass("drag-target"), this.dragOffsetX = t.clientX - this.dragTarget.offset().left, this.dragOffsetY = t.clientY - this.dragTarget.offset().top, this.listOffsetX = this.listElement.offset().left, this.listOffsetY = this.listElement.offset().top, this.listWidth = this.listElement.width(), this.listHeight = this.listElement.height(), this.listItemSize = this.dragTarget.outerHeight(), this.listItemCols = Math.floor(this.listWidth / this.listItemSize), $(document).on("mousemove", this.onDocumentMouseMove), $(document).on("mouseup", this.onDocumentMouseUp), this.onDocumentMouseMove(t))
    },
    onDocumentMouseMove : function (t) {
        t.preventDefault();
        var e = this.listElement.find(".palette-list-item"),
        i = t.clientX - this.listOffsetX - this.dragOffsetX,
        n = t.clientY - this.listOffsetY - this.dragOffsetY;
        i = Math.max(Math.min(i, this.listWidth - this.listItemSize), 0),
        n = Math.max(Math.min(n, this.listHeight - this.listItemSize), 0),
        this.dragGhost.css({
            left : i,
            top : n
        });
        var s = Math.round(i / this.listItemSize),
        o = Math.round(n / this.listItemSize);
        s = Math.max(Math.min(s, this.listItemCols), 0),
        o = Math.max(Math.min(o, e.length), 0);
        var a = o * this.listItemCols + s,
        r = $(e[a]);
        r.is(this.dragTarget) || (this.dragTarget.index() > a ? r.before(this.dragTarget) : r.after(this.dragTarget))
    },
    onDocumentMouseUp : function () {
        this.dragTarget.removeClass("drag-target"),
        this.dragGhost.remove(),
        $(document).off("mousemove", this.onDocumentMouseMove),
        $(document).off("mouseup", this.onDocumentMouseUp),
        this.persist()
    }
});