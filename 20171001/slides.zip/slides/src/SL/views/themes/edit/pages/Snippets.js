import SL from '../../../../SL';

SL("views.themes.edit.pages").Snippets = Class.extend({
    init : function (t, e) {
        this.panel = t,
        this.theme = e,
        this.changed = new signals.Signal,
        this.render(),
        this.bind(),
        this.syncMoveButtons()
    },
    render : function () {
        this.domElement = $('<div class="page" data-page-id="snippets">'),
        this.domElement.html(['<div class="page-header">', "<h4>Snippets</h4>", "<p>Snippets are small HTML templates that your team members can use as building blocks when creating decks. These templates can contain placeholder variables that are filled out at the time of insertion.</p>", '<div class="header-buttons">', '<button class="button outline documentation-link">More info</button>', "</div>", '<div class="documentation">', $("#snippet-panel-documentation").html(), "</div>", "</div>", '<div class="page-body">', '<ul class="snippet-list"></ul>', '<ul class="snippet-controls snippet-list-item sl-form">', '<div class="add-button-wrapper">', '<button class="button l add-button">Add Snippet <span class="icon i-plus"></span></button>', "</div>", '<div class="unit text">', "<label>Title</label>", '<input class="title-value" maxlength="200" type="text" readonly>', "</div>", '<div class="unit text">', "<label>Template</label>", '<textarea class="template-value" rows="4" readonly></textarea>', "</div>", "</ul>", "</div>"].join("")),
        this.innerElement = this.domElement.find(".page-body"),
        this.listElement = this.domElement.find(".snippet-list"),
        this.controlsElement = this.domElement.find(".snippet-controls"),
        this.addButton = this.domElement.find(".snippet-controls .add-button-wrapper"),
        this.renderList()
    },
    renderList : function () {
        this.listElement.empty(),
        this.theme.get("snippets").forEach(this.renderListItem.bind(this))
    },
    renderListItem : function (t) {
        var e = $('<li class="snippet-list-item sl-form">');
        return e.html(['<div class="unit text">', "<label>Title</label>", '<input class="title-value" maxlength="200" value="' + t.get("title") + '" type="text" spellcheck="false">', "</div>", '<div class="unit text">', "<label>Template</label>", '<textarea class="template-value" rows="4" spellcheck="false">' + t.get("template") + "</textarea>", '<div class="status" data-tooltip="" data-tooltip-maxwidth="400" data-tooltip-align="left"><span class="icon i-info"></span></div>', "</div>", '<div class="snippet-list-item-footer">', '<button class="button outline delete-button" data-tooltip="Delete" data-tooltip-delay="1000"><snap class="icon i-trash-stroke"></snap></button>', '<button class="button outline preview-button" data-tooltip="Preview" data-tooltip-delay="1000"><snap class="icon i-eye"></snap></button>', '<button class="button outline move-up-button" data-tooltip="Move Up" data-tooltip-delay="1000"><snap class="icon i-arrow-up"></snap></button>', '<button class="button outline move-down-button" data-tooltip="Move Down" data-tooltip-delay="1000"><snap class="icon i-arrow-down"></snap></button>', "</div>"].join("")),
        e.appendTo(this.listElement),
        e.data("model", t),
        e.find("input, textarea").on("input", this.onSnippetChange.bind(this)),
        e.find("input, textarea").on("focus", this.onSnippetFocused.bind(this)),
        e.find(".delete-button").on("click", this.onSnippetDelete.bind(this)),
        e.find(".preview-button").on("click", this.onSnippetFocused.bind(this)),
        e.find(".move-up-button").on("click", this.onSnippetMoveUp.bind(this)),
        e.find(".move-down-button").on("click", this.onSnippetMoveDown.bind(this)),
        this.validateSnippet(e),
        e
    },
    bind : function () {
        this.addButton.on("click", this.addSnippet.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.listElement.find(".snippet-list-item").each(function (t, e) {
            this.layoutSnippet($(e))
        }
            .bind(this))
    },
    addSnippet : function () {
        this.theme.get("snippets").create().then(function (t) {
            var e = this.renderListItem(t);
            e.data("model", t),
            e.find("input").first().focus(),
            setTimeout(function () {
                var t = this.domElement.prop("scrollHeight");
                t -= this.domElement.outerHeight(!0),
                t -= this.controlsElement.outerHeight(!0),
                this.domElement.scrollTop(t)
            }
                .bind(this), 1),
            this.changed.dispatch(),
            this.syncMoveButtons()
        }
            .bind(this))
    },
    layoutSnippet : function (t) {
        var e = t.find(".template-value");
        e.attr("rows", 4);
        var i = parseFloat(e.css("line-height")),
        n = e.prop("scrollHeight"),
        s = e.prop("clientHeight");
        n > s && e.attr("rows", Math.min(Math.ceil(n / i), 10))
    },
    validateSnippet : function (t) {
        var e = t.data("model"),
        i = [],
        n = [],
        s = e.templateHasVariables(),
        o = e.templateHasSelection();
        if (s && o)
            n.push("Templates can not mix variables and selection tags.");
        else if (s) {
            var a = e.getTemplateVariables();
            i.push("Found " + a.length + " variables:"),
            a.forEach(function (t) {
                i.push(t.defaultValue ? "- " + t.label + " (default: " + t.defaultValue + ")" : "- " + t.label)
            })
        }
        n.length ? t.find(".status").addClass("negative").show().attr("data-tooltip", n.join("<br>")) : i.length ? t.find(".status").removeClass("negative").show().attr("data-tooltip", i.join("<br>")) : t.find(".status").removeClass("negative").hide()
    },
    previewSnippet : function (t) {
        var e = this.panel.editor.getPreviewWindow(),
        i = e.$("#snippet-slide");
        0 === i.length && (i = $('<section id="snippet-slide">').appendTo(e.$(".reveal .slides"))),
        i.html(['<div class="sl-block" data-block-type="html" style="width: 100%; left: 0; top: 0; height: auto;">', '<div class="sl-block-content">', t.templatize(t.getTemplateVariables()), "</div>", "</div>"].join("")),
        e.SL.util.skipCSSTransitions(),
        e.Reveal.sync(),
        e.Reveal.slide(i.index())
    },
    syncSnippetOrder : function () {
        var t = this.listElement.find(".snippet-list-item"),
        e = this.theme.get("snippets");
        t.sort(function (t, i) {
            var n = e.find($(t).data("model")),
            s = e.find($(i).data("model"));
            return n - s
        }
            .bind(this)),
        t.each(function (t, e) {
            this.listElement.append(e)
        }
            .bind(this)),
        this.syncMoveButtons()
    },
    syncMoveButtons : function () {
        this.listElement.find(".snippet-list-item").each(function (t, e) {
            e = $(e),
            e.find(".move-up-button").toggleClass("disabled", e.is(":first-child")),
            e.find(".move-down-button").toggleClass("disabled", e.is(":last-child"))
        })
    },
    destroy : function () {
        this.changed.dispose(),
        this.listElement.find(".snippet-list-item").off().removeData("model");
        var t = this.panel.editor.getPreviewWindow();
        t.$("#snippet-slide").remove(),
        t.Reveal.sync(),
        t.Reveal.slide(0),
        this.panel = null,
        this.theme = null
    },
    onSnippetFocused : function (t) {
        var e = $(t.target).closest(".snippet-list-item");
        e.length && this.previewSnippet(e.data("model"))
    },
    onSnippetChange : function (t) {
        var e = $(t.target).closest(".snippet-list-item");
        if (e.length) {
            var i = e.find(".title-value").val(),
            n = e.find(".template-value").val(),
            s = SL.util.html.findScriptTags(n);
            if (s.length > 0)
                return SL.notify("Scripts are not allowed. Please remove all script tags for this snippet to save.", "negative"),
                !1;
            var o = e.data("model");
            o.set("title", i),
            o.set("template", n),
            this.layoutSnippet(e),
            this.validateSnippet(e),
            this.previewSnippet(o),
            this.changed.dispatch()
        }
    },
    onSnippetDelete : function (t) {
        var e = $(t.target).closest(".snippet-list-item");
        if (e.length) {
            var i = e.data("model");
            i ? SL.prompt({
                anchor : $(t.currentTarget),
                title : SL.locale.get("THEME_SNIPPET_DELETE_CONFIRM"),
                type : "select",
                data : [{
                        html : "<h3>Cancel</h3>"
                    }, {
                        html : "<h3>Remove</h3>",
                        selected : !0,
                        className : "negative",
                        callback : function () {
                            SL.util.anim.collapseListItem(e,
                                function () {
                                e.remove(),
                                this.syncMoveButtons()
                            }
                                .bind(this));
                            var t = this.theme.get("snippets");
                            t.remove(e.data("model")),
                            this.changed.dispatch()
                        }
                        .bind(this)
                    }
                ]
            }) : SL.notify("An error occured while deleting this snippet")
        } else
            SL.notify("An error occured while deleting this snippet")
    },
    onSnippetMoveUp : function (t) {
        var e = $(t.target).closest(".snippet-list-item");
        if (e.length) {
            var i = e.data("model");
            if (i) {
                var n = this.theme.get("snippets");
                n.shiftLeft(n.find(i)),
                this.changed.dispatch(),
                this.syncSnippetOrder()
            }
        }
    },
    onSnippetMoveDown : function (t) {
        var e = $(t.target).closest(".snippet-list-item");
        if (e.length) {
            var i = e.data("model");
            if (i) {
                var n = this.theme.get("snippets");
                n.shiftRight(n.find(i)),
                this.changed.dispatch(),
                this.syncSnippetOrder()
            }
        }
    }
});