import SL from '../../../SL';

SL("views.themes.edit").GlobalCSSPanel = SL.views.themes.edit.Panel.extend({
    PAGES : [{
            name : "Global CSS",
            id : "css",
            factory : "renderCSS"
        }
    ],
    init : function (t, e) {
        this.team = e,
        this.team.get("global_css_input") || this.team.set("global_css_input", ""),
        this.team.get("global_css_output") || this.team.set("global_css_output", ""),
        this.data = {
            global_css_input : this.team.get("global_css_input"),
            global_css_output : this.team.get("global_css_output")
        },
        this._super(t),
        this.domElement.addClass("panel-global-css")
    },
    load : function () {
        this.afterLoad()
    },
    renderCSS : function () {
        this.css = new SL.views.themes.edit.pages.CSS(this, this.theme, {
                title : "Global CSS",
                description : "Add custom CSS or LESS styles to all decks created by your team. These styles are injected before any theme-specific CSS. ",
                setInput : function (t) {
                    this.data.global_css_input = t
                }
                .bind(this),
                getInput : function () {
                    return this.data.global_css_input
                }
                .bind(this),
                setOutput : function (t) {
                    this.data.global_css_output = t
                }
                .bind(this),
                getOutput : function () {
                    return this.data.global_css_output
                }
                .bind(this)
            }),
        this.css.appendTo(this.pagesElement),
        this.css.changed.add(this.checkUnsavedChanges.bind(this))
    },
    paintPreview : function () {
        this.preprocess().then(function () {
            this.editor.refreshPreview(this.theme, this.data.global_css_output)
        }
            .bind(this),
            function () {
            this.editor.refreshPreview(this.theme, this.data.global_css_output)
        }
            .bind(this))
    },
    preprocess : function () {
        return this.css.persist()
    },
    hasUnsavedChanges : function () {
        return this.team.get("global_css_input") !== this.data.global_css_input
    },
    save : function (t) {
        var e = this.data.global_css_input,
        i = this.data.global_css_output,
        n = this.saveButton.data("ladda");
        n && n.start(),
        this.preprocess().then(function () {
            $.ajax({
                url : SL.config.AJAX_UPDATE_TEAM,
                type : "PUT",
                data : {
                    team : {
                        global_css_input : e,
                        global_css_output : i
                    }
                },
                context : this
            }).done(function () {
                this.team.set("global_css_input", e),
                this.team.set("global_css_output", i),
                this.checkUnsavedChanges(),
                SL.util.callback(t)
            }).fail(function () {
                SL.notify("Failed to save, please try again", "negative")
            }).always(function () {
                n && n.stop()
            })
        }
            .bind(this),
            function () {
            SL.notify("Please fix all CSS errors before saving", "negative"),
            n && n.stop()
        }
            .bind(this))
    }
});