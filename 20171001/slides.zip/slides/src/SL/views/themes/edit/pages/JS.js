import SL from '../../../../SL';

SL("views.themes.edit.pages").JS = Class.extend({
    init : function (t, e) {
        this.panel = t,
        this.theme = e,
        this.changed = new signals.Signal,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="page" data-page-id="js">'),
        this.domElement.html(['<div class="page-header page-header-absolute">', "<h4>JavaScript</h4>", "<p>Scripts will be executed when a deck that uses this theme is loaded. They are injected at the end of the document, after all other scripts.</p>", '<div class="header-buttons">', '<button class="button outline float-right insert-image" data-tooltip="Insert image URL"><span class="icon i-picture"></span></button>', "</div>", "</div>", '<div class="editor-wrapper">', '<div id="ace-js" class="editor"></div>', "</div>"].join("")),
        this.insertImageButton = this.domElement.find(".insert-image")
    },
    setupAce : function () {
        if (!this.ace)
            try {
                this.ace = ace.edit("ace-js"),
                SL.util.setAceEditorDefaults(this.ace),
                this.ace.getSession().setMode("ace/mode/javascript"),
                this.ace.getSession().setValue(this.theme.get("js") || ""),
                this.ace.getSession().on("change", this.onInputChanged.bind(this))
            } catch (t) {
                console.log("An error occurred while initializing the Ace JS editor.")
            }
    },
    bind : function () {
        this.insertImageButton.on("click", this.onInsertImageClicked.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.setupAce()
    },
    focus : function () {
        this.ace.focus()
    },
    persist : function () {
        return this.theme.set("js", this.getValue()),
        Promise.resolve()
    },
    getValue : function () {
        return this.ace ? this.ace.getSession().getValue() : ""
    },
    destroy : function () {
        this.changed.dispose(),
        this.ace && (this.ace.destroy(), this.ace = null),
        this.panel = null,
        this.theme = null
    },
    onInputChanged : function () {
        this.panel.updatePreview(1e3)
    },
    onInsertImageClicked : function () {
        var t = SL.popup.open(SL.components.medialibrary.MediaLibrary, {
                select : SL.models.Media.IMAGE
            });
        t.selected.addOnce(function (t) {
            t.isUploaded() ? (this.ace.insert(t.get("url")), this.focus()) : t.uploadCompleted.add(function () {
                this.ace.insert(t.get("url"))
            }
                .bind(this))
        }
            .bind(this))
    }
});