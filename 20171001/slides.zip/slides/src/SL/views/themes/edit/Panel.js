import SL from '../../../SL';

SL("views.themes.edit").Panel = Class.extend({
    DEFAULT_PAGE : "settings",
    PAGES : [{
            name : "Settings",
            id : "settings",
            factory : "renderSettings"
        }, {
            name : "CSS",
            id : "css",
            factory : "renderCSS"
        }, {
            name : "HTML",
            id : "html",
            factory : "renderHTML"
        }, {
            name : "JS",
            id : "js",
            factory : "renderJS",
            condition : function () {
                return SL.current_team.get("allow_scripts")
            }
        }, {
            name : "Palette",
            id : "palette",
            factory : "renderPalette",
            condition : function () {
                return this.editor.VERSION > 1
            }
        }, {
            name : "Snippets",
            id : "snippets",
            factory : "renderSnippets"
        }
    ],
    init : function (t, e, i) {
        this.editor = t,
        this.theme = e,
        this.themeOptionsConfig = i,
        this.previewTimeout = -1,
        this.destroyed = new signals.Signal,
        this.updatePreview = this.updatePreview.bind(this),
        this.paintPreview = this.paintPreview.bind(this),
        this.render(),
        this.load()
    },
    load : function () {
        this.theme.load().done(function () {
            this.theme = this.theme.clone(),
            this.afterLoad(),
            this.savedJSON = JSON.stringify(this.theme.toJSON()),
            this.checkUnsavedChanges()
        }
            .bind(this)).fail(function () {
            this.close(),
            SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
        }
            .bind(this))
    },
    afterLoad : function () {
        this.preloaderElement.addClass("hidden"),
        setTimeout(function () {
            this.preloaderElement.remove(),
            this.preloaderElement = null
        }
            .bind(this), 500),
        this.renderHeader(),
        this.renderPages(),
        this.bind(),
        this.showPage(this.DEFAULT_PAGE),
        this.paintPreview()
    },
    render : function () {
        this.domElement = $('<div class="panel">'),
        this.domElement.appendTo(this.editor.editorInnerElement),
        this.pagesElement = $('<div class="pages">'),
        this.pagesElement.appendTo(this.domElement),
        this.preloaderElement = $('<div class="preloader"><div class="preloader-inner"><div class="preloader-spinner"></div></div></div>'),
        this.preloaderElement.appendTo(this.editor.editorInnerElement),
        SL.util.html.generateSpinners()
    },
    renderHeader : function () {
        this.headerElement = $('<header class="panel-header">').appendTo(this.domElement),
        this.tabsElement = $('<div class="page-tabs">').appendTo(this.headerElement),
        this.cancelButton = $('<button class="button l grey cancel-button">Close</button>').appendTo(this.headerElement),
        this.saveButton = $('<button class="button l positive save-button ladda-button" data-style="zoom-out">Save</button>').appendTo(this.headerElement),
        this.saveButton.data("ladda", Ladda.create(this.saveButton.get(0))),
        this.onSaveClicked = this.onSaveClicked.bind(this),
        this.onCancelClicked = this.onCancelClicked.bind(this),
        this.saveButton.on("click", this.onSaveClicked),
        this.cancelButton.on("click", this.onCancelClicked)
    },
    renderPages : function () {
        this.PAGES.forEach(function (t) {
            ("function" != typeof t.condition || t.condition.call(this)) && ($('<button class="page-tab" data-page-id="' + t.id + '">' + t.name + "</button>").on("click", this.showPage.bind(this, t.id)).appendTo(this.tabsElement), this[t.factory]())
        }
            .bind(this)),
        1 === this.PAGES.length && this.tabsElement.hide()
    },
    renderSettings : function () {
        this.settingsElement = $('<div class="page sl-form sl-scrollable" data-page-id="settings">').appendTo(this.pagesElement),
        this.settingsElement.append('<div class="unit name" data-required><label for="">Name</label><input id="theme-name" placeholder="Theme name" type="text" value="' + (this.theme.get("name") || "Untitled") + '"></div>'),
        this.settingsElement.find("#theme-name").on("change", this.paintPreview),
        this.settingsElement.find("#theme-name").on("input", this.onNameInputChanged.bind(this)),
        this.renderThemeOptions()
    },
    renderThemeOptions : function () {
        var t = $.extend(this.themeOptionsConfig, {
                model : this.theme,
                container : this.settingsElement,
                themeEditor : !0,
                resolution : !0,
                supportsCustomFonts : !0
            });
        "no-color" !== t.colors[t.colors.length - 1].id && t.colors.push({
            id : "no-color",
            tooltip : "Specifies as few color styles as possible, useful if you want to write custom CSS from the ground up."
        }),
        "no-font" !== t.fonts[t.fonts.length - 1].id && t.fonts.push({
            id : "no-font",
            title : "None",
            tooltip : "Specifies as few typographic styles as possible, useful if you want to write custom CSS from the ground up."
        }),
        this.themeOptions = new SL.components.ThemeOptions(t),
        this.themeOptions.changed.add(this.paintPreview)
    },
    renderCSS : function () {
        this.css = new SL.views.themes.edit.pages.CSS(this, this.theme),
        this.css.appendTo(this.pagesElement),
        this.css.changed.add(this.checkUnsavedChanges.bind(this))
    },
    renderHTML : function () {
        this.html = new SL.views.themes.edit.pages.HTML(this, this.theme),
        this.html.appendTo(this.pagesElement),
        this.html.changed.add(this.checkUnsavedChanges.bind(this))
    },
    renderJS : function () {
        this.js = new SL.views.themes.edit.pages.JS(this, this.theme),
        this.js.appendTo(this.pagesElement),
        this.js.changed.add(this.checkUnsavedChanges.bind(this))
    },
    renderPalette : function () {
        this.palette = new SL.views.themes.edit.pages.Palette(this, this.theme),
        this.palette.appendTo(this.pagesElement),
        this.palette.changed.add(this.checkUnsavedChanges.bind(this))
    },
    renderSnippets : function () {
        this.snippets = new SL.views.themes.edit.pages.Snippets(this, this.theme),
        this.snippets.appendTo(this.pagesElement),
        this.snippets.changed.add(this.checkUnsavedChanges.bind(this))
    },
    bind : function () {
        this.onDocumentKeyDown = this.onDocumentKeyDown.bind(this),
        $(document).on("keydown", this.onDocumentKeyDown),
        this.domElement.on("click", ".page-header .documentation-link",
            function (t) {
            t.preventDefault();
            var e = $(t.currentTarget),
            i = e.closest(".page-header");
            i.toggleClass("expanded"),
            e.text(i.hasClass("expanded") ? "Less info" : "More info")
        }
            .bind(this))
    },
    showPage : function (t) {
        this.domElement.find(".page").removeClass("past present future"),
        this.domElement.find('.page[data-page-id="' + t + '"]').addClass("present"),
        this.domElement.find('.page[data-page-id="' + t + '"]').prevAll().addClass("past"),
        this.domElement.find('.page[data-page-id="' + t + '"]').nextAll().addClass("future"),
        this.domElement.find(".panel-header .page-tab").removeClass("selected"),
        this.domElement.find('.panel-header .page-tab[data-page-id="' + t + '"]').addClass("selected"),
        "css" === t && this.css ? this.css.focus() : "html" === t && this.html ? this.html.focus() : "js" === t && this.js ? this.js.focus() : "palette" === t && this.palette && this.palette.refresh(),
        setTimeout(function () {
            this.domElement.find(".page").addClass("transition")
        }
            .bind(this), 1),
        this.resetScrollPosition()
    },
    resetScrollPosition : function () {
        this.domElement.scrollLeft(0).scrollTop(0),
        this.settingsElement && this.settingsElement.scrollLeft(0).scrollTop(0)
    },
    updatePreview : function (t) {
        "number" != typeof t && (t = 250),
        clearTimeout(this.previewTimeout),
        this.previewTimeout = setTimeout(function () {
                this.paintPreview()
            }
                .bind(this), t)
    },
    paintPreview : function () {
        this.preprocess().then(function () {
            this.editor.refreshPreview(this.theme)
        }
            .bind(this),
            function () {
            this.editor.refreshPreview(this.theme)
        }
            .bind(this))
    },
    preprocess : function (t, e) {
        this.theme.set("name", this.domElement.find("#theme-name").val());
        var i = [];
        return this.css && i.push(this.css.persist()),
        this.html && i.push(this.html.persist()),
        this.js && i.push(this.js.persist()),
        this.checkUnsavedChanges(),
        Promise.all(i).then(t, e)
    },
    hasUnsavedChanges : function () {
        return this.theme && this.savedJSON !== JSON.stringify(this.theme.toJSON())
    },
    checkUnsavedChanges : function () {
        this.domElement.toggleClass("has-unsaved-changes", this.hasUnsavedChanges())
    },
    save : function (t) {
        var e = this.saveButton.data("ladda");
        e && e.start(),
        this.preprocess().then(function () {
            this.editor.saveTheme(this.theme,
                function () {
                e && e.stop(),
                this.savedJSON = JSON.stringify(this.theme.toJSON()),
                this.checkUnsavedChanges(),
                SL.util.callback(t)
            }
                .bind(this),
                function () {
                e && e.stop()
            }
                .bind(this))
        }
            .bind(this),
            function () {
            SL.notify("Please fix all CSS errors before saving", "negative"),
            e && e.stop()
        }
            .bind(this))
    },
    close : function (t) {
        this.hasUnsavedChanges() ? SL.prompt({
            anchor : this.cancelButton,
            title : SL.locale.get("WARN_UNSAVED_CHANGES"),
            alignment : "b",
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Discard</h3>",
                    className : "divider",
                    callback : function () {
                        this.destroy(),
                        SL.util.callback(t)
                    }
                    .bind(this)
                }, {
                    html : "<h3>Save</h3>",
                    className : "positive",
                    selected : !0,
                    callback : function () {
                        SL.util.callback(t),
                        this.save(this.destroy.bind(this))
                    }
                    .bind(this)
                }
            ]
        }) : (this.destroy(), SL.util.callback(t))
    },
    getTheme : function () {
        return this.theme
    },
    onNameInputChanged : function () {
        this.theme.set("name", this.domElement.find("#theme-name").val()),
        this.checkUnsavedChanges()
    },
    onSaveClicked : function () {
        this.save()
    },
    onCancelClicked : function () {
        this.close()
    },
    onDocumentKeyDown : function (t) {
        (t.metaKey || t.ctrlKey) && 83 === t.keyCode ? (this.hasUnsavedChanges() && this.save(), t.preventDefault()) : 27 === t.keyCode && this.close()
    },
    destroy : function () {
        this.isDestroyed || (this.isDestroyed = !0, clearTimeout(this.previewTimeout), this.destroyed.dispatch(), this.destroyed.dispose(), $(document).off("keydown", this.onDocumentKeyDown), setTimeout(function () {
                this.css && (this.css.destroy(), this.css = null),
                this.html && (this.html.destroy(), this.html = null),
                this.js && (this.js.destroy(), this.js = null),
                this.palette && (this.palette.destroy(), this.palette = null),
                this.snippets && (this.snippets.destroy(), this.snippets = null),
                this.themeOptions && this.themeOptions.destroy(),
                this.preloaderElement && this.preloaderElement.remove(),
                this.domElement && this.domElement.remove()
            }
                .bind(this), 500))
    }
});