import SL from '../../SL';

SL("views.statik").Pricing = SL.views.statik.All.extend({
    init : function () {
        this._super(),
        $(".tier").each(this.setupTier.bind(this))
    },
    setupTier : function (t, e) {
        var e = $(e),
        i = e.find(".cta a");
        i.length && !i.hasClass("disabled") && (e.on("click",
                function (t) {
                t.preventDefault(),
                window.location = i.attr("href")
            }), e.on("mouseenter",
                function () {
                e.addClass("hover")
            }), e.on("mouseleave",
                function () {
                e.removeClass("hover")
            }))
    }
});