import SL from '../../SL';

SL("views.statik").All = SL.views.Base.extend({
    init : function () {
        this._super(),
        $("img.click-to-expand").on("click",
            function () {
            $(this).toggleClass("expanded")
        }),
        this.setupHighlight()
    },
    setupHighlight : function () {
        $("code").length > 0 && "undefined" != typeof window.hljs && window.hljs.initHighlightingOnLoad()
    }
});