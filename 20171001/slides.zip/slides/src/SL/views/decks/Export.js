import SL from '../../SL';

SL("views.decks").Export = SL.views.Base.extend({
    init : function () {
        this._super(),
        SLConfig.deck.notes && [].forEach.call(document.querySelectorAll(".reveal .slides section"),
            function (t) {
            var e = SLConfig.deck.notes[t.getAttribute("data-id")];
            e && "string" == typeof e && t.setAttribute("data-notes", e)
        }),
        SL.util.deck.renderInlineMath()
    }
});