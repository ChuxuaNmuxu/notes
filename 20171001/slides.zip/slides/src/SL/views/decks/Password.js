import SL from '../../SL';

SL("views.decks").Password = SL.views.Base.extend({
    OUTRO_DURATION : 600,
    init : function () {
        this._super(),
        this.domElement = $(".password-content"),
        this.formElement = this.domElement.find(".sl-form"),
        this.inputElement = this.formElement.find(".password-input"),
        this.submitButton = this.formElement.find(".password-submit"),
        this.submitLoader = Ladda.create(this.submitButton.get(0)),
        this.iconElement = $(".password-icon"),
        this.titleElement = $(".password-title"),
        this.incorrectPasswordCounter = 0,
        this.incorrectPasswordMessages = ["Wrong password, please try again", "Still wrong, give it another try", "That one was wrong too", "Nope"],
        this.submitButton.on("vclick", this.onSubmitClicked.bind(this)),
        $(document).on("keydown", this.onKeyDown.bind(this))
    },
    submit : function () {
        this.request || (this.submitLoader.start(), this.iconElement.removeClass("wobble"), this.request = $.ajax({
                    url : SL.config.AJAX_ACCESS_TOKENS_PASSWORD_AUTH(SLConfig.access_token_id),
                    type : "PUT",
                    context : this,
                    data : {
                        access_token : {
                            password : this.inputElement.val()
                        }
                    }
                }).done(function () {
                    this.domElement.addClass("outro"),
                    this.titleElement.text("All set! Loading deck..."),
                    setTimeout(function () {
                        window.location.reload()
                    },
                        this.OUTRO_DURATION)
                }).fail(function () {
                    this.submitLoader.stop(),
                    this.titleElement.text(this.getIncorrectPasswordMessage()),
                    this.iconElement.addClass("wobble"),
                    this.request = null
                }))
    },
    getIncorrectPasswordMessage : function () {
        return this.incorrectPasswordMessages[this.incorrectPasswordCounter++ % this.incorrectPasswordMessages.length]
    },
    onSubmitClicked : function (t) {
        t.preventDefault(),
        this.submit()
    },
    onKeyDown : function (t) {
        13 === t.keyCode && (t.preventDefault(), this.submit())
    }
});