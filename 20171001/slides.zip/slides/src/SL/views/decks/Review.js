import SL from '../../SL';

SL("views.decks").Review = SL.views.Base.extend({
    init : function () {
        this._super(),
        $("html").toggleClass("small-mode", window.innerWidth < 850),
        SL.util.setupReveal({
            help : !1,
            history : !0,
            openLinksInTabs : !0,
            margin : .15
        }),
        SL.helpers.PageLoader.show(),
        this.setupCollaboration().then(function () {
            SL.fonts.isReady() ? SL.helpers.PageLoader.hide() : SL.fonts.ready.add(SL.helpers.PageLoader.hide)
        }),
        SL.session.enforce()
    },
    setupCollaboration : function () {
        this.collaboration = new SL.components.collab.Collaboration({
                container : document.body,
                fixed : !$("html").hasClass("small-mode"),
                autofocusComment : !1
            });
        var t = new Promise(function (t) {
                this.collaboration.loaded.add(function () {
                    t()
                }
                    .bind(this))
            }
                .bind(this));
        return this.collaboration.load(),
        t
    }
});