import SL from '../../SL';

SL("views.decks").Embed = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.footerElement = $(".embed-footer"),
        this.shareButton = this.footerElement.find(".embed-footer-share"),
        this.fullscreenButton = this.footerElement.find(".embed-footer-fullscreen"),
        this.revealElement = $(".reveal"),
        SL.util.setupReveal({
            embedded : !0,
            openLinksInTabs : !0,
            trackEvents : !0,
            maxScale : SL.config.PRESENT_UPSIZING_MAX_SCALE
        }),
        $(window).on("resize", this.layout.bind(this)),
        $(document).on("webkitfullscreenchange mozfullscreenchange MSFullscreenChange fullscreenchange", this.layout.bind(this)),
        this.shareButton.on("click", this.onShareClicked.bind(this)),
        this.fullscreenButton.on("click", this.onFullscreenClicked.bind(this));
        var t = SL.util.getQuery().style;
        "hidden" !== t || SL.current_deck.isPaid() || (t = null),
        t && $("html").attr("data-embed-style", t),
        Modernizr.fullscreen === !1 && this.fullscreenButton.hide(),
        this.layout()
    },
    layout : function () {
        this.revealElement.height(this.footerElement.is(":visible") ? window.innerHeight - this.footerElement.height() : "100%"),
        Reveal.layout()
    },
    onFullscreenClicked : function () {
        var t = $("html").get(0);
        return t ? (SL.helpers.Fullscreen.enter(t), !1) : void 0
    },
    onShareClicked : function () {
        SL.popup.open(SL.components.decksharer.DeckSharer, {
            deck : SL.current_deck
        }),
        SL.analytics.trackPresenting("Share clicked (embed footer)")
    }
});