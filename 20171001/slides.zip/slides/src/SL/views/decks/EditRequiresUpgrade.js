import SL from '../../SL';

SL("views.decks").EditRequiresUpgrade = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.makePublicButton = $(".make-deck-public").first(),
        this.makePublicButton.on("click", this.onMakePublicClicked.bind(this)),
        this.makePublicLoader = Ladda.create(this.makePublicButton.get(0))
    },
    makeDeckPublic : function () {
        var t = {
            type : "POST",
            url : SL.config.AJAX_PUBLISH_DECK(SL.current_deck.get("id")),
            context : this,
            data : {
                visibility : SL.models.Deck.VISIBILITY_ALL
            }
        };
        this.makePublicLoader.start(),
        $.ajax(t).done(function () {
            window.location = SL.routes.DECK_EDIT(SL.current_user.get("username"), SL.current_deck.get("slug"))
        }).fail(function () {
            SL.notify(SL.locale.get("DECK_VISIBILITY_CHANGED_ERROR"), "negative"),
            this.makePublicLoader.stop()
        })
    },
    onMakePublicClicked : function (t) {
        t.preventDefault(),
        this.makeDeckPublic()
    }
});