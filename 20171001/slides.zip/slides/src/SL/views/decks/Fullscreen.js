import SL from '../../SL';

SL("views.decks").Fullscreen = SL.views.Base.extend({
    init : function () {
        this._super(),
        /no-autoplay=1/.test(window.location.search) && $(".reveal [data-autoplay]").removeAttr("data-autoplay"),
        SL.util.setupReveal({
            history : !navigator.userAgent.match(/(iphone|ipod|ipad|android)/gi),
            openLinksInTabs : !0,
            trackEvents : !0,
            maxScale : SL.config.PRESENT_UPSIZING_MAX_SCALE
        })
    }
});