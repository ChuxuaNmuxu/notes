import SL from '../../SL';

SL("views.decks").Speaker = SL.views.Base.extend({
    init : function () {
        this._super(),
        this.notesElement = $(".speaker-controls .notes"),
        this.notesValue = $(".speaker-controls .notes .value"),
        this.timeElement = $(".speaker-controls .time"),
        this.timeTimerValue = $(".speaker-controls .time .timer-value"),
        this.timeClockValue = $(".speaker-controls .time .clock-value"),
        this.timeResetButton = $(".speaker-controls .time .timer-reset-button"),
        this.subscribersElement = $(".speaker-controls .subscribers"),
        this.subscribersValue = $(".speaker-controls .subscribers .subscribers-value"),
        this.currentElement = $(".current-slide"),
        this.upcomingElement = $(".upcoming-slide"),
        this.upcomingFrame = $(".upcoming-slide iframe"),
        this.upcomingJumpTo = $(".upcoming-slide-jump-to"),
        this.speakerLayout = $(".speaker-layout-button"),
        this.speakerLayout.on("vclick", this.onLayoutClicked.bind(this)),
        $(".reveal [data-autoplay]").removeAttr("data-autoplay"),
        this.isMobileSpeakerView() || this.setLayout(SL.current_user.settings.get("speaker_layout")),
        this.upcomingFrame.length ? (this.upcomingFrame.on("load", this.onUpcomingFrameLoaded.bind(this)), this.upcomingFrame.attr("src", this.upcomingFrame.attr("data-src"))) : this.setup(),
        SL.helpers.PageLoader.show()
    },
    setup : function () {
        Reveal.addEventListener("ready",
            function () {
            this.currentReveal = window.Reveal,
            this.currentReveal.addEventListener("slidechanged", this.onCurrentSlideChanged.bind(this)),
            this.currentReveal.addEventListener("fragmentshown", this.onCurrentFragmentChanged.bind(this)),
            this.currentReveal.addEventListener("fragmenthidden", this.onCurrentFragmentChanged.bind(this)),
            this.currentReveal.addEventListener("paused", this.onCurrentPaused.bind(this)),
            this.currentReveal.addEventListener("resumed", this.onCurrentResumed.bind(this)),
            this.upcomingFrame.length && (this.upcomingReveal = this.upcomingFrame.get(0).contentWindow.Reveal, this.upcomingReveal.isReady() ? this.setupUpcomingReveal() : this.upcomingReveal.addEventListener("ready", this.setupUpcomingReveal.bind(this))),
            this.setupTimer(),
            this.setupTouch();
            var t = {
                reveal : this.currentReveal,
                publisher : !0,
                showErrors : !0
            };
            SL.util.user.isPseudoLoggedIn() && (t.deckReloadEndpoint = window.location.pathname + ".json"),
            this.stream = new SL.helpers.StreamLive(t),
            this.stream.ready.add(this.onStreamReady.bind(this)),
            this.stream.deckChanged.add(this.onStreamDeckChanged.bind(this)),
            this.stream.stateChanged.add(this.onStreamStateChanged.bind(this)),
            this.stream.subscribersChanged.add(this.onStreamSubscribersChanged.bind(this)),
            this.stream.timerReset.add(this.restartTimer.bind(this)),
            this.stream.connect(),
            this.isMobileSpeakerView() || this.setupPointer(),
            this.layout(),
            window.addEventListener("resize", this.layout.bind(this))
        }
            .bind(this)),
        SL.util.setupReveal({
            touch : !0,
            history : !1,
            autoSlide : 0,
            openLinksInTabs : !0,
            trackEvents : !0,
            showNotes : !1
        })
    },
    setupUpcomingReveal : function () {
        this.upcomingReveal.configure({
            history : !1,
            controls : !1,
            progress : !1,
            overview : !1,
            autoSlide : 0,
            transition : "none",
            backgroundTransition : "none"
        }),
        this.upcomingReveal.addEventListener("slidechanged", this.onUpcomingSlideChanged.bind(this)),
        this.upcomingReveal.addEventListener("fragmentshown", this.onUpcomingFragmentChanged.bind(this)),
        this.upcomingReveal.addEventListener("fragmenthidden", this.onUpcomingFragmentChanged.bind(this)),
        this.upcomingFrame.get(0).contentWindow.document.body.className += " no-transition",
        this.upcomingJumpTo.on("vclick", this.onJumpToUpcomingSlide.bind(this)),
        this.syncJumpButton()
    },
    setupTouch : function () {
        if (this.isMobileSpeakerView() && (SL.util.device.HAS_TOUCH || window.navigator.pointerEnabled)) {
            this.touchControls = $(['<div class="touch-controls">', '<div class="touch-controls-content">', '<span class="status">', "Tap or Swipe to change slide", "</span>", '<span class="slide-number"></span>', "</div>", '<div class="touch-controls-progress"></div>', "</div>"].join("")).appendTo(document.body),
            this.touchControlsProgress = this.touchControls.find(".touch-controls-progress"),
            this.touchControlsSlideNumber = this.touchControls.find(".slide-number"),
            this.touchControlsStatus = this.touchControls.find(".status"),
            setTimeout(function () {
                this.touchControls.addClass("visible")
            }
                .bind(this), 1e3);
            var t = document.body,
            e = new Hammer(t);
            e.get("swipe").set({
                direction : Hammer.DIRECTION_ALL
            }),
            e.get("press").set({
                threshold : 1e3
            }),
            $(t).on("touchstart",
                function (i) {
                1 === $(i.target).closest(".notes-overflowing").length ? (e.stop(), $(t).one("touchend",
                        function (t) {
                        var e = {
                            x : i.originalEvent.pageX,
                            y : i.originalEvent.pageY
                        },
                        n = {
                            x : t.originalEvent.pageX,
                            y : t.originalEvent.pageY
                        };
                        SL.util.trig.distanceBetween({
                            x : e.x,
                            y : e.y
                        }, {
                            x : n.x,
                            y : n.y
                        }) < 10 && (this.currentReveal.next(), this.showTouchStatus("Next slide"))
                    }
                        .bind(this))) : i.preventDefault()
            }
                .bind(this)),
            e.on("swipe",
                function (t) {
                switch (t.direction) {
                case Hammer.DIRECTION_LEFT:
                    this.currentReveal.right(),
                    this.showTouchStatus("Next slide");
                    break;
                case Hammer.DIRECTION_RIGHT:
                    this.currentReveal.left(),
                    this.showTouchStatus("Previous slide");
                    break;
                case Hammer.DIRECTION_UP:
                    this.currentReveal.down(),
                    this.showTouchStatus("Next vertical slide");
                    break;
                case Hammer.DIRECTION_DOWN:
                    this.currentReveal.up(),
                    this.showTouchStatus("Previous vertical slide")
                }
            }
                .bind(this)),
            e.on("tap",
                function (t) {
                1 === $(t.target).closest(".timer-reset-button").length ? t.preventDefault() : (this.currentReveal.next(), this.showTouchStatus("Next slide"))
            }
                .bind(this)),
            e.on("press",
                function () {
                this.currentReveal.isPaused() && (this.currentReveal.togglePause(!1), this.showTouchStatus("Resumed"))
            }
                .bind(this))
        }
    },
    setupPointer : function () {
        this.pointer = new SL.components.StreamPointer({
                publisher : !0,
                stream : this.stream,
                hideDefault : !0,
                container : this.currentElement.get(0)
            }),
        this.syncPointer()
    },
    setupTimer : function () {
        this.timeResetButton.on("vclick",
            function () {
            this.stream.broadcast({
                type : "timer:reset"
            }),
            this.restartTimer()
        }
            .bind(this)),
        this.restartTimer(),
        setInterval(this.syncTimer.bind(this), 1e3)
    },
    restartTimer : function () {
        this.startTime = Date.now(),
        this.syncTimer()
    },
    layout : function () {
        var t = window.innerHeight - this.notesValue.offset().top - 10;
        this.isMobileSpeakerView() ? this.touchControls && (t -= this.touchControls.outerHeight()) : this.subscribersElement.hasClass("visible") && (t -= this.subscribersElement.outerHeight()),
        this.notesValue.height(t),
        this.syncNotesOverflow()
    },
    setLayout : function (t, e) {
        $("html").attr("data-speaker-layout", t),
        this.currentReveal && this.currentReveal.layout(),
        this.upcomingReveal && this.upcomingReveal.layout(),
        this.layout(),
        e && (SL.current_user.settings.set("speaker_layout", t), SL.current_user.settings.save(["speaker_layout"]))
    },
    getLayout : function () {
        return SL.current_user.settings.get("speaker_layout") || SL.views.decks.Speaker.LAYOUT_DEFAULT
    },
    sync : function () {
        setTimeout(function () {
            this.syncUpcomingSlide(),
            this.syncTouchControls(),
            this.syncNotes(),
            this.syncNotesOverflow(),
            this.syncTimer()
        }
            .bind(this), 1)
    },
    syncTimer : function () {
        var t = moment();
        this.timeClockValue.html(t.format("hh:mm") + ' <span class="dim">' + t.format("A") + "<span>"),
        t.hour(0).minute(0).second((Date.now() - this.startTime) / 1e3);
        var e = t.format("HH") + ":",
        i = t.format("mm") + ":",
        n = t.format("ss");
        "00:" === e && (e = '<span class="dim">' + e + "</span>", "00:" === i && (i = '<span class="dim">' + i + "</span>")),
        this.timeTimerValue.html(e + i + n)
    },
    syncUpcomingSlide : function () {
        if (this.upcomingReveal) {
            var t = this.currentReveal.getIndices();
            this.upcomingReveal.slide(t.h, t.v, t.f),
            this.upcomingReveal.next();
            var e = this.upcomingReveal.getIndices();
            this.upcomingElement.toggleClass("is-last-slide", t.h === e.h && t.v === e.v && t.f === e.f)
        }
    },
    syncJumpButton : function () {
        if (this.upcomingReveal) {
            var t = this.currentReveal.getIndices(),
            e = this.upcomingReveal.getIndices();
            this.upcomingJumpTo.toggleClass("hidden", t.h === e.h && t.v === e.v && t.f === e.f)
        }
    },
    syncNotes : function () {
        var t = $(this.currentReveal.getCurrentSlide()).attr("data-notes") || "";
        t ? (this.notesElement.show(), this.notesValue.text(t), this.notesElement.removeAttr("data-note-length"), t.length < 120 ? this.notesElement.attr("data-note-length", "short") : t.length > 210 && this.notesElement.attr("data-note-length", "long")) : this.notesElement.hide()
    },
    syncNotesOverflow : function () {
        this.notesValue.toggleClass("notes-overflowing", this.notesValue.prop("scrollHeight") > this.notesValue.height())
    },
    syncTouchControls : function () {
        if (this.touchControls) {
            var t = this.currentReveal.getProgress();
            this.touchControlsProgress.css({
                "-webkit-transform" : "scale(" + t + ", 1)",
                "-moz-transform" : "scale(" + t + ", 1)",
                "-ms-transform" : "scale(" + t + ", 1)",
                transform : "scale(" + t + ", 1)"
            });
            var e = $(".reveal .slides section:not(.stack)").length,
            i = this.currentReveal.getIndices().h + this.currentReveal.getIndices().v;
            i += $(".reveal .slides>section.present").prevAll("section").find(">section:gt(0)").length,
            i += 1,
            this.touchControlsSlideNumber.html(i + "/" + e)
        }
    },
    syncPointer : function () {
        this.pointer && this.pointer.setEnabled(SL.current_user.settings.get("present_pointer"))
    },
    showTouchStatus : function (t) {
        clearTimeout(this.touchControlsStatusTimeout);
        var e = this.currentReveal && this.currentReveal.isPaused();
        e && (t = "Paused (tap+hold to resume)"),
        this.touchControlsStatus && (this.touchControlsStatus.text(t).removeClass("hidden"), e || (this.touchControlsStatusTimeout = setTimeout(function () {
                        this.touchControlsStatus.addClass("hidden")
                    }
                        .bind(this), 1e3)))
    },
    isMobileSpeakerView : function () {
        return $("html").hasClass("speaker-mobile")
    },
    onUpcomingFrameLoaded : function () {
        this.setup()
    },
    onStreamReady : function () {
        SL.helpers.PageLoader.hide(),
        this.sync()
    },
    onStreamDeckChanged : function () {
        this.syncNotes()
    },
    onStreamStateChanged : function (t) {
        t && "boolean" == typeof t.present_pointer && (SL.current_user.settings.set("present_pointer", t.present_pointer), this.syncPointer())
    },
    onStreamSubscribersChanged : function (t) {
        "number" == typeof this.subscriberCount && (this.subscribersValue.removeClass("flash green flash-red"), t > this.subscriberCount ? setTimeout(function () {
                this.subscribersValue.addClass("flash-green")
            }
                .bind(this), 1) : t < this.subscriberCount && setTimeout(function () {
                this.subscribersValue.addClass("flash-red")
            }
                .bind(this), 1)),
        this.subscriberCount = t,
        this.subscriberCount > 0 ? (this.subscribersValue.html('<span class="icon i-eye"></span>' + t), this.subscribersElement.addClass("visible")) : this.subscribersElement.removeClass("visible"),
        this.layout()
    },
    onCurrentSlideChanged : function () {
        this.sync()
    },
    onCurrentFragmentChanged : function () {
        this.sync()
    },
    onCurrentPaused : function () {
        this.pausedInstructions || (this.pausedInstructions = $('<h3 class="message-overlay">Paused. Press the "B" key to resume.</h3>'), this.pausedInstructions.appendTo(this.currentElement), this.pausedInstructions.addClass("visible"))
    },
    onCurrentResumed : function () {
        this.pausedInstructions && (this.pausedInstructions.remove(), this.pausedInstructions = null)
    },
    onUpcomingSlideChanged : function () {
        this.syncJumpButton()
    },
    onUpcomingFragmentChanged : function () {
        this.syncJumpButton()
    },
    onJumpToUpcomingSlide : function () {
        var t = this.upcomingReveal.getIndices();
        this.currentReveal.slide(t.h, t.v, t.f),
        this.syncUpcomingSlide()
    },
    onLayoutClicked : function () {
        var t = this.getLayout();
        SL.prompt({
            anchor : this.speakerLayout,
            type : "select",
            title : "Speaker layout",
            className : "sl-speaker-layout-prompt",
            data : [{
                    html : '<div class="speaker-layout-icon" data-speaker-layout="' + SL.views.decks.Speaker.LAYOUT_DEFAULT + '"></div><h3>Default</h3>',
                    selected : t === SL.views.decks.Speaker.LAYOUT_DEFAULT,
                    callback : this.setLayout.bind(this, SL.views.decks.Speaker.LAYOUT_DEFAULT, !0)
                }, {
                    html : '<div class="speaker-layout-icon" data-speaker-layout="' + SL.views.decks.Speaker.LAYOUT_WIDE + '"></div><h3>Wide</h3>',
                    selected : t === SL.views.decks.Speaker.LAYOUT_WIDE,
                    callback : this.setLayout.bind(this, SL.views.decks.Speaker.LAYOUT_WIDE, !0)
                }, {
                    html : '<div class="speaker-layout-icon" data-speaker-layout="' + SL.views.decks.Speaker.LAYOUT_TALL + '"></div><h3>Tall</h3>',
                    selected : t === SL.views.decks.Speaker.LAYOUT_TALL,
                    callback : this.setLayout.bind(this, SL.views.decks.Speaker.LAYOUT_TALL, !0)
                }, {
                    html : '<div class="speaker-layout-icon" data-speaker-layout="' + SL.views.decks.Speaker.LAYOUT_NOTES_ONLY + '"></div><h3>Notes only</h3>',
                    selected : t === SL.views.decks.Speaker.LAYOUT_NOTES_ONLY,
                    callback : this.setLayout.bind(this, SL.views.decks.Speaker.LAYOUT_NOTES_ONLY, !0)
                }
            ]
        })
    }
});

SL.views.decks.Speaker.LAYOUT_DEFAULT = "default",
SL.views.decks.Speaker.LAYOUT_WIDE = "wide",
SL.views.decks.Speaker.LAYOUT_TALL = "tall",
SL.views.decks.Speaker.LAYOUT_NOTES_ONLY = "notes-only";