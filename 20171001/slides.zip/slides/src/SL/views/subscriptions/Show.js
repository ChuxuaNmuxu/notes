import SL from '../../SL';

SL("views.subscriptions").Show = SL.views.Base.extend({
    DOTTED_CARD_PREFIX : "&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; ",
    init : function () {
        this._super(),
        this.strings = {
            CONFIRM_UNSUBSCRIBE_ACTION : "Cancel subscription",
            CONFIRM_UNSUBSCRIBE_DESCRIPTION : SL.locale.get("DOWNGRADE_TO_FREE_CONFIRM")
        },
        this.load().then(this.onDataLoaded.bind(this), this.onDataFailed.bind(this))
    },
    bindLadda : function () {
        $(".column section .ladda-button").each(function (t, e) {
            e = $(e),
            e.data("ladda") || e.data("ladda", Ladda.create(e.get(0)))
        })
    },
    load : function () {
        return Promise.all([this.loadAccountDetails(), this.loadSubscriptionDetails()])
    },
    loadAccountDetails : function () {
        return $.ajax({
            url : SL.config.AJAX_ACCOUNT_DETAILS,
            type : "GET",
            context : this
        }).done(function (t) {
            this.data = new SL.models.Customer(t.customer)
        })
    },
    loadSubscriptionDetails : function () {
        return $.ajax({
            url : SL.config.AJAX_SUBSCRIPTION_DETAILS,
            type : "GET",
            context : this
        }).done(function (t) {
            this.subscriptionDetails = t
        })
    },
    onDataLoaded : function () {
        this.render()
    },
    onDataFailed : function () {
        $(".billing-loader").text(SL.locale.get("BILLING_DETAILS_ERROR"))
    },
    render : function () {
        $(".billing-loader").remove(),
        this.renderDetails(),
        this.renderHistory(),
        (!SL.current_user.isEnterprise() || SL.current_user.billing_address) && this.renderAddress(),
        this.bindLadda()
    },
    renderDetails : function () {
        var t = $('<section class="billing-details"><h2>Billing details</h2></section>').appendTo(".billing-wrapper"),
        e = this.data.hasActiveSubscription();
        if (e) {
            if (t.append('<div class="field status"><span class="label">Status</span><span class="value">Active</span></div>'), t.append('<div class="field"><span class="label">Plan</span><span class="value">' + SL.util.string.toTitleCase(this.subscriptionDetails.plan.tier) + "</span></div>"), this.data.has("active_card") && t.append('<div class="field card"><span class="label">Card</span><span class="value">' + this.DOTTED_CARD_PREFIX + this.data.get("active_card.last4") + "</span></div>"), t.append('<div class="field"><span class="label">Billing period</span><span class="value">' + (this.subscriptionDetails.billed_yearly ? "Yearly" : "Monthly") + "</span></div>"), this.data.hasActiveSubscription() && this.data.hasCoupon()) {
                var i = this.data.get("subscription.coupon_code").toUpperCase(),
                n = this.data.get("subscription.percent_off");
                n > 0 && (i += " / " + n + "% off"),
                t.append('<div class="field"><span class="label">Coupon</span><span class="value">' + i + "</span></div>")
            }
            if (this.data.has("subscription")) {
                var s = moment.unix(this.data.getNextInvoiceDate()).format("MMMM Do, YYYY"),
                o = "$" + this.data.getNextInvoiceSum();
                t.append('<div class="field payment-cycle"><span class="label">Next invoice</span><span class="value">' + o + " on " + s + "</span></div>")
            }
            t.append('<footer class="actions"><a class="button outline thin" href="' + SL.routes.SUBSCRIPTIONS_EDIT_CARD + '">Change credit card</a><button class="button negative outline thin cancel-subscription ladda-button" data-style="expand-right" data-spinner-color="#222">' + this.strings.CONFIRM_UNSUBSCRIBE_ACTION + "</button></footer>"),
            this.data.get("can_change_period") && t.find(".actions").prepend('<a class="button outline thin" href="' + SL.routes.SUBSCRIPTIONS_EDIT_PERIOD + '">Switch to annual billing</a>'),
            t.find(".actions").prepend('<a class="button outline thin" href="' + SL.routes.PRICING + '">Upgrade</a>'),
            t.find(".actions").prepend('<p class="title">Options</p>')
        } else {
            var a = "No active subscription";
            this.data.get("subscription") && (a = SL.util.string.toTitleCase(this.subscriptionDetails.plan.tier) + " until " + moment.unix(this.data.get("subscription.current_period_end")).format("MMM Do, YYYY")),
            t.append('<div class="field status"><span class="label">Status</span><span class="value">' + a + "</span></div>"),
            t.append('<footer class="actions"><button class="button outline thin positive reactivate-subscription ladda-button" data-style="expand-right" data-spinner-color="#222">Reactivate subscription</button></footer>'),
            this.reactivateButton = $(".billing-details .reactivate-subscription"),
            this.reactivateButton.length && (this.reactivateButton.on("click", this.onReactivateSubscriptionClicked.bind(this)), this.reactivateLoader = Ladda.create(this.reactivateButton.get(0)))
        }
        this.cancelButton = $(".billing-details .cancel-subscription"),
        this.cancelButton.length && (this.cancelButton.on("click", this.onCancelSubscriptionClicked.bind(this)), this.cancelLoader = Ladda.create(this.cancelButton.get(0)))
    },
    renderHistory : function () {
        var t = $(['<section class="billing-history">', "<h2>Receipts</h2>", '<table class="sl-table"></table>', "</section>"].join("")).appendTo(".billing-wrapper"),
        e = t.find("table");
        if (this.data.get("can_toggle_notifications") === !0) {
            t.append(['<div class="sl-checkbox outline">', '<input type="checkbox" id="receipt-notifications">', '<label for="receipt-notifications">Send receipts via email when I\'m charged</label>', "</div>"].join(""));
            var i = t.find("#receipt-notifications");
            i.on("change", this.onEmailNotificationChanged.bind(this)),
            SL.current_user.notify_on_receipt && i.prop("checked", !0)
        }
        e.html(["<tr>", '<th class="amount">Amount</th>', '<th class="date">Date</th>', '<th class="card">Card</th>', '<th class="download">PDF</th>', "</tr>"].join(""));
        var n = this.data.get("charges");
        n && n.length ? n.forEach(function (t) {
            if (t.paid) {
                var i = $(['<tr data-charge-id="' + t.id + '">', '<td class="amount">$' + (t.amount / 100).toFixed(2) + "</td>", '<td class="date">' + moment.unix(t.created).format("DD-MM-YYYY") + "</td>", '<td class="card">' + this.DOTTED_CARD_PREFIX + t.card.last4 + "</td>", '<td class="download">', '<form action="' + SL.config.AJAX_SUBSCRIPTIONS_PRINT_RECEIPT(t.id) + '" method="post">', '<button type="submit" class="button outline thin ladda-button download-button" data-style="slide-right" data-spinner-color="#222">', '<span class="icon i-download"></span>', "</button>", "</form>", "</td>", "</tr>"].join(""));
                i.appendTo(e),
                SL.util.dom.insertCSRF(i.find(".download form"))
            }
        }
            .bind(this)) : e.replaceWith("<p>" + SL.locale.get("BILLING_DETAILS_NOHISTORY") + "</p>")
    },
    renderAddress : function () {
        var t = $(['<section class="billing-address">', "<h2>Billing address</h2>", '<div class="sl-form">', '<div class="unit">', '<p class="unit-description">If you wish to include a billing address on your receipts please enter it below.</p>', '<textarea class="billing-address-input" rows="4" maxlength="300">', SL.current_user.billing_address || "", "</textarea>", "</div>", '<div class="footer">', '<button class="button l positive billing-address-save">Save</button>', "</div>", "</div>", "</section>"].join("")).appendTo(".billing-wrapper");
        this.addressInputField = t.find(".billing-address-input"),
        this.addressSaveButton = t.find(".billing-address-save"),
        this.addressInputField.on("change keyup mouseup", this.checkAddress.bind(this)),
        this.addressSaveButton.on("click", this.saveAddress.bind(this)),
        this.checkAddress()
    },
    checkAddress : function () {
        this.addressInputField.val() === (SL.current_user.billing_address || "") ? this.addressSaveButton.hide() : this.addressSaveButton.show()
    },
    saveAddress : function () {
        this.billingAddressXHR && this.billingAddressXHR.abort();
        var t = this.addressInputField.val() || "";
        this.billingAddressXHR = $.ajax({
                url : SL.config.AJAX_UPDATE_USER,
                type : "PUT",
                context : this,
                data : {
                    user : {
                        billing_address : t
                    }
                }
            }).done(function () {
                SL.current_user.billing_address = t,
                SL.notify("Billing address saved")
            }).fail(function () {
                SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
            }).always(function () {
                this.billingAddressXHR = null,
                this.checkAddress()
            })
    },
    onCancelSubscriptionClicked : function (t) {
        SL.prompt({
            anchor : $(t.currentTarget),
            title : this.strings.CONFIRM_UNSUBSCRIBE_DESCRIPTION,
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Confirm</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        this.cancelLoader.start(),
                        $.ajax({
                            url : SL.config.AJAX_SUBSCRIPTIONS,
                            type : "DELETE",
                            context : this
                        }).done(this.onCancelSubscriptionSuccess).fail(this.onCancelSubscriptionError)
                    }
                    .bind(this)
                }
            ]
        })
    },
    onCancelSubscriptionSuccess : function () {
        SL.notify(SL.locale.get("DOWNGRADE_TO_FREE_SUCCESS")),
        window.location.reload()
    },
    onCancelSubscriptionError : function () {
        SL.notify(SL.locale.get("GENERIC_ERROR")),
        this.cancelLoader.stop()
    },
    onReactivateSubscriptionClicked : function (t) {
        SL.prompt({
            anchor : $(t.currentTarget),
            title : "Are you sure you want to reactivate your subscription?",
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Reactivate</h3>",
                    selected : !0,
                    className : "positive",
                    callback : function () {
                        this.reactivateLoader.start(),
                        $.ajax({
                            url : SL.config.AJAX_SUBSCRIPTIONS_REACTIVATE,
                            type : "PUT",
                            context : this
                        }).done(this.onReactivateSubscriptionSuccess).fail(this.onReactivateSubscriptionError)
                    }
                    .bind(this)
                }
            ]
        })
    },
    onReactivateSubscriptionSuccess : function () {
        SL.notify("Subscription reactivated!"),
        window.location.reload()
    },
    onReactivateSubscriptionError : function () {
        SL.notify(SL.locale.get("GENERIC_ERROR")),
        this.cancelLoader.stop()
    },
    onEmailNotificationChanged : function (t) {
        this.emailNotificationXHR && this.emailNotificationXHR.abort();
        var e = $(t.currentTarget).is(":checked");
        this.emailNotificationXHR = $.ajax({
                url : SL.config.AJAX_UPDATE_USER,
                type : "PUT",
                context : this,
                data : {
                    user : {
                        notify_on_receipt : e
                    }
                }
            }).done(function () {
                SL.notify(e === !0 ? "Got it. We'll email receipts to you" : "Receipts will no longer be emailed")
            }).fail(function () {
                SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
            }).always(function () {
                this.emailNotificationXHR = null
            })
    }
});