import SL from '../../SL';

SL("views.subscriptions").EditPeriod = SL.views.Base.extend({
    init : function () {
        this._super(),
        Ladda.bind($("#payment-form button[type=submit]").get(0))
    }
});