import SL from '../SL';

SL("helpers").ImageUploader = Class.extend({
    init : function (t) {
        this.options = $.extend({
                service : SL.config.AJAX_MEDIA_CREATE,
                timeout : 9e4
            },
                t),
        this.onUploadSuccess = this.onUploadSuccess.bind(this),
        this.onUploadProgress = this.onUploadProgress.bind(this),
        this.onUploadError = this.onUploadError.bind(this),
        this.progressed = new signals.Signal,
        this.succeeded = new signals.Signal,
        this.failed = new signals.Signal
    },
    upload : function (t, e) {
        return t && t.type.match(/image.*/) ? "number" == typeof t.size && t.size / 1024 > SL.config.MAX_IMAGE_UPLOAD_SIZE.maxsize ? void SL.notify("No more than " + Math.round(MAX_IMAGE_UPLOAD_SIZE / 1e3) + "mb please", "negative") : (this.fileUploader && this.fileUploader.destroy(), this.fileUploader = new SL.helpers.FileUploader({
                    file : t,
                    filename : e || this.options.filename,
                    service : this.options.service,
                    timeout : this.options.timeout
                }), this.fileUploader.succeeded.add(this.onUploadSuccess), this.fileUploader.progressed.add(this.onUploadProgress), this.fileUploader.failed.add(this.onUploadError), void this.fileUploader.upload()) : void SL.notify("Only image files, please")
    },
    isUploading : function () {
        return !(!this.fileUploader || !this.fileUploader.isUploading())
    },
    onUploadSuccess : function (t) {
        t && "string" == typeof t.url ? this.succeeded.dispatch(t.url) : this.failed.dispatch(),
        this.fileUploader.destroy(),
        this.fileUploader = null
    },
    onUploadProgress : function (t) {
        this.progressed.dispatch(t)
    },
    onUploadError : function () {
        this.failed.dispatch(),
        this.fileUploader.destroy(),
        this.fileUploader = null
    },
    destroy : function () {
        this.succeeded.dispose(),
        this.progressed.dispose(),
        this.failed.dispose(),
        this.fileUploader && this.fileUploader.destroy()
    }
});