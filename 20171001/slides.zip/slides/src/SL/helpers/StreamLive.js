import SL from '../SL';

SL("helpers").StreamLive = Class.extend({
    init : function (t) {
        this.options = $.extend({
                reveal : window.Reveal,
                showErrors : !0,
                subscriber : !0,
                publisher : !1,
                publisherID : Date.now() + "-" + Math.round(1e6 * Math.random()),
                deck : SL.current_deck
            },
                t),
        this.options.deckReloadEndpoint || (this.options.deckReloadEndpoint = SL.config.AJAX_GET_DECK_JSON(this.options.deck.user.get("username"), this.options.deck.get("slug"))),
        this.ready = new signals.Signal,
        this.stateChanged = new signals.Signal,
        this.deckChanged = new signals.Signal,
        this.statusChanged = new signals.Signal,
        this.subscribersChanged = new signals.Signal,
        this.pointerChanged = new signals.Signal,
        this.timerReset = new signals.Signal,
        this.socketIsDisconnected = !1,
        this.lastPublishedTime = 0,
        this.debugMode = !!SL.util.getQuery().debug
    },
    connect : function () {
        this.options.publisher ? this.setupPublisher() : this.setupSubscriber()
    },
    setupPublisher : function () {
        this.publish = this.publish.bind(this),
        this.publishThrottled = this.publishThrottled.bind(this),
        this.publishable = !0,
        this.options.reveal.addEventListener("slidechanged", this.publishThrottled),
        this.options.reveal.addEventListener("fragmentshown", this.publishThrottled),
        this.options.reveal.addEventListener("fragmenthidden", this.publishThrottled),
        this.options.reveal.addEventListener("overviewshown", this.publish),
        this.options.reveal.addEventListener("overviewhidden", this.publish),
        this.options.reveal.addEventListener("paused", this.publish),
        this.options.reveal.addEventListener("resumed", this.publish),
        $.ajax({
            url : SL.config.AJAX_DECK_STREAM(this.options.deck.get("id")),
            type : "POST",
            context : this
        }).done(function (t) {
            this.publisherKey = t.publisher_key,
            t.active && t.state ? (this.log("found active stream"), this.setState(JSON.parse(t.state), !0), this.setupSocket(), this.ready.dispatch()) : (this.log("no active stream, publishing state"), this.publish(function () {
                    this.setupSocket(),
                    this.ready.dispatch()
                }
                    .bind(this)))
        }).error(function (t) {
            this.showSetupError(t)
        })
    },
    setupSubscriber : function () {
        $.ajax({
            url : SL.config.AJAX_DECK_STREAM(this.options.deck.get("id")),
            type : "GET",
            context : this
        }).done(function (t) {
            t.state ? (this.log("found existing stream"), this.setStatus(SL.helpers.StreamLive.STATUS_NONE), this.setState(JSON.parse(t.state), !0), this.setupSocket(), this.ready.dispatch()) : this.showWaitingForPresenter()
        }).error(function () {
            this.showWaitingForPresenter()
        })
    },
    setupSocket : function () {
        if (this.hideSetupError(), this.options.subscriber) {
            var t = SL.config.STREAM_ENGINE_HOST + "/" + SL.config.STREAM_ENGINE_LIVE_NAMESPACE;
            this.log("socket attempting to connect to", t),
            this.socket = io.connect(t, {
                    reconnectionDelayMax : 1e4
                }),
            this.socket.on("connect", this.onSocketConnected.bind(this)),
            this.socket.on("connect_error", this.onSocketDisconnected.bind(this)),
            this.socket.on("disconnect", this.onSocketDisconnected.bind(this)),
            this.socket.on("reconnect_attempt", this.onSocketReconnectAttempt.bind(this)),
            this.socket.on("reconnect_failed", this.onSocketReconnectFailed.bind(this)),
            this.socket.on("message", this.onSocketMessage.bind(this)),
            this.socket.on("subscribers", this.onSocketSubscribersMessage.bind(this)),
            this.socket.on("broadcast", this.onSocketBroadcastMessage.bind(this))
        }
    },
    publish : function (t, e) {
        if (clearTimeout(this.publishTimeout), this.publishable) {
            this.lastPublishedTime = Date.now();
            var i = this.options.reveal.getState();
            if (i.publisher_id = this.options.publisherID, i = $.extend(i, e), this.socketIsDisconnected === !0)
                return this.publishAfterReconnect = !0,
                void this.log("publish stalled while disconnected");
            this.log("publish", i.publisher_id),
            $.ajax({
                url : SL.config.AJAX_DECK_STREAM(this.options.deck.get("id")),
                type : "PUT",
                data : {
                    state : JSON.stringify(i)
                },
                success : t
            })
        }
    },
    publishThrottled : function () {
        clearTimeout(this.publishTimeout),
        Date.now() - this.lastPublishedTime > SL.helpers.StreamLive.STATE_CHANGE_THROTTLE ? this.publish.apply(this, arguments) : this.publishTimeout = setTimeout(this.publishThrottled, SL.helpers.StreamLive.STATE_CHANGE_THROTTLE)
    },
    emit : function () {
        this.log("emit", arguments),
        this.socket && this.socket.emit.apply(this.socket, arguments)
    },
    broadcast : function (t) {
        this.emit("broadcast", JSON.stringify(t))
    },
    log : function () {
        if (this.debugMode && "function" == typeof console.log.apply) {
            var t = "Stream (" + (this.options.publisher ? "publisher" : "subscriber") + "):",
            e = [t].concat(Array.prototype.slice.call(arguments));
            console.log.apply(console, e)
        }
    },
    setState : function (t, e) {
        this.publishable = !1,
        clearTimeout(this.publishTimeout),
        e && $(".reveal").addClass("no-transition"),
        this.options.reveal.setState(t),
        this.stateChanged.dispatch(t),
        setTimeout(function () {
            this.publishable = !0,
            e && $(".reveal").removeClass("no-transition")
        }
            .bind(this), 1)
    },
    setStatus : function (t) {
        this.status !== t && (this.status = t, this.statusChanged.dispatch(this.status))
    },
    getRetryStartTime : function () {
        return this.retryStartTime
    },
    isPublisher : function () {
        return this.options.publisher
    },
    showWaitingForPresenter : function () {
        this.retryStartTime = Date.now(),
        this.setStatus(SL.helpers.StreamLive.STATUS_WAITING_FOR_PUBLISHER),
        this.log("no existing stream, retrying in " + SL.helpers.StreamLive.CONNECTION_RETRY_INTERVAL / 1e3 + "s"),
        setTimeout(this.setupSubscriber.bind(this), SL.helpers.StreamLive.CONNECTION_RETRY_INTERVAL)
    },
    showSetupError : function (t) {
        this.setupError || (this.setupError = t && 401 === t.status ? new SL.components.RetryNotification('<strong>Sorry, we\u2019re having trouble connecting.</strong><br>Please make sure you are still signed in.<br>If the problem persists, contact us <a href="http://help.slides.com" target="_blank">here</a>.', {
                    type : "negative"
                }) : new SL.components.RetryNotification('<strong>Sorry, we\u2019re having trouble connecting.</strong><br>If the problem persists, contact us <a href="http://help.slides.com" target="_blank">here</a>.', {
                    type : "negative"
                }), this.setupError.disableCountdown(), this.setupError.destroyed.add(function () {
                this.setupError = null
            }
                .bind(this)), this.setupError.retryClicked.add(function () {
                this.setupError.destroy(),
                this.setupError = null,
                this.connect()
            }
                .bind(this)))
    },
    hideSetupError : function () {
        this.setupError && this.setupError.hide()
    },
    showConnectionError : function () {
        this.disconnectTimeout = setTimeout(function () {
                this.connectionError || (this.connectionError = new SL.components.RetryNotification("Lost connection to server"), this.connectionError.startCountdown(0), this.connectionError.destroyed.add(function () {
                        this.connectionError = null
                    }
                        .bind(this)), this.connectionError.retryClicked.add(function () {
                        this.connectionError.startCountdown(0),
                        this.socket.io.close(),
                        this.socket.io.open()
                    }
                        .bind(this)))
            }
                .bind(this), 1e4)
    },
    hideConnectionError : function () {
        clearTimeout(this.disconnectTimeout),
        this.connectionError && this.connectionError.hide()
    },
    onSocketMessage : function (t) {
        try {
            var e = JSON.parse(t.data);
            "deck_changed" === e.type ? this.onSocketDeckChanged() : e.publisher_id != this.options.publisherID && (this.log("sync", "from: " + e.publisher_id, "to: " + this.options.publisherID), this.setState(e))
        } catch (i) {
            this.log("unable to parse streamed deck state as JSON.")
        }
        this.setStatus(SL.helpers.StreamLive.STATUS_NONE)
    },
    onSocketDeckChanged : function () {
        this.log("deck changed"),
        this.reloadDeckXHR && this.reloadDeckXHR.abort(),
        this.reloadDeckXHR = $.ajax({
                url : this.options.deckReloadEndpoint,
                type : "GET",
                context : this
            }).done(function (t) {
                if (t && t.data) {
                    t.width && this.options.deck.set("width", t.width),
                    t.height && this.options.deck.set("height", t.height),
                    t.theme_color && this.options.deck.set("theme_color", t.theme_color),
                    t.theme_font && this.options.deck.set("theme_font", t.theme_font),
                    t.transition && this.options.deck.set("transition", t.transition),
                    t.notes && this.options.deck.set("notes", t.notes);
                    var e = SL.models.Theme.fromDeck(this.options.deck.toJSON());
                    SL.helpers.ThemeController.paint(e, {
                        center : !1
                    }),
                    SL.util.deck.replaceHTML(t.data),
                    t.notes && SL.util.deck.injectNotes(),
                    window.hljs && $(".reveal .slides pre code").each(function () {
                        window.hljs.highlightBlock(this)
                    }),
                    this.deckChanged.dispatch()
                }
            }).always(function () {
                this.reloadDeckXHR = null
            })
    },
    onSocketSubscribersMessage : function (t) {
        this.subscribersChanged.dispatch(t.subscribers)
    },
    onSocketBroadcastMessage : function (t) {
        try {
            var e = JSON.parse(t.data)
        } catch (i) {
            this.log("unable to parse streamed socket message as JSON.")
        }
        switch (this.log("broadcast", e), e.type) {
        case "live:pointer":
            this.pointerChanged.dispatch(e);
            break;
        case "timer:reset":
            this.timerReset.dispatch(e)
        }
    },
    onSocketConnected : function () {
        this.log("socket connected"),
        this.socket.emit("subscribe", {
            deck_id : this.options.deck.get("id"),
            publisher : this.options.publisher,
            publisher_key : this.publisherKey
        }),
        this.socketIsDisconnected === !0 && (this.socketIsDisconnected = !1, this.log("socket connection regained"), this.setStatus(SL.helpers.StreamLive.STATUS_NONE), this.publishAfterReconnect === !0 && (this.publishAfterReconnect = !1, this.log("publishing stalled state"), this.publish())),
        this.hideConnectionError()
    },
    onSocketReconnectAttempt : function () {
        this.connectionError && this.connectionError.startCountdown(this.socket.io.backoff.duration())
    },
    onSocketReconnectFailed : function () {
        this.connectionError && this.connectionError.disableCountdown()
    },
    onSocketDisconnected : function () {
        this.socketIsDisconnected === !1 && (this.socketIsDisconnected = !0, this.log("socket connection lost"), this.setStatus(SL.helpers.StreamLive.STATUS_CONNECTION_LOST), this.options.showErrors && this.showConnectionError())
    }
});