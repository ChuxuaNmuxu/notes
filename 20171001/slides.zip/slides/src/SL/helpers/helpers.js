import SL from '../SL';

import './FileUploader';
import './Fullscreen';
import './ImageUploader';
import './PageLoader';
import './PollJob';
import './StreamEditor';

SL.helpers.StreamEditor.STATUS_CONNECTED = "connected",
SL.helpers.StreamEditor.STATUS_RECONNECTED = "reconnected",
SL.helpers.StreamEditor.STATUS_RECONNECT_FAILED = "reconnect_failed",
SL.helpers.StreamEditor.STATUS_DISCONNECTED = "disconnected",
SL.helpers.StreamEditor.singleton = function () {
	return this._instance || (this._instance = new SL.helpers.StreamEditor({
				deckID : SLConfig.deck.id,
				slideID : SL.util.deck.getSlideID(Reveal.getCurrentSlide())
			})),
	this._instance
};

import './StreamLive';

SL.helpers.StreamLive.CONNECTION_RETRY_INTERVAL = 1e4,
SL.helpers.StreamLive.STATE_CHANGE_THROTTLE = 200,
SL.helpers.StreamLive.STATUS_NONE = "",
SL.helpers.StreamLive.STATUS_CONNECTION_LOST = "connection_lost",
SL.helpers.StreamLive.STATUS_WAITING_FOR_PUBLISHER = "waiting_for_publisher";

import './ThemeController';
