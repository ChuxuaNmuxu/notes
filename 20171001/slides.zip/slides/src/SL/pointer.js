import SL from './SL';

SL.pointer = {
	down : !1,
	downTimeout : -1,
	init : function () {
		$(document).on("mousedown", this.onMouseDown.bind(this)),
		$(document).on("mouseleave", this.onMouseLeave.bind(this)),
		$(document).on("mouseup", this.onMouseUp.bind(this))
	},
	isDown : function () {
		return this.down
	},
	onMouseDown : function () {
		clearTimeout(this.downTimeout),
		this.down = !0,
		this.downTimeout = setTimeout(function () {
				this.down = !1
			}
				.bind(this), 3e4)
	},
	onMouseLeave : function () {
		clearTimeout(this.downTimeout),
		this.down = !1
	},
	onMouseUp : function () {
		clearTimeout(this.downTimeout),
		this.down = !1
	}
};