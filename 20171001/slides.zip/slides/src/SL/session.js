import SL from './SL';

SL.session = {
	enforce : function () {
		this.enforced || (this.enforced = !0, this.hasLoggedOut = !1, this.loginInterval = setInterval(this.check.bind(this), SL.config.LOGIN_STATUS_INTERVAL))
	},
	check : function () {
		$.get(SL.config.AJAX_CHECK_STATUS).done(function (t) {
			t && t.user_signed_in ? this.onLoggedIn() : this.onLoggedOut()
		}
			.bind(this))
	},
	onLoggedIn : function () {
		this.hasLoggedOut && (this.hasLoggedOut = !1, SL.popup.close(SL.components.popup.SessionExpired))
	},
	onLoggedOut : function () {
		this.hasLoggedOut || (this.hasLoggedOut = !0, SL.popup.open(SL.components.popup.SessionExpired))
	}
};