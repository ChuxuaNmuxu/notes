import './colorPicker.js';
import './sidebar.js';
import './toolbars.js';
