import SL from '../../SL'; 
 
 SL("editor.components").Toolbars = Class.extend({
	init: function (e) {
		this.editor = e,
			this.stack = [],
			this.render(),
			this.show(),
			this.push(new SL.editor.components.toolbars.Add)
	},
	render: function () {
		this.domElement = $('<div class="toolbars">').appendTo(document.body),
			this.innerElement = $('<div class="toolbars-inner">').appendTo(this.domElement),
			this.scrollerElement = $('<div class="toolbars-scroller">').appendTo(this.innerElement),
			this.footerElement = $('<div class="toolbars-footer"></div>').appendTo(this.domElement),
			SL.current_user.isPaid() ? SL.current_user.isLite() && !SL.current_user.isEnterprise() ? this.footerElement.append('<a class="pricing-link upgrade-button" data-tooltip="You\'re using Slides Lite.<br>Click to learn more about our plans." href="/pricing">Lite</a>') : SL.current_user.isPro() && !SL.current_user.isEnterprise() && this.footerElement.append('<a class="pricing-link upgrade-button" data-tooltip="You\'re using Slides Pro.<br>Click to learn more about our plans." href="/pricing">Pro</a>') : this.footerElement.append('<a class="pricing-link upgrade-button emphasize" data-tooltip="Gain access to offline presenting, private sharing, PDF exports and more.<br>Click to learn all about our plans." data-tooltip-maxwidth="270" href="/pricing">Upgrade</a>'),
			this.footerElement.find(".upgrade-button").on("click", function () {
				SL.analytics.trackEditor("Click upgrade link", "footer")
			}),
			SL.editor.controllers.Capabilities.isTouchEditor() || (this.footerElement.append('<div class="option editor-settings" data-tooltip="Editor settings"><span class="icon i-equalizer"></span></div>'), this.footerElement.find(".option.editor-settings").on("click", this.onSettingsClicked))
	},
	show: function () {
		this.domElement.addClass("visible")
	},
	hide: function () {
		this.domElement.removeClass("visible")
	},
	push: function (e) {
		this.stack.push(e),
			e.appendTo(this.scrollerElement),
			this.layout()
	},
	pop: function () {
		this.stack.length > 1 && this.stack.pop().destroyAfter(1e3),
			this.layout()
	},
	get: function (e) {
		return this.stack[this.stack.length - 1 + (e || 0)]
	},
	clear: function () {
		for (; this.stack.length > 1;)
			this.stack.pop().destroyAfter(1e3);
		this.layout()
	},
	sync: function () {
		this.stack.forEach(function (e) {
			e.sync()
		})
	},
	layout: function () {
		for (var e = 0, t = 0, i = this.stack.length; i > t; t++) {
			var n = this.stack[t];
			n.move(e, null),
				e += n.measure().width,
				i - 1 > t && n.collapse()
		}
		var o = this.get(),
			r = o.measure();
		this.domElement.find(".toolbar").removeClass("visible"),
			o.domElement.addClass("visible");
		var s = "translateX(" + -Math.round(r.x) + "px)";
		this.scrollerElement.css({
			"-webkit-transform": s,
			"-moz-transform": s,
			"-ms-transform": s,
			transform: s
		})
	},
	getToolbarMeasurements: function () {
		var e = this.innerElement.position(),
			t = {
				x: e.left,
				y: e.top,
				width: this.innerElement.width(),
				height: this.innerElement.height()
			};
		return t.bottom = t.y + t.height,
			t.right = t.x + t.width,
			t
	},
	hasOpenPanel: function () {
		return this.stack.some(function (e) {
			return e.hasOpenPanel()
		})
	},
	collapse: function () {
		this.stack.forEach(function (e) {
			e.collapse()
		})
	},
	onSettingsClicked: function (e) {
		this.settingsPrompt = SL.prompt({
			anchor: e.currentTarget,
			type: "custom",
			title: "Editor Settings",
			className: "editor-settings",
			html: ['<div class="editor-option sl-checkbox outline">', '<input id="editor-settings-grid" type="checkbox">', '<label for="editor-settings-grid" data-tooltip="Display a grid behind the slide to help with alignment." data-tooltip-delay="500" data-tooltip-alignment="r" data-tooltip-maxwidth="220">Grid</label>', "</div>", '<div class="editor-option sl-checkbox outline">', '<input id="editor-settings-snap" type="checkbox">', '<label for="editor-settings-snap" data-tooltip="Snap dragged blocks to the grid, slide edges and other blocks." data-tooltip-delay="500" data-tooltip-alignment="r" data-tooltip-maxwidth="220">Snap</label>', "</div>", '<div class="editor-option sl-checkbox outline">', '<input id="editor-settings-developer-mode" type="checkbox">', '<label for="editor-settings-developer-mode" data-tooltip="Turn on developer-friendly features:<br>- Per slide HTML editor.<br>- Access to full deck HTML, for exporting to reveal.js.<br>- Add class names to any focused block. Makes it easy to target content with custom CSS." data-tooltip-delay="500" data-tooltip-alignment="r" data-tooltip-maxwidth="340">Developer mode</label>', "</div>"].join("")
		});
		var t = this.settingsPrompt.getDOMElement().find("#editor-settings-grid");
		t.prop("checked", SL.current_user.settings.get("editor_grid")),
			t.on("change", function (e) {
				SL.current_user.settings.set("editor_grid", e.currentTarget.checked),
					SL.current_user.settings.save(["editor_grid"]),
					SL.editor.controllers.Grid.refresh(),
					SL.analytics.trackEditor("Toggle Grid")
			});
		var i = this.settingsPrompt.getDOMElement().find("#editor-settings-snap");
		i.prop("checked", SL.current_user.settings.get("editor_snap")),
			i.on("change", function (e) {
				SL.current_user.settings.set("editor_snap", e.currentTarget.checked),
					SL.current_user.settings.save(["editor_snap"]),
					SL.analytics.trackEditor("Toggle Snap")
			});
		var n = this.settingsPrompt.getDOMElement().find("#editor-settings-developer-mode");
		n.prop("checked", SL.current_user.settings.get("developer_mode")),
			n.on("change", function (e) {
				SL.current_user.settings.set("developer_mode", e.currentTarget.checked),
					SL.current_user.settings.save(["developer_mode"]),
					SL.view.slideOptions.configure({
						html: e.currentTarget.checked
					}),
					SL.analytics.trackEditor("Toggle Developer Mode")
			})
	}
}), SL("editor.components.toolbars").Base = Class.extend({
	init: function () {
		this.render()
	},
	render: function () {
		this.domElement = $('<div class="toolbar">'),
			this.listElement = $('<div class="toolbar-list">').appendTo(this.domElement),
			this.scrollShadow = new SL.components.ScrollShadow({
				parentElement: this.domElement,
				contentElement: this.listElement,
				resizeContent: !1
			})
	},
	appendTo: function (e) {
		this.domElement.appendTo(e);
		this.scrollShadow.sync()
	},
	collapse: function () {
		this.getAllOptions().forEach(function (e) {
			"object" == typeof e.panel && e.panel.hide()
		})
	},
	sync: function () {
		this.getAllOptions().forEach(function (e) {
			"function" == typeof e.sync && e.sync()
		})
	},
	move: function (e, t) {
		this.domElement.css({
			left: e,
			top: t
		}),
			this.scrollShadow.sync()
	},
	measure: function () {
		var e = this.domElement.position();
		return {
			x: e.left,
			y: e.top,
			width: this.domElement.outerWidth(),
			height: this.domElement.outerHeight()
		}
	},
	hasOpenPanel: function () {
		return this.getAllOptions().some(function (e) {
			return !("object" != typeof e.panel || !e.panel.isVisible())
		})
	},
	getAllOptions: function () {
		var e = [];
		return "object" == typeof this.options && this.options.length && (e = e.concat(this.options), this.options.forEach(function (t) {
			"object" == typeof t.options && t.options.length && (e = e.concat(t.options))
		})),
			e
	},
	destroyAfter: function (e) {
		this.collapse(),
			clearTimeout(this.destroyTimeout),
			"number" == typeof e && (this.destroyTimeout = setTimeout(this.destroy.bind(this), e))
	},
	destroy: function () {
		this.domElement.remove(),
			this.scrollShadow.destroy()
	}
}), 
SL("editor.components.toolbars").AddSnippet = SL.editor.components.toolbars.Base.extend({
	init: function () {
		this._super()
	},
	render: function () {
		this._super(),
			this.domElement.attr("data-type", "add"),
			this.sync()
	},
	sync: function () {
		this._super();
		var e = SL.view.getCurrentTheme();
		if (e) {
			var t = e.get("snippets");
			t && !t.isEmpty() && t.forEach(function (e) {
				var t = $('<div class="toolbar-add-snippet-option">');
				t.text(e.get("title")),
					t.appendTo(this.listElement),
					t.on("vclick", this.onSnippetClicked.bind(this, e))
			}
				.bind(this))
		}
	},
	insert: function (e, t) {
		SL.editor.controllers.Blocks.add({
			type: "snippet",
			slide: e,
			afterInit: function (e) {
				e.setCustomHTML(t);
				e.resizeToFitContent()
			}
		})
	},
	onSnippetClicked: function (e) {
		var t = $(Reveal.getCurrentSlide());
		if (e.templateHasVariables()) {
			var i = SL.popup.open(SL.components.popup.InsertSnippet, {
				snippet: e
			});
			i.snippetInserted.add(function (e) {
				this.insert(t, e)
			}
				.bind(this))
		} else {
			var n = e.get("template").replace(SL.models.ThemeSnippet.TEMPLATE_SELECTION_TAG, "");
			this.insert(t, n)
		}
	}
}),

SL("editor.components.toolbars").Add = SL.editor.components.toolbars.Base.extend({
	init: function () {
		this._super()
	},
	render: function () {
		this._super(),
			this.domElement.attr("data-type", "add"),
			SL.config.BLOCKS.forEach(function (e) {
				if (!e.hidden) {
					var t = $(['<div class="toolbar-add-block-option" data-block-type="' + e.type + '">', '<span class="toolbar-add-block-option-icon icon i-' + e.icon + '"></span>', '<span class="toolbar-add-block-option-label">' + e.label + "</span>", "</div>"].join(""));
					this.bindOption(t, e),
						t.appendTo(this.listElement)
				}
			}
				.bind(this)),
			this.renderSnippets()
	},
	renderSnippets: function () {
		this.snippetsOptions = $(['<div class="toolbar-add-block-option">', '<span class="toolbar-add-block-option-icon icon i-document-alt-stroke"></span>', '<span class="toolbar-add-block-option-label">Snippet</span>', "</div>"].join("")),
			this.snippetsOptions.on("vclick", function () {
				SL.view.toolbars.push(new SL.editor.components.toolbars.AddSnippet)
			}
				.bind(this))
	},
	sync: function () {
		this._super();
		var e = SL.view.getCurrentTheme();
		e && e.get("snippets") && !e.get("snippets").isEmpty() ? this.snippetsOptions.appendTo(this.listElement) : this.snippetsOptions.detach()
	},
	bindOption: function (e, t) {
		function i() {
			l || (SL.editor.controllers.Blocks.add({
				type: t.type,
				blockOptions: {
					insertedFromToolbar: !0
				}
			}), SL.editor.controllers.History.pushLatest(), SL.analytics.trackEditor("Insert block", t.type))
		}
		function n(e) {
			a = !0,
				l = !1,
				s = e.clientX,
				$(document).on("mousemove", o),
				$(document).on("mouseup", r),
				e.preventDefault()
		}
		function o(e) {
			if (a && !l && e.clientX - s > 10) {
				l = !0;
				var i = SL.editor.controllers.Blocks.add({
					type: t.type,
					silent: !0,
					center: !1
				}),
					n = $(".reveal .slides").offset(),
					o = i.measure();
				i.move(e.clientX - n.left - o.width / 2, e.clientY - n.top - o.height / 2),
					i.onMouseDown(e),
					SL.analytics.trackEditor("Insert block via drag", t.type)
			}
			e.preventDefault()
		}
		function r() {
			$(document).off("mousemove", o),
				$(document).off("mouseup", r),
				a = !1,
				l = !1
		}
		var s = 0,
			a = !1,
			l = !1;
		e.on("vclick", i),
			SL.editor.controllers.Capabilities.isTouchEditor() || e.on("mousedown", n)
	}
}), SL("editor.components.toolbars").EditMultiple = SL.editor.components.toolbars.Base.extend({
	init: function () {
		this.options = [],
			this._super()
	},
	render: function () {
		this._super(),
			this.domElement.attr("data-type", "edit-multiple"),
			[SL.editor.components.toolbars.options.BlockAlignHorizontal, SL.editor.components.toolbars.options.BlockAlignVertical, SL.editor.components.toolbars.options.BlockLayout, SL.editor.components.toolbars.options.BlockDepth, SL.editor.components.toolbars.options.BlockActions].forEach(this.renderOption.bind(this))
	},
	renderOption: function (e) {
		var t = new e(SL.editor.controllers.Blocks.getFocusedBlocks()[0]);
		t.appendTo(this.listElement),
			this.options.push(t)
	},
	destroy: function () {
		for (; this.options.length;)
			this.options.pop().destroy();
		this._super()
	}
}), SL("editor.components.toolbars").Edit = SL.editor.components.toolbars.Base.extend({
	init: function (e) {
		this.block = e,
			this.options = [],
			this._super()
	},
	render: function () {
		this._super(),
			this.domElement.attr("data-type", "edit"),
			this.block.getToolbarOptions().forEach(this.renderOption.bind(this)),
			SL.editor.controllers.Capabilities.canUseCSSEditor() && SL.view.isDeveloperMode() && this.renderOption(SL.editor.components.toolbars.options.ClassName)
	},
	renderOption: function (e) {
		var t = new e(this.block);
		t.appendTo(this.listElement),
			t.changed && t.changed.add(this.sync.bind(this)),
			this.options.push(t)
	},
	appendTo: function () {
		this._super.apply(this, arguments),
			this.sync()
	},
	destroy: function () {
		for (; this.options.length;)
			this.options.pop().destroy();
		this._super()
	}
}), SL("editor.components.toolbars.groups").Base = Class.extend({
	init: function (e, t) {
		this.block = e,
			this.config = $.extend({
				label: "Group",
				items: [],
				expandable: !0
			}, t),
			this.options = [],
			this.render(),
			this.bind()
	},
	render: function () {
		this.domElement = $('<div class="toolbar-option toolbar-group">'),
			this.config.type && this.domElement.attr("data-group-type", this.config.type),
			this.config.expandable ? (this.triggerElement = $('<div class="toolbar-group-trigger">').appendTo(this.domElement), this.triggerElement.append('<span class="label">' + this.config.label + "</span>"), this.triggerElement.append('<span class="checkbox icon i-checkmark"></span>'), this.optionsElement = $('<div class="toolbar-group-options">').appendTo(this.domElement), this.optionsInnerElement = $('<div class="toolbar-group-options-inner">').appendTo(this.optionsElement)) : this.optionsInnerElement = $('<div class="toolbar-group-inner">').appendTo(this.domElement),
			this.config.items.forEach(this.renderOption.bind(this))
	},
	renderOption: function (e) {
		var t = new e(this.block);
		t.appendTo(this.optionsInnerElement),
			this.options.push(t)
	},
	bind: function () {
		this.domElement.find(".toolbar-group-trigger").on("vclick", this.onClicked.bind(this))
	},
	appendTo: function (e) {
		this.domElement.appendTo(e)
	},
	sync: function () {
		this.expand()
	},
	trigger: function () { },
	expand: function () {
		this.config.expandable && (this.domElement.addClass("expanded"), this.optionsElement.height(this.optionsInnerElement.prop("scrollHeight") + 2)),
			this.options.forEach(function (e) {
				"function" == typeof e.readFromBlock && e.readFromBlock()
			})
	},
	collapse: function () {
		this.domElement.removeClass("expanded"),
			this.optionsElement.height(0)
	},
	isExpanded: function () {
		return this.domElement.hasClass("expanded")
	},
	onClicked: function (e) {
		e.preventDefault(),
			this.trigger()
	},
	destroy: function () {
		for (; this.options.length;)
			this.options.pop().destroy();
		this.domElement.remove()
	}
}), SL("editor.components.toolbars.groups").Animation = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "animation",
			label: "Animation",
			items: [SL.editor.components.toolbars.options.AnimationType, SL.editor.components.toolbars.options.TransitionDuration, SL.editor.components.toolbars.options.TransitionDelay, SL.editor.components.toolbars.options.AnimationPreview]
		}, t))
	},
	sync: function () {
		this.block.isset("attribute.data-animation-type") ? this.expand() : this.collapse()
	},
	trigger: function () {
		if (this.block.isset("attribute.data-animation-type"))
			this.block.unset("attribute.data-animation-type"), this.block.unset("style.transition-duration"), this.block.unset("style.transition-delay");
		else {
			this.block.set("attribute.data-animation-type", this.block.getPropertySettings("attribute.data-animation-type").options[0].value);
			var e = SL.config.DEFAULT_SLIDE_TRANSITION_DURATION / 1e3 * .75,
				t = SL.config.DEFAULT_SLIDE_TRANSITION_DURATION / 1e3 * .75;
			/^(none|fade)$/gi.test(SL.current_deck.get("transition")) && (t = 0),
				this.block.isset("style.transition-duration") || this.block.set("style.transition-duration", e),
				this.block.isset("style.transition-delay") || this.block.set("style.transition-delay", t),
				this.block.isFragment() && this.block.removeFragment(),
				SL.analytics.trackEditor("Toolbar: Add animation")
		}
		this.sync()
	}
}), SL("editor.components.toolbars.groups").BorderCSS = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-css",
			label: "Border",
			items: [SL.editor.components.toolbars.options.BorderStyle, SL.editor.components.toolbars.options.BorderWidth, SL.editor.components.toolbars.options.BorderRadius, SL.editor.components.toolbars.options.BorderColor]
		}, t))
	},
	sync: function () {
		var e = this.block.get("style.border-style");
		e && "none" !== e ? this.expand() : this.collapse()
	},
	trigger: function () {
		this.block.isset("style.border-style") ? (this.block.unset("style.border-style"), this.block.unset("style.border-radius")) : (this.block.set("style.border-style", "solid"), this.block.isset("style.border-width") || this.block.set("style.border-width", 1), this.block.isset("style.border-color") || this.block.set("style.border-color", "#000000")),
			this.sync()
	}
}), SL("editor.components.toolbars.groups").BorderSVG = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-svg",
			label: "Border",
			items: [SL.editor.components.toolbars.options.ShapeStrokeWidth, SL.editor.components.toolbars.options.ShapeStrokeColor]
		}, t))
	},
	sync: function () {
		this.block.supportsStroke() ? (this.domElement.show(), this.block.hasStroke() ? (this.expand(), this.options.forEach(function (e) {
			e.readFromBlock()
		})) : this.collapse()) : this.domElement.hide()
	},
	trigger: function () {
		this.block.toggleStroke(),
			this.sync()
	}
}), SL("editor.components.toolbars.groups").LineType = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-type",
			expandable: !1,
			items: [SL.editor.components.toolbars.options.LineStartType, SL.editor.components.toolbars.options.LineEndType]
		}, t))
	}
}), SL("editor.components.toolbars.groups").Link = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "link",
			label: "link",
			items: [SL.editor.components.toolbars.options.LinkURL]
		}, t))
	},
	sync: function () {
		this.block.isLinked() ? this.expand() : this.collapse()
	},
	trigger: function () {
		this.block.setLinkURL(this.block.isLinked() ? null : ""),
			this.sync(),
			this.isExpanded() && !SL.editor.controllers.Capabilities.isTouchEditor() && this.options && this.options[0] && "function" == typeof this.options[0].focus && setTimeout(function () {
				this.options[0].focus()
			}
				.bind(this), 200)
	}
}), SL("editor.components.toolbars.groups").TableSize = SL.editor.components.toolbars.groups.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-size",
			expandable: !1,
			items: [SL.editor.components.toolbars.options.TableCols, SL.editor.components.toolbars.options.TableRows]
		}, t)),
			this.options[0].domElement.after('<div class="cross">x</div>'),
			this.setupBackfill(),
			this.setupPreview()
	},
	sync: function () {
		this._super(),
			this.refreshPreview()
	},
	setupBackfill: function () {
		this.options.forEach(function (e) {
			e.changeStarted.add(this.refreshBackfill.bind(this)),
				e.changeEnded.add(this.refreshBackfill.bind(this))
		}
			.bind(this))
	},
	refreshBackfill: function () {
		var e = this.options.some(function (e) {
			return e.isChanging()
		}
			.bind(this));
		e ? this.block.enableBackfill() : this.block.disableBackfill()
	},
	setupPreview: function () {
		this.canvasElement = $('<canvas class="table-preview"></canvas>').appendTo(this.domElement),
			this.canvas = this.canvasElement.get(0),
			this.canvasContext = this.canvas.getContext("2d"),
			this.refreshPreview = this.refreshPreview.bind(this),
			this.block.tableSizeChanged.add(this.refreshPreview),
			this.block.tableHeaderChanged.add(this.refreshPreview),
			this.options.forEach(function (e) {
				e.changed.add(this.refreshPreview)
			}
				.bind(this))
	},
	refreshPreview: function () {
		var e = Math.round(this.domElement.width()),
			t = Math.round(.8 * e);
		this.canvas.style.width = e + "px",
			this.canvas.style.height = t + "px",
			e *= 2,
			t *= 2,
			this.canvas.width = e,
			this.canvas.height = t,
			this.canvasContext.clearRect(0, 0, e, t);
		for (var i = this.block.get("attribute.data-table-cols"), n = this.block.get("attribute.data-table-rows"), o = this.block.get("attribute.data-table-has-header"), r = 4, s = e / i, a = t / n, l = 0; i > l; l++)
			for (var c = 0; n > c; c++)
				this.canvasContext.fillStyle = o && 0 === c ? "#555" : "#444", this.canvasContext.fillRect(l * s + r / 2, c * a + r / 2, s - r, a - r)
	},
	destroy: function () {
		this.block.tableSizeChanged && this.block.tableSizeChanged.remove(this.refreshPreview),
			this.options.forEach(function (e) {
				e.changed.remove(this.refreshPreview)
			}
				.bind(this)),
			this._super()
	}
}), SL("editor.components.toolbars.options").Base = Class.extend({
	init: function (e, t) {
		this.block = e,
			this.config = t || {},
			this.property = this.getPropertySettings(),
			this.render(),
			this.bind()
	},
	render: function () {
		if (this.domElement = $('<div class="toolbar-option">'), this.config.type && this.domElement.attr("data-option-type", this.config.type), this.config.tooltip && this.domElement.attr({
			"data-tooltip": this.config.tooltip,
			"data-tooltip-delay": 1e3,
			"data-tooltip-maxwidth": 200
		}), this.config.label && (this.domElement.append('<h4 class="toolbar-option-label">' + this.config.label + "</h4>"), this.config.helpTooltip)) {
			var e;
			e = $(this.config.helpTooltipLink ? '<a class="toolbar-option-help" href="' + this.config.helpTooltipLink + '" target="_blank">' : '<div class="toolbar-option-help">'),
				e.attr({
					"data-tooltip": this.config.helpTooltip,
					"data-tooltip-alignment": "r",
					"data-tooltip-maxwidth": 240
				}),
				e.html("?"),
				e.appendTo(this.domElement.find(".toolbar-option-label"))
		}
		this.config.description && this.domElement.append('<h5 class="toolbar-option-description">' + this.config.description + "</h5>")
	},
	bind: function () {
		this.config.shortcut && Mousetrap.bind(this.config.shortcut, function (e) {
			e.preventDefault(),
				this.trigger()
		}
			.bind(this)),
			this.domElement.on("vclick", this.onClicked.bind(this))
	},
	appendTo: function (e) {
		this.domElement.appendTo(e)
	},
	destroy: function () {
		this.domElement.remove()
	},
	getPropertySettings: function () {
		return this.block && "string" == typeof this.config.property ? this.block.getPropertySettings(this.config.property) : null
	},
	onClicked: function (e) {
		$(e.target).is(".toolbar-option-help, .toolbar-option-description a") || e.preventDefault()
	}
}), SL("editor.components.toolbars.options").Value = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, t),
			this.changed = new signals.Signal,
			this.value = this.getDefaultValue(),
			this.config.watchBlock && this.block.watch(this.config.property, this.onPropertyChanged)
	},
	bind: function () {
		this._super(),
			this.onPropertyChanged = this.onPropertyChanged.bind(this)
	},
	appendTo: function (e) {
		this._super(e),
			this.readFromBlock()
	},
	readFromBlock: function () {
		this.setValue(this.block.get(this.config.property))
	},
	writeToBlock: function () {
		this.isWritingToBlock = !0,
			this.block.set(this.config.property, this.getValue()),
			this.isWritingToBlock = !1
	},
	setValue: function (e, t) {
		this.value = e,
			t && (this.writeToBlock(), this.changed.dispatch(this.value))
	},
	getValue: function () {
		return this.value
	},
	getDefaultValue: function () {
		return this.block.getPropertyDefault(this.config.property)
	},
	getUnit: function () {
		return this.property.unit ? this.property.unit : ""
	},
	onPropertyChanged: function () {
		this.isWritingToBlock || this.readFromBlock()
	},
	destroy: function () {
		this.config.watchBlock && this.block && this.block.unwatch(this.config.property, this.onPropertyChanged),
			this.changed.dispose(),
			this._super()
	}
}), SL("editor.components.toolbars.options").Button = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, t)
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-button"),
			(this.config.title || this.config.icon) && (this.domElement.addClass("has-title"), this.titleElement = $('<div class="toolbar-option-title vcenter">').appendTo(this.domElement), this.config.title ? this.titleElement.html('<span class="title vcenter-target">' + this.config.title + "</span>") : this.config.icon && (this.domElement.addClass("is-icon"), this.titleElement.html('<span class="icon i-' + this.config.icon + ' vcenter-target"></span>'), this.config.activeIcon && (this.domElement.addClass("has-active-state"), this.activeElement = $('<div class="toolbar-option-title vcenter active">').appendTo(this.domElement), this.activeElement.html('<span class="icon i-' + this.config.activeIcon + ' vcenter-target"></span>'))))
	}
}), SL("editor.components.toolbars.options").Checkbox = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "checkbox"
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-checkbox"),
			this.checkboxElement = $('<span class="checkbox icon i-checkmark">'),
			this.checkboxElement.appendTo(this.domElement)
	},
	setValue: function (e, t) {
		this.domElement.toggleClass("checked", e),
			this._super(e, t)
	},
	getValue: function () {
		return this.domElement.hasClass("checked")
	},
	onClicked: function (e) {
		this._super(e),
			this.setValue(!this.getValue(), !0)
	}
}), SL("editor.components.toolbars.options").Color = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "color",
			alpha: !1
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-color"),
			this.triggerElement = $('<div class="toolbar-color-trigger">'),
			this.triggerElement.appendTo(this.domElement),
			this.triggerInnerElement = $('<div class="toolbar-color-trigger-inner">'),
			this.triggerInnerElement.appendTo(this.triggerElement),
			this.resetElement = $('<div class="toolbar-color-reset icon i-undo" data-tooltip="Use default color" data-tooltip-delay="500">'),
			this.resetElement.appendTo(this.triggerElement)
	},
	bind: function () {
		this._super(),
			this.triggerInnerElement.on("vclick", this.onTriggerClicked.bind(this)),
			this.resetElement.on("vclick", this.onResetClicked.bind(this))
	},
	readFromBlock: function () {
		this._super(),
			this.syncTriggerUI()
	},
	setValue: function (e, t) {
		this._super(e, t),
			this.syncTriggerUI()
	},
	syncTriggerUI: function () {
		var e = this.getTriggerColor();
		this.triggerElement.toggleClass("transparent", tinycolor(e).getAlpha() < 1),
			this.triggerInnerElement.css("background-color", e)
	},
	getTriggerColor: function () {
		return this.value
	},
	getColorpickerConfig: function () {
		return {
			anchor: this.triggerElement,
			alignment: "r",
			alpha: this.config.alpha,
			color: this.getValue(),
			changeCallback: this.setValue.bind(this),
			resetCallback: this.onResetClicked.bind(this)
		}
	},
	onPanelShown: function () {
		this.readFromBlock(),
			this.domElement.addClass("is-active")
	},
	onPanelHidden: function () {
		this.pickerWrapper.spectrum("saveCurrentSelection"),
			this.domElement.removeClass("is-active")
	},
	onTriggerClicked: function () {
		SL.view.colorpicker.toggle(this.getColorpickerConfig())
	},
	onResetClicked: function () {
		this.setValue(this.getDefaultValue() || "", !0),
			this.readFromBlock(),
			SL.view.colorpicker.hide()
	},
	destroy: function () {
		this._super()
	}
}), SL("editor.components.toolbars.options").Multi = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "multi",
			items: []
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-multi"),
			this.domElement.attr("data-number-of-items", this.config.items.length),
			this.innerElement = $('<div class="toolbar-multi-inner">').appendTo(this.domElement),
			this.config.items.forEach(function (e) {
				var t = $(['<div class="toolbar-multi-item" data-value="' + e.value + '">', e.icon ? '<span class="icon i-' + e.icon + '"></span>' : e.title, "</div>"].join(""));
				e.tooltip && t.attr("data-tooltip", e.tooltip),
					t.appendTo(this.innerElement)
			}
				.bind(this))
	},
	bind: function () {
		this._super(),
			this.domElement.find(".toolbar-multi-item").on("vclick", this.onListItemClicked.bind(this))
	},
	trigger: function () { },
	onListItemClicked: function (e) {
		var t = $(e.currentTarget).attr("data-value");
		t && this.trigger(t)
	}
}), SL("editor.components.toolbars.options").Radio = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "radio",
			items: []
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-radio"),
			this.domElement.attr("data-number-of-items", this.config.items.length),
			this.innerElement = $('<div class="toolbar-radio-inner">').appendTo(this.domElement),
			this.config.items.forEach(function (e) {
				this.innerElement.append(['<div class="toolbar-radio-item" data-value="' + e.value + '">', e.icon ? '<span class="icon i-' + e.icon + '"></span>' : e.title, "</div>"].join(""))
			}
				.bind(this))
	},
	bind: function () {
		this._super(),
			this.domElement.find(".toolbar-radio-item").on("vclick", this.onListItemClicked.bind(this))
	},
	setValue: function (e, t) {
		this.hasValue(e) && (this.domElement.find(".toolbar-radio-item").removeClass("selected"), this.domElement.find('.toolbar-radio-item[data-value="' + e + '"]').first().addClass("selected"), this._super(e, t))
	},
	hasValue: function (e) {
		return this.config.items.some(function (t) {
			return t.value === e
		})
	},
	onListItemClicked: function (e) {
		var t = $(e.currentTarget).attr("data-value");
		t && this.setValue(t, !0)
	}
}), SL("editor.components.toolbars.options").Range = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "range"
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-range"),
			this.rangeElement = $('<div class="range">'),
			this.rangeElement.appendTo(this.domElement),
			this.rangeProgressElement = $('<div class="range-progress">').appendTo(this.rangeElement),
			this.rangeNumericElement = $('<div class="range-numeric">').appendTo(this.rangeElement)
	},
	bind: function () {
		this._super(),
			this.changed = new signals.Signal,
			this.onMouseDown = this.onMouseDown.bind(this),
			this.onMouseMove = this.onMouseMove.bind(this),
			this.onMouseUp = this.onMouseUp.bind(this),
			this.rangeElement.on("vmousedown", this.onMouseDown)
	},
	setValue: function (e, t) {
		e = Math.max(Math.min(e, this.property.maxValue), this.property.minValue),
			this.rangeProgressElement.css("width", this.valueToPercent(e) + "%"),
			this._super(e, t),
			this.rangeNumericElement.text(this.getValue().toFixed(this.property.decimals) + this.getUnit())
	},
	getValue: function () {
		var e = this.percentToValue(parseInt(this.rangeProgressElement.get(0).style.width, 10)),
			t = Math.pow(10, this.property.decimals);
		return Math.round(e * t) / t
	},
	valueToPercent: function (e) {
		var t = (e - this.property.minValue) / (this.property.maxValue - this.property.minValue) * 100;
		return Math.max(Math.min(t, 100), 0)
	},
	percentToValue: function (e) {
		return this.property.minValue + e / 100 * (this.property.maxValue - this.property.minValue)
	},
	onMouseDown: function (e) {
		e.preventDefault(),
			$(document).on("vmousemove", this.onMouseMove),
			$(document).on("vmouseup", this.onMouseUp),
			this.onMouseMove(e),
			this.rangeElement.addClass("is-scrubbing")
	},
	onMouseMove: function (e) {
		var t = e.clientX - this.rangeElement.offset().left;
		this.setValue(this.percentToValue(t / this.rangeElement.width() * 100), !0),
			this.writeToBlock()
	},
	onMouseUp: function () {
		$(document).off("vmousemove", this.onMouseMove),
			$(document).off("vmouseup", this.onMouseUp),
			this.rangeElement.removeClass("is-scrubbing")
	}
}), SL("editor.components.toolbars.options").Select = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "select",
			panelType: "select",
			panelWidth: "auto",
			panelHeight: "auto",
			panelMaxHeight: 300,
			panelAlignment: "r",
			value: 0,
			items: []
		}, t)),
			this.keySearchString = "",
			this.keySearchTimeout
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-select"),
			this.triggerElement = $('<div class="toolbar-select-trigger">'),
			this.triggerElement.appendTo(this.domElement)
	},
	renderPanel: function () {
		this.panel = new SL.editor.components.toolbars.util.Panel({
			type: this.config.panelType,
			anchor: this.triggerElement,
			keydown: this.onKeyDown.bind(this),
			maxHeight: this.config.panelMaxHeight,
			width: this.config.panelWidth,
			height: this.config.panelHeight,
			alignment: this.config.panelAlignment
		}),
			this.panel.shown.add(this.onPanelShown.bind(this)),
			this.config.items.forEach(this.renderItem.bind(this)),
			this.getListElements().on("vclick", this.onListItemClicked.bind(this))
	},
	renderItem: function (e) {
		this.panel.contentElement.append('<div class="toolbar-select-item" data-value="' + e.value + '">' + (e.title || e.value) + "</div>")
	},
	setValue: function (e, t) {
		this.hasValue(e) && (this._super(e, t), this.displaySelectedValue(), this.getListElements().removeClass("selected"), this.getListElements().filter('[data-value="' + this.value + '"]').first().addClass("selected")),
			t && this.panel && this.panel.hide()
	},
	hasValue: function (e) {
		return this.config.items.some(function (t) {
			return t.value === e
		})
	},
	displaySelectedValue: function () {
		this.triggerElement.text(this.getTitleByValue(this.value))
	},
	clearFocus: function () {
		this.getListElements().removeClass("focused")
	},
	focusDefault: function () {
		var e = this.getListElements(),
			t = e.filter(".focused"),
			i = e.filter(".selected");
		0 === t.length && (i.length ? i.addClass("focused") : e.first().addClass("focused"))
	},
	focusItem: function (e) {
		e && e.length && (this.getListElements().removeClass("focused"), e.addClass("focused")),
			this.scrollIntoView()
	},
	focusStep: function (e) {
		this.focusDefault();
		var t = this.getListElements().filter(".focused");
		this.focusItem(0 > e ? t.prev() : t.next()),
			this.scrollIntoView()
	},
	focusByTitle: function (e) {
		var t = this.getListElements().filter(function (t, i) {
			return 0 === i.textContent.toLowerCase().indexOf(e.toLowerCase())
		});
		t.length && this.focusItem(t.first())
	},
	scrollIntoView: function () {
		var e = this.getListElements(),
			t = e.filter(".focused"),
			i = e.filter(".selected");
		t.length ? SL.util.dom.scrollIntoViewIfNeeded(t.get(0)) : i.length && SL.util.dom.scrollIntoViewIfNeeded(i.get(0))
	},
	getTitleByValue: function (e) {
		var t = null;
		return this.config.items.forEach(function (i) {
			i.value === e && (t = i.title)
		}),
			t
	},
	getDefaultValue: function () {
		return this.config.items[0].value
	},
	getListElements: function () {
		return this.panel ? this.panel.contentElement.find(".toolbar-select-item") : $()
	},
	onListItemClicked: function (e) {
		var t = $(e.currentTarget).attr("data-value");
		t && this.setValue(t, !0)
	},
	onPanelShown: function () {
		this.getListElements().removeClass("selected"),
			this.getListElements().filter('[data-value="' + this.getValue() + '"]').first().addClass("selected"),
			this.scrollIntoView(),
			this.clearFocus()
	},
	onClicked: function (e) {
		this._super(e),
			this.panel ? this.panel.toggle() : (this.renderPanel(), this.panel.show())
	},
	onKeyDown: function (e) {
		if (38 === e.keyCode || 9 === e.keyCode && e.shiftKey)
			this.focusStep(-1);
		else if (40 === e.keyCode || 9 === e.keyCode)
			this.focusStep(1);
		else if (13 === e.keyCode) {
			var t = this.getListElements().filter(".focused").attr("data-value");
			t && this.setValue(t, !0)
		} else if (27 === e.keyCode)
			this.panel.hide();
		else {
			var i = String.fromCharCode(e.keyCode);
			i.match(/[A-Z0-9#\+]/i) && (clearTimeout(this.keySearchTimeout), this.keySearchTimeout = setTimeout(function () {
				this.keySearchString = ""
			}
				.bind(this), 500), this.keySearchString += i, this.focusByTitle(this.keySearchString))
		}
		return !1
	},
	destroy: function () {
		this.panel && (this.panel.destroy(), this.panel = null),
			this._super()
	}
}), SL("editor.components.toolbars.options").SelectLineType = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			panelWidth: 75,
			panelMaxHeight: 430,
			panelAlignment: "b"
		}, t))
	},
	renderItem: function (e) {
		var t = $('<div class="toolbar-select-item" data-value="' + e.value + '">');
		t.appendTo(this.panel.contentElement),
			this.createPreviewSVG(t, e.value, 59, 40)
	},
	displaySelectedValue: function () {
		this.triggerElement.find("svg").remove(),
			this.createPreviewSVG(this.triggerElement, this.value, 44, 40)
	},
	createPreviewSVG: function (e, t, i, n) {
		var o = document.createElementNS(SL.util.svg.NAMESPACE, "svg");
		o.setAttribute("xmlns", SL.util.svg.NAMESPACE),
			o.setAttribute("version", "1.1"),
			o.setAttribute("width", i),
			o.setAttribute("height", n),
			o.setAttribute("viewBox", "0 0 " + i + " " + n),
			o.setAttribute("preserveAspectRatio", "xMidYMid"),
			SL.editor.blocks.Line.generate(o, {
				interactive: !1,
				startType: "line-start-type" === this.config.type ? t : null,
				endType: "line-end-type" === this.config.type ? t : null,
				color: "#333333",
				width: 6,
				x1: 0,
				y1: n / 2,
				x2: i,
				y2: n / 2
			}),
			e.append(o)
	}
}), SL("editor.components.toolbars.options").Stepper = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "stepper",
			progressbar: !0,
			loop: !1
		}, t)),
			this.valueRange = this.property.maxValue - this.property.minValue,
			this.stepSize = this.valueRange < 1 ? this.valueRange / 200 : 1,
			this.property.stepSize && (this.stepSize = this.property.stepSize),
			this.changing = !1,
			this.mouseDownValue = 0,
			this.mouseDownX = 0
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-stepper"),
			this.stepperElement = $('<div class="stepper">'),
			this.stepperElement.appendTo(this.domElement),
			this.config.progressbar && (this.progressbar = $('<div class="stepper-progress">').appendTo(this.stepperElement)),
			this.numberInput = $('<input type="text" class="stepper-number">').appendTo(this.stepperElement)
	},
	bind: function () {
		this._super(),
			this.changeStarted = new signals.Signal,
			this.changeEnded = new signals.Signal,
			this.onMouseDown = this.onMouseDown.bind(this),
			this.onMouseMove = this.onMouseMove.bind(this),
			this.onMouseUp = this.onMouseUp.bind(this),
			this.stepperElement.on("vmousedown", this.onMouseDown),
			this.numberInput.on("input", this.onInput.bind(this)),
			this.numberInput.on("keydown", this.onInputKeyDown.bind(this)),
			this.numberInput.on("focus", this.onInputFocused.bind(this)),
			this.numberInput.on("blur", this.onInputBlurred.bind(this))
	},
	setValue: function (e, t, i) {
		if (isNaN(e) && (e = this.value), this.value = e, this.config.loop && (this.value < this.property.minValue && (this.value = this.property.maxValue + this.value % (this.property.maxValue - this.property.minValue)), this.value > this.property.minValue && (this.value = this.property.minValue + this.value % (this.property.maxValue - this.property.minValue))), this.value = Math.max(Math.min(this.value, this.property.maxValue), this.property.minValue), this.value = this.roundValue(this.value), !i) {
			var n = this.value;
			this.property.decimals > 0 && (n = n.toFixed(this.property.decimals)),
				this.property.unit && !this.property.unitHidden && (n += this.property.unit),
				this.numberInput.val(n)
		}
		if (this.progressbar) {
			var o = this.valueToPercent(this.value) / 100;
			this.progressbar.css("transform", "scaleX(" + o + ")")
		}
		this._super(this.value, t)
	},
	roundValue: function (e) {
		var t = Math.pow(10, this.property.decimals);
		return Math.round(e * t) / t
	},
	valueToPercent: function (e) {
		var t = (e - this.property.minValue) / (this.property.maxValue - this.property.minValue) * 100;
		return Math.max(Math.min(t, 100), 0)
	},
	isChanging: function () {
		return this.changing
	},
	onChangeStart: function () {
		this.isChanging() || (this.stepperElement.addClass("is-changing"), this.changing = !0, this.changeStarted.dispatch())
	},
	onChangeEnd: function () {
		this.isChanging() && (this.stepperElement.removeClass("is-changing"), this.changing = !1, this.changeEnded.dispatch())
	},
	onMouseDown: function (e) {
		this.numberInput.is(":focus") || e.preventDefault(),
			$(document).on("vmousemove", this.onMouseMove),
			$(document).on("vmouseup", this.onMouseUp),
			this.mouseDownX = e.clientX,
			this.mouseDownValue = this.getValue(),
			this.onChangeStart()
	},
	onMouseMove: function (e) {
		this.stepperElement.addClass("is-scrubbing");
		var t = e.clientX - this.mouseDownX;
		1 === this.stepSize && this.valueRange < 15 ? t *= .25 : 1 === this.stepSize && this.valueRange < 30 ? t *= .5 : 1 === this.stepSize && this.valueRange > 150 && (t *= 1.5),
			this.setValue(this.mouseDownValue + t * this.stepSize, !0),
			this.writeToBlock()
	},
	onMouseUp: function (e) {
		$(document).off("vmousemove", this.onMouseMove),
			$(document).off("vmouseup", this.onMouseUp),
			this.stepperElement.hasClass("is-scrubbing") === !1 ? this.onClick(e) : this.onChangeEnd(),
			this.stepperElement.removeClass("is-scrubbing")
	},
	onClick: function () {
		this.numberInput.focus()
	},
	onInput: function () {
		this.setValue(parseFloat(this.numberInput.val()), !0, !0),
			this.writeToBlock()
	},
	onInputKeyDown: function (e) {
		var t = 0;
		38 === e.keyCode ? t = this.stepSize : 40 === e.keyCode && (t = -this.stepSize),
			t && (e.shiftKey && (t *= 10), this.setValue(this.getValue() + t, !0), this.writeToBlock(), e.preventDefault())
	},
	onInputFocused: function () {
		this.onChangeStart()
	},
	onInputBlurred: function () {
		this.onChangeEnd(),
			this.setValue(this.getValue(), !0)
	},
	destroy: function () {
		this.changeStarted.dispose(),
			this.changeEnded.dispose(),
			this._super()
	}
}), SL("editor.components.toolbars.options").Text = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "text",
			multiline: !1,
			expandable: !1,
			maxlength: 255,
			placeholder: ""
		}, t))
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-text"),
			this.config.multiline ? (this.inputElement = $("<textarea></textarea>"), this.config.expandable && (this.expandElement = $('<div class="expand-button icon i-fullscreen"></div>'), this.expandElement.appendTo(this.domElement))) : this.inputElement = $("<input />"),
			this.inputElement.attr({
				"class": "toolbar-text-input",
				maxlength: this.config.maxlength,
				placeholder: this.config.placeholder
			}),
			this.inputElement.appendTo(this.domElement)
	},
	bind: function () {
		this._super(),
			this.inputElement.on("input", this.onInputChange.bind(this)),
			this.expandElement && this.expandElement.on("vclick", this.onExpandClicked.bind(this))
	},
	focus: function () {
		this.inputElement.focus()
	},
	expand: function () {
		this.editor || (this.editor = new SL.components.TextEditor({
			type: "code",
			value: this.getValue()
		}), this.editor.saved.add(function (e) {
			this.setValue(e),
				this.writeToBlock(),
				this.editor = null
		}
			.bind(this)), this.editor.canceled.add(function () {
				this.editor = null
			}
				.bind(this)))
	},
	destroy: function () {
		this.editor && (this.editor.destroy(), this.editor = null),
			this._super()
	},
	setValue: function (e) {
		this.inputElement.val(e),
			this._super(e)
	},
	getValue: function () {
		return this.inputElement.val()
	},
	onInputChange: function () {
		this.writeToBlock()
	},
	onExpandClicked: function () {
		this.expand()
	}
}), SL("editor.components.toolbars.options").Toggle = SL.editor.components.toolbars.options.Value.extend({
	init: function (e, t) {
		this._super(e, t)
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-toggle")
	},
	bind: function () {
		this._super()
	},
	setValue: function (e, t) {
		this.domElement.attr("data-value", e),
			this._super(e, t)
	},
	onClicked: function (e) {
		e.preventDefault(),
			this.setValue(!this.getValue(), !0)
	}
}), SL("editor.components.toolbars.options").AnimationPreview = SL.editor.components.toolbars.options.Button.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			title: "Preview"
		}, t))
	},
	onClicked: function (e) {
		this._super(e);
		var t = $(Reveal.getCurrentSlide());
		t.addClass("no-transition").removeClass("present"),
			SL.util.dom.calculateStyle(t),
			t.removeClass("no-transition").addClass("present")
	}
}), SL("editor.components.toolbars.options").AnimationType = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "animation-type",
			label: "Effect",
			property: "attribute.data-animation-type",
			items: e.getPropertySettings("attribute.data-animation-type").options
		}, t))
	},
	renderPanel: function () {
		this._super.apply(this, arguments),
			this.previewElement = $('<div class="animation-preview"></div>'),
			this.previewElement.appendTo(this.panel.domElement),
			this.previewInnerElement = $('<div class="animation-preview-inner"></div>'),
			this.previewInnerElement.appendTo(this.previewElement),
			this.panel.getContentElement().on("mouseleave", this.onPanelMouseOut.bind(this)),
			this.getListElements().on("mouseenter", this.onItemMouseOver.bind(this))
	},
	onItemMouseOver: function (e) {
		var t = $(e.currentTarget).attr("data-value");
		t && (this.previewElement.addClass("visible"), this.previewInnerElement.attr("data-animation-type", t).css("transition-duration", "").removeClass("animate"), setTimeout(function () {
			this.previewInnerElement.css("transition-duration", this.block.get("style.transition-duration") + "s").addClass("animate")
		}
			.bind(this), 100))
	},
	onPanelMouseOut: function () {
		this.previewElement.removeClass("visible")
	}
}), SL("editor.components.toolbars.options").Back = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "back",
			icon: "arrow-up",
			tooltip: "Go back"
		}, t))
	},
	onClicked: function (e) {
		this._super(e),
			SL.view.toolbars.pop()
	}
}), SL("editor.components.toolbars.options").BackgroundColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "background-color",
			label: "Background Color",
			property: "style.background-color",
			alpha: !0
		}, t))
	},
	getColorpickerConfig: function () {
		var e = this._super.apply(this, arguments),
			t = tinycolor(this.getValue()).toRgb();
		return 0 === t.r && 0 === t.g && 0 === t.b && 0 === t.a && (e.color = "#000000"),
			e
	}
}), SL("editor.components.toolbars.options").BlockActions = SL.editor.components.toolbars.options.Multi.extend({
	init: function (e, t) {
		var i = [{
			value: "duplicate",
			icon: "new-window",
			tooltip: "Duplicate"
		}, {
			value: "delete",
			icon: "trash-fill",
			tooltip: "Delete"
		}
		];
		e && e.options.horizontalResizing && e.options.verticalResizing && i.unshift({
			value: "expand",
			icon: "fullscreen",
			tooltip: "Maximize"
		}),
			e && e.hasPlugin(SL.editor.blocks.plugin.HTML) && i.unshift({
				value: "html",
				icon: "file-xml",
				tooltip: "Edit HTML"
			}),
			this._super(e, $.extend({
				type: "block-actions",
				label: "Actions",
				items: i
			}, t))
	},
	trigger: function (e) {
		var t = SL.editor.controllers.Blocks.getFocusedBlocks();
		if ("html" === e)
			t[0].editHTML(), SL.analytics.trackEditor("Toolbar: Edit HTML");
		else if ("expand" === e) {
			var i = SL.util.deck.getSlideSize();
			t.forEach(function (e) {
				e.resize({
					width: i.width,
					height: i.height
				}),
					e.moveToCenter()
			}),
				SL.editor.controllers.History.pushLatest(),
				SL.analytics.trackEditor("Toolbar: Expand block")
		} else
			"duplicate" === e ? (SL.editor.controllers.Blocks.copy(), SL.editor.controllers.Blocks.paste(), SL.editor.controllers.History.pushLatest(), SL.analytics.trackEditor("Toolbar: Duplicate block")) : "delete" === e && (t.forEach(function (e) {
				e.destroy()
			}), SL.editor.controllers.History.pushLatest(), SL.analytics.trackEditor("Toolbar: Delete block"))
	}
}), SL("editor.components.toolbars.options").BlockAlignHorizontal = SL.editor.components.toolbars.options.Multi.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "block-align-horizontal",
			label: "Alignment",
			items: [{
				value: "left",
				icon: "alignleftedges"
			}, {
				value: "horizontal-center",
				icon: "alignhorizontalcenters"
			}, {
				value: "right",
				icon: "alignrightedges"
			}
			]
		}, t))
	},
	trigger: function (e) {
		this._super(e),
			SL.editor.controllers.Blocks.align(SL.editor.controllers.Blocks.getFocusedBlocks(), e)
	}
}), SL("editor.components.toolbars.options").BlockAlignVertical = SL.editor.components.toolbars.options.Multi.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "block-align-vertical",
			items: [{
				value: "top",
				icon: "aligntopedges"
			}, {
				value: "vertical-center",
				icon: "alignverticalcenters"
			}, {
				value: "bottom",
				icon: "alignbottomedges"
			}
			]
		}, t))
	},
	trigger: function (e) {
		this._super(e),
			SL.editor.controllers.Blocks.align(SL.editor.controllers.Blocks.getFocusedBlocks(), e)
	}
}), SL("editor.components.toolbars.options").BlockDepth = SL.editor.components.toolbars.options.Multi.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "block-depth",
			label: "Depth",
			items: [{
				value: "back",
				icon: "arrow-down",
				tooltip: "Move to back"
			}, {
				value: "front",
				icon: "arrow-up",
				tooltip: "Move to front"
			}
			]
		}, t))
	},
	trigger: function (e) {
		"front" === e ? SL.editor.controllers.Blocks.moveBlocksToDepth(SL.editor.controllers.Blocks.getFocusedBlocks(), 1e4) : "back" === e && SL.editor.controllers.Blocks.moveBlocksToDepth(SL.editor.controllers.Blocks.getFocusedBlocks(), 0)
	}
}), SL("editor.components.toolbars.options").BlockLayout = SL.editor.components.toolbars.options.Multi.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "block-layout",
			label: "Layout",
			items: [{
				value: "row",
				icon: "ellipsis-h",
				tooltip: "Row"
			}, {
				value: "column",
				icon: "ellipsis-v",
				tooltip: "Column"
			}
			]
		}, t))
	},
	trigger: function (e) {
		var t = 0,
			i = SL.prompt({
				anchor: this.innerElement,
				alignment: "r",
				title: "Spacing between each element",
				type: "range",
				cancelLabel: "",
				confirmLabel: "Done",
				data: {
					value: t,
					minValue: 0,
					maxValue: 300,
					unit: "px",
					width: 250
				}
			});
		SL.editor.controllers.Blocks.layout(SL.editor.controllers.Blocks.getFocusedBlocksInVisualOrder(), e, t),
			i.rangeInput.changed.add(function (i) {
				i = parseFloat(i),
					("number" != typeof i || isNaN(i)) && (i = t),
					SL.editor.controllers.Blocks.layout(SL.editor.controllers.Blocks.getFocusedBlocksInVisualOrder(), e, i)
			}
				.bind(this))
	}
}), SL("editor.components.toolbars.options").BorderColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-color",
			label: "Color",
			property: "style.border-color"
		}, t))
	}
}), SL("editor.components.toolbars.options").BorderRadius = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-radius",
			label: "Radius",
			property: "style.border-radius"
		}, t))
	}
}), SL("editor.components.toolbars.options").BorderStyle = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-style",
			label: "Style",
			property: "style.border-style",
			items: e.getPropertySettings("style.border-style").options
		}, t))
	}
}), SL("editor.components.toolbars.options").BorderWidth = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "border-width",
			label: "Width",
			property: "style.border-width"
		}, t))
	}
}), SL("editor.components.toolbars.options").ClassName = SL.editor.components.toolbars.options.Text.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "class-name",
			label: "Class name",
			property: "attribute.class",
			helpTooltip: "Adds a class name to the underlying HTML element. Useful when trying to target elements with custom CSS."
		}, t))
	}
}), SL("editor.components.toolbars.options").CodeLanguage = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "code-language",
			label: "Language",
			property: "code.language",
			items: e.getPropertySettings("code.language").options,
			panelMaxHeight: 400
		}, t))
	}
}), SL("editor.components.toolbars.options").CodeTheme = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "code-theme",
			label: "Theme",
			property: "code.theme",
			items: e.getPropertySettings("code.theme").options,
			panelType: "code-theme",
			panelWidth: 180,
			panelMaxHeight: 500
		}, t))
	}
}), SL("editor.components.toolbars.options").Code = SL.editor.components.toolbars.options.Text.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "code",
			label: "Code",
			property: "code.value",
			placeholder: "Paste code to syntax highlight...",
			multiline: !0,
			expandable: !0,
			maxlength: 1e7
		}, t))
	},
	bind: function () {
		this._super(),
			this.block && (this.onEditingRequested = this.onEditingRequested.bind(this), this.block.editingRequested.add(this.onEditingRequested))
	},
	destroy: function () {
		this.block && this.block.editingRequested.remove(this.onEditingRequested),
			this._super()
	},
	onEditingRequested: function () {
		this.expand()
	}
}), SL("editor.components.toolbars.options").Divider = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "divider"
		}, t)),
			this.domElement.addClass("toolbar-divider")
	}
}), SL("editor.components.toolbars.options").HTML = SL.editor.components.toolbars.options.Button.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			title: "Edit HTML",
			property: "html.value"
		}, t))
	},
	onClicked: function (e) {
		this._super(e),
			this.block.editHTML()
	}
}), SL("editor.components.toolbars.options").IframeAutoplay = SL.editor.components.toolbars.options.Checkbox.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "iframe-autoplay",
			label: "Autoplay",
			property: "iframe.autoplay"
		}, t)),
			this.updateVisibility()
	},
	bind: function () {
		this._super(),
			this.block && (this.updateVisibility = this.updateVisibility.bind(this), this.block.iframeSourceChanged.add(this.updateVisibility))
	},
	setValue: function (e, t) {
		this._super(e, t)
	},
	updateVisibility: function () {
		var e = this.block.get("iframe.src");
		e && (/^.*(youtube\.com\/embed\/)/.test(e) || /^.*(player\.vimeo.com\/)/.test(e)) ? this.domElement.show() : this.domElement.hide()
	},
	destroy: function () {
		this.block && !this.block.destroyed && this.block.iframeSourceChanged.remove(this.updateVisibility),
			this._super()
	}
}), SL("editor.components.toolbars.options").IframeSRC = SL.editor.components.toolbars.options.Text.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "iframe-src",
			label: "Iframe Source",
			property: "iframe.src",
			placeholder: "URL or <iframe>...",
			multiline: !0,
			maxlength: 2e3
		}, t))
	},
	bind: function () {
		this._super(),
			this.block && (this.onEditingRequested = this.onEditingRequested.bind(this), this.block.editingRequested.add(this.onEditingRequested))
	},
	destroy: function () {
		this.block && this.block.editingRequested.remove(this.onEditingRequested),
			this._super()
	},
	writeToBlock: function () {
		var e = this.getValue().trim();
		SL.util.string.URL_REGEX.test(e) ? this.block.set(this.config.property, e) : this.block.set(this.config.property, "")
	},
	onInputChange: function () {
		var e = this.getValue();
		if (/<iframe/gi.test(e))
			try {
				this.setValue($(e).attr("src"))
			} catch (t) { }
		this.writeToBlock()
	},
	onEditingRequested: function () {
		this.focus()
	}
}), SL("editor.components.toolbars.options").ImageInlineSVG = SL.editor.components.toolbars.options.Checkbox.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "image-inline-svg",
			label: "Inline SVG",
			property: "attribute.data-inline-svg"
		}, t)),
			this.sync = this.sync.bind(this),
			e.imageURLChanged.add(this.sync)
	},
	sync: function () {
		this.block.isSVG() ? this.domElement.show() : this.domElement.hide()
	},
	destroy: function () {
		this.block.imageURLChanged && this.block.imageURLChanged.remove(this.sync),
			this._super()
	}
}), SL("editor.components.toolbars.options").Image = SL.editor.components.toolbars.options.Base.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "image",
			labe: "Image"
		}, t)),
			this.syncUI()
	},
	render: function () {
		this._super(),
			this.domElement.addClass("toolbar-image"),
			this.innerElement = $('<div class="toolbar-image-inner">').appendTo(this.domElement),
			this.placeholderElement = $('<div class="toolbar-image-placeholder">').appendTo(this.innerElement),
			this.labelElement = $('<div class="toolbar-image-label">Select</div>').appendTo(this.innerElement),
			this.urlElement = $('<div class="toolbar-image-url icon i-link"></div>').appendTo(this.innerElement),
			this.spinnerElement = $(['<div class="toolbar-image-progress">', '<span class="spinner centered"></span>', "</div>"].join("")).appendTo(this.innerElement)
	},
	bind: function () {
		this._super(),
			this.onMediaLibrarySelection = this.onMediaLibrarySelection.bind(this),
			this.syncUI = this.syncUI.bind(this),
			this.block.imageStateChanged.add(this.syncUI),
			this.innerElement.on("vclick", function (e) {
				if (0 === $(e.target).closest(".toolbar-image-url").length) {
					var t = SL.popup.open(SL.components.medialibrary.MediaLibrary, {
						select: SL.models.Media.IMAGE
					});
					t.selected.addOnce(this.onMediaLibrarySelection)
				} else
					this.onEditURLClicked(e)
			}
				.bind(this))
	},
	syncUI: function () {
		if (this.block.hasImage()) {
			var e = this.block.get("image.src");
			this.innerElement.css("background-image", 'url("' + e + '")', ""),
				this.placeholderElement.hide(),
				this.urlElement.toggle(0 !== e.search(SL.config.S3_HOST))
		} else
			this.innerElement.css("background-image", ""), this.placeholderElement.show(), this.urlElement.show();
		this.block.isLoading() || this.block.isUploading() ? (this.spinnerElement.show(), SL.util.html.generateSpinners()) : this.spinnerElement.hide()
	},
	onEditURLClicked: function (e) {
		e.preventDefault();
		var t = SL.prompt({
			anchor: this.urlElement,
			title: "Image URL",
			type: "input",
			confirmLabel: "Save",
			alignment: "r",
			data: {
				value: this.block.get("image.src"),
				placeholder: "http://...",
				width: 400
			}
		});
		t.confirmed.add(function (e) {
			this.block.set("image.src", e),
				this.syncUI()
		}
			.bind(this))
	},
	onMediaLibrarySelection: function (e) {
		this.block.setImageModel(e),
			this.syncUI()
	},
	destroy: function () {
		this.block.imageStateChanged && this.block.imageStateChanged.remove(this.syncUI),
			this._super()
	}
}), SL("editor.components.toolbars.options").LetterSpacing = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "letter-spacing",
			label: "Letter spacing",
			property: "style.letter-spacing",
			progressbar: !1
		}, t))
	}
}), SL("editor.components.toolbars.options").LineColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-color",
			label: "Color",
			property: "attribute.data-line-color"
		}, t))
	}
}), SL("editor.components.toolbars.options").LineEndType = SL.editor.components.toolbars.options.SelectLineType.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-end-type",
			panelType: "line-end-type",
			label: "End",
			property: "attribute.data-line-end-type",
			items: e.getPropertySettings("attribute.data-line-end-type").options
		}, t))
	}
}), SL("editor.components.toolbars.options").LineHeight = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-height",
			label: "Line Height",
			property: "style.line-height",
			progressbar: !1
		}, t))
	}
}), SL("editor.components.toolbars.options").LineStartType = SL.editor.components.toolbars.options.SelectLineType.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-start-type",
			panelType: "line-start-type",
			label: "Start",
			property: "attribute.data-line-start-type",
			items: e.getPropertySettings("attribute.data-line-start-type").options
		}, t))
	}
}), SL("editor.components.toolbars.options").LineStyle = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-style",
			panelType: "line-style",
			panelWidth: "auto",
			panelAlignment: "b",
			label: "Style",
			property: "attribute.data-line-style",
			items: e.getPropertySettings("attribute.data-line-style").options
		}, t))
	},
	renderItem: function (e) {
		var t = $('<div class="toolbar-select-item" data-value="' + e.value + '">');
		t.appendTo(this.panel.contentElement),
			this.createPreviewSVG(t, e.value, 126, 40)
	},
	displaySelectedValue: function () {
		this.triggerElement.find("svg").remove(),
			this.createPreviewSVG(this.triggerElement, this.value, 126, 40)
	},
	createPreviewSVG: function (e, t, i, n) {
		var o = document.createElementNS(SL.util.svg.NAMESPACE, "svg");
		o.setAttribute("xmlns", SL.util.svg.NAMESPACE),
			o.setAttribute("version", "1.1"),
			o.setAttribute("width", i),
			o.setAttribute("height", n),
			o.setAttribute("viewBox", "0 0 " + i + " " + n),
			o.setAttribute("preserveAspectRatio", "xMidYMid"),
			SL.editor.blocks.Line.generate(o, {
				interactive: !1,
				startType: null,
				endType: null,
				style: t,
				color: "#333333",
				width: 6,
				x1: 0,
				y1: n / 2,
				x2: i,
				y2: n / 2
			}),
			e.append(o)
	}
}), SL("editor.components.toolbars.options").LineWidth = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "line-width",
			label: "Thickness",
			property: "attribute.data-line-width"
		}, t))
	}
}), SL("editor.components.toolbars.options").LinkURL = SL.editor.components.toolbars.options.Text.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "link-url",
			property: "link.href",
			placeholder: "http://"
		}, t))
	},
	writeToBlock: function () {
		var e = this.getValue().trim();
		SL.util.string.URL_REGEX.test(e) || /^#\/\d/.test(e) ? this.block.set(this.config.property, e) : this.block.set(this.config.property, "")
	}
}), SL("editor.components.toolbars.options").MathColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "math-color",
			label: "Color",
			property: "style.color"
		}, t))
	}
}), SL("editor.components.toolbars.options").MathInput = SL.editor.components.toolbars.options.Text.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "math",
			label: "Math",
			description: 'Display TeX math formulae. Inline math is also available. <a href="http://help.slides.com/knowledgebase/articles/446424" target="_blank">Learn more</a>',
			property: "math.value",
			placeholder: "Type/paste TeX...",
			multiline: !0,
			expandable: !0,
			maxlength: 1e7
		}, t))
	},
	bind: function () {
		this._super(),
			this.block && (this.onEditingRequested = this.onEditingRequested.bind(this), this.block.editingRequested.add(this.onEditingRequested))
	},
	destroy: function () {
		this.block && this.block.editingRequested.remove(this.onEditingRequested),
			this._super()
	},
	onEditingRequested: function () {
		this.expand()
	}
}), SL("editor.components.toolbars.options").MathSize = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "text-size",
			label: "Scale",
			property: "style.font-size"
		}, t))
	},
	setValue: function () {
		if (this._super.apply(this, arguments), this.measurementsBeforeResize) {
			var e = this.block.measure(),
				t = this.measurementsBeforeResize.x + (this.measurementsBeforeResize.width - e.width) / 2,
				i = this.measurementsBeforeResize.y + (this.measurementsBeforeResize.height - e.height) / 2;
			isNaN(t) || isNaN(i) || this.block.move(t, i)
		}
	},
	onChangeStart: function () {
		this.measurementsBeforeResize = this.block.measure(),
			this._super.apply(this, arguments)
	},
	onChangeEnd: function () {
		this.measurementsBeforeResize = null,
			this._super.apply(this, arguments)
	}
}), SL("editor.components.toolbars.options").Opacity = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "opacity",
			label: "Opacity",
			property: "style.opacity"
		}, t))
	}
}), SL("editor.components.toolbars.options").Padding = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "padding",
			label: "Padding",
			property: "style.padding"
		}, t))
	},
	syncPaddingHint: function () {
		this.isChanging() ? this.block.showPaddingHint() : this.block.hidePaddingHint()
	},
	writeToBlock: function () {
		this._super.apply(this, arguments),
			this.syncPaddingHint()
	},
	onMouseMove: function () {
		this._super.apply(this, arguments),
			this.syncPaddingHint()
	},
	onMouseUp: function () {
		this._super.apply(this, arguments),
			this.syncPaddingHint()
	},
	onInputFocused: function () {
		this._super.apply(this, arguments),
			this.syncPaddingHint()
	},
	onInputBlurred: function () {
		this._super.apply(this, arguments),
			this.syncPaddingHint()
	}
}), SL("editor.components.toolbars.options").Rotation = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "rotation",
			label: "Rotation",
			property: "transform.rotate",
			watchBlock: !0,
			loop: !0,
			progressbar: !1
		}, t)),
			this.propertyChanged
	}
}), SL("editor.components.toolbars.options").ShapeFillColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "shape-fill-color",
			label: "Color",
			property: "attribute.data-shape-fill-color",
			alpha: !0
		}, t))
	}
}), SL("editor.components.toolbars.options").ShapeStretch = SL.editor.components.toolbars.options.Checkbox.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "shape-stretch",
			label: "Stretch to Fill",
			property: "attribute.data-shape-stretch"
		}, t))
	}
}), SL("editor.components.toolbars.options").ShapeStrokeColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "shape-stroke-color",
			label: "Color",
			property: "attribute.data-shape-stroke-color"
		}, t))
	}
}), SL("editor.components.toolbars.options").ShapeStrokeWidth = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "shape-stroke-width",
			label: "Width",
			property: "attribute.data-shape-stroke-width"
		}, t))
	}
}), SL("editor.components.toolbars.options").ShapeType = SL.editor.components.toolbars.options.Select.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "shape-type",
			panelType: "shape-type",
			panelWidth: 246,
			panelMaxHeight: 430,
			label: "Shape",
			property: "attribute.data-shape-type",
			items: e.getPropertySettings("attribute.data-shape-type").options
		}, t))
	},
	renderPanel: function () {
		this._super.apply(this, arguments),
			this.renderAttribution()
	},
	renderItem: function (e) {
		var t = 32,
			i = 32,
			n = document.createElementNS(SL.util.svg.NAMESPACE, "svg");
		n.setAttribute("xmlns", SL.util.svg.NAMESPACE),
			n.setAttribute("version", "1.1"),
			n.setAttribute("width", t),
			n.setAttribute("height", i),
			n.setAttribute("preserveAspectRatio", "xMidYMid");
		var o = SL.editor.blocks.Shape.shapeFromType(e.value);
		o.setAttribute("fill", "#333333"),
			n.appendChild(o);
		var r = $('<div class="toolbar-select-item" data-value="' + e.value + '">');
		r.append(n),
			r.appendTo(this.panel.contentElement);
		var s = SL.util.svg.boundingBox(o);
		n.setAttribute("viewBox", [Math.round(s.x) || 0, Math.round(s.y) || 0, Math.round(s.width) || 32, Math.round(s.height) || 32].join(" "))
	},
	renderAttribution: function () {
		var e = $('<div class="toolbar-select-attribution">');
		e.html('<a href="/about#credits" target="_blank">Icons from IcoMoon</a>'),
			e.appendTo(this.panel.contentElement)
	},
	displaySelectedValue: function () {
		var e = 32,
			t = 32,
			i = document.createElementNS(SL.util.svg.NAMESPACE, "svg");
		i.setAttribute("xmlns", SL.util.svg.NAMESPACE),
			i.setAttribute("version", "1.1"),
			i.setAttribute("width", e),
			i.setAttribute("height", t),
			i.setAttribute("preserveAspectRatio", "xMidYMid");
		var n = SL.editor.blocks.Shape.shapeFromType(this.value, e, t);
		n.setAttribute("fill", "#ffffff"),
			i.appendChild(n),
			this.triggerElement.find("svg").remove(),
			this.triggerElement.append(i);
		var o = SL.util.svg.boundingBox(n);
		i.setAttribute("viewBox", [Math.round(o.x) || 0, Math.round(o.y) || 0, Math.round(o.width) || 32, Math.round(o.height) || 32].join(" "))
	}
}), SL("editor.components.toolbars.options").TableBorderColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-border-color",
			label: "Border color",
			property: "attribute.data-table-border-color",
			alpha: !0
		}, t))
	},
	getTriggerColor: function () {
		return this.block.getTableBorderColor()
	}
}), SL("editor.components.toolbars.options").TableBorderWidth = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-border-width",
			label: "Border width",
			property: "attribute.data-table-border-width"
		}, t))
	}
}), SL("editor.components.toolbars.options").TableCols = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-cols",
			label: "Columns",
			property: "attribute.data-table-cols",
			progressbar: !1
		}, t)),
			this.onTableSizeChanged = this.onTableSizeChanged.bind(this),
			e.tableSizeChanged.add(this.onTableSizeChanged)
	},
	onTableSizeChanged: function () {
		this.readFromBlock()
	},
	destroy: function () {
		this.block.tableSizeChanged && this.block.tableSizeChanged.remove(this.onTableSizeChanged),
			this._super()
	}
}), SL("editor.components.toolbars.options").TableHasHeader = SL.editor.components.toolbars.options.Checkbox.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-has-header",
			label: "Header",
			property: "attribute.data-table-has-header",
			tooltip: "The first table row is a header."
		}, t))
	}
}), SL("editor.components.toolbars.options").TablePadding = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-padding",
			label: "Cell padding",
			property: "attribute.data-table-padding"
		}, t))
	}
}), SL("editor.components.toolbars.options").TableRows = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "table-rows",
			label: "Rows",
			property: "attribute.data-table-rows",
			progressbar: !1
		}, t)),
			this.onTableSizeChanged = this.onTableSizeChanged.bind(this),
			e.tableSizeChanged.add(this.onTableSizeChanged)
	},
	onTableSizeChanged: function () {
		this.readFromBlock()
	},
	destroy: function () {
		this.block.tableSizeChanged && this.block.tableSizeChanged.remove(this.onTableSizeChanged),
			this._super()
	}
}), SL("editor.components.toolbars.options").TextAlign = SL.editor.components.toolbars.options.Radio.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "text-align",
			label: "Text Alignment",
			property: "style.text-align",
			items: e.getPropertySettings("style.text-align").options
		}, t))
	}
}), SL("editor.components.toolbars.options").TextColor = SL.editor.components.toolbars.options.Color.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "text-color",
			label: "Text Color",
			property: "style.color"
		}, t))
	}
}), SL("editor.components.toolbars.options").TextSize = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "text-size",
			label: "Text Scale",
			property: "style.font-size",
			progressbar: !1
		}, t))
	}
}), SL("editor.components.toolbars.options").TransitionDelay = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "transition-delay",
			label: "Delay",
			property: "style.transition-delay"
		}, t))
	}
}), SL("editor.components.toolbars.options").TransitionDuration = SL.editor.components.toolbars.options.Stepper.extend({
	init: function (e, t) {
		this._super(e, $.extend({
			type: "transition-duration",
			label: "Duration",
			property: "style.transition-duration"
		}, t))
	}
}), SL("editor.components.toolbars.util").Panel = Class.extend({
	init: function (e) {
		this.options = $.extend({
			width: "auto",
			height: "auto",
			maxHeight: "none",
			keydown: !1,
			offsetX: 0,
			offsetY: 0,
			alignment: "r"
		}, e),
			this.render(),
			this.bind(),
			SL.editor.components.toolbars.util.Panel.INSTANCES.push(this)
	},
	render: function () {
		this.domElement = $('<div class="toolbar-panel">'),
			this.contentElement = $('<div class="toolbar-panel-content">').appendTo(this.domElement),
			this.arrowElement = $('<div class="toolbar-panel-arrow">').appendTo(this.domElement),
			this.contentElement.css({
				width: this.options.width,
				height: this.options.height,
				maxHeight: this.options.maxHeight
			}),
			this.domElement.attr("data-alignment", this.options.alignment),
			"string" == typeof this.options.type && this.domElement.attr("data-panel-type", this.options.type),
			"number" == typeof this.options.height && this.domElement.css("overflow", "auto")
	},
	bind: function () {
		this.shown = new signals.Signal,
			this.hidden = new signals.Signal,
			this.isVisible = this.isVisible.bind(this),
			this.onDocumentClick = this.onDocumentClick.bind(this)
	},
	show: function () {
		SL.editor.components.toolbars.util.Panel.INSTANCES.forEach(function (e) {
			e !== this && e.isVisible() && e.hide()
		}),
			this.domElement.appendTo(SL.view.toolbars.domElement),
			this.layout(),
			this.shown.dispatch(),
			"function" == typeof this.options.keydown && SL.keyboard.keydown(this.options.keydown),
			$(document).on("click", this.onDocumentClick)
	},
	hide: function () {
		this.domElement.detach(),
			this.hidden.dispatch(),
			SL.keyboard.release(this.options.keydown)
	},
	toggle: function () {
		this.isVisible() ? this.hide() : this.show()
	},
	isVisible: function () {
		return this.domElement.parent().length > 0
	},
	layout: function () {
		if (this.options.anchor && "auto" === this.options.width && this.domElement.width(this.options.anchor.outerWidth()), this.options.anchor) {
			var e = this.options.anchor.offset(),
				t = this.options.anchor.outerWidth(),
				i = this.options.anchor.outerHeight(),
				n = 6,
				o = e.left + this.options.offsetX - this.domElement.parent().offset().left,
				r = e.top + this.options.offsetY;
			"b" === this.options.alignment ? (o += t / 2 - this.domElement.outerWidth() / 2, r += i) : o += t,
				r = Math.max(r, n),
				r = Math.min(r, window.innerHeight - this.domElement.outerHeight() - n),
				this.domElement.css({
					left: o,
					top: r
				}),
				this.arrowElement.css("b" === this.options.alignment ? {
					left: this.domElement.outerWidth() / 2,
					top: ""
				}
					: {
						left: "",
						top: e.top - r + i / 2
					})
		}
	},
	getContentElement: function () {
		return this.contentElement
	},
	onDocumentClick: function (e) {
		var t = $(e.target);
		0 === t.closest(this.options.anchor).length && 0 === t.closest(this.domElement).length && this.hide()
	},
	destroy: function () {
		$(document).off("click", this.onDocumentClick);
		for (var e = 0; e < SL.editor.components.toolbars.util.Panel.INSTANCES.length; e++)
			SL.editor.components.toolbars.util.Panel.INSTANCES[e] === this && SL.editor.components.toolbars.util.Panel.INSTANCES.splice(e, 1);
		SL.keyboard.release(this.options.keydown),
			this.shown.dispose(),
			this.hidden.dispose(),
			this.domElement.remove()
	}
}), SL.editor.components.toolbars.util.Panel.INSTANCES = [], SL("editor.controllers").API = {
	forkDeck: function () {
		SL.helpers.PageLoader.show({
			message: "Duplicating..."
		}),
			$.ajax({
				type: "POST",
				url: SL.config.AJAX_FORK_DECK(SLConfig.deck.id),
				context: this
			}).done(function (e) {
				e && e.deck && "string" == typeof e.deck.slug ? window.location = SL.routes.DECK_EDIT(SL.current_user.get("username"), e.deck.slug) : (SL.helpers.PageLoader.hide(), SL.notify(SL.locale.get("GENERIC_ERROR"), "negative"))
			}).fail(function () {
				SL.helpers.PageLoader.hide(),
					SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
			})
	},
	deleteDeck: function () {
		SL.prompt({
			title: "You are deleting the full presentation.",
			subtitle: "Are you sure you want to do this?",
			type: "select",
			data: [{
				html: "<h3>Cancel</h3>"
			}, {
				html: "<h3>Delete my presentation</h3>",
				selected: !0,
				className: "negative",
				callback: function () {
					SL.helpers.PageLoader.show({
						message: "Deleting..."
					}),
						$.ajax({
							type: "POST",
							url: SL.config.AJAX_TRASH_DECK(SLConfig.deck.id),
							data: {},
							context: this
						}).done(function () {
							window.location = SL.current_user.getProfileURL()
						}).fail(function () {
							SL.notify(SL.locale.get("DECK_DELETE_ERROR"), "negative"),
								SL.helpers.PageLoader.hide()
						})
				}
					.bind(this)
			}
			]
		})
	}
}
