import SL from '../../SL';

SL("editor.controllers").Blocks = {
	init: function (e) {
		this.editor = e,
			this.clipboard = [],
			this.clipboardAction = null,
			this.focusChanged = new signals.Signal,
			this.textSaved = new signals.Signal,
			this.bind(),
			parseInt(SL.util.getQuery().debug, 10) > 1 && this.paintDebugBoundingBoxes()
	},
	bind: function () {
		this.onDocumentMouseDown = this.onDocumentMouseDown.bind(this),
			this.onDocumentMouseMove = this.onDocumentMouseMove.bind(this),
			this.onDocumentMouseUp = this.onDocumentMouseUp.bind(this),
			this.onDocumentKeyDown = this.onDocumentKeyDown.bind(this),
			this.onTextEditingTouchMove = this.onTextEditingTouchMove.bind(this),
			this.onTextEditingTouchEnd = this.onTextEditingTouchEnd.bind(this),
			this.afterBlockTextInput = $.throttle(this.afterBlockTextInput.bind(this), 250),
			$(document).on("vmousedown", this.onDocumentMouseDown),
			$(document).on("keydown", this.onDocumentKeyDown)
	},
	sync: function (e) {
		var t = [];
		e = $(e || Reveal.getCurrentSlide());
		e.find(".sl-block").each(function (e, i) {
			i = $(i);
			i.data("block-instance") || this.add({
				type: i.attr("data-block-type"),
				element: i
			});
			t.push(i.data("block-instance"))
		}.bind(this));
		return t
	},
	syncNewSlide: function () {
		var e = this.sync.apply(this, arguments);
		this.normalizeBlockDepths(e)
	},
	add: function (e) {
		"undefined" == typeof e.slide && (e.slide = Reveal.getCurrentSlide()),
			"undefined" == typeof e.silent && (e.silent = !1),
			"undefined" == typeof e.center && (e.center = !0);
		var t = SL.config.BLOCKS.getByProperties({
			type: e.type
		});
		if (t) {
			var i;
			return e.element ? (i = new SL.editor.blocks[t.factory]({
				element: e.element
			}), e.element.data("block-instance", i), 0 === e.element.parent().length && i.appendTo(e.slide)) : (i = new SL.editor.blocks[t.factory](e.blockOptions), i.appendTo(e.slide), i.setDefaults(), e.afterInit && "function" == typeof e.afterInit && e.afterInit(i), e.width && i.resize({
				width: e.width
			}), e.height && i.resize({
				height: e.height
			}), this.place(i, {
				skipIntro: e.silent,
				center: e.center
			}), ("number" == typeof e.x || "number" == typeof e.y) && i.move(e.x, e.y), e.silent || SL.editor.controllers.Blocks.focus(i)),
				i.hasID() === !1 && i.setID(this.generateID(i)),
				i.removed.add(function () {
					i.isFocused() && SL.editor.controllers.Blocks.blur()
				}),
				i
		}
	},
	generateID: function (e) {
		return this.uniqueBlockCount = this.uniqueBlockCount ? this.uniqueBlockCount + 1 : 1,
			CryptoJS.MD5("block-" + e.getType() + "-" + this.uniqueBlockCount + "-" + Date.now() + "-" + Math.round(1e9 * Math.random())).toString()
	},
	place: function (e, t) {
		t = t || {},
			SL.editor.controllers.Blocks.moveBlocksToDepth([e], Number.MAX_VALUE),
			t.center && e.moveToCenter(),
			t.skipIntro || e.runIntro()
	},
	focus: function (e, t, i) {  //t：按住shift键
		"undefined" == typeof t && (t = !1);
		"undefined" == typeof i && (i = !0);
		e && e.nodeName && (e = $(e).data("block-instance"));  //e是一个dom节点
		e && "function" == typeof e.focus && (t ? e.isFocused() ? e.isFocused() && i && e.blur() : e.focus() : e.isFocused() || (this.blur(), e.focus()), this.afterFocusChange()) //e是base
	},
	blur: function (e) {
		(e || this.getFocusedBlocks()).forEach(function (e) {
			e.blur()
		}),
			this.afterFocusChange()
	},
	blurBlocksBySlide: function (e) {
		$(e).find(".sl-block").each(function () {
			var e = $(this).data("block-instance");
			e && e.blur()
		}),
			this.afterFocusChange()
	},
	afterFocusChange: function () {
		var e = this.getFocusedBlocks();
		1 === e.length && e[0].getToolbarOptions().length ? this.editor.toolbars.get().block !== e[0] && this.editor.toolbars.push(new SL.editor.components.toolbars.Edit(e[0])) : e.length > 1 ? this.editor.toolbars.get() instanceof SL.editor.components.toolbars.EditMultiple || (this.editor.toolbars.clear(), this.editor.toolbars.push(new SL.editor.components.toolbars.EditMultiple)) : this.editor.toolbars.clear(),
			$("html").toggleClass("multiple-blocks-selected", e.length > 1),
			this.focusChanged.dispatch()
	},
	afterBlockTextInput: function () {
		$(".reveal-viewport").scrollLeft(0).scrollTop(0)
	},
	afterBlockTextSaved: function (e) {
		this.textSaved.dispatch(e)
	},
	copy: function () {
		this.clipboardAction = "copy";
		var e = this.getFocusedBlocks();
		e.length && (this.clipboard.length = 0, e.forEach(function (e) {
			this.clipboard.push({
				block: e,
				measurements: e.measure()
			})
		}
			.bind(this)), SL.analytics.trackEditor("Copy block"))
	},
	cut: function () {
		this.clipboardAction = "cut";
		var e = this.getFocusedBlocks();
		e.length && (this.clipboard.length = 0, e.forEach(function (e) {
			this.clipboard.push({
				block: e,
				measurements: e.measure()
			}),
				e.blur(),
				e.detach()
		}
			.bind(this)), SL.editor.controllers.Blocks.blur(), SL.analytics.trackEditor("Cut block"))
	},
	paste: function () {
		var e = $(Reveal.getCurrentSlide()),
			t = 15;
		if (this.clipboard.length && e.length) {
			this.blur();
			var i = [];
			this.clipboard.forEach(function (e) {
				var n = e.block.domElement.clone(),
					o = JSON.parse(JSON.stringify(e.measurements));
				if (n.removeAttr("data-block-id"), n.find(">.editing-ui").remove(), "copy" === this.clipboardAction)
					for (; this.getBlocksByMeasurements(o).length;)
						o.x += t, o.y += t, o.right && (o.right += t), o.bottom && (o.bottom += t);
				var r = this.add({
					type: n.attr("data-block-type"),
					element: n
				});
				r.move(o.x, o.y),
					this.focus(r, !0),
					i.push(r)
			}
				.bind(this)),
				i.sort(function (e, t) {
					return e.get("style.z-index") - t.get("style.z-index")
				}),
				i.forEach(function (e) {
					SL.editor.controllers.Blocks.moveBlocksToDepth([e], Number.MAX_VALUE)
				}),
				SL.analytics.trackEditor("Paste block"),
				Reveal.sync()
		}
	},
	getClipboard: function () {
		return this.clipboard
	},
	align: function (e, t) {
		var i = this.getCombinedBounds(e);
		"left" === t ? e.forEach(function (e) {
			e.move(i.x)
		}) : "horizontal-center" === t ? e.forEach(function (e) {
			e.move(i.x + (i.width - e.measure().width) / 2)
		}) : "right" === t ? e.forEach(function (e) {
			e.move(i.right - e.measure().width)
		}) : "top" === t ? e.forEach(function (e) {
			e.move(null, i.y)
		}) : "vertical-center" === t ? e.forEach(function (e) {
			e.move(null, i.y + (i.height - e.measure().height) / 2)
		}) : "bottom" === t && e.forEach(function (e) {
			e.move(null, i.bottom - e.measure().height)
		})
	},
	layout: function (e, t, i) {
		("number" != typeof i || isNaN(i)) && (i = 10);
		var n = 0,
			o = 0,
			r = e.map(function (e) {
				var t = e.measure();
				return n += t.width,
					o += t.height, {
						block: e,
						measurements: t
					}
			});
		n += i * (e.length - 1),
			o += i * (e.length - 1);
		var s = SL.util.deck.getSlideSize();
		if ("column" === t) {
			var a = s.height / 2 - o / 2;
			r.forEach(function (e) {
				e.block.move(s.width / 2 - e.measurements.width / 2, a),
					a += e.measurements.height + i
			})
		} else if ("row" === t) {
			var l = s.width / 2 - n / 2;
			r.forEach(function (e) {
				e.block.move(l, s.height / 2 - e.measurements.height / 2),
					l += e.measurements.width + i
			})
		}
	},
	discoverBlockPairs: function () {
		var e = this.getCurrentBlocks(),
			t = SL.editor.controllers.Blocks.getAdjacentBlocks(e);
		e.forEach(function (e) {
			e.unpair()
		}),
			t.forEach(function (e) {
				"bottom" !== e.relationship || "text" !== e.blockA.type && "html" !== e.blockA.type || e.blockA.pair(e.blockB, "bottom")
			})
	},
	moveBlocksToDepth: function (e, t) {
		var i = this.getCurrentBlocks();
		t = Math.min(Math.max(t, SL.editor.controllers.Blocks.MIN_BLOCK_DEPTH), i.length + SL.editor.controllers.Blocks.MIN_BLOCK_DEPTH),
			this.normalizeBlockDepths(i, t),
			e.forEach(function (e) {
				e.set("style.z-index", t)
			})
	},
	normalizeBlockDepths: function (e, t) {
		e.sort(function (e, t) {
			return e.get("style.z-index") - t.get("style.z-index")
		});
		var i = SL.editor.controllers.Blocks.MIN_BLOCK_DEPTH;
		e.forEach(function (e) {
			i === t && (i += 1),
				e.set("style.z-index", i),
				i += 1
		})
	},
	paintDebugBoundingBoxes: function () {
		var e = $("<canvas>").appendTo(".slides");
		e.css({
			position: "absolute",
			top: 0,
			left: 0,
			zIndex: 100,
			pointerEvents: "none"
		});
		var t = e.get(0).getContext("2d"),
			i = function () {
				var n = $(".slides").width(),
					o = $(".slides").height();
				e.attr({
					width: n,
					height: o
				}),
					t.clearRect(0, 0, n, o),
					SL.editor.controllers.Blocks.getCurrentBlocks().forEach(function (e) {
						var i = e.measure(!0),
							n = e.measure(),
							o = e.getAnchorPositions();
						t.fillStyle = "rgba(0,255,0,0.1)",
							t.fillRect(n.x, n.y, n.width, n.height),
							t.save(),
							t.translate(i.x, i.y),
							t.fillStyle = "rgba(255,0,0,1.0)",
							t.fillRect(o.n.x - 4, o.n.y - 4, 8, 8),
							t.fillRect(o.e.x - 4, o.e.y - 4, 8, 8),
							t.fillRect(o.s.x - 4, o.s.y - 4, 8, 8),
							t.fillRect(o.w.x - 4, o.w.y - 4, 8, 8),
							t.restore()
					}),
					requestAnimationFrame(i)
			};
		i()
	},
	getCombinedBounds: function (e) {
		var t = {
			y: Number.MAX_VALUE,
			right: 0,
			bottom: 0,
			x: Number.MAX_VALUE
		};
		return e.forEach(function (e) {
			var i = e.measure();
			t.x = Math.min(t.x, i.x),
				t.y = Math.min(t.y, i.y),
				t.right = Math.max(t.right, i.right),
				t.bottom = Math.max(t.bottom, i.bottom)
		}
			.bind(this)),
			t.width = t.right - t.x,
			t.height = t.bottom - t.y,
			t
	},
	getFocusedBlocksInVisualOrder: function () {
		var e = {
			x: 0,
			y: 0
		};
		return this.getFocusedBlocks().sort(function (t, i) {
			var n = SL.util.trig.distanceBetween(t.measure(), e),
				o = SL.util.trig.distanceBetween(i.measure(), e);
			return n - o
		})
	},
	getFocusedBlocks: function () {
		var e = [];
		this.getCurrentBlocks().forEach(function (t) {
			t.isFocused() && e.push(t)
		});
		return e;
	},
	getCurrentBlocks: function () {
		return this.getBlocksBySlide(Reveal.getCurrentSlide())
	},
	getBlocksBySlide: function (e) {
		SL.editor.controllers.Blocks.sync(e);
		var t = [];
		$(e).find(".sl-block").each(function () {
			var e = $(this).data("block-instance");
			e && t.push(e)
		});
		return	t
	},
	getBlocksByMeasurements: function (e) {
		var t = [];
		return this.getCurrentBlocks().forEach(function (i) {
			var n = i.measure(),
				o = !0;
			for (var r in e)
				e.hasOwnProperty(r) && e[r] !== n[r] && (o = !1);
			o && t.push(i)
		}),
			t
	},
	getAdjacentBlocks: function (e) {
		var t = [],
			e = e || this.getCurrentBlocks();
		return e.forEach(function (i) {
			t = t.concat(SL.editor.controllers.Blocks.getAdjacentBlocksTo(i, e))
		}),
			t
	},
	getAdjacentBlocksTo: function (e, t) {
		var i = 4,
			n = [],
			t = t || this.getCurrentBlocks(),
			o = e.measure();
		return t.forEach(function (t) {
			var r = t.measure(),
				s = SL.util.trig.intersection(o, r);
			s.height > 0 && (Math.abs(o.x - r.right) < i ? n.push({
				relationship: "left",
				blockA: e,
				blockB: t
			}) : Math.abs(o.right - r.x) < i && n.push({
				relationship: "right",
				blockA: e,
				blockB: t
			})),
				s.width > 0 && (Math.abs(o.y - r.bottom) < i ? n.push({
					relationship: "top",
					blockA: e,
					blockB: t
				}) : Math.abs(o.bottom - r.y) < i && n.push({
					relationship: "bottom",
					blockA: e,
					blockB: t
				}))
		}),
			n
	},
	onDocumentMouseDown: function (e) {
		if (SL.view.isEditing() === !1)
			return !0;
		var t = $(e.target).closest(".reveal").length > 0;
		var isRevealControls = $(e.target).closest(".reveal .controls").length > 0;
	    var isBlock = $(e.target).closest(".sl-block").length > 0;
		var isToolbar = $(e.target).closest(".toolbars").length > 0;
		if ( !t || isBlock || isRevealControls)
			isToolbar && this.getFocusedBlocks().forEach(function (e) {
				"function" == typeof e.disableEditing && e.disableEditing()
			});
		else {
			if (SL.editor.controllers.Capabilities.isTouchEditor()) {
				var i = this.getFocusedBlocks().some(function (e) {
					return e.isEditingText()
				});
				if (i)
					return this.touchMouseStart = {
						x: e.clientX,
						y: e.clientY
					},
						this.touchMouseMoved = !1,
						$(document).on("vmousemove", this.onTextEditingTouchMove),
						$(document).on("vmouseup", this.onTextEditingTouchEnd),
						!0
			}
			e.shiftKey || (SL.editor.controllers.Blocks.blur(), $(document.activeElement).blur()),
				e.preventDefault(),
				SL.editor.controllers.Selection.start(e.clientX, e.clientY),
				$(document).on("vmousemove", this.onDocumentMouseMove),
				$(document).on("vmouseup", this.onDocumentMouseUp)
		}
	},
	onDocumentMouseMove: function (e) {
		SL.editor.controllers.Selection.sync(e.clientX, e.clientY)
	},
	onDocumentMouseUp: function () {
		SL.editor.controllers.Selection.stop(),
			$(document).off("vmousemove", this.onDocumentMouseMove),
			$(document).off("vmouseup", this.onDocumentMouseUp)
	},
	onTextEditingTouchMove: function (e) {
		(e.clientX !== this.touchMouseStart.x || e.clientY !== this.touchMouseStart.y) && (this.touchMouseMoved = !0)
	},
	onTextEditingTouchEnd: function () {
		this.touchMouseMoved || SL.editor.controllers.Blocks.blur(),
			$(document).off("vmousemove", this.onTextEditingTouchMove),
			$(document).off("vmouseup", this.onTextEditingTouchEnd)
	},
	onDocumentKeyDown: function (e) {
		if (SL.view.isEditing() === !1)
			return !0;
		if (SL.util.isTypingEvent(e))
			return !0;
		var t = this.editor.sidebar.isExpanded();
		if (!t) {
			var i = e.metaKey || e.ctrlKey,
				n = this.getFocusedBlocks();
			if (37 === e.keyCode || 38 === e.keyCode || 39 === e.keyCode || 40 === e.keyCode && n.length) {
				var o = e.shiftKey ? 10 : 1,
					r = 0,
					s = 0;
				switch (e.keyCode) {
					case 37:
						r = -o;
						break;
					case 39:
						r = o;
						break;
					case 38:
						s = -o;
						break;
					case 40:
						s = o
				}
				n.forEach(function (e) {
					e.move(r, s, {
						isOffset: !0
					})
				})
			} else
				8 !== e.keyCode && 46 !== e.keyCode || !n.length ? i && !e.shiftKey && 65 === e.keyCode ? (this.getCurrentBlocks().forEach(function (e) {
					SL.editor.controllers.Blocks.focus(e, !0, !1)
				}), e.preventDefault()) : i && !e.shiftKey && 67 === e.keyCode && n.length ? (SL.editor.controllers.Blocks.copy(), e.preventDefault()) : i && !e.shiftKey && 88 === e.keyCode && n.length ? (SL.editor.controllers.Blocks.cut(), e.preventDefault()) : i && !e.shiftKey && 86 === e.keyCode && SL.editor.controllers.Blocks.getClipboard().length > 0 && (SL.editor.controllers.Blocks.paste(), e.preventDefault()) : (n.forEach(function (e) {
					e.destroy()
				}), SL.editor.controllers.History.pushLatest(), e.preventDefault())
		}
	}
},
	SL.editor.controllers.Blocks.MIN_BLOCK_DEPTH = 10