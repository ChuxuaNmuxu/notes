import SL from '../../SL';

SL("editor.controllers").DeckImport = {
	TEXT_FORMATS : {
		h1 : "h1",
		h2 : "h2",
		h3 : "h3",
		p : "p"
	},
	THEME_COLOR_MAP : {
		"white-blue" : "white-blue",
		"black-blue" : "black-blue"
	},
	THEME_FONT_MAP : {
		asul : "asul",
		helvetica : "helvetica",
		josefine : "josefine",
		league : "league",
		merriweather : "merriweather",
		montserrat : "montserrat",
		news : "news",
		opensans : "opensans",
		palatino : "palatino",
		quicksand : "quicksand",
		sketch : "sketch",
		overpass : "overpass2"
	},
	TRANSITION_MAP : {
		none : "none",
		fade : "fade",
		slide : "slide",
		concave : "concave",
		convex : "convex"
	},
	init : function (e) {
		this.editor = e,
		this.onImportConfirmed = this.onImportConfirmed.bind(this),
		this.onImportCanceled = this.onImportCanceled.bind(this),
		this.importing = !1,
		SL.util.getQuery().define && "object" == typeof window.SLDeckDefinition && e.isNewDeck() && (this.editor.deckSaved.add(this.onDeckSaved.bind(this)), this.start(SLDeckDefinition))
	},
	start : function (e) {
		this.importing || (this.importing = !0, this.domElement = $('<div class="sl-deck-import">'), this.domElement.appendTo($(".projector")), this.domElement.append('<p class="description">You are importing a deck. Please review the content and click below to save it to your account.</p>'), this.controlsButtons = $('<div class="sl-deck-import-buttons">'), this.controlsButtons.appendTo(this.domElement), this.confirmButton = $('<button class="button white l sl-deck-import-confirm">Save deck</button>'), this.confirmButton.on("vclick", this.onImportConfirmed), this.confirmButton.appendTo(this.controlsButtons), this.cancelButton = $('<button class="button outline white l sl-deck-import-cancel">Cancel</button>'), this.cancelButton.on("vclick", this.onImportCanceled), this.cancelButton.appendTo(this.controlsButtons), this.importJSON(e), $("html").addClass("deck-import-open"))
	},
	stop : function () {
		this.importing = !1,
		this.domElement.remove(),
		$("html").removeClass("deck-import-open")
	},
	importJSON : function (e) {
		SL.helpers.PageLoader.show({
			message : "Importing..."
		}),
		$(".reveal .slides").empty(),
		e.title && (SLConfig.deck.title = e.title),
		e.description && (SLConfig.deck.description = e.description),
		e.loop && (SLConfig.deck.should_loop = e.loop),
		e["slide-number"] && (SLConfig.deck.slide_number = e["slide-number"]),
		"number" == typeof e.width && (SLConfig.deck.width = e.width, Reveal.configure({
				width : SLConfig.deck.width
			})),
		"number" == typeof e.height && (SLConfig.deck.height = e.height, Reveal.configure({
				height : SLConfig.deck.width
			})),
		SLConfig.deck.theme_color = this.THEME_COLOR_MAP[e["theme-color"]] || SL.config.DEFAULT_THEME_COLOR,
		SLConfig.deck.theme_font = this.THEME_FONT_MAP[e["theme-font"]] || SL.config.DEFAULT_THEME_FONT,
		SLConfig.deck.transition = this.TRANSITION_MAP[e.transition] || SL.config.DEFAULT_THEME_TRANSITION,
		SLConfig.deck.background_transition = this.TRANSITION_MAP[e["background-transition"]] || SL.config.DEFAULT_THEME_BACKGROUND_TRANSITION,
		"string" == typeof e.css && SL.editor.controllers.Capabilities.canUseCSSEditor() && this.importCSS(e.css),
		e.slides.forEach(this.importSlideJSON, this),
		Reveal.sync(),
		Reveal.slide(0, 0),
		SL.editor.controllers.Blocks.sync(),
		SL.editor.controllers.Grid.refresh(),
		SL.view.slideOptions.syncRemoveSlide(),
		this.editor.setupTheme(),
		this.waitForContentToLoad().then(this.afterContentLoaded.bind(this))
	},
	importCSS : function (e) {
		var t = new less.Parser;
		t.parse(".reveal { " + e + " }", function (t, i) {
			if (t)
				SL.notify("Failed to parse imported CSS: <br>" + t.message);
			else {
				var n = SL.util.string.moveCSSImportsToBeginning(i.toCSS());
				SLConfig.deck.css_input = e,
				SLConfig.deck.css_output = n,
				$("#user-css-output").html(n)
			}
		}
			.bind(this))
	},
	importSlideJSON : function (e, t) {
		var i = $("<section>").appendTo($(".reveal .slides"));
		SL.util.deck.generateIdentifiers(i),
		e instanceof Array ? e.forEach(function (e) {
			this.importSlideJSON(e, i)
		}, this) : (e.notes && (SLConfig.deck.notes[i.attr("data-id")] = e.notes), e["background-color"] && i.attr("data-background-color", e["background-color"]), e["background-image"] && i.attr("data-background-image", e["background-image"]), e["background-size"] && i.attr("data-background-size", e["background-size"]), this.slideBlockCount = {}, e.blocks && e.blocks.forEach(function (e) {
				this.importBlockJSON(e, i);
				var t = e.type;
				this.slideBlockCount[t] ? this.slideBlockCount[t] += 1 : this.slideBlockCount[t] = 1
			}, this), e.html && this.importBlockJSON({
				type : "html",
				value : e.html
			}, i), "object" == typeof t && i.appendTo(t))
	},
	importBlockJSON : function (e, t) {
		var i = SL.util.deck.getSlideSize(),
		n = {
			slide : t,
			silent : !0,
			width : Math.round(.8 * i.width)
		};
		switch (e.type) {
		case "html":
			n.type = "text",
			n.width = .8 * i.width,
			n.afterInit = function (t) {
				t.set("style.text-align", e.align),
				t.set("style.padding", e.padding),
				t.setCustomHTML(e.value)
			};
			break;
		case "text":
			n.type = "text",
			n.width = .8 * i.width;
			var o = this.TEXT_FORMATS[e.format] || (this.slideBlockCount.text > 0 ? "h2" : "h1");
			n.afterInit = function (t) {
				t.set("style.text-align", e.align),
				t.set("style.padding", e.padding),
				t.setHTML("<" + o + ">" + e.value + "</" + o + ">")
			};
			break;
		case "iframe":
			n.type = "iframe",
			n.width = .6 * i.width,
			n.height = .6 * i.height,
			n.afterInit = function (t) {
				t.set("iframe.src", e.value)
			};
			break;
		case "image":
			n.type = "image",
			n.width = .6 * i.width,
			n.height = .6 * i.height,
			n.afterInit = function (t) {
				t.set("image.src", e.value)
			};
			break;
		case "code":
			n.type = "code",
			n.width = .6 * i.width,
			n.height = .6 * i.height,
			n.afterInit = function (t) {
				e.value && t.set("code.value", e.value),
				e.language && t.set("code.language", e.language),
				e.theme && t.set("code.theme", e.theme)
			};
			break;
		default:
			return void console.warn('Unrecognized block type: "' + e.type + '"')
		}
		e.x && (n.x = e.x),
		e.y && (n.y = e.y),
		e.width && "number" == typeof n.width && (n.width = e.width),
		e.height && "number" == typeof n.height && (n.height = e.height),
		this.importBlockSize(n, e, n.width, n.height);
		var r = SL.editor.controllers.Blocks.add(n);
		("number" == typeof n.x || "number" == typeof n.y) && (r._importedWithAbsolutePosition = !0)
	},
	importBlockSize : function (e, t, i, n) {
		"number" == typeof i && (e.width = Math.round("number" == typeof t.width ? t.width : i)),
		"number" == typeof n && (e.height = Math.round("number" == typeof t.height ? t.height : n))
	},
	layoutSlide : function (e) {
		e.style.display = "block";
		var t = SL.editor.controllers.Blocks.getBlocksBySlide(e).filter(function (e) {
				return !e._importedWithAbsolutePosition
			});
		SL.editor.controllers.Blocks.layout(t, "column"),
		e.style.display = ""
	},
	waitForContentToLoad : function () {
		var e = [];
		return $(".reveal .slides section").each(function (t, i) {
			i.style.display = "block",
			SL.editor.controllers.Blocks.getBlocksBySlide(i).forEach(function (t) {
				"image" === t.getType() && t.isLoading() && e.push(new Promise(function (e) {
						t.imageStateChanged.add(function () {
							(t.isLoaded() || !t.isLoading()) && e()
						})
					}))
			})
		}
			.bind(this)),
		e.push(new Promise(function (e) {
				var t = SL.fonts.loadDeckFont(SLConfig.deck.theme_font, {
						active : e,
						inactive : e
					});
				t || e()
			})),
		Promise.all(e)
	},
	afterContentLoaded : function () {
		SL.helpers.PageLoader.hide(),
		$(".reveal .slides section").each(function (e, t) {
			this.layoutSlide(t),
			Reveal.sync()
		}
			.bind(this))
	},
	isImporting : function () {
		return this.importing
	},
	onImportCanceled : function () {
		this.stop(),
		SL.analytics.trackEditor("Deck JSON import canceled"),
		SL.helpers.PageLoader.show({
			message : "Canceling import..."
		}),
		SL.view.redirect(SL.routes.USER(SL.current_user.get("username")), !0)
	},
	onImportConfirmed : function () {
		this.stop(),
		SL.analytics.trackEditor("Deck JSON import confirmed"),
		this.editor.save(function (e) {
			e && SL.notify("This deck has been saved to your account!")
		})
	},
	onDeckSaved : function () {
		this.isImporting() && (this.domElement.remove(), this.importing = !1, SL.notify("Deck saved!"))
	}
}