 import SL from '../../SL';
 
 SL("editor.blocks").Code = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("code", e),
			this.editingRequested = new signals.Signal
		},
		setup : function () {
			this._super(),
			this.properties.code = {
				value : {
					setter : this.setCode.bind(this),
					getter : this.getCode.bind(this)
				},
				language : {
					defaultValue : "none",
					setter : this.setCodeLanguage.bind(this),
					getter : this.getCodeLanguage.bind(this),
					options : [{
							value : "none",
							title : "Automatic"
						}, {
							value : "1c",
							title : "1C"
						}, {
							value : "actionscript",
							title : "ActionScript"
						}, {
							value : "apache",
							title : "Apache"
						}, {
							value : "applescript",
							title : "AppleScript"
						}, {
							value : "asciidoc",
							title : "AsciiDoc"
						}, {
							value : "bash",
							title : "Bash"
						}, {
							value : "clojure",
							title : "Clojure"
						}, {
							value : "cmake",
							title : "CMake"
						}, {
							value : "coffeescript",
							title : "CoffeeScript"
						}, {
							value : "cpp",
							title : "C++"
						}, {
							value : "cs",
							title : "C#"
						}, {
							value : "css",
							title : "CSS"
						}, {
							value : "d",
							title : "D"
						}, {
							value : "delphi",
							title : "Delphi"
						}, {
							value : "diff",
							title : "Diff"
						}, {
							value : "django",
							title : "Django "
						}, {
							value : "dos",
							title : "DOS"
						}, {
							value : "elixir",
							title : "Elixir"
						}, {
							value : "elm",
							title : "Elm"
						}, {
							value : "erlang",
							title : "Erlang"
						}, {
							value : "fix",
							title : "FIX"
						}, {
							value : "fsharp",
							title : "F#"
						}, {
							value : "gherkin",
							title : "gherkin"
						}, {
							value : "glsl",
							title : "GLSL"
						}, {
							value : "go",
							title : "Go"
						}, {
							value : "haml",
							title : "Haml"
						}, {
							value : "handlebars",
							title : "Handlebars"
						}, {
							value : "haskell",
							title : "Haskell"
						}, {
							value : "xml",
							title : "HTML"
						}, {
							value : "http",
							title : "HTTP"
						}, {
							value : "ini",
							title : "Ini file"
						}, {
							value : "java",
							title : "Java"
						}, {
							value : "javascript",
							title : "JavaScript"
						}, {
							value : "json",
							title : "JSON"
						}, {
							value : "lasso",
							title : "Lasso"
						}, {
							value : "less",
							title : "LESS"
						}, {
							value : "lisp",
							title : "Lisp"
						}, {
							value : "livecodeserver",
							title : "LiveCode Server"
						}, {
							value : "lua",
							title : "Lua"
						}, {
							value : "makefile",
							title : "Makefile"
						}, {
							value : "markdown",
							title : "Markdown"
						}, {
							value : "mathematica",
							title : "Mathematica"
						}, {
							value : "matlab",
							title : "Matlab"
						}, {
							value : "nginx",
							title : "nginx"
						}, {
							value : "objectivec",
							title : "Objective C"
						}, {
							value : "perl",
							title : "Perl"
						}, {
							value : "php",
							title : "PHP"
						}, {
							value : "python",
							title : "Python"
						}, {
							value : "r",
							title : "R"
						}, {
							value : "ruby",
							title : "Ruby"
						}, {
							value : "ruleslanguage",
							title : "Oracle Rules Language"
						}, {
							value : "rust",
							title : "Rust"
						}, {
							value : "scala",
							title : "Scala"
						}, {
							value : "scss",
							title : "SCSS"
						}, {
							value : "smalltalk",
							title : "SmallTalk"
						}, {
							value : "sql",
							title : "SQL"
						}, {
							value : "stylus",
							title : "Stylus"
						}, {
							value : "swift",
							title : "Swift"
						}, {
							value : "tex",
							title : "TeX"
						}, {
							value : "vbnet",
							title : "VB.NET"
						}, {
							value : "vbscript",
							title : "VBScript"
						}, {
							value : "vim",
							title : "vim"
						}, {
							value : "xml",
							title : "XML"
						}, {
							value : "yaml",
							title : "YAML"
						}
					]
				},
				theme : {
					defaultValue : "zenburn",
					setter : this.setCodeTheme.bind(this),
					getter : this.getCodeTheme.bind(this),
					options : [{
							value : "zenburn",
							title : "Zenburn"
						}, {
							value : "ascetic",
							title : "Ascetic"
						}, {
							value : "far",
							title : "Far"
						}, {
							value : "github-gist",
							title : "GitHub Gist"
						}, {
							value : "ir-black",
							title : "Ir Black"
						}, {
							value : "monokai",
							title : "Monokai"
						}, {
							value : "obsidian",
							title : "Obsidian"
						}, {
							value : "solarized-dark",
							title : "Solarized Dark"
						}, {
							value : "solarized-light",
							title : "Solarized Light"
						}, {
							value : "tomorrow",
							title : "Tomorrow"
						}, {
							value : "xcode",
							title : "Xcode"
						}
					]
				}
			}
		},
		paint : function () {
			if (this.domElement.find(".sl-block-placeholder, .sl-block-content-preview").remove(), this.isEmpty())
				this.showPlaceholder();
			else {
				var e = $('<div class="editing-ui sl-block-content-preview visible-in-preview">').appendTo(this.contentElement),
				t = this.getPreElement().clone().appendTo(e);
				hljs.highlightBlock(t.get(0))
			}
			this.syncZ()
		},
		setDefaults : function () {
			this._super(),
			this.resize({
				width : 500,
				height : 300
			});
			var e = this.getDefaultCodeLanguage();
			e && this.setCodeLanguage(e);
			var t = this.getDefaultCodeTheme();
			t && this.setCodeTheme(t)
		},
		setCode : function (e) {
			this.getCodeElement().html(SL.util.escapeHTMLEntities(e)),
			this.paint()
		},
		getCode : function () {
			return SL.util.unescapeHTMLEntities(this.getCodeElement().html())
		},
		setCodeLanguage : function (e) {
			this.getPreElement().attr("class", e),
			this.paint(),
			SL.editor.blocks.Code.defaultLanguage = e
		},
		getCodeLanguage : function () {
			return this.getCodeLanguageFromPre(this.getPreElement())
		},
		getCodeLanguageFromPre : function (e) {
			var t = e.attr("class") || "";
			return t = t.replace(/hljs/gi, ""),
			t = t.trim()
		},
		getDefaultCodeLanguage : function () {
			if ("string" == typeof SL.editor.blocks.Code.defaultLanguage)
				return SL.editor.blocks.Code.defaultLanguage;
			for (var e = $('.reveal .sl-block[data-block-type="code"] pre[class!="none"]').get(), t = 0; t < e.length; t++) {
				var i = this.getCodeLanguageFromPre($(e[t]));
				if (i)
					return i
			}
			return null
		},
		setCodeTheme : function (e) {
			this.contentElement.attr("data-highlight-theme", e),
			SL.editor.blocks.Code.defaultTheme = e
		},
		getCodeTheme : function () {
			return this.contentElement.attr("data-highlight-theme")
		},
		getDefaultCodeTheme : function () {
			return "string" == typeof SL.editor.blocks.Code.defaultTheme ? SL.editor.blocks.Code.defaultTheme : $('.reveal .sl-block[data-block-type="code"] .sl-block-content[data-highlight-theme]').first().attr("data-highlight-theme")
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.options.Code, SL.editor.components.toolbars.options.CodeLanguage, SL.editor.components.toolbars.options.CodeTheme, SL.editor.components.toolbars.options.TextSize, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Rotation, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.BorderCSS, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		getPreElement : function () {
			var e = this.contentElement.find(">pre");
			return 0 === e.length && (e = $("<pre><code></code></pre>").appendTo(this.contentElement)),
			e
		},
		getCodeElement : function () {
			var e = this.getPreElement(),
			t = e.find(">code");
			return 0 === t.length && (t = $("<code>").appendTo(e)),
			t
		},
		isEmpty : function () {
			return !this.isset("code.value")
		},
		onDoubleClick : function (e) {
			this._super(e),
			this.editingRequested.dispatch()
		},
		onKeyDown : function (e) {
			this._super(e),
			13 !== e.keyCode || SL.util.isTypingEvent(e) || (this.editingRequested.dispatch(), e.preventDefault())
		}
	}), SL("editor.blocks").Iframe = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("iframe", e),
			this.editingRequested = new signals.Signal,
			this.iframeSourceChanged = new signals.Signal,
			this.paint()
		},
		setup : function () {
			this._super(),
			this.setIframeURL = this.setIframeURL.bind(this),
			this.getIframeURL = this.getIframeURL.bind(this),
			this.setIframeAutoplay = this.setIframeAutoplay.bind(this),
			this.getIframeAutoplay = this.getIframeAutoplay.bind(this),
			this.setIframeURL = $.debounce(this.setIframeURL, 400),
			this.properties.iframe = {
				src : {
					setter : this.setIframeURL,
					getter : this.getIframeURL
				},
				autoplay : {
					defaultValue : !1,
					setter : this.setIframeAutoplay,
					getter : this.getIframeAutoplay
				}
			}
		},
		paint : function () {
			this._super.apply(this, arguments);
			var e = this.getIframeURL(),
			t = window.location.protocol;
			"https:" === t && e && /^http:/gi.test(e) ? 0 === this.domElement.find(".sl-block-overlay-message").length && this.contentElement.append(['<div class="editing-ui sl-block-overlay sl-block-overlay-message below-content">', '<div class="overlay-content">Cannot display non-HTTPS iframe while in the editor.</div>', "</div>"].join("")) : this.domElement.find(".sl-block-overlay-message").remove()
		},
		setDefaults : function () {
			this._super(),
			this.resize({
				width : 360,
				height : 300
			})
		},
		getIframeURL : function () {
			return this.getIframeElement().attr("src") || this.getIframeElement().attr("data-src")
		},
		setIframeURL : function (e) {
			e !== this.get("iframe.src") && (this.getIframeElement().attr({
					src : e,
					"data-src" : e
				}), this.iframeSourceChanged.dispatch(e)),
			this.paint()
		},
		getIframeAutoplay : function () {
			return this.getIframeElement().get(0).hasAttribute("data-autoplay")
		},
		setIframeAutoplay : function (e) {
			e === !0 ? this.getIframeElement().attr("data-autoplay", "") : this.getIframeElement().removeAttr("data-autoplay")
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.options.IframeSRC, SL.editor.components.toolbars.options.IframeAutoplay, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Padding, SL.editor.components.toolbars.options.Rotation, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.BorderCSS, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		getIframeElement : function () {
			var e = this.contentElement.find("iframe");
			return 0 === e.length && (e = $("<iframe>").appendTo(this.contentElement)),
			e.attr({
				webkitallowfullscreen : "",
				mozallowfullscreen : "",
				allowfullscreen : "",
				sandbox : "allow-forms allow-scripts allow-popups allow-same-origin allow-pointer-lock"
			}),
			e
		},
		isEmpty : function () {
			return !this.isset("iframe.src")
		},
		destroy : function () {
			this.iframeSourceChanged.dispose(),
			this._super()
		},
		onDoubleClick : function (e) {
			this._super(e),
			this.editingRequested.dispatch()
		},
		onKeyDown : function (e) {
			this._super(e),
			13 !== e.keyCode || SL.util.isTypingEvent(e) || (this.editingRequested.dispatch(), e.preventDefault())
		}
	}), SL("editor.blocks").Image = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("image", e),
			this.plug(SL.editor.blocks.plugin.Link),
			this.imageURLChanged = new signals.Signal,
			this.imageStateChanged = new signals.Signal,
			this.contentElement.find("img").on("error", function () {
				this.loadingFailed = !0,
				this.paint()
			}
				.bind(this))
		},
		setup : function () {
			this._super(),
			this.properties.image = {
				src : {
					setter : this.setImageURL.bind(this),
					getter : this.getImageURL.bind(this)
				}
			},
			this.properties.attribute["data-inline-svg"] = {
				defaultValue : !1
			}
		},
		bind : function () {
			this._super(),
			this.onUploadCompleted = this.onUploadCompleted.bind(this),
			this.onUploadFailed = this.onUploadFailed.bind(this),
			this.propertyChanged.add(this.onPropertyChanged.bind(this))
		},
		setDefaults : function () {
			this._super(),
			this.resize({
				width : 360,
				height : 300
			}),
			this.options.insertedFromToolbar && (this.options.introDelay = 300, this.browse())
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.options.Image, SL.editor.components.toolbars.options.ImageInlineSVG, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Rotation, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.BorderCSS, SL.editor.components.toolbars.groups.Link, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		setImageURL : function (e) {
			var t = this.contentElement.find("img"),
			i = this.hasLoadingFailed();
			1 === t.length && t.prop("complete") === !0 && 0 === t.prop("naturalWidth") && (i = !0),
			(e !== this.getImageURL() || i) && (this.loading = !0, this.loadingFailed = !1, this.paint(), this.imageStateChanged.dispatch(), 0 === t.length ? (t = $('<img src="' + e + '">'), t.css("visibility", "hidden"), t.appendTo(this.contentElement)) : t.attr("src", e), t.off("load").on("load", function () {
					t.css("visibility", ""),
					this.loading = !1,
					this.syncAspectRatio(),
					this.paint(),
					this.imageStateChanged.dispatch(),
					this.paintInlineSVG()
				}
					.bind(this)), t.off("error").on("error", function () {
					SL.notify("Failed to load image", "negative"),
					this.loading = !1,
					this.loadingFailed = !0,
					this.paint(),
					this.imageStateChanged.dispatch()
				}
					.bind(this)), this.imageURLChanged.dispatch(e))
		},
		getImageURL : function () {
			return this.contentElement.find("img").attr("src")
		},
		setImageModel : function (e) {
			e.isSVG() && this.set("attribute.data-inline-svg", e.get("inline")),
			this.intermediateModel = e,
			this.intermediateModel.isUploaded() ? this.onUploadCompleted() : (this.paint(), this.imageStateChanged.dispatch(), this.intermediateModel.uploadCompleted.add(this.onUploadCompleted), this.intermediateModel.uploadFailed.add(this.onUploadFailed))
		},
		isLoading : function () {
			return !!this.loading || !!this.loadingSVG
		},
		isUploading : function () {
			return !(!this.intermediateModel || !this.intermediateModel.isWaitingToUpload() && !this.intermediateModel.isUploading())
		},
		hasImage : function () {
			var e = this.get("image.src");
			return !!("string" == typeof e && e.length > 0)
		},
		hasLoadingFailed : function () {
			return this.loadingFailed
		},
		isLoaded : function () {
			var e = this.getNaturalSize(!0);
			return e && e.width > 0 && e.height > 0
		},
		isSVG : function () {
			return this.hasImage() && /^svg/i.test(this.get("image.src").split(".").pop())
		},
		getNaturalSize : function (e) {
			var t = this.contentElement.find("img");
			if (t.length) {
				var i = {};
				if (!e && (i.width = parseInt(t.attr("data-natural-width"), 10), i.height = parseInt(t.attr("data-natural-height"), 10), i.width && i.height))
					return i;
				if (i.width = t.get(0).naturalWidth, i.height = t.get(0).naturalHeight, i.width && i.height)
					return t.attr({
						"data-natural-width" : i.width,
						"data-natural-height" : i.height
					}), i
			}
			return null
		},
		getAspectRatio : function (e) {
			var t = this.getNaturalSize(e);
			return t ? t.width / t.height : this._super()
		},
		syncAspectRatio : function (e) {
			"undefined" == typeof e && (e = !0);
			var t = this.getNaturalSize(e);
			if (t) {
				var i = this.measure(!0);
				this.resize({
					width : i.width,
					height : i.height,
					center : !0
				})
			}
		},
		paint : function () {
			this.domElement.find(".sl-block-placeholder, .sl-block-overlay-warning, .image-progress").remove(),
			this.isLoading() || this.isUploading() ? (this.contentElement.append(['<div class="editing-ui sl-block-overlay image-progress">', '<span class="spinner centered"></span>', "</div>"].join("")), SL.util.html.generateSpinners()) : this.hasLoadingFailed() ? (this.contentElement.append(['<div class="editing-ui sl-block-overlay sl-block-overlay-warning">', '<div class="overlay-content">Failed to load image.<br><button class="button white image-retry-button" style="margin-top: 10px;">Retry</button></div>', "</div>"].join("")), this.domElement.find(".image-retry-button").on("click", function () {
					this.setImageURL(this.getImageURL())
				}
					.bind(this))) : this.hasImage() || this.showPlaceholder();
			var e = this.contentElement.find("img");
			1 === e.length && "none" === e.css("display") && e.css("display", ""),
			this.syncZ()
		},
		paintInlineSVG : function () {
			this.isSVG() && this.get("attribute.data-inline-svg") ? (this.loadingSVG = !0, this.paint(), $.ajax({
					url : this.getImageURL() + "?t=" + Date.now(),
					type : "GET",
					dataType : "xml",
					context : this
				}).done(function (e) {
					var t = $(e).find("svg").first().get(0);
					if (t) {
						if (t.setAttribute("preserveAspectRatio", "xMidYMid meet"), !t.hasAttribute("viewBox")) {
							var i = this.getNaturalSize();
							i && t.setAttribute("viewBox", "0 0 " + i.width + " " + i.height)
						}
						$(t).find("style").remove(),
						this.contentElement.find("img").css("display", "none"),
						this.contentElement.find("svg").remove(),
						this.contentElement.append(t)
					}
				}).always(function () {
					this.loadingSVG = !1,
					this.paint(),
					this.imageStateChanged.dispatch()
				})) : (this.contentElement.find("img").css("display", ""), this.contentElement.find("svg").remove())
		},
		clear : function () {
			this.contentElement.find("img").remove(),
			this.paint(),
			this.imageStateChanged.dispatch()
		},
		browse : function () {
			var e = SL.popup.open(SL.components.medialibrary.MediaLibrary, {
					select : SL.models.Media.IMAGE
				});
			e.selected.addOnce(this.setImageModel.bind(this))
		},
		destroy : function () {
			this.intermediateModel && (this.intermediateModel.uploadCompleted.remove(this.onUploadCompleted), this.intermediateModel.uploadFailed.remove(this.onUploadFailed), this.intermediateModel = null),
			this.imageStateChanged.dispose(),
			this.imageStateChanged = null,
			this.imageURLChanged.dispose(),
			this.imageURLChanged = null,
			this._super()
		},
		onUploadCompleted : function () {
			var e = this.intermediateModel.get("url");
			this.intermediateModel = null,
			this.set("image.src", e),
			this.imageStateChanged.dispatch()
		},
		onUploadFailed : function () {
			this.intermediateModel = null,
			this.paint(),
			this.imageStateChanged.dispatch()
		},
		onDoubleClick : function () {
			this.browse()
		},
		onPropertyChanged : function (e) {
			"attribute.data-inline-svg" === e[0] && this.paintInlineSVG()
		}
	}), SL("editor.blocks").Line = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("line", $.extend({
					minWidth : 1,
					minHeight : 1,
					horizontalResizing : !1,
					verticalResizing : !1
				}, e)),
			this.transform.destroy(),
			this.transform = new SL.editor.blocks.behavior.TransformLine(this),
			this.transform.transformStarted.add(this.onTransformStarted.bind(this)),
			this.transform.transformEnded.add(this.onTransformEnded.bind(this)),
			this.plug(SL.editor.blocks.plugin.Link)
		},
		setup : function () {
			this._super(),
			this.properties.attribute["data-line-style"] = {
				defaultValue : "solid",
				options : [{
						value : "solid"
					}, {
						value : "dotted"
					}, {
						value : "dashed"
					}
				]
			},
			this.properties.attribute["data-line-start-type"] = {
				defaultValue : "none",
				options : [{
						value : "none"
					}, {
						value : "line-arrow"
					}, {
						value : "arrow"
					}, {
						value : "circle"
					}, {
						value : "square"
					}
				]
			},
			this.properties.attribute["data-line-end-type"] = {
				defaultValue : "none",
				options : [{
						value : "none"
					}, {
						value : "line-arrow"
					}, {
						value : "arrow"
					}, {
						value : "circle"
					}, {
						value : "square"
					}
				]
			},
			this.properties.attribute["data-line-width"] = {
				unit : "px",
				type : "number",
				minValue : 1,
				maxValue : 50,
				defaultValue : SL.editor.blocks.Line.DEFAULT_LINE_WIDTH
			},
			this.properties.attribute["data-line-color"] = {
				defaultValue : SL.editor.blocks.Line.DEFAULT_COLOR
			},
			this.properties.attribute["data-line-x1"] = {
				type : "number",
				minValue : 0,
				maxValue : Number.MAX_VALUE,
				defaultValue : 0
			},
			this.properties.attribute["data-line-y1"] = {
				type : "number",
				minValue : 0,
				maxValue : Number.MAX_VALUE,
				defaultValue : 0
			},
			this.properties.attribute["data-line-x2"] = {
				type : "number",
				minValue : 0,
				maxValue : Number.MAX_VALUE,
				defaultValue : 0
			},
			this.properties.attribute["data-line-y2"] = {
				type : "number",
				minValue : 0,
				maxValue : Number.MAX_VALUE,
				defaultValue : 0
			}
		},
		bind : function () {
			this._super(),
			this.propertyChanged.add(this.onPropertyChanged.bind(this))
		},
		setDefaults : function () {
			this._super(),
			this.set({
				"attribute.data-line-x1" : 0,
				"attribute.data-line-y1" : 200,
				"attribute.data-line-x2" : 200,
				"attribute.data-line-y2" : 0,
				"attribute.data-line-color" : this.getPropertyDefault("attribute.data-line-color"),
				"attribute.data-line-start-type" : this.getPropertyDefault("attribute.data-line-start-type"),
				"attribute.data-line-end-type" : this.getPropertyDefault("attribute.data-line-end-type")
			})
		},
		paint : function () {
			var e = this.getSVGElement();
			e.setAttribute("preserveAspectRatio", "xMidYMid"),
			e.innerHTML = "",
			SL.editor.blocks.Line.generate(e, {
				startType : this.get("attribute.data-line-start-type"),
				endType : this.get("attribute.data-line-end-type"),
				style : this.get("attribute.data-line-style"),
				color : this.get("attribute.data-line-color"),
				width : this.get("attribute.data-line-width"),
				x1 : this.get("attribute.data-line-x1"),
				y1 : this.get("attribute.data-line-y1"),
				x2 : this.get("attribute.data-line-x2"),
				y2 : this.get("attribute.data-line-y2")
			});
			var t = this.getViewBox();
			if (e.setAttribute("width", t.width), e.setAttribute("height", t.height), e.setAttribute("viewBox", [t.x, t.y, t.width, t.height].join(" ")), this.measurementsBeforeTransform) {
				var i = t.x - this.viewBoxBeforeTransform.x,
				n = t.y - this.viewBoxBeforeTransform.y;
				this.move(this.measurementsBeforeTransform.x + i, this.measurementsBeforeTransform.y + n)
			}
			this.transform && this.transform.layout()
		},
		resize : function () {
			this._super.apply(this, arguments),
			this.paint()
		},
		hitTest : function (e) {
			var t = this.getGlobalLinePoint(SL.editor.blocks.Line.POINT_1),
			i = this.getGlobalLinePoint(SL.editor.blocks.Line.POINT_2),
			n = SL.util.trig.isPointWithinRect(t.x, t.y, e) && SL.util.trig.isPointWithinRect(i.x, i.y, e);
			if (n)
				return !0;
			var o = [[{
						x : e.x,
						y : e.y
					}, {
						x : e.x + e.width,
						y : e.y
					}
				], [{
						x : e.x + e.width,
						y : e.y
					}, {
						x : e.x + e.width,
						y : e.y + e.height
					}
				], [{
						x : e.x,
						y : e.y + e.height
					}, {
						x : e.x + e.width,
						y : e.y + e.height
					}
				], [{
						x : e.x,
						y : e.y
					}, {
						x : e.x,
						y : e.y + e.height
					}
				]];
			return o.some(function (e) {
				return !!SL.util.trig.findLineIntersection(t, i, e[0], e[1])
			})
		},
		setGlobalLinePoint : function (e, t, i) {
			var n = this.getViewBox(),
			o = this.measure();
			e === SL.editor.blocks.Line.POINT_1 ? ("number" == typeof t && this.set("attribute.data-line-x1", t - (o.x - n.x)), "number" == typeof i && this.set("attribute.data-line-y1", i - (o.y - n.y))) : e === SL.editor.blocks.Line.POINT_2 && ("number" == typeof t && this.set("attribute.data-line-x2", t - (o.x - n.x)), "number" == typeof i && this.set("attribute.data-line-y2", i - (o.y - n.y)))
		},
		getGlobalLinePoint : function (e) {
			var t = this.getViewBox(),
			i = this.measure();
			return e === SL.editor.blocks.Line.POINT_1 ? {
				x : i.x - t.x + this.get("attribute.data-line-x1"),
				y : i.y - t.y + this.get("attribute.data-line-y1")
			}
			 : e === SL.editor.blocks.Line.POINT_2 ? {
				x : i.x - t.x + this.get("attribute.data-line-x2"),
				y : i.y - t.y + this.get("attribute.data-line-y2")
			}
			 : void 0
		},
		getOppositePointID : function (e) {
			return e === SL.editor.blocks.Line.POINT_1 ? SL.editor.blocks.Line.POINT_2 : SL.editor.blocks.Line.POINT_1
		},
		getViewBox : function () {
			var e = this.get("attribute.data-line-x1"),
			t = this.get("attribute.data-line-y1"),
			i = this.get("attribute.data-line-x2"),
			n = this.get("attribute.data-line-y2"),
			o = {
				x : Math.round(Math.min(e, i)),
				y : Math.round(Math.min(t, n))
			};
			return o.width = Math.max(Math.round(Math.max(e, i) - o.x), 1),
			o.height = Math.max(Math.round(Math.max(t, n) - o.y), 1),
			o
		},
		getSVGElement : function () {
			var e = this.contentElement.find("svg").get(0);
			return e || (e = document.createElementNS(SL.util.svg.NAMESPACE, "svg"), e.setAttribute("xmlns", SL.util.svg.NAMESPACE), e.setAttribute("version", "1.1"), this.contentElement.append(e)),
			e
		},
		getLineElement : function () {
			var e = this.getSVGElement(),
			t = e.querySelector("line");
			return t || (t = document.createElementNS(SL.util.svg.NAMESPACE, "line"), e.appendChild(t)),
			t
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.groups.LineType, SL.editor.components.toolbars.options.LineStyle, SL.editor.components.toolbars.options.LineWidth, SL.editor.components.toolbars.options.LineColor, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.Link, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		onPropertyChanged : function () {
			this.paint()
		},
		onTransformStarted : function () {
			this.measurementsBeforeTransform = this.measure(),
			this.viewBoxBeforeTransform = this.getViewBox()
		},
		onTransformEnded : function () {
			this.measurementsBeforeTransform = null,
			this.viewBoxBeforeTransform = null
		}
	}), SL.editor.blocks.Line.DEFAULT_COLOR = "#000000", SL.editor.blocks.Line.DEFAULT_LINE_WIDTH = 2, SL.editor.blocks.Line.POINT_1 = "p1", SL.editor.blocks.Line.POINT_2 = "p2", SL.editor.blocks.Line.roundPoints = function () {
	for (var e = 0; e < arguments.length; e++)
		arguments[e].x = Math.round(arguments[e].x), arguments[e].y = Math.round(arguments[e].y)
}