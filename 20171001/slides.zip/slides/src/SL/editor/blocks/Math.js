import SL from '../../SL';

SL("editor.blocks").Math = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("math", $.extend(e, {
					horizontalResizing : !1,
					verticalResizing : !1
				})),
			this.editingRequested = new signals.Signal
		},
		setup : function () {
			this._super(),
			this.properties.math = {
				value : {
					setter : this.setValue.bind(this),
					getter : this.getValue.bind(this)
				}
			}
		},
		paint : function () {
			if (this.domElement.find(".sl-block-placeholder, .sl-block-content-preview, .sl-block-overlay-warning").remove(), this.isEmpty())
				this.domElement.addClass("is-empty"), this.showPlaceholder(), this.getMathOutputElement().empty();
			else
				try {
					this.domElement.removeClass("is-empty"),
					katex.render(this.getMathInputElement().text(), this.getMathOutputElement().get(0))
				} catch (e) {
					this.domElement.addClass("is-empty"),
					this.contentElement.append(['<div class="editing-ui sl-block-overlay sl-block-overlay-warning">', '<div class="overlay-content">', '<span class="icon i-info" data-tooltip="' + e.message + '" data-tooltip-maxwidth="500"></span>', "An error occurred while parsing your equation.", "</div>", "</div>"].join(""))
				}
			this.syncZ()
		},
		setDefaults : function () {
			this._super()
		},
		setValue : function (e) {
			this.getMathInputElement().html(e),
			this.paint()
		},
		getValue : function () {
			return this.getMathInputElement().text()
		},
		getMathInputElement : function () {
			var e = this.contentElement.find(".math-input");
			return 0 === e.length && (e = $('<div class="math-input"></div>').appendTo(this.contentElement)),
			e
		},
		getMathOutputElement : function () {
			this.contentElement.find(".math-output:gt(0)").remove();
			var e = this.contentElement.find(".math-output");
			return 0 === e.length && (e = $('<div class="math-output"></div>').appendTo(this.contentElement)),
			e
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.options.MathInput, SL.editor.components.toolbars.options.MathSize, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.MathColor, SL.editor.components.toolbars.options.BackgroundColor, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Padding, SL.editor.components.toolbars.options.Rotation, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.BorderCSS, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		isEmpty : function () {
			return !this.isset("math.value")
		},
		onDoubleClick : function (e) {
			this._super(e),
			this.editingRequested.dispatch()
		},
		onKeyDown : function (e) {
			this._super(e),
			13 !== e.keyCode || SL.util.isTypingEvent(e) || (this.editingRequested.dispatch(), e.preventDefault())
		}
	}), SL("editor.blocks.plugin").HTML = Class.extend({
		init : function (e) {
			this.block = e,
			this.block.editHTML = function () {
				var e = SL.popup.open(SL.components.popup.EditHTML, {
						html : this.contentElement.html()
					});
				e.saved.add(function (e) {
					this.setCustomHTML(e)
				}
					.bind(this))
			}
			.bind(e),
			this.block.setCustomHTML = function (e) {
				this.contentElement.attr("data-has-custom-html", ""),
				this.contentElement.html(e)
			}
			.bind(e),
			this.block.setHTML = function (e) {
				this.contentElement.html(e)
			}
			.bind(e),
			this.block.hasCustomHTML = function () {
				return this.contentElement.get(0).hasAttribute("data-has-custom-html")
			}
			.bind(e)
		},
		destroy : function () {
			delete this.block.editHTML,
			delete this.block.setCustomHTML,
			delete this.block.hasCustomHTML
		}
	}), SL("editor.blocks.plugin").Link = Class.extend({
		init : function (e) {
			this.block = e,
			this.block.setLinkURL = function (e) {
				"string" == typeof e ? (this.isLinked() === !1 && this.changeContentElementType("a"), this.contentElement.attr("href", e), this.contentElement.attr("target", "_blank"), /^#\/\d/.test(e) && this.contentElement.removeAttr("target")) : (this.contentElement.removeAttr("target"), this.changeContentElementType(this.options.contentElementType))
			}
			.bind(e),
			this.block.getLinkURL = function () {
				return this.contentElement.attr("href")
			}
			.bind(e),
			this.block.isLinked = function () {
				return this.contentElement.is("a")
			}
			.bind(e),
			this.block.properties.link = {
				href : {
					setter : this.block.setLinkURL,
					getter : this.block.getLinkURL,
					checker : this.block.isLinked
				}
			}
		},
		destroy : function () {
			delete this.block.properties.link,
			delete this.block.setLinkURL,
			delete this.block.getLinkURL,
			delete this.block.isLinked
		}
	}), SL("editor.blocks").Shape = SL.editor.blocks.Base.extend({
		init : function (e) {
			this._super("shape", $.extend({
					minWidth : 4,
					minHeight : 4
				}, e)),
			this.plug(SL.editor.blocks.plugin.Link)
		},
		setup : function () {
			this._super(),
			this.properties.attribute["data-shape-type"] = {
				defaultValue : "rect",
				options : [{
						value : "rect"
					}, {
						value : "circle"
					}, {
						value : "diamond"
					}, {
						value : "octagon"
					}, {
						value : "triangle-up"
					}, {
						value : "triangle-down"
					}, {
						value : "triangle-left"
					}, {
						value : "triangle-right"
					}, {
						value : "arrow-up"
					}, {
						value : "arrow-down"
					}, {
						value : "arrow-left"
					}, {
						value : "arrow-right"
					}
				]
			};
			for (var e in SL.util.svg.SYMBOLS)
				this.properties.attribute["data-shape-type"].options.push({
					value : "symbol-" + e
				});
			this.properties.attribute["data-shape-stretch"] = {
				defaultValue : !0
			},
			this.properties.attribute["data-shape-fill-color"] = {
				defaultValue : "#000000"
			},
			this.properties.attribute["data-shape-stroke-color"] = {},
			this.properties.attribute["data-shape-stroke-width"] = {
				type : "number",
				decimals : 0,
				minValue : 1,
				maxValue : 50,
				defaultValue : 0
			}
		},
		bind : function () {
			this._super(),
			this.propertyChanged.add(this.onPropertyChanged.bind(this))
		},
		setDefaults : function () {
			this._super(),
			this.resize({
				width : 300,
				height : 300
			}),
			this.set("attribute.data-shape-type", this.getPropertyDefault("attribute.data-shape-type")),
			this.set("attribute.data-shape-fill-color", this.getPropertyDefault("attribute.data-shape-fill-color")),
			this.set("attribute.data-shape-stretch", this.getPropertyDefault("attribute.data-shape-stretch"))
		},
		paint : function () {
			var e = this.get("attribute.data-shape-type"),
			t = this.get("attribute.data-shape-fill-color"),
			i = this.get("attribute.data-shape-stroke-color"),
			n = this.get("attribute.data-shape-stroke-width"),
			o = this.get("attribute.data-shape-stretch"),
			r = this.domElement.width(),
			s = this.domElement.height();
			o || (r = s = Math.min(r, s));
			var a = SL.editor.blocks.Shape.shapeFromType(e, r, s);
			if (a) {
				var l = this.hasStroke(),
				c = this.supportsStroke(a),
				d = this.getSVGElement();
				if (d.setAttribute("width", "100%"), d.setAttribute("height", "100%"), d.setAttribute("preserveAspectRatio", o ? "none" : "xMidYMid"), d.innerHTML = "", c && l) {
					var u = SL.util.string.uniqueID("shape-mask-"),
					h = document.createElementNS(SL.util.svg.NAMESPACE, "defs"),
					p = document.createElementNS(SL.util.svg.NAMESPACE, "clipPath");
					p.setAttribute("id", u),
					p.appendChild($(a).clone().get(0)),
					h.appendChild(p),
					d.appendChild(h),
					a.setAttribute("clip-path", "url(#" + u + ")")
				}
				a.setAttribute("class", "shape-element"),
				t && a.setAttribute("fill", t),
				c && i && a.setAttribute("stroke", i),
				c && n && a.setAttribute("stroke-width", 2 * n),
				d.appendChild(a);
				var m = SL.util.svg.boundingBox(a);
				d.setAttribute("viewBox", [Math.round(m.x) || 0, Math.round(m.y) || 0, Math.round(m.width) || 32, Math.round(m.height) || 32].join(" "))
			}
		},
		resize : function () {
			this._super.apply(this, arguments),
			this.paint()
		},
		toggleStroke : function () {
			this.hasStroke() ? this.unset(["attribute.data-shape-stroke-color", "attribute.data-shape-stroke-width"]) : this.set({
				"attribute.data-shape-stroke-color" : "#000000",
				"attribute.data-shape-stroke-width" : 1
			}),
			this.paint()
		},
		hasStroke : function () {
			return this.isset("attribute.data-shape-stroke-color") || this.isset("attribute.data-shape-stroke-width")
		},
		supportsStroke : function (e) {
			return $(e || this.getSVGShapeElement()).is("rect, circle, ellipse, polygon")
		},
		getSVGElement : function () {
			var e = this.contentElement.find("svg").get(0);
			return e || (e = document.createElementNS(SL.util.svg.NAMESPACE, "svg"), e.setAttribute("xmlns", SL.util.svg.NAMESPACE), e.setAttribute("version", "1.1"), this.contentElement.append(e)),
			e
		},
		getSVGShapeElement : function () {
			return $(this.getSVGElement().querySelector(".shape-element"))
		},
		getToolbarOptions : function () {
			return [SL.editor.components.toolbars.options.ShapeType, SL.editor.components.toolbars.options.ShapeStretch, SL.editor.components.toolbars.options.ShapeFillColor, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.Opacity, SL.editor.components.toolbars.options.Rotation, SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.groups.BorderSVG, SL.editor.components.toolbars.groups.Link, SL.editor.components.toolbars.groups.Animation].concat(this._super())
		},
		onPropertyChanged : function () {
			this.paint()
		}
	}), SL.editor.blocks.Shape.shapeFromType = function (e, t, i) {
	return t = t || 32,
	i = i || 32,
	/^symbol\-/.test(e) ? SL.util.svg.symbol(e.replace(/^symbol\-/, "")) : "rect" === e ? SL.util.svg.rect(t, i) : "circle" === e ? SL.util.svg.ellipse(t, i) : "diamond" === e ? SL.util.svg.polygon(t, i, 4) : "octagon" === e ? SL.util.svg.polygon(t, i, 8) : "triangle-up" === e ? SL.util.svg.triangleUp(t, i) : "triangle-down" === e ? SL.util.svg.triangleDown(t, i) : "triangle-left" === e ? SL.util.svg.triangleLeft(t, i) : "triangle-right" === e ? SL.util.svg.triangleRight(t, i) : "arrow-up" === e ? SL.util.svg.arrowUp(t, i) : "arrow-down" === e ? SL.util.svg.arrowDown(t, i) : "arrow-left" === e ? SL.util.svg.arrowLeft(t, i) : "arrow-right" === e ? SL.util.svg.arrowRight(t, i) : void 0
}