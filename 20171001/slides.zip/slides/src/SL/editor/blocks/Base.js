 import SL from '../../SL';
 
 SL("editor.blocks").Base = Class.extend({
	init : function (e, t) {
		this.type = e,
		this.pairings = [],
		this.plugins = [],
		this.options = $.extend({
				contentElementType : "div",
				aspectRatio : 0,
				minWidth : 30,
				minHeight : 30,
				horizontalResizing : !0,
				verticalResizing : !0,
				rotation : !0,
				keyboardConsumer : !1,
				introDelay : 1
			}, t),
		this.options.element && (
				this.domElement = $(this.options.element), 
				this.contentElement = this.domElement.find(".sl-block-content")
			),
		this.setup(),
		this.validateProperties(),
		this.render(),
		this.bind(),
		this.format(),
		this.paint(),
		this.transform = new SL.editor.blocks.behavior.Transform(this)
	},
	setup : function () {
		this.watchlist = {},
		this.removed = new signals.Signal,
		this.dragStarted = new signals.Signal,
		this.dragUpdated = new signals.Signal,
		this.dragEnded = new signals.Signal,
		this.propertyChanged = new signals.Signal,
		this.focused = false,
		this.moved = !1,
		this.mouseDownCursor = {
			x : 0,
			y : 0
		},
		this.mouseDownMeasurements = null,
		this.properties = {
			style : {
				opacity : {
					type : "number",
					unit : "%",
					minValue : 0,
					maxValue : 100,
					defaultValue : 100,
					serialize : function (e) {
						return parseInt(e, 10) / 100
					},
					deserialize : function (e) {
						return 100 * parseFloat(e)
					},
					setter : this.setOpacity.bind(this),
					getter : this.getOpacity.bind(this)
				},
				padding : {
					type : "number",
					unit : "px",
					decimals : 0,
					minValue : 0,
					maxValue : 100,
					defaultValue : 0
				},
				color : {
					computed : !0
				},
				"background-color" : {
					computed : !0
				},
				"border-color" : {
					computed : !0,
					getter : this.getBorderColor.bind(this)
				},
				"border-style" : {
					defaultValue : "none",
					options : [{
							value : "solid",
							title : "Solid"
						}, {
							value : "dashed",
							title : "Dashed"
						}, {
							value : "dotted",
							title : "Dotted"
						}
					]
				},
				"border-width" : {
					type : "number",
					unit : "px",
					decimals : 0,
					minValue : 0,
					maxValue : 200,
					defaultValue : 0
				},
				"border-radius" : {
					type : "number",
					unit : "px",
					decimals : 0,
					minValue : 0,
					maxValue : 200,
					defaultValue : 0
				},
				"text-align" : {
					options : [{
							value : "left",
							icon : "alignleft"
						}, {
							value : "center",
							icon : "aligncenter"
						}, {
							value : "right",
							icon : "alignright"
						}, {
							value : "justify",
							icon : "alignjustify"
						}
					]
				},
				"font-size" : {
					type : "number",
					unit : "%",
					minValue : 1,
					maxValue : 500,
					defaultValue : 100
				},
				"line-height" : {
					type : "number",
					unit : "%",
					minValue : 0,
					maxValue : 300,
					defaultValue : 100,
					serialize : function (e) {
						return parseInt(e, 10) / 100 * 1.3
					},
					deserialize : function (e) {
						return parseFloat(e) / 1.3 * 100
					}
				},
				"letter-spacing" : {
					type : "number",
					unit : "%",
					minValue : 0,
					maxValue : 300,
					defaultValue : 100,
					serialize : function (e) {
						return parseInt(e, 10) / 100 - 1 + "em"
					},
					deserialize : function (e) {
						return 100 * (parseFloat(e) + 1)
					}
				},
				"z-index" : {
					type : "number",
					minValue : 0,
					maxValue : 1e3,
					setter : this.setZ.bind(this),
					getter : this.getZ.bind(this)
				},
				"transition-duration" : {
					type : "number",
					unit : "s",
					decimals : 1,
					minValue : 0,
					maxValue : 10,
					stepSize : .1,
					defaultValue : 0
				},
				"transition-delay" : {
					type : "number",
					unit : "s",
					decimals : 1,
					minValue : 0,
					maxValue : 100,
					stepSize : .1,
					defaultValue : 0
				}
			},
			transform : {
				rotate : {
					type : "number",
					unit : "deg",
					decimals : 0,
					minValue : 0,
					maxValue : 360,
					defaultValue : 0,
					setter : this.setRotation.bind(this),
					getter : this.getRotation.bind(this)
				}
			},
			attribute : {
				"class" : {
					type : "string",
					setter : this.setClassName.bind(this),
					getter : this.getClassName.bind(this)
				},
				"data-animation-type" : {
					options : [{
							value : "fade-in",
							title : "Fade in"
						}, {
							value : "fade-out",
							title : "Fade out"
						}, {
							value : "slide-up",
							title : "Slide up"
						}, {
							value : "slide-down",
							title : "Slide down"
						}, {
							value : "slide-right",
							title : "Slide right"
						}, {
							value : "slide-left",
							title : "Slide left"
						}, {
							value : "scale-up",
							title : "Scale up"
						}, {
							value : "scale-down",
							title : "Scale down"
						}
					]
				}
			}
		}
	},
	validateProperties : function () {
		for (var e in this.properties) {
			var t = this.properties[e];
			for (var i in this.properties[e]) {
				var n = t[i],
				o = [];
				"number" === n.type && ("number" != typeof n.minValue && o.push("must have minValue"), "number" != typeof n.maxValue && o.push("must have maxValue"), "number" != typeof n.decimals && (n.decimals = 0), "string" != typeof n.unit && (n.unit = "")),
				o.length && console.warn('Malformed property "' + e + "." + i + '"', o)
			}
		}
	},
	render : function () {
		this.domElement || (this.domElement = $("<div>"), this.domElement.addClass("sl-block")),
		this.contentElement && 0 !== this.contentElement.length || (this.contentElement = $("<" + this.options.contentElementType + ">").appendTo(this.domElement), this.contentElement.addClass("sl-block-content")),
		this.domElement.attr("data-block-type", this.type),
		this.domElement.data("block-instance", this)
	},
	bind : function () {
		this.onClick = this.onClick.bind(this),
		this.onMouseDown = this.onMouseDown.bind(this),
		this.onMouseMove = this.onMouseMove.bind(this),
		this.onMouseUp = this.onMouseUp.bind(this),
		this.onKeyDown = this.onKeyDown.bind(this),
		this.onKeyUp = this.onKeyUp.bind(this),
		this.onDoubleClick = this.onDoubleClick.bind(this),
		this.syncTransformVisibility = this.syncTransformVisibility.bind(this),
		this.domElement.on("vclick", this.onClick),
		this.domElement.on("vmousedown", this.onMouseDown),
		SL.editor.controllers.Blocks.focusChanged.add(this.syncTransformVisibility)
	},
	format : function () {
		this.options.horizontalResizing === !1 && this.domElement.css("width", "auto"),
		this.options.verticalResizing === !1 && this.domElement.css("height", "auto")
	},
	setDefaults : function () {
		this.domElement.css({
			"min-width" : this.options.minWidth,
			"min-height" : this.options.minHeight
		})
	},
	setID : function (e) {
		this.domElement.attr("data-block-id", e)
	},
	getID : function () {
		return this.domElement.attr("data-block-id")
	},
	hasID : function () {
		return !!this.getID()
	},
	getType : function () {
		return this.type
	},
	appendTo : function (e) {
		this.domElement.appendTo(e)
	},
	detach : function () {
		this.domElement.detach()
	},
	blur : function () {
		this.focused && (this.focused = !1, this.domElement.removeClass("is-focused"), this.syncTransformVisibility(), this.hidePaddingHint(), $(document).off("keydown", this.onKeyDown), $(document).off("keyup", this.onKeyUp))
	},
	plug : function (e) {
		this.hasPlugin(e) ? console.log("Plugin is already plugged.") : this.plugins.push(new e(this))
	},
	unplug : function (e) {
		for (var t = 0; t < this.plugins.length; t++) {
			var i = this.plugins[t];
			i instanceof e && (i.destroy(), this.plugins.splice(t, 1))
		}
	},
	hasPlugin : function (e) {
		return this.plugins.some(function (t) {
			return t instanceof e
		})
	},
	isFocused : function () {
		return this.focused
	},
	showPaddingHint : function (e) {
		var t = this.get("style.padding");
		if (t > 0) {
			var i = this.domElement.find(".sl-block-padding-hint");
			0 === i.length && (i = $('<div class="editing-ui sl-block-overlay sl-block-padding-hint">'), i.appendTo(this.contentElement));
			var n = this.measure(!0),
			o = Math.round(window.devicePixelRatio || 1),
			r = 1 * o;
			t *= o;
			var s = n.height * o,
			a = n.width * o,
			l = Math.round(a / 2),
			c = Math.round(s / 2),
			d = Math.round(t),
			u = Math.round(a - t),
			h = Math.round(s - t),
			p = Math.round(t),
			m = i.find("canvas");
			0 === m.length && (m = $("<canvas>").appendTo(i)),
			m.attr({
				width : a,
				height : s
			}),
			m.css({
				width : a / o,
				height : s / o
			});
			var g = m.get(0).getContext("2d");
			g.clearRect(0, 0, a, s),
			g.fillStyle = "rgba(17, 188, 231, 0.1)",
			g.fillRect(0, 0, a, s),
			g.clearRect(p, d, a - 2 * t, s - 2 * t),
			g.fillStyle = "rgba(17, 188, 231, 0.6)",
			g.fillRect(p, d, a - 2 * t, r),
			g.fillRect(u - r, d, r, s - 2 * t),
			g.fillRect(p, h - r, a - 2 * t, r),
			g.fillRect(p, d, r, s - 2 * t),
			g.fillRect(l - r, 0, r, t),
			g.fillRect(l - r, h, r, t),
			g.fillRect(0, c - r, t, r),
			g.fillRect(u, c - r, t, r),
			this.syncZ(),
			clearTimeout(this.hintPaddingTimeout),
			"number" == typeof e && (this.hintPaddingTimeout = setTimeout(this.hidePaddingHint.bind(this), e))
		} else
			this.hidePaddingHint()
	},
	hidePaddingHint : function () {
		clearTimeout(this.hintPaddingTimeout),
		this.domElement.find(".sl-block-padding-hint").remove()
	},
	watch : function (e, t) {
		this.watchlist[e] || (this.watchlist[e] = new signals.Signal),
		this.watchlist[e].add(t)
	},
	unwatch : function (e, t) {
		this.watchlist[e] && this.watchlist[e].remove(t)
	},
	set : function (e, t) {
		if ("string" == typeof e) {
			var i = e;
			e = {},
			e[i] = t
		}
		var n = [];
		for (var o in e)
			if (e.hasOwnProperty(o)) {
				var r = this.getPropertySettings(o);
				if (r) {
					var s = o.split("."),
					a = e[o],
					l = a,
					c = "function" == typeof r.targetElement ? r.targetElement() : this.contentElement;
					"number" == typeof a && 0 === r.decimals && (a = Math.round(a)),
					r.unit && (a += r.unit),
					r.serialize && (a = r.serialize(a)),
					r.setter ? r.setter.call(null, a) : "style" === s[0] ? "undefined" != typeof r.defaultValue && r.defaultValue === l ? c.css(s[1], "") : c.css(s[1], a) : "attribute" === s[0] && c.attr(s[1], a),
					n.push(o),
					this.watchlist[o] && this.watchlist[o].dispatch()
				} else
					console.log("Property not found:", o)
			}
		n.length && this.propertyChanged.dispatch(n)
	},
	get : function (e) {
		var t = this.getPropertySettings(e);
		if (t) {
			var i,
			n = e.split("."),
			o = "function" == typeof t.targetElement ? t.targetElement() : this.contentElement;
			if (o && o.length)
				if (t.getter)
					i = t.getter.call(this);
				else if ("style" === n[0]) {
					var r = n[1].replace(/-(\w)/g, function (e, t) {
							return t.toUpperCase()
						});
					i = t.computed ? o.css(r) : o.get(0).style[r]
				} else if ("attribute" === n[0] && (i = o.attr(n[1]), "string" == typeof i)) {
					if ("null" === i)
						return null;
					if ("true" === i)
						return !0;
					if ("false" === i)
						return !1;
					if (i.match(/^\d+$/))
						return parseFloat(i)
				}
			return "number" === t.type && (i = parseFloat(i)),
			t.deserialize && (i = t.deserialize(i)),
			"undefined" !== t.defaultValue && ("number" === t.type ? isNaN(i) && (i = t.defaultValue) : i || (i = t.defaultValue)),
			i
		}
		return void console.log("Property not found:", e)
	},
	unset : function (e) {
		"string" == typeof e && (e = [e]);
		var t = [];
		e.forEach(function (e) {
			var i = this.getPropertySettings(e);
			if (i) {
				var n = e.split("."),
				o = "function" == typeof i.targetElement ? i.targetElement() : this.contentElement;
				"style" === n[0] ? o.css(n[1], "") : "attribute" === n[0] && o.removeAttr(n[1]),
				t.push(e)
			}
		}
			.bind(this)),
		t.length && this.propertyChanged.dispatch(t)
	},
	isset : function (e) {
		var t = this.getPropertySettings(e);
		if (t) {
			if (t.checker)
				return t.call();
			var i = this.get(e);
			if ("undefined" != typeof i && i !== t.defaultValue)
				return !0
		}
		return !1
	},
	getPropertySettings : function (e) {
		if ("string" == typeof e) {
			e = e.split(".");
			var t = e[0],
			i = e[1],
			n = this.properties[t] ? this.properties[t][i] : null;
			if (n)
				return n;
			console.log("Property not found:", e)
		}
		return null
	},
	getPropertyDefault : function (e) {
		var t = this.getPropertySettings(e);
		return t ? t.defaultValue : null
	},
	setOpacity : function (e) {
		this.contentElement.css("opacity", ""),
		1 === e ? (this.domElement.find(".sl-block-style").css("opacity", ""), this.removeStyleWrapper()) : this.createStyleWrapper().css("opacity", e)
	},
	getOpacity : function () {
		var e,
		t = this.domElement.find(".sl-block-style");
		return e = t.length ? t.get(0).style.opacity : this.contentElement.get(0).style.opacity,
		e = parseFloat(e),
		("undefined" == typeof e || isNaN(e)) && (e = 1),
		e
	},
	setRotation : function (e) {
		e && "0deg" !== e ? this.createStyleWrapper().css("transform", "rotate(" + e + ")") : (this.domElement.find(".sl-block-style").css("transform", ""), this.removeStyleWrapper()),
		this.transform.sync()
	},
	getRotation : function () {
		var e = this.domElement.find(".sl-block-style");
		return e.length ? SL.util.parseCSSTransform(e.get(0).style.transform).rotate || 0 : 0
	},
	getCSSTransform : function () {
		return this.domElement.find(".sl-block-style").css("transform") || ""
	},
	hasTransform : function () {
		return this.isRotated()
	},
	isRotated : function () {
		return 0 !== this.get("transform.rotate")
	},
	setZ : function (e) {
		this.contentElement.css("z-index", e),
		this.domElement.find(".sl-block-overlay, .sl-block-style").css("z-index", e)
	},
	getZ : function () {
		var e = parseInt(this.contentElement.css("z-index"), 10);
		return isNaN(e) ? 0 : e
	},
	syncZ : function () {
		this.domElement.find(".sl-block-overlay, .sl-block-style").css("z-index", this.getZ())
	},
	setClassName : function (e) {
		e = e.replace(/\s{2,}/g, " "),
		e = e.replace(/[^a-zA-Z0-9-_\s]*/gi, ""),
		e = e.trim(),
		this.contentElement.attr("class", "sl-block-content" + (e ? " " + e : ""))
	},
	getClassName : function () {
		var e = this.contentElement.attr("class");
		return e = e.split(" ").map(function (e) {
				return e = e.trim(),
				(/^(sl\-|cke\_)/gi.test(e) || "visible" === e) && (e = ""),
				e
			}).join(" "),
		e = e.replace(/\s{2,}/g, " "),
		e = e.trim()
	},
	getBorderColor : function () {
		return this.contentElement.css("border-top-color")
	},
	getAspectRatio : function () {
		return this.options.aspectRatio
	},
	hasAspectRatio : function () {
		return this.getAspectRatio() > 0
	},
	syncAspectRatio : function () {
		if (this.hasAspectRatio()) {
			var e = this.measure(!0);
			this.resize({
				width : e.width,
				height : e.height,
				center : !0
			})
		}
	},
	syncTransformVisibility : function () {
		this.isFocused() ? this.transform.show() : this.transform.hide()
	},
	showPlaceholder : function () {
		0 === this.contentElement.find(".sl-block-placeholder").length && this.contentElement.append('<div class="editing-ui sl-block-overlay sl-block-placeholder">')
	},
	hidePlaceholder : function () {
		this.contentElement.find(".sl-block-placeholder").remove()
	},
	createStyleWrapper : function () {
		var e = this.domElement.find(".sl-block-style");
		return 0 === e.length && (e = $('<div class="sl-block-style"></div>'), this.contentElement.wrap(e), this.syncZ()),
		e
	},
	removeStyleWrapper : function () {
		!this.hasTransform() && 1 !== this.getOpacity() && this.contentElement.parent(".sl-block-style").length && this.contentElement.unwrap()
	},
	paint : function () {
		this.isEmpty() ? this.showPlaceholder() : this.hidePlaceholder(),
		this.syncZ()
	},
	isEmpty : function () {
		return !1
	},
	isEditingText : function () {
		return !1
	},
	isFragment : function () {
		return this.contentElement.hasClass("fragment")
	},
	removeFragment : function () {
		this.contentElement.removeClass("fragment").removeAttr("data-fragment-index")
	},
	getToolbarOptions : function () {
		return SL.editor.controllers.Blocks.getCurrentBlocks().length > 1 ? [SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.BlockDepth, SL.editor.components.toolbars.options.BlockActions] : [SL.editor.components.toolbars.options.Divider, SL.editor.components.toolbars.options.BlockActions]
	},
	changeContentElementType : function (e) {
		this.contentElement.changeElementType(e),
		this.contentElement = this.domElement.find(".sl-block-content")
	},
	move : function (e, t, i) {
		if (i && i.isOffset)
			this.domElement.css({
				left : "+=" + e,
				top : "+=" + t
			});
		else {
			var n = 0,
			o = 0;
			if (this.hasTransform()) {
				var r = this.measure(!0),
				s = this.measure();
				n = r.x - s.x,
				o = r.y - s.y
			}
			var a = {};
			"number" == typeof e && (a.left = Math.round(e + n)),
			"number" == typeof t && (a.top = Math.round(t + o)),
			this.domElement.css(a)
		}
	},
	moveToCenter : function () {
		var e = this.measure(),
		t = SL.view.getSlideSize();
		this.move((t.width - e.width) / 2, (t.height - e.height) / 2)
	},
	resize : function (e) {
		debugger
		e = e || {};
		var t,
		i;
		if (this.transform.isResizing()) {
			i = this.transform.getState().originalAnchorPositions;
			t = this.transform.getState().originalMeasurements ;
		} else {
			t = this.measure(),
		"number" == typeof e.top && (e.height = t.bottom - e.top, e.direction = "n");
		"number" == typeof e.left && (e.width = t.right - e.left, e.direction = "w");
		"number" == typeof e.right && (e.width = e.right - t.x);
		"number" == typeof e.bottom && (e.height = e.bottom - t.y);
		}
		var n = Math.max(e.width, this.options.minWidth);
		var o = Math.max(e.height, this.options.minHeight);
		if (this.transform.isResizingProportionally()) {
			var r = t.width / t.height;
			/s|n/.test(e.direction) ? n = o * r : o = n / r
		}
		if (this.hasAspectRatio()) {
			var s = this.getAspectRatio();
			e.direction ? /s|n/.test(e.direction) ? n = o * s : o = n / s : this.getAspectRatio() < 1 ? n = o * s : o = n / s
		}
		if (this.domElement.css({
				width : this.options.horizontalResizing ? Math.round(n) : "auto",
				height : this.options.verticalResizing ? Math.round(o) : "auto"
			}), this.transform.isResizingCentered() || e.center) {
			var a = this.measure(!0);
			this.domElement.css({
				left : t.x + (t.width - a.width) / 2,
				top : t.y + (t.height - a.height) / 2
			})
		} else if (this.transform.isResizing()) {
			var l = SL.editor.blocks.behavior.Transform.OPPOSITE_ANCHOR_IDS[this.transform.getState().direction],
			c = i ? i[l] : {
				x : 0,
				y : 0
			},
			d = this.getAnchorPositions()[l];
			if (c && d) {
				var u = t.x - (d.x - c.x),
				h = t.y - (d.y - c.y);
				this.domElement.css({
					left : Math.round(u),
					top : Math.round(h)
				})
			}
		} else
			e.direction &&
			(/n/.test(e.direction) && 
			this.domElement.css("top", t.bottom - o), /w/.test(e.direction) && 
			this.domElement.css("left", t.right - n), 1 === e.direction.length && 
			
			(/n|s/.test(e.direction) ? this.domElement.css("left", t.x + (t.width - n) / 2) : 
			/e|w/.test(e.direction) && this.domElement.css("top", t.y + (t.height - o) / 2)))
	},
	measure : function (e) {
		var t = this.domElement.get(0),
		i = {
			x : t.offsetLeft,
			y : t.offsetTop,
			width : this.domElement.outerWidth(),
			height : this.domElement.outerHeight()
		};
		i.right = i.x + i.width,
		i.bottom = i.y + i.height;
		var n = this.get("transform.rotate");
		if (0 !== n && !e) {
			var o = i.x + i.width / 2,
			r = i.y + i.height / 2,
			s = SL.util.trig.rotateAround(i.x, i.y, o, r, n),
			a = SL.util.trig.rotateAround(i.right, i.y, o, r, n),
			l = SL.util.trig.rotateAround(i.right, i.bottom, o, r, n),
			c = SL.util.trig.rotateAround(i.x, i.bottom, o, r, n);
			i.x = Math.round(Math.min(s.x, a.x, l.x, c.x)),
			i.y = Math.round(Math.min(s.y, a.y, l.y, c.y)),
			i.right = Math.round(Math.max(s.x, a.x, l.x, c.x)),
			i.bottom = Math.round(Math.max(s.y, a.y, l.y, c.y)),
			i.width = Math.round(i.right - i.x),
			i.height = Math.round(i.bottom - i.y)
		}
		return i
	},
	getAnchorPositions : function () {
		var e = this.measure(!0),
		t = this.get("transform.rotate"),
		i = e.width / 2,
		n = e.height / 2;
		return {
			n : SL.util.trig.rotateAround(0 + e.width / 2, 0, i, n, t),
			e : SL.util.trig.rotateAround(e.width, 0 + e.height / 2, i, n, t),
			s : SL.util.trig.rotateAround(0 + e.width / 2, e.height, i, n, t),
			w : SL.util.trig.rotateAround(0, 0 + e.height / 2, i, n, t),
			nw : SL.util.trig.rotateAround(0, 0, i, n, t),
			ne : SL.util.trig.rotateAround(e.width, 0, i, n, t),
			se : SL.util.trig.rotateAround(e.width, e.height, i, n, t),
			sw : SL.util.trig.rotateAround(0, e.height, i, n, t),
			measurements : e
		}
	},
	hitTest : function (e) {
		if (this.isRotated()) {
			var t = this.getAnchorPositions(),
			i = t.measurements,
			n = i.x > e.x && i.right < e.x + e.width && i.y > e.y && i.bottom < e.y + e.height;
			if (n)
				return !0;
			var o = [[{
						x : i.x + t.nw.x,
						y : i.y + t.nw.y
					}, {
						x : i.x + t.ne.x,
						y : i.y + t.ne.y
					}
				], [{
						x : i.x + t.ne.x,
						y : i.y + t.ne.y
					}, {
						x : i.x + t.se.x,
						y : i.y + t.se.y
					}
				], [{
						x : i.x + t.sw.x,
						y : i.y + t.sw.y
					}, {
						x : i.x + t.se.x,
						y : i.y + t.se.y
					}
				], [{
						x : i.x + t.nw.x,
						y : i.y + t.nw.y
					}, {
						x : i.x + t.sw.x,
						y : i.y + t.sw.y
					}
				]],
			r = [[{
						x : e.x,
						y : e.y
					}, {
						x : e.x + e.width,
						y : e.y
					}
				], [{
						x : e.x + e.width,
						y : e.y
					}, {
						x : e.x + e.width,
						y : e.y + e.height
					}
				], [{
						x : e.x,
						y : e.y + e.height
					}, {
						x : e.x + e.width,
						y : e.y + e.height
					}
				], [{
						x : e.x,
						y : e.y
					}, {
						x : e.x,
						y : e.y + e.height
					}
				]];
			return r.some(function (e) {
				return o.some(function (t) {
					return !!SL.util.trig.findLineIntersection(t[0], t[1], e[0], e[1])
				})
			})
		}
		return SL.util.trig.intersects(this.measure(), e)
	},
	runIntro : function () {
		this.domElement.addClass("intro-start"),
		setTimeout(function () {
			this.domElement.removeClass("intro-start").addClass("intro-end"),
			setTimeout(function () {
				this.domElement.removeClass("intro-end")
			}
				.bind(this), 500)
		}
			.bind(this), this.options.introDelay || 1)
	},
	pair : function (e, t) {
		this.pairings.push({
			block : e,
			direction : t
		})
	},
	unpair : function () {
		this.pairings.length = 0
	},
	syncPairs : function () {
		this.pairings.forEach(function (e) {
			e.block.syncPairs()
		})
	},
	destroy : function () {
		this.destroyed = !0,
		SL.editor.controllers.Blocks.focusChanged.remove(this.syncTransformVisibility);
		for (var e in this.watchlist)
			this.watchlist[e].dispose(), delete this.watchlist[e];
		this.removed.dispatch(),
		this.removed.dispose(),
		this.dragStarted.dispose(),
		this.dragUpdated.dispose(),
		this.dragEnded.dispose(),
		this.propertyChanged.dispose(),
		this.transform.destroy(),
		this.domElement.off("vclick", this.onClick),
		this.domElement.off("vmousedown", this.onMouseDown),
		this.domElement.data("block-instance", null),
		this.domElement.remove()
	},
	onClick : function (e) {
		SL.view.isEditing() && this.hasPlugin(SL.editor.blocks.plugin.Link) && this.isLinked() && e.preventDefault()
	},
	focus : function () {
		if (!this.focused) {
			this.focused = true;
			this.domElement.addClass("is-focused");
			this.syncTransformVisibility();
			$(document).on("keydown", this.onKeyDown);
			$(document).on("keyup", this.onKeyUp);
		}
	},
	onMouseDown : function (e) {
		// return !SL.view.isEditing() || 
		// $(e.target).closest(".sl-block-transform .anchor").length > 0 ||
		// $(e.target).closest(".sl-table-column-resizer").length > 0 ?
		// true: void(
		// 	this.isEditingText() || (
				e.preventDefault();
				SL.editor.controllers.Blocks.focus(this, e.shiftKey);
				$("input:focus, textarea:focus").blur();
				$(document).on("vmousemove", this.onMouseMove);
				$(document).on("vmouseup", this.onMouseUp);
				this.moved = false;
				this.mouseDownCursor.x = e.clientX;
				this.mouseDownCursor.y = e.clientY;
				this.dragTargets = SL.editor.controllers.Blocks.getFocusedBlocks().map(function (e) {
						return {
							block : e,
							origin : e.measure()
						}
					})
				// )
			// )
	},
	onMouseMove : function (e) {
		var t = this.moved || Math.abs(this.mouseDownCursor.x - e.clientX) > 1 || Math.abs(this.mouseDownCursor.y - e.clientY) > 1;
		t && (
			e.preventDefault(),
			this.dragTargets.forEach(function (t) {
				t.block.move(t.origin.x + (e.clientX - this.mouseDownCursor.x), t.origin.y + (e.clientY - this.mouseDownCursor.y))
			}.bind(this)),
			this.moved === !1 && SL.editor.controllers.Guides.start(SL.editor.controllers.Blocks.getFocusedBlocks()), 
			SL.editor.controllers.Guides.sync(), 
			this.moved = !0
			)
	},
	onMouseUp : function (e) {
		if (e.preventDefault(), $(document).off("vmousemove", this.onMouseMove), $(document).off("vmouseup", this.onMouseUp), SL.editor.controllers.Guides.stop(), !this.moved) {
			"number" != typeof this.lastMouseUpTime && (this.lastMouseUpTime = 0, this.lastDoubleClickTime = 0);
			var t = Date.now(),
			i = 400;
			t - this.lastMouseUpTime < i && (t - this.lastDoubleClickTime > i && this.onDoubleClick(e), this.lastDoubleClickTime = t),
			this.lastMouseUpTime = t
		}
	},
	onDoubleClick : function () {},
	onKeyDown : function () {},
	onKeyUp : function () {}
})