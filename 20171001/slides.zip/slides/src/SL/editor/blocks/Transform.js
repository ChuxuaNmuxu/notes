 import SL from '../../SL';
 
 SL("editor.blocks.behavior").Transform = Class.extend({
	ANCHOR_SIZE : 16,
	init : function (e) {
		this.block = e,
		this.state = {
			direction : null,
			centered : !1,
			proportional : !1,
			originalMeasurements : null,
			originalCenter : {
				x : 0,
				y : 0
			},
			originalCursorPosition : {
				x : 0,
				y : 0
			}
		},
		this.render(),
		this.bind(),
		this.sync()
	},
	render : function () {
		this.domElement = $('<div class="sl-block-transform editing-ui">'),
		this.anchors = {},
		this.anchors.n = $('<div class="anchor" data-direction="n">').appendTo(this.domElement),
		this.anchors.e = $('<div class="anchor" data-direction="e">').appendTo(this.domElement),
		this.anchors.s = $('<div class="anchor" data-direction="s">').appendTo(this.domElement),
		this.anchors.w = $('<div class="anchor" data-direction="w">').appendTo(this.domElement),
		this.anchors.nw = $('<div class="anchor" data-direction="nw">').appendTo(this.domElement),
		this.anchors.ne = $('<div class="anchor" data-direction="ne">').appendTo(this.domElement),
		this.anchors.se = $('<div class="anchor" data-direction="se">').appendTo(this.domElement),
		this.anchors.sw = $('<div class="anchor" data-direction="sw">').appendTo(this.domElement);
		var e = '<div class="anchor-point"></div>';
		this.block.options.horizontalResizing && this.block.options.verticalResizing ? this.domElement.find(".anchor").html(e) : this.block.options.horizontalResizing ? this.anchors.e.add(this.anchors.w).append(e) : this.block.options.verticalResizing && this.anchors.n.add(this.anchors.s).append(e),
		this.block.options.rotation && this.domElement.find(".anchor").append('<div class="anchor-rotation"></div>')
	},
	bind : function () {
		this.onAnchorMouseDown = this.onAnchorMouseDown.bind(this),
		this.onResizeMouseMove = this.onResizeMouseMove.bind(this),
		this.onResizeMouseUp = this.onResizeMouseUp.bind(this),
		this.onRotateMouseMove = this.onRotateMouseMove.bind(this),
		this.onRotateMouseUp = this.onRotateMouseUp.bind(this),
		this.transformStarted = new signals.Signal,
		this.transformEnded = new signals.Signal;
		for (var e in this.anchors)
			this.anchors[e].on("vmousedown", this.onAnchorMouseDown)
	},
	sync : function () {
		if (this.block.hasTransform() === !1)
			this.domElement.css("transform", ""), this.domElement.find(".anchor[data-cursor-direction]").removeAttr("data-cursor-direction");
		else {
			this.domElement.css("transform", this.block.getCSSTransform());
			for (var e = SL.editor.blocks.behavior.Transform.ANCHOR_IDS, t = e.concat(), i = this.block.get("transform.rotate"), n = Math.round(i / 360 * e.length); 0 > n; )
				t.unshift(t.pop()), n++;
			for (; n > 0; )
				t.push(t.shift()), n--;
			this.domElement.find(".anchor").each(function () {
				var i = this.getAttribute("data-direction"),
				n = t[e.indexOf(i)];
				this.setAttribute("data-cursor-direction", n)
			})
		}
	},
	show : function () {
		0 === this.domElement.parent().length && (this.domElement.appendTo(this.block.domElement), this.domElement.addClass("visible"))
	},
	hide : function () {
		this.domElement.detach(),
		this.domElement.removeClass("visible")
	},
	destroy : function () {
		$(document).off("vmousemove", this.onResizeMouseMove),
		$(document).off("vmouseup", this.onResizeMouseUp),
		$(document).off("vmousemove", this.onRotateMouseMove),
		$(document).off("vmouseup", this.onRotateMouseUp),
		this.domElement.remove()
	},
	isResizing : function () {
		return !!this.state.direction
	},
	isResizingCentered : function () {
		return this.isResizing() && this.state.centered
	},
	isResizingProportionally : function () {
		return this.isResizing() && this.state.proportional
	},
	canUseGuides : function () {
		return !this.block.isRotated()
	},
	getState : function () {
		return this.state
	},
	onAnchorMouseDown : function (e) {
		if (e.preventDefault(), this.moved = !1, $(e.target).hasClass("anchor-rotation")) {
			$(document).on("vmousemove", this.onRotateMouseMove),
			$(document).on("vmouseup", this.onRotateMouseUp),
			this.state.slideBounds = SL.util.getRevealSlidesBounds(),
			this.state.originalRotation = this.block.get("transform.rotate"),
			this.state.originalMeasurements = this.block.measure(),
			this.state.originalCenter.x = this.state.originalMeasurements.x + this.state.originalMeasurements.width / 2,
			this.state.originalCenter.y = this.state.originalMeasurements.y + this.state.originalMeasurements.height / 2;
			var t = e.clientX - this.state.slideBounds.x,
			i = e.clientY - this.state.slideBounds.y;
			this.state.originalCursorAngle = 180 * (Math.atan2(i - this.state.originalCenter.y, t - this.state.originalCenter.x) + Math.PI / 2) / Math.PI
		} else
			this.state.direction = $(e.currentTarget).attr("data-direction"), this.state.direction && ($(document).on("vmousemove", this.onResizeMouseMove), $(document).on("vmouseup", this.onResizeMouseUp), this.state.originalCursorPosition.x = e.clientX, this.state.originalCursorPosition.y = e.clientY, this.state.originalMeasurements = this.block.measure(!0), this.state.originalAnchorPositions = this.block.getAnchorPositions())
	},
	onResizeMouseMove : function (e) {
		e.preventDefault(),
		this.moved || (this.transformStarted.dispatch(this), SL.editor.controllers.Guides.start([this.block], {
				action : "resize",
				direction : this.state.direction
			})),
		this.moved = !0;
		var t = e.clientX,
		i = e.clientY,
		n = t - this.state.originalCursorPosition.x,
		o = i - this.state.originalCursorPosition.y,
		r = this.block.get("transform.rotate");
		if (r) {
			var s = SL.util.trig.rotateAround(n, o, 0, 0, -r);
			n = s.x,
			o = s.y
		}
		e.altKey && (n *= 2, o *= 2);
		var a = "",
		l = "";
		switch (this.state.direction) {
		case "e":
			a = Math.max(this.state.originalMeasurements.width + n, 1);
			break;
		case "w":
			a = Math.max(this.state.originalMeasurements.width - n, 1);
			break;
		case "s":
			l = Math.max(this.state.originalMeasurements.height + o, 1);
			break;
		case "n":
			l = Math.max(this.state.originalMeasurements.height - o, 1);
			break;
		case "nw":
			a = Math.max(this.state.originalMeasurements.width - n, 1),
			l = Math.max(this.state.originalMeasurements.height - o, 1);
			break;
		case "ne":
			a = Math.max(this.state.originalMeasurements.width + n, 1),
			l = Math.max(this.state.originalMeasurements.height - o, 1);
			break;
		case "se":
			a = Math.max(this.state.originalMeasurements.width + n, 1),
			l = Math.max(this.state.originalMeasurements.height + o, 1);
			break;
		case "sw":
			a = Math.max(this.state.originalMeasurements.width - n, 1),
			l = Math.max(this.state.originalMeasurements.height + o, 1)
		}
		this.block.hasAspectRatio() ? ("" === a && (a = this.state.originalMeasurements.width * (l / this.state.originalMeasurements.height)), "" === l && (l = this.state.originalMeasurements.height * (a / this.state.originalMeasurements.width))) : ("" === a && (a = this.state.originalMeasurements.width), "" === l && (l = this.state.originalMeasurements.height)),
		this.state.centered = e.altKey,
		this.state.proportional = e.shiftKey,
		this.block.resize({
			width : a,
			height : l,
			direction : this.state.direction
		}),
		this.canUseGuides() && SL.editor.controllers.Guides.sync()
	},
	onResizeMouseUp : function (e) {
		e.preventDefault(),
		$(document).off("vmousemove", this.onResizeMouseMove),
		$(document).off("vmouseup", this.onResizeMouseUp),
		SL.editor.controllers.Guides.stop(),
		this.moved && this.transformEnded.dispatch(this),
		this.state.direction = null,
		this.state.centered = null,
		this.state.proportional = null
	},
	onRotateMouseMove : function (e) {
		e.preventDefault(),
		this.moved || this.transformStarted.dispatch(this),
		this.moved = !0;
		var t = (this.state.originalMeasurements.x + this.state.originalMeasurements.width / 2, this.state.originalMeasurements.y + this.state.originalMeasurements.height / 2, e.clientX - this.state.slideBounds.x),
		i = e.clientY - this.state.slideBounds.y,
		n = Math.atan2(i - this.state.originalCenter.y, t - this.state.originalCenter.x) + Math.PI / 2;
		if (n = 180 * n / Math.PI, n = this.state.originalRotation + (n - this.state.originalCursorAngle), 0 > n && (n = 360 + n % 360), n > 0 && (n %= 360), SL.current_user.settings.get("editor_snap"))
			for (var o = 0; o < SL.editor.blocks.behavior.Transform.ROTATION_SNAP_ANGLES.length; o++) {
				var r = SL.editor.blocks.behavior.Transform.ROTATION_SNAP_ANGLES[o];
				if (Math.abs(n - r) < SL.editor.blocks.behavior.Transform.ROTATION_SNAP_RANGE) {
					n = r;
					break
				}
			}
		this.block.set("transform.rotate", n)
	},
	onRotateMouseUp : function (e) {
		e.preventDefault(),
		$(document).off("vmousemove", this.onRotateMouseMove),
		$(document).off("vmouseup", this.onRotateMouseUp),
		this.moved && this.transformEnded.dispatch(this),
		this.state.originalCursorAngle = null,
		this.state.originalRotation = null
	}
}),

SL.editor.blocks.behavior.Transform.ROTATION_SNAP_RANGE = 3
, SL.editor.blocks.behavior.Transform.ROTATION_SNAP_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315, 360],
SL.editor.blocks.behavior.Transform.ANCHOR_IDS = ["n", "ne", "e", "se", "s", "sw", "w", "nw"],
SL.editor.blocks.behavior.Transform.OPPOSITE_ANCHOR_IDS = {
	n : "s",
	ne : "sw",
	e : "w",
	se : "nw",
	s : "n",
	sw : "ne",
	w : "e",
	nw : "se"
}