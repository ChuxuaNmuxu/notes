import SL from '../SL';

SL("models").Team = SL.models.Model.extend({
	init : function (t) {
		if (this._super(t), "object" == typeof this.data.themes)
			for (var e = 0,
				i = this.data.themes.length; i > e; e++)
				this.data.themes[e] = new SL.models.Theme(this.data.themes[e]);
		this.set("themes", new SL.collections.Collection(this.data.themes))
	},
	hasThemes : function () {
		var t = this.get("themes");
		return t && t.size() > 0
	},
	getDefaultTheme : function () {
		return this.get("themes").getByProperties({
			id : this.get("default_theme_id")
		})
	},
	getCostPerUser : function () {
		var t = this.get("account_billing_period"),
		e = this.get("account_cost_per_user");
		return "yearly" === t ? "$" + e + "/year" : "monthly" === t ? "$" + e + "/month" : "N/A"
	},
	isManuallyUpgraded : function () {
		return !!this.get("manually_upgraded")
	},
	allowPublicDecks : function () {
		return !!this.get("allow_public_decks")
	},
	save : function (t) {
		var e = {
			team : {}
		};
		return t ? t.forEach(function (t) {
			e.team[t] = this.get(t)
		}
			.bind(this)) : e.team = this.toJSON(),
		$.ajax({
			url : SL.config.AJAX_UPDATE_TEAM,
			type : "PUT",
			data : e
		})
	},
	clone : function () {
		return new SL.models.Team(JSON.parse(JSON.stringify(this.data)))
	}
});