import SL from '../../SL';

SL("models.collab").Comment = SL.models.Model.extend({
	init : function (t) {
		this._super(t),
		this.state = this.has("id") ? SL.models.collab.Comment.STATE_SAVED : SL.models.collab.Comment.STATE_SAVING,
		this.stateChanged = new signals.Signal
	},
	setState : function (t) {
		this.state = t,
		this.stateChanged.dispatch(this)
	},
	getState : function () {
		return this.state
	},
	getDisplayName : function () {
		return this.get("name") || this.get("username")
	},
	clone : function () {
		return new SL.models.collab.Comment(JSON.parse(JSON.stringify(this.data)))
	},
	save : function (t) {
		var e = {
			comment : {}
		};
		return t ? t.forEach(function (t) {
			e.comment[t] = this.get(t)
		}
			.bind(this)) : e.comment = this.toJSON(),
		$.ajax({
			url : SL.config.AJAX_COMMENTS_UPDATE(SL.current_deck.get("id"), this.get("id")),
			type : "PUT",
			data : e
		})
	},
	destroy : function () {
		return $.ajax({
			url : SL.config.AJAX_COMMENTS_DELETE(SL.current_deck.get("id"), this.get("id")),
			type : "DELETE"
		})
	}
});