import SL from '../../SL';

SL("models.collab").DeckUser = SL.models.Model.extend({
	init : function (t) {
		this._super(t),
		this.has("status") || this.set("status", SL.models.collab.DeckUser.STATUS_DISCONNECTED)
	},
	getDisplayName : function () {
		return this.get("name") || this.get("username")
	},
	canComment : function () {
		return !0
	},
	canEdit : function () {
		return  - 1 !== [SL.models.collab.DeckUser.ROLE_OWNER, SL.models.collab.DeckUser.ROLE_ADMIN, SL.models.collab.DeckUser.ROLE_EDITOR].indexOf(this.get("role"))
	},
	isAdmin : function () {
		return  - 1 !== [SL.models.collab.DeckUser.ROLE_OWNER, SL.models.collab.DeckUser.ROLE_ADMIN].indexOf(this.get("role"))
	},
	isOnline : function () {
		return this.get("status") && this.get("status") !== SL.models.collab.DeckUser.STATUS_DISCONNECTED
	},
	isIdle : function () {
		return this.get("status") === SL.models.collab.DeckUser.STATUS_IDLE
	},
	isEditing : function () {
		return this.get("editing") === !0
	},
	isActive : function () {
		return this.get("active") === !0
	},
	isCurrentUser : function () {
		return this.get("user_id") === SL.current_user.get("id")
	},
	clone : function () {
		return new SL.models.collab.DeckUser(JSON.parse(JSON.stringify(this.data)))
	},
	save : function (t) {
		var e = {
			user : {}
		};
		return t ? t.forEach(function (t) {
			e.user[t] = this.get(t)
		}
			.bind(this)) : e.user = this.toJSON(),
		$.ajax({
			url : SL.config.AJAX_DECKUSER_UPDATE(SL.current_deck.get("id"), this.get("user_id")),
			type : "PUT",
			data : e
		})
	},
	destroy : function () {
		return $.ajax({
			url : SL.config.AJAX_DECKUSER_DELETE(SL.current_deck.get("id"), this.get("user_id")),
			type : "DELETE"
		})
	}
});