import SL from '../SL';

SL("models").AccessToken = SL.models.Model.extend({
	init : function (t) {
		this._super(t)
	},
	save : function (t) {
		var e = {
			access_token : {}
		};
		return t ? t.forEach(function (t) {
			e.access_token[t] = this.get(t)
		}
			.bind(this)) : e.access_token = this.toJSON(),
		$.ajax({
			url : SL.config.AJAX_ACCESS_TOKENS_UPDATE(this.get("deck_id"), this.get("id")),
			type : "PUT",
			data : e
		})
	},
	destroy : function () {
		return $.ajax({
			url : SL.config.AJAX_ACCESS_TOKENS_DELETE(this.get("deck_id"), this.get("id")),
			type : "DELETE"
		})
	},
	clone : function () {
		return new SL.models.AccessToken(JSON.parse(JSON.stringify(this.data)))
	}
});