import SL from '../SL';

SL("models").Customer = SL.models.Model.extend({
	init : function (t) {
		this._super(t)
	},
	isTrial : function () {
		return "trialing" === this.get("subscription.status")
	},
	hasActiveSubscription : function () {
		return this.has("subscription") && !this.get("subscription.cancel_at_period_end")
	},
	hasCoupon : function () {
		return this.has("subscription") && this.has("subscription.coupon_code")
	},
	getNextInvoiceDate : function () {
		return this.get("next_charge")
	},
	getNextInvoiceSum : function () {
		return (parseFloat(this.get("next_charge_amount")) / 100).toFixed(2)
	},
	clone : function () {
		return new SL.models.Customer(JSON.parse(JSON.stringify(this.data)))
	}
});