import SL from '../SL';

import './Model';
import './AccessToken';
import './collab/Comment';

SL.models.collab.Comment.STATE_SAVED = "saved",
SL.models.collab.Comment.STATE_SAVING = "saving",
SL.models.collab.Comment.STATE_FAILED = "failed";

import './collab/DeckUser';

SL.models.collab.DeckUser.ROLE_OWNER = "owner",
SL.models.collab.DeckUser.ROLE_ADMIN = "admin",
SL.models.collab.DeckUser.ROLE_EDITOR = "editor",
SL.models.collab.DeckUser.ROLE_VIEWER = "viewer",
SL.models.collab.DeckUser.STATUS_DISCONNECTED = "disconnected",
SL.models.collab.DeckUser.STATUS_VIEWING = "viewing",
SL.models.collab.DeckUser.STATUS_IDLE = "idle";

import './Customer';
import './Deck';

SL("models").Deck.VISIBILITY_SELF = "self",
SL("models").Deck.VISIBILITY_TEAM = "team",
SL("models").Deck.VISIBILITY_ALL = "all";

import './MediaTag';
import './Media';

SL.models.Media.STATUS_UPLOAD_WAITING = "waiting",
SL.models.Media.STATUS_UPLOADING = "uploading",
SL.models.Media.STATUS_UPLOADED = "uploaded",
SL.models.Media.STATUS_UPLOAD_FAILED = "upload-failed",
SL.models.Media.IMAGE = {
	id : "image",
	filter : function (t) {
		return t.isImage()
	}
},
SL.models.Media.SVG = {
	id : "svg",
	filter : function (t) {
		return t.isSVG()
	}
},
SL.models.Media.VIDEO = {
	id : "video",
	filter : function (t) {
		return t.isVideo()
	}
};

import './Team';
import './Template';
import './ThemeSnippet';

SL.models.ThemeSnippet.TEMPLATE_VARIABLE_OPENER = "{{",
SL.models.ThemeSnippet.TEMPLATE_VARIABLE_CLOSER = "}}",
SL.models.ThemeSnippet.TEMPLATE_VARIABLE_DIVIDER = "::",
SL.models.ThemeSnippet.TEMPLATE_VARIABLE_REGEX = /\{\{.*?\}\}/gi,
SL.models.ThemeSnippet.TEMPLATE_SELECTION_TAG = "{{selection}}";

import './Theme';

SL("models").Theme.fromDeck = function (t) {
	return new SL.models.Theme({
		id : t.theme_id,
		name : "",
		width : t.width,
		height : t.height,
		center : t.center,
		rolling_links : t.rolling_links,
		font : t.theme_font,
		color : t.theme_color,
		transition : t.transition,
		background_transition : t.background_transition,
		font_typekit : t.font_typekit,
		font_google : t.font_google,
		snippets : "",
		palette : []
	})
};

import './UserMembership';

SL.models.UserMembership.ROLE_OWNER = "owner",
SL.models.UserMembership.ROLE_ADMIN = "admin",
SL.models.UserMembership.ROLE_MEMBER = "member";

import './UserPrivileges';
import './UserSettings';
import './User';
