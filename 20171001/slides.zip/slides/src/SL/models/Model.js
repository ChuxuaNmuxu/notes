import SL from '../SL';

SL("models").Model = Class.extend({
	init : function (t) {
		this.watchlist = {},
		this.setData(t)
	},
	setData : function (t) {
		this.data = t || {}
	},
	getData : function () {
		return this.data
	},
	setAll : function (t) {
		for (var e in t)
			this.set(e, t[e])
	},
	set : function (t, e) {
		this.data[t] = e,
		this.watchlist[t] && this.watchlist[t].dispatch(e)
	},
	get : function (t) {
		if ("string" == typeof t && /\./.test(t)) {
			for (var e = t.split("."), i = this.data; e.length && i; )
				t = e.shift(),
				i = i[t];
			return i
		}
		return this.data[t]
	},
	has : function (t) {
		var e = this.get(t);
		return !!e || e === !1 || 0 === e
	},
	watch : function (t, e) {
		this.watchlist[t] || (this.watchlist[t] = new signals.Signal),
		this.watchlist[t].add(e)
	},
	unwatch : function (t, e) {
		this.watchlist[t] && this.watchlist[t].remove(e)
	},
	toJSON : function () {
		return JSON.parse(JSON.stringify(this.data))
	},
	destroy : function () {
		for (var t in this.watchlist)
			this.watchlist[t].dispose(),
			delete this.watchlist[t]
	}
});