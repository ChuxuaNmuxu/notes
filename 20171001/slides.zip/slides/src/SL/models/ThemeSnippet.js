import SL from '../SL';

SL("models").ThemeSnippet = SL.models.Model.extend({
	init : function (t) {
		this._super(t),
		this.has("title") || this.set("title", ""),
		this.has("template") || this.set("template", "")
	},
	templatize : function (t) {
		var e = this.get("template");
		return e && (e = e.split(SL.models.ThemeSnippet.TEMPLATE_SELECTION_TAG).join(""), t.forEach(function (t) {
				e = e.replace(t.string, t.value || t.defaultValue)
			})),
		e
	},
	getTemplateVariables : function () {
		var t = this.get("template");
		if (t) {
			t = t.split(SL.models.ThemeSnippet.TEMPLATE_SELECTION_TAG).join("");
			var e = t.match(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_REGEX);
			if (e)
				return e = e.map(function (t) {
						var e = t.split(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_DIVIDER),
						i = {
							string : t,
							label : e[0] || "",
							defaultValue : e[1] || ""
						};
						return i.label = i.label.trim(),
						i.defaultValue = i.defaultValue.trim(),
						i.label = i.label.replace(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_OPENER, ""),
						i.label = i.label.replace(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_CLOSER, ""),
						i.defaultValue = i.defaultValue.replace(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_OPENER, ""),
						i.defaultValue = i.defaultValue.replace(SL.models.ThemeSnippet.TEMPLATE_VARIABLE_CLOSER, ""),
						i
					})
		}
		return []
	},
	templateHasVariables : function () {
		return this.getTemplateVariables().length > 0
	},
	templateHasSelection : function () {
		var t = this.get("template");
		return t ? t.indexOf(SL.models.ThemeSnippet.TEMPLATE_SELECTION_TAG) > -1 : !1
	},
	isEmpty : function () {
		return !this.get("title") && !this.get("template")
	}
});