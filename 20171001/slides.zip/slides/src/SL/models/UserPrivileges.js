import SL from '../SL';

SL("models").UserPrivileges = SL.models.Model.extend({
	init : function (t, e) {
		this._super(t, e),
		this.user = e
	},
	privateDecks : function () {
		return this.user.isPaid()
	},
	privateLinks : function () {
		return this.user.isPro()
	},
	customCSS : function () {
		return this.user.isPro()
	},
	hideEmbedFooter : function () {
		return this.user.isPaid()
	}
});