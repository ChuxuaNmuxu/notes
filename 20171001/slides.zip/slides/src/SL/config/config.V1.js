import SL from '../SL';

SL.config.V1 = {
	DEFAULT_THEME_COLOR : "grey-blue",
	DEFAULT_THEME_FONT : "league",
	DEFAULT_THEME_TRANSITION : "linear",
	DEFAULT_THEME_BACKGROUND_TRANSITION : "fade",
	THEME_COLORS : [{
			id : "grey-blue"
		}, {
			id : "black-mint"
		}, {
			id : "black-orange"
		}, {
			id : "forest-yellow"
		}, {
			id : "lila-yellow"
		}, {
			id : "asphalt-orange"
		}, {
			id : "sky-blue"
		}, {
			id : "beige-brown"
		}, {
			id : "sand-grey"
		}, {
			id : "silver-green"
		}, {
			id : "silver-blue"
		}, {
			id : "cobalt-orange"
		}, {
			id : "white-blue"
		}, {
			id : "mint-beige"
		}, {
			id : "sea-yellow"
		}, {
			id : "coral-blue"
		}
	],
	THEME_FONTS : [{
			id : "league",
			title : "League"
		}, {
			id : "opensans",
			title : "Open Sans"
		}, {
			id : "josefine",
			title : "Josefine"
		}, {
			id : "palatino",
			title : "Palatino"
		}, {
			id : "news",
			title : "News"
		}, {
			id : "montserrat",
			title : "Montserrat"
		}, {
			id : "helvetica",
			title : "Helvetica"
		}, {
			id : "asul",
			title : "Asul"
		}, {
			id : "merriweather",
			title : "Merriweather"
		}, {
			id : "sketch",
			title : "Sketch"
		}, {
			id : "quicksand",
			title : "Quicksand"
		}, {
			id : "overpass",
			title : "Overpass v1",
			deprecated : !0
		}, {
			id : "overpass2",
			title : "Overpass"
		}
	]
};