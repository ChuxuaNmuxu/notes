import SL from '../SL';

SL("components").TemplatesPage = Class.extend({
	init : function (t) {
		this.options = t || {},
		this.templateSelected = new signals.Signal,
		this.render()
	},
	render : function () {
		this.domElement = $('<div class="page" data-page-id="' + this.options.id + '">'),
		this.actionList = $('<div class="action-list">').appendTo(this.domElement),
		this.templateList = $('<div class="template-list">').appendTo(this.domElement),
		this.options.templates.forEach(this.renderTemplate.bind(this)),
		(this.isDefaultTemplates() || this.isTeamTemplates() && this.getNumberOfVisibleTemplates() > 0) && (this.blankTemplate = this.renderBlankTemplate(), this.duplicateTemplate = this.renderDuplicateTemplate())
	},
	renderBlankTemplate : function (t) {
		return t = $.extend({
				container : this.actionList,
				editable : !1
			},
				t),
		this.renderTemplate(new SL.models.Template({
				label : "Blank",
				html : ""
			}), t)
	},
	renderDuplicateTemplate : function (t, e) {
		return t = $.extend({
				container : this.actionList,
				editable : !1
			},
				t),
		this.renderTemplate(new SL.models.Template({
				label : "Duplicate",
				html : e || ""
			}), t)
	},
	renderTemplate : function (t, e) {
		e = $.extend({
				prepend : !1,
				editable : !0,
				container : this.templateList
			},
				e);
		var i = $('<div class="template-item">');
		i.html(['<div class="template-item-thumb themed">', '<div class="template-item-thumb-content reveal reveal-thumbnail ready">', '<div class="slides">', t.get("html"), "</div>", '<div class="backgrounds"></div>', "</div>", "</div>"].join("")),
		i.data("template-model", t),
		i.on("vclick", this.onTemplateSelected.bind(this, i)),
		i.find(".slides>section").addClass("present"),
		i.find('.sl-block[data-block-type="code"] pre').addClass("hljs"),
		t.get("label") && i.append('<span class="template-item-label">' + t.get("label") + "</span>"),
		e.replaceTemplate ? e.replaceTemplate.replaceWith(i) : e.replaceTemplateAt ? e.container.find(".template-item").eq(e.replaceTemplateAt).replaceWith(i) : e.prepend ? e.container.prepend(i) : e.container.append(i);
		var n = i.find("section").attr("data-background-color"),
		s = i.find("section").attr("data-background-image"),
		o = i.find("section").attr("data-background-size"),
		a = i.find("section").attr("data-background-position"),
		r = $('<div class="slide-background present template-item-thumb-background">');
		if (r.addClass(i.find(".template-item-thumb .reveal section").attr("class")), r.appendTo(i.find(".template-item-thumb .reveal>.backgrounds")), (n || s) && (n && r.css("background-color", n), s && r.css("background-image", 'url("' + s + '")'), o && r.css("background-size", o), a && r.css("background-position", a)), this.isEditable() && e.editable) {
			var l = $('<div class="template-item-options"></div>').appendTo(i),
			d = $('<div class="option"><span class="icon i-trash-stroke"></span></div>');
			if (d.attr("data-tooltip", "Delete this template"), d.on("vclick", this.onTemplateDeleteClicked.bind(this, i)), d.appendTo(l), this.isTeamTemplates() && SL.current_user.getThemes().size() > 1) {
				var c = $('<div class="option"><span class="icon i-ellipsis-v"></span></div>');
				c.attr("data-tooltip", "Theme availability"),
				c.on("vclick", this.onTemplateThemeClicked.bind(this, i)),
				c.appendTo(l)
			}
		}
		return i
	},
	refresh : function () {
		this.duplicateTemplate && this.duplicateTemplate.length && (this.duplicateTemplate = this.renderDuplicateTemplate({
					replaceTemplate : this.duplicateTemplate
				},
					SL.data.templates.templatize(Reveal.getCurrentSlide()))),
		this.templateList.find(".placeholder").remove(),
		this.refreshSizes();
		var t = SL.view.getCurrentTheme(),
		e = this.domElement.find(".template-item");
		if (this.isTeamTemplates() && e.each(function (e, i) {
				var n = $(i),
				s = n.data("template-model").isAvailableForTheme(t);
				n.toggleClass(SL.current_user.isEnterpriseManager() ? "semi-hidden" : "hidden", !s)
			}
				.bind(this)), e = this.domElement.find(".template-item:not(.hidden)"), e.length)
			e.each(function (e, i) {
				var n = $(i),
				s = (n.data("template-model"), n.find(".template-item-thumb"));
				s.attr("class", s.attr("class").replace(/theme\-(font|color)\-([a-z0-9-])*/gi, "")),
				s.addClass("theme-font-" + t.get("font")),
				s.addClass("theme-color-" + t.get("color")),
				s.find(".template-item-thumb-content img[data-src]").each(function () {
					this.setAttribute("src", this.getAttribute("data-src")),
					this.removeAttribute("data-src")
				}),
				SL.data.templates.layoutTemplate(s.find("section"), !0)
			}
				.bind(this)),
			this.templateList.find(".placeholder").remove();
		else {
			var i = "You haven't saved any custom templates yet.<br>Click the button below to save one now.";
			this.isTeamTemplates() && (i = SL.current_user.isEnterpriseManager() ? "Templates saved here are made available to the everyone in your team." : "No templates are available for the current theme."),
			this.templateList.append('<p class="placeholder">' + i + "</p>")
		}
	},
	refreshSizes : function () {
		var t = Reveal.getConfig(),
		e = t.width,
		i = t.height,
		n = 204,
		s = n / e,
		o = Math.round(i * s);
		this.domElement.find(".template-item-thumb").css("height", o),
		this.domElement.find(".template-item-thumb-content").css({
			width : e,
			height : i,
			transform : "scale(" + s + ")"
		})
	},
	appendTo : function (t) {
		this.domElement.appendTo(t)
	},
	saveCurrentSlide : function () {
		var t = SL.config.AJAX_SLIDE_TEMPLATES_CREATE;
		return this.isTeamTemplates() && (t = SL.config.AJAX_TEAM_SLIDE_TEMPLATES_CREATE),
		$.ajax({
			type : "POST",
			url : t,
			context : this,
			data : {
				slide_template : {
					html : SL.data.templates.templatize(Reveal.getCurrentSlide())
				}
			}
		}).done(function (t) {
			this.options.templates.create(t, {
				prepend : !0
			}).then(function (t) {
				this.renderTemplate(t, {
					prepend : !0
				}),
				this.refresh()
			}
				.bind(this)),
			SL.notify(SL.locale.get("TEMPLATE_CREATE_SUCCESS"))
		}).fail(function () {
			SL.notify(SL.locale.get("TEMPLATE_CREATE_ERROR"), "negative")
		})
	},
	isEditable : function () {
		return this.isUserTemplates() || this.isTeamTemplates() && SL.current_user.isEnterpriseManager()
	},
	isDefaultTemplates : function () {
		return "default" === this.options.id
	},
	isUserTemplates : function () {
		return "user" === this.options.id
	},
	isTeamTemplates : function () {
		return "team" === this.options.id
	},
	getNumberOfVisibleTemplates : function () {
		return this.domElement.find(".template-item:not(.hidden)").length
	},
	onTemplateSelected : function (t, e) {
		e.preventDefault(),
		this.templateSelected.dispatch(t.data("template-model"))
	},
	onTemplateDeleteClicked : function (t, e) {
		return e.preventDefault(),
		SL.prompt({
			anchor : $(e.currentTarget),
			title : SL.locale.get("TEMPLATE_DELETE_CONFIRM"),
			type : "select",
			hoverTarget : t,
			data : [{
					html : "<h3>Cancel</h3>"
				}, {
					html : "<h3>Delete</h3>",
					selected : !0,
					className : "negative",
					callback : function () {
						var e = t.data("template-model"),
						i = SL.config.AJAX_SLIDE_TEMPLATES_DELETE(e.get("id"));
						this.isTeamTemplates() && (i = SL.config.AJAX_TEAM_SLIDE_TEMPLATES_DELETE(e.get("id"))),
						$.ajax({
							type : "DELETE",
							url : i,
							context : this
						}).done(function () {
							t.remove(),
							this.refresh()
						})
					}
					.bind(this)
				}
			]
		}),
		!1
	},
	onTemplateThemeClicked : function (t, e) {
		e.preventDefault();
		var i = SL.current_user.getThemes();
		if (i.size() > 0) {
			var n = t.data("template-model"),
			s = n.get("id"),
			o = n.isAvailableForAllThemes(),
			a = ($(Reveal.getCurrentSlide()), [{
						value : "All themes",
						selected : o,
						exclusive : !0,
						className : "header-item",
						callback : function () {
							i.forEach(function (t) {
								t.hasSlideTemplate(s) && t.removeSlideTemplate([s]).fail(this.onGenericError)
							}
								.bind(this)),
							this.refresh()
						}
						.bind(this)
					}
				]);
			i.forEach(function (t) {
				a.push({
					value : t.get("name"),
					selected : o ? !1 : n.isAvailableForTheme(t),
					callback : function (e, i) {
						i ? t.addSlideTemplate([s]).fail(this.onGenericError) : t.removeSlideTemplate([s]).fail(this.onGenericError),
						this.refresh()
					}
					.bind(this)
				})
			}
				.bind(this)),
			SL.prompt({
				anchor : $(e.currentTarget),
				title : "Available for...",
				type : "list",
				alignment : "l",
				data : a,
				multiselect : !0,
				optional : !0,
				hoverTarget : t
			})
		}
		return !1
	},
	onGenericError : function () {
		SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
	}
});