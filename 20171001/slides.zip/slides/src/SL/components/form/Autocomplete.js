import SL from '../../SL';

SL("components.form").Autocomplete = Class.extend({
    init : function (t, e, i) {
        this.inputElement = t,
        this.searchMethod = e,
        this.confirmed = new signals.Signal,
        this.config = $.extend({
                offsetY : 0,
                offsetX : 0,
                className : null
            },
                i),
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-autocomplete">'),
        this.config.className && this.domElement.addClass(this.config.className)
    },
    bind : function () {
        this.onDocumentKeydown = this.onDocumentKeydown.bind(this),
        this.showSuggestions = this.showSuggestions.bind(this),
        this.hideSuggestions = this.hideSuggestions.bind(this),
        this.layout = $.throttle(this.layout, 500, this),
        this.onInput = $.throttle(this.onInput, 500, this),
        this.inputElement.on("input", this.onInput),
        this.inputElement.on("focus", this.onInput),
        this.inputElement.on("blur", this.hideSuggestions),
        this.domElement.on("mousedown", this.onClick.bind(this))
    },
    layout : function () {
        var t = this.inputElement.get(0).getBoundingClientRect();
        this.domElement.css({
            top : t.bottom + this.config.offsetY,
            left : t.left + this.config.offsetX,
            width : t.width
        })
    },
    showSuggestions : function (t) {
        var e = t.map(function (t, e) {
                var i = "sl-autocomplete-item" + (0 === e ? " focus" : "");
                return "string" == typeof t && (t = {
                        value : t,
                        label : t
                    }),
                '<div class="' + i + '" data-value="' + t.value + '">' + t.label + "</div>"
            });
        this.domElement.html(e.join("")),
        this.domElement.appendTo(document.body),
        this.layout(),
        $(window).on("resize", this.layout),
        SL.keyboard.keydown(this.onDocumentKeydown)
    },
    hideSuggestions : function () {
        this.domElement.detach(),
        $(window).off("resize", this.layout),
        SL.keyboard.release(this.onDocumentKeydown)
    },
    focus : function (t) {
        var e = this.domElement.find(".focus");
        e.length || (e = this.domElement.find(".sl-autocomplete-item").first(), e.addClass("focus"));
        var i = t > 0 ? e.next(".sl-autocomplete-item") : e.prev(".sl-autocomplete-item");
        i.length && (e.removeClass("focus"), i.addClass("focus"))
    },
    setValue : function (t) {
        this.inputElement.val(t),
        this.confirmed.dispatch(t)
    },
    getFocusedValue : function () {
        return this.domElement.find(".focus").attr("data-value")
    },
    destroy : function () {
        this.confirmed.dispose(),
        this.inputElement.off("input", this.onInput),
        this.hideSuggestions()
    },
    onInput : function () {
        this.searchMethod(this.inputElement.val()).then(function (t) {
            t.length > 0 ? this.inputElement.is(":focus") && this.showSuggestions(t) : this.hideSuggestions()
        }
            .bind(this),
            function () {
            this.hideSuggestions()
        }
            .bind(this))
    },
    onClick : function (t) {
        var e = $(t.target).closest(".sl-autocomplete-item");
        e.length && (this.setValue(e.attr("data-value")), this.hideSuggestions())
    },
    onDocumentKeydown : function (t) {
        return 27 === t.keyCode ? (this.hideSuggestions(), !1) : 13 === t.keyCode || 9 === t.keyCode ? (this.setValue(this.getFocusedValue()), this.hideSuggestions(), !1) : 38 === t.keyCode ? (this.focus( - 1), !1) : 40 === t.keyCode ? (this.focus(1), !1) : !0
    }
});