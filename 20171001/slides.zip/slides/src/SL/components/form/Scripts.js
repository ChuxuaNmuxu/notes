import SL from '../../SL';

SL("components.form").Scripts = Class.extend({
    init : function (t) {
        this.domElement = $(t),
        this.render(),
        this.readValues(),
        this.renderList()
    },
    render : function () {
        this.valueElement = this.domElement.find(".value-holder"),
        this.listElement = $('<ul class="list">'),
        this.listElement.delegate("li .remove", "click", this.onListItemRemove.bind(this)),
        this.listElement.appendTo(this.domElement),
        this.inputWrapper = $('<div class="input-wrapper"></div>').appendTo(this.domElement),
        this.inputElement = $('<input type="text" placeholder="https://...">'),
        this.inputElement.on("keyup", this.onInputKeyUp.bind(this)),
        this.inputElement.appendTo(this.inputWrapper),
        this.submitElement = $('<div class="button outline">Add</div>'),
        this.submitElement.on("click", this.submitInput.bind(this)),
        this.submitElement.appendTo(this.inputWrapper),
        this.domElement.parents("form").first().on("submit", this.onFormSubmit.bind(this))
    },
    renderList : function () {
        this.listElement.empty(),
        this.values.forEach(function (t) {
            this.listElement.append(['<li class="list-item" data-value="' + t + '">', t, '<span class="icon i-x remove"></span>', "</li>"].join(""))
        }
            .bind(this))
    },
    formatValues : function () {
        for (var t = 0; t < this.values.length; t++)
            this.values[t] = SL.util.string.trim(this.values[t]),
            "" === this.values[t] && this.values.splice(t, 1)
    },
    readValues : function () {
        this.values = (this.valueElement.val() || "").split(","),
        this.formatValues()
    },
    writeValues : function () {
        this.formatValues(),
        this.valueElement.val(this.values.join(","))
    },
    addValue : function (t) {
        return t = t || "",
        0 === t.search(/https\:\/\//gi) ? (this.values.push(t), this.renderList(), this.writeValues(), !0) : 0 === t.search(/http\:\/\//gi) ? (SL.notify("Script must be loaded via HTTPS", "negative"), !1) : (SL.notify("Please enter a valid script URL", "negative"), !1)
    },
    removeValue : function (t) {
        if ("string" == typeof t)
            for (var e = 0; e < this.values.length; e++)
                this.values[e] === t && this.values.splice(e, 1);
        else
            "number" == typeof t && this.values.splice(t, 1);
        this.renderList(),
        this.writeValues()
    },
    submitInput : function () {
        this.addValue(this.inputElement.val()) && this.inputElement.val("")
    },
    onListItemRemove : function (t) {
        var e = $(t.target).parent().index();
        "number" == typeof e && this.removeValue(e)
    },
    onInputKeyUp : function (t) {
        13 === t.keyCode && this.submitInput()
    },
    onFormSubmit : function (t) {
        return this.inputElement.is(":focus") ? (t.preventDefault(), !1) : void 0
    }
});