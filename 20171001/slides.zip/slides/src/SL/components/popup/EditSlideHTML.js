import SL from '../../SL';

SL("components.popup").EditSlideHTML = SL.components.popup.EditHTML.extend({
    TYPE : "edit-slide-html",
    init : function (t) {
        SL.current_user.privileges.customCSS() && (t.additionalHeaderActions = [{
                    label : "Advanced slide options",
                    className : "outline",
                    callback : this.onAdvancedSlideOptionsClicked.bind(this)
                }, {
                    type : "divider"
                }
            ]),
        t.html = SL.util.html.indent(SL.editor.controllers.Serialize.getSlideAsString(t.slide, {
                    inner : !0,
                    lazy : !1,
                    exclude : ".math-output"
                })),
        this._super(t)
    },
    onAdvancedSlideOptionsClicked : function () {
        SL.popup.openOne(SL.components.popup.AdvancedSlideOptions, {
            slide : this.options.slide
        })
    }
});