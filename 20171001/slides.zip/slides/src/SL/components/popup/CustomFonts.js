import SL from '../../SL';

SL("components.popup").CustomFonts = SL.components.popup.Popup.extend({
    TYPE : "custom-fonts",
    init : function (t) {
        this._super($.extend({
                title : "Load custom fonts",
                deck : null,
                theme : null,
                width : 600,
                closeOnClickOutside : !0,
                headerActions : [{
                        label : "Cancel",
                        className : "outline",
                        callback : this.close.bind(this)
                    }, {
                        label : "Save",
                        className : "positive",
                        callback : this.onSaveClicked.bind(this)
                    }
                ]
            },
                t)),
        this.loadGoogleFontList()
    },
    render : function () {
        return this._super(),
        this.bodyElement.append($(['<div class="sl-form">', '<div class="unit typekit-settings">', '<h4 class="form-label">Typekit</h4>', '<p class="unit-description">Specify a <a href="https://typekit.com/" target="_blank">Typekit</a> kit ID to load for this presentation.</p>', '<input type="text" maxlength="255" placeholder="Kit ID">', "</div>", '<div class="unit google-settings">', '<h4 class="form-label">Google Fonts</h4>', '<p class="unit-description">A list of comma separated font families to load from <a href="https://fonts.google.com/" target="_blank">Google Fonts</a>. Font weights can be indicated with a colon after the font family, for example: Open Sans:300,700</p>', '<input type="text" maxlength="255" placeholder="Droid Sans, Droid Serif:bold">', '<p class="google-status"></p>', "</div>", "<div>"].join(""))),
        this.options.deck || this.options.theme ? (this.googleStatus = this.bodyElement.find(".google-settings .google-status"), this.typekitInput = this.bodyElement.find(".typekit-settings input"), this.googleInput = this.bodyElement.find(".google-settings input"), this.googleInput.on("input", this.onGoogleInput.bind(this)), this.options.theme ? (this.typekitInput.val(this.options.theme.get("font_typekit") || ""), this.googleInput.val(this.options.theme.get("font_google") || "")) : (this.typekitInput.val(this.options.deck.get("font_typekit") || ""), this.googleInput.val(this.options.deck.get("font_google") || "")), void this.validateGoogleFonts()) : void this.bodyElement.html("Configuration error. Missing deck/theme model.")
    },
    loadGoogleFontList : function () {
        window.SLGoogleFontList ? this.setupGoogleFontAutocomplete() : $.get(SL.config.GOOGLE_FONTS_LIST).done(function (t) {
            window.SLGoogleFontList = t.items.map(function (t) {
                    return {
                        family : t.family,
                        variants : t.variants.join(", ")
                    }
                }),
            this.setupGoogleFontAutocomplete()
        }
            .bind(this))
    },
    searchGoogleFontList : function (t) {
        var e = [];
        if (t && t.length > 0) {
            for (var i = window.SLGoogleFontList,
                n = 0,
                s = i.length; s > n; n++) {
                var o = i[n];
                    - 1 !== o.family.search(new RegExp(t, "i")) && e.push({
                    value : o.family,
                    label : '<div class="value">' + o.family + '</div><div class="description">' + o.variants + "</div>"
                })
            }
            e = e.slice(0, 10)
        }
        return Promise.resolve(e)
    },
    setupGoogleFontAutocomplete : function () {
        this.googleFontAutocomplete = new SL.components.form.Autocomplete(this.googleInput, this.searchGoogleFontList.bind(this), {
                className : "light-grey",
                offsetY : 1
            }),
        this.googleFontAutocomplete.confirmed.add(this.onGoogleInput.bind(this))
    },
    onSaveClicked : function (t) {
        this.saveLoader || ($(t.target).addClass("ladda-button").attr({
                "data-style" : "expand-right",
                "data-spinner-size" : "26"
            }), this.saveLoader = Ladda.create(t.target)),
        this.saveLoader.start(),
        this.saveAndClose()
    },
    saveAndClose : function () {
        var t = this.typekitInput.val() || "",
        e = this.googleInput.val() || "";
        this.options.theme ? (this.saveLoader.stop(), this.options.theme.setAll({
                font_typekit : t,
                font_google : e
            }), this.close(!0)) : $.ajax({
            url : SL.config.AJAX_UPDATE_DECK(this.options.deck.get("id")),
            type : "PUT",
            context : this,
            data : {
                deck : {
                    font_typekit : t,
                    font_google : e
                }
            }
        }).done(function () {
            this.options.deck.setAll({
                font_typekit : t,
                font_google : e
            }),
            t.length && SL.fonts.loadTypekitFont(t),
            e.length && SL.fonts.loadGoogleFont(e),
            this.close(!0)
        }).fail(function () {
            SL.notify("An error occured while saving", "negative")
        }).always(function () {
            this.saveLoader.stop()
        })
    },
    validateGoogleFonts : function () {
        var t = SL.fonts.parseGoogleFontFamilies(this.googleInput.val() || ""),
        e = t.length + " " + SL.util.string.pluralize("font", "s", t.length > 1) + ": ";
        e += t.map(function (t) {
            return '<span class="google-status-item">' + t + "</span>"
        }).join(""),
        this.googleStatus.html(e),
        this.googleStatus.toggleClass("visible", t.length > 0)
    },
    destroy : function () {
        this.saveLoader && this.saveLoader.remove(),
        this._super()
    },
    onGoogleInput : function () {
        this.validateGoogleFonts()
    }
});