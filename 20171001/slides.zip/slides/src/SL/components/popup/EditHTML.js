import SL from '../../SL';

SL("components.popup").EditHTML = SL.components.popup.Popup.extend({
    TYPE : "edit-html",
    init : function (t) {
        this._super($.extend({
                title : "Edit HTML",
                width : 1200,
                height : 750,
                headerActions : [{
                        label : "Cancel",
                        className : "outline",
                        callback : this.close.bind(this)
                    }, {
                        label : "Save",
                        className : "positive",
                        callback : this.saveAndClose.bind(this)
                    }
                ]
            },
                t)),
        this.saved = new signals.Signal
    },
    render : function () {
        this._super(),
        this.bodyElement.html('<div id="ace-html" class="editor"></div>'),
        this.editor && "function" == typeof this.editor.destroy && (this.editor.destroy(), this.editor = null);
        try {
            this.editor = ace.edit("ace-html"),
            SL.util.setAceEditorDefaults(this.editor),
            this.editor.getSession().setMode("ace/mode/html")
        } catch (t) {
            console.log("An error occurred while initializing the Ace editor.")
        }
        this.editor.getSession().setValue(this.options.html || ""),
        this.editor.focus()
    },
    saveAndClose : function () {
        this.saved.dispatch(this.getHTML()),
        this.close(!0)
    },
    checkUnsavedChanges : function (t) {
        this.getHTML() === this.options.html || this.cancelPrompt ? t() : (this.cancelPrompt = SL.prompt({
                    title : "Discard unsaved changes?",
                    type : "select",
                    data : [{
                            html : "<h3>Cancel</h3>"
                        }, {
                            html : "<h3>Discard</h3>",
                            selected : !0,
                            className : "negative",
                            callback : t
                        }
                    ]
                }), this.cancelPrompt.destroyed.add(function () {
                this.cancelPrompt = null
            }
                .bind(this)))
    },
    getHTML : function () {
        return this.editor.getSession().getValue()
    },
    destroy : function () {
        this.editor && "function" == typeof this.editor.destroy && (this.editor.destroy(), this.editor = null),
        this.saved && (this.saved.dispose(), this.saved = null),
        this._super()
    }
});