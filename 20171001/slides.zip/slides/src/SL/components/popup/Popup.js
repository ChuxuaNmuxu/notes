import SL from '../../SL';

SL("components.popup").Popup = Class.extend({
    WINDOW_PADDING : .01,
    USE_ABSOLUTE_POSITIONING : SL.util.device.IS_PHONE || SL.util.device.IS_TABLET,
    init : function (t) {
        this.options = $.extend({
                title : "",
                titleItem : "",
                header : !0,
                headerActions : [{
                        label : "Close",
                        className : "grey",
                        callback : this.close.bind(this)
                    }
                ],
                width : "auto",
                height : "auto",
                singleton : !1,
                closeOnEscape : !0,
                closeOnClickOutside : !0
            },
                t),
        this.options.additionalHeaderActions && (this.options.headerActions = this.options.additionalHeaderActions.concat(this.options.headerActions)),
        this.closed = new signals.Signal,
        this.render(),
        this.bind(),
        this.layout()
    },
    render : function () {
        this.domElement = $('<div class="sl-popup" data-id="' + this.TYPE + '">'),
        this.domElement.appendTo(document.body),
        this.innerElement = $('<div class="sl-popup-inner">'),
        this.innerElement.appendTo(this.domElement),
        this.options.header && this.renderHeader(),
        this.bodyElement = $('<div class="sl-popup-body">'),
        this.bodyElement.appendTo(this.innerElement)
    },
    renderHeader : function () {
        this.headerElement = $(['<header class="sl-popup-header">', '<h3 class="sl-popup-header-title">' + this.options.title + "</h3>", "</header>"].join("")),
        this.headerElement.appendTo(this.innerElement),
        this.headerTitleElement = this.headerElement.find(".sl-popup-header-title"),
        this.options.titleItem && (this.headerTitleElement.append('<span class="sl-popup-header-title-item"></span>'), this.headerTitleElement.find(".sl-popup-header-title-item").text(this.options.titleItem)),
        this.options.headerActions && this.options.headerActions.length && (this.headerActionsElement = $('<div class="sl-popup-header-actions">').appendTo(this.headerElement), this.options.headerActions.forEach(function (t) {
                "divider" === t.type ? $('<div class="divider"></div>').appendTo(this.headerActionsElement) : $('<button class="button l ' + t.className + '">' + t.label + "</button>").appendTo(this.headerActionsElement).on("vclick",
                    function (e) {
                    t.callback(e),
                    e.preventDefault()
                })
            }
                .bind(this)))
    },
    bind : function () {
        this.onKeyDown = this.onKeyDown.bind(this),
        this.onWindowResize = this.onWindowResize.bind(this),
        this.onBackgroundClicked = this.onBackgroundClicked.bind(this),
        this.domElement.on("vclick", this.onBackgroundClicked)
    },
    layout : function () {
        if (this.innerElement.css({
                width : this.options.width,
                height : this.options.height
            }), this.options.height) {
            var t = this.headerElement ? this.headerElement.outerHeight() : 0;
            this.headerElement && "number" == typeof this.options.height ? this.bodyElement.css("height", this.options.height - t) : this.bodyElement.css("height", "auto");
            var e = window.innerHeight;
            this.bodyElement.css("max-height", e - t - e * this.WINDOW_PADDING * 2)
        }
        if (this.headerElement) {
            var i = this.headerElement.width(),
            n = this.headerActionsElement.outerWidth();
            this.headerTitleElement.css("max-width", i - n - 30)
        }
        if (this.USE_ABSOLUTE_POSITIONING) {
            var s = $(window);
            this.domElement.css({
                position : "absolute",
                height : Math.max($(window).height(), $(document).height())
            }),
            this.innerElement.css({
                position : "absolute",
                transform : "none",
                top : s.scrollTop() + (s.height() - this.innerElement.outerHeight()) / 2,
                left : s.scrollLeft() + (s.width() - this.innerElement.outerWidth()) / 2,
                maxWidth : s.width() - window.innerWidth * this.WINDOW_PADDING * 2
            })
        }
    },
    open : function (t) {
        this.domElement.appendTo(document.body),
        clearTimeout(this.closeTimeout),
        this.closeTimeout = null,
        this.options = $.extend(this.options, t),
        SL.keyboard.keydown(this.onKeyDown),
        $(window).on("resize", this.onWindowResize),
        setTimeout(function () {
            this.domElement.addClass("visible")
        }
            .bind(this), 1)
    },
    close : function (t) {
        this.closeTimeout || (t ? this.closeConfirmed() : this.checkUnsavedChanges(this.closeConfirmed.bind(this)))
    },
    closeConfirmed : function () {
        SL.keyboard.release(this.onKeyDown),
        $(window).off("resize", this.onWindowResize),
        this.domElement.removeClass("visible"),
        SL.popup.unregister(this),
        this.closeTimeout = setTimeout(function () {
                this.domElement.detach(),
                this.isSingleton() || this.destroy()
            }
                .bind(this), 500),
        this.closed.dispatch()
    },
    checkUnsavedChanges : function (t) {
        t()
    },
    isSingleton : function () {
        return this.options.singleton
    },
    onBackgroundClicked : function (t) {
        $(t.target).is(this.domElement) && (this.options.closeOnClickOutside && this.close(), t.preventDefault())
    },
    onWindowResize : function () {
        this.layout()
    },
    onKeyDown : function (t) {
        return 27 === t.keyCode ? (this.options.closeOnEscape && this.close(), !1) : !0
    },
    destroy : function () {
        SL.popup.unregister(this),
        this.options = null,
        this.closed.dispose(),
        this.domElement.remove()
    }
});