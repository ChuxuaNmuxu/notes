import SL from '../../SL';

SL("components.popup").Revision = SL.components.popup.Popup.extend({
    TYPE : "revision",
    init : function (t) {
        this._super($.extend({
                revisionURL : null,
                revisionTimeAgo : null,
                title : "Revision",
                titleItem : "from " + t.revisionTimeAgo,
                width : 900,
                height : 700,
                headerActions : [{
                        label : "Open in new tab",
                        className : "outline",
                        callback : this.onOpenExternalClicked.bind(this)
                    }, {
                        label : "Restore",
                        className : "grey",
                        callback : this.onRestoreClicked.bind(this)
                    }, {
                        label : "Close",
                        className : "grey",
                        callback : this.close.bind(this)
                    }
                ]
            },
                t)),
        this.restoreRequested = new signals.Signal,
        this.externalRequested = new signals.Signal
    },
    render : function () {
        this._super(),
        this.bodyElement.html(['<div class="spinner centered"></div>', '<div class="deck"></div>'].join("")),
        this.bodyElement.addClass("loading"),
        SL.util.html.generateSpinners();
        var t = $("<iframe>", {
                src : this.options.revisionURL,
                load : function () {
                    this.bodyElement.removeClass("loading")
                }
                .bind(this)
            });
        t.appendTo(this.bodyElement.find(".deck"))
    },
    onRestoreClicked : function (t) {
        this.restoreRequested.dispatch(t)
    },
    onOpenExternalClicked : function (t) {
        this.externalRequested.dispatch(t)
    },
    destroy : function () {
        this.bodyElement.find(".deck iframe").attr("src", ""),
        this.bodyElement.find(".deck").empty(),
        this.restoreRequested.dispose(),
        this.externalRequested.dispose(),
        this._super()
    }
});