import SL from '../../SL';

SL("components.popup").AdvancedSlideOptions = SL.components.popup.Popup.extend({
	TYPE : "advanced-slide-options",
	init : function (t) {
		this._super($.extend({
				title : "Advanced Slide Options",
				slide : null,
				width : 600,
				closeOnClickOutside : !0,
				headerActions : [{
						label : "Cancel",
						className : "outline",
						callback : this.close.bind(this)
					}, {
						label : "Save",
						className : "positive",
						callback : this.onSaveClicked.bind(this)
					}
				]
			},
				t))
	},
	render : function () {
		this._super(),
		this.formElement = $('<div class="sl-form">').appendTo(this.bodyElement),
		this.renderVideo(),
		this.renderIframe(),
		this.renderSlideID(),
		SL.current_user.privileges.customCSS() && SL.current_user.settings.get("developer_mode") && this.renderSlideClasses(),
		this.syncInputs()
	},
	renderVideo : function () {
		this.formElement.append($(['<div class="unit">', '<h4 class="form-label">Video Background</h4>', '<p class="unit-description">Play a full screen video in the background of this slide. We recommend using MP4 since that format works in all modern browsers.</p>', '<input class="video-url" type="text" maxlength="2000" placeholder="Video URL...">', '<div class="video-options">', '<div class="unit sl-checkbox outline">', '<input id="video-muted-checkbox" class="video-muted-checkbox" type="checkbox" disabled />', '<label for="video-muted-checkbox">Mute</label>', "</div>", '<div class="unit sl-checkbox outline">', '<input id="video-loop-checkbox" class="video-loop-checkbox" type="checkbox" disabled />', '<label for="video-loop-checkbox">Loop</label>', "</div>", '<div class="unit">', '<select class="sl-select video-size-select">', '<option value="">Full screen</option>', '<option value="contain">Letterbox</option>', "</select>", "</div>", "</div>", "</div>"].join(""))),
		this.videoURLInput = this.bodyElement.find(".video-url"),
		this.videoURLInput.val(this.options.slide.getAttribute("data-background-video") || ""),
		this.videoURLInput.on("input", this.syncInputs.bind(this)),
		this.videoMutedInput = this.bodyElement.find(".video-muted-checkbox"),
		this.videoMutedInput.prop("checked", "true" == this.options.slide.getAttribute("data-background-video-muted")),
		this.videoLoopInput = this.bodyElement.find(".video-loop-checkbox"),
		this.videoLoopInput.prop("checked", "true" == this.options.slide.getAttribute("data-background-video-loop")),
		this.videoSizeInput = this.bodyElement.find(".video-size-select"),
		this.videoSizeInput.val(this.options.slide.getAttribute("data-background-size"))
	},
	renderIframe : function () {
		this.formElement.append($(['<div class="unit">', '<h4 class="form-label">Iframe Background</h4>', '<p class="unit-description">Show a full screen iframe element in the background of this slide.</p>', '<input class="iframe-url" type="text" maxlength="2000" placeholder="Iframe URL...">', "</div>"].join(""))),
		this.iframeURLInput = this.bodyElement.find(".iframe-url"),
		this.iframeURLInput.val(this.options.slide.getAttribute("data-background-iframe") || "")
	},
	renderSlideID : function () {
		this.formElement.append($(['<div class="unit">', '<h4 class="form-label">Slide ID</h4>', '<p class="unit-description">Specify an identifier to use for internal links. Point your links to <code>#/mySlideID</code></p>', '<input class="slide-id" type="text" placeholder="A-Z, lowercase, no spaces...">', "</div>"].join(""))),
		this.slideIDInput = this.bodyElement.find(".slide-id"),
		this.slideIDInput.val(this.readSlideID()),
		this.slideIDInput.on("blur",
			function () {
			this.slideIDInput.val(SL.util.string.slug(this.slideIDInput.val().trim()))
		}
			.bind(this))
	},
	renderSlideClasses : function () {
		this.formElement.append($(['<div class="unit">', '<h4 class="form-label">Slide classes</h4>', '<p class="unit-description">Specify class names which will be added to the slide wrapper. Useful for targeting from the CSS editor.</p>', '<input class="slide-classes" type="text" placeholder="Classes...">', "</div>"].join(""))),
		this.slideClassesInput = this.bodyElement.find(".slide-classes"),
		this.slideClassesInput.val(this.readSlideClasses())
	},
	onSaveClicked : function () {
		var t = this.videoURLInput.val().trim();
		t ? this.options.slide.setAttribute("data-background-video", t) : this.options.slide.removeAttribute("data-background-video"),
		this.videoMutedInput.prop("checked") ? this.options.slide.setAttribute("data-background-video-muted", "true") : this.options.slide.removeAttribute("data-background-video-muted");
		var e = this.videoSizeInput.val();
		e ? this.options.slide.setAttribute("data-background-size", e) : this.options.slide.removeAttribute("data-background-size"),
		this.videoLoopInput.prop("checked") ? this.options.slide.setAttribute("data-background-video-loop", "true") : this.options.slide.removeAttribute("data-background-video-loop");
		var i = this.iframeURLInput.val().trim();
		if (/<iframe/gi.test(i))
			try {
				i = $(i).attr("src")
			} catch (n) {}
		i ? this.options.slide.setAttribute("data-background-iframe", i) : this.options.slide.removeAttribute("data-background-iframe"),
		this.slideIDInput && this.writeSlideID(this.slideIDInput.val().trim()),
		this.slideClassesInput && this.writeSlideClasses(this.slideClassesInput.val().trim()),
		Reveal.sync(),
		this.close(!0)
	},
	syncInputs : function () {
		var t = this.videoURLInput.val().trim();
		this.videoMutedInput.attr("disabled", t.length < 2),
		this.videoLoopInput.attr("disabled", t.length < 2),
		this.videoSizeInput.attr("disabled", t.length < 2)
	},
	readSlideID : function () {
		return this.options.slide.getAttribute("id")
	},
	writeSlideID : function (t) {
		t = SL.util.string.slug(t),
		t && t.length ? this.options.slide.setAttribute("id", t) : this.options.slide.removeAttribute("id")
	},
	readSlideClasses : function () {
		return this.options.slide.className.split(" ").filter(function (t) {
			return  - 1 === SL.config.RESERVED_SLIDE_CLASSES.indexOf(t)
		}).join(" ")
	},
	writeSlideClasses : function (t) {
		t = t || "",
		t = t.trim().replace(/\s{2,}/g, " ");
		var e = this.options.slide.className.split(" ").filter(function (t) {
				return  - 1 !== SL.config.RESERVED_SLIDE_CLASSES.indexOf(t)
			});
		e = e.concat(t.split(" ")),
		this.options.slide.className = e.join(" ")
	}
});