import SL from '../../SL';

SL("components.popup").SessionExpired = SL.components.popup.Popup.extend({
    TYPE : "session-expired",
    init : function (t) {
        this._super($.extend({
                title : "Session expired",
                width : 500,
                closeOnEscape : !1,
                closeOnClickOutside : !1,
                headerActions : [{
                        label : "Ignore",
                        className : "outline negative",
                        callback : this.close.bind(this)
                    }, {
                        label : "Retry",
                        className : "positive",
                        callback : this.onRetryClicked.bind(this)
                    }
                ]
            },
                t))
    },
    render : function () {
        this._super(),
        this.bodyElement.html(["<p>You are no longer signed in to Slides. This can happen when you leave the page idle for too long, log out in a different tab or go offline. To continue please:</p>", "<ol>", '<li><a href="' + SL.routes.SIGN_IN + '" target="_blank" style="text-decoration: underline;">Sign in</a> to Slides from another browser tab.</li>', "<li>Come back to this tab and press the 'Retry' button.</li>", "</ol>"].join(""))
    },
    onRetryClicked : function () {
        SL.editor && 1 === SL.editor.Editor.VERSION ? SL.view.checkLogin(!0) : SL.session.check()
    },
    destroy : function () {
        this._super()
    }
});