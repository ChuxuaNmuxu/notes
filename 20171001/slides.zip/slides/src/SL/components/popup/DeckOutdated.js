import SL from '../../SL';

SL("components.popup").DeckOutdated = SL.components.popup.Popup.extend({
    TYPE : "deck-outdated",
    init : function (t) {
        this._super($.extend({
                title : "Newer version available",
                width : 500,
                closeOnClickOutside : !1,
                headerActions : [{
                        label : "Ignore",
                        className : "outline",
                        callback : this.close.bind(this)
                    }, {
                        label : "Reload",
                        className : "positive",
                        callback : this.onReloadClicked.bind(this)
                    }
                ]
            },
                t))
    },
    render : function () {
        this._super(),
        this.bodyElement.html(["<p>A more recent version of this presentation is available on the server. This can happen when the presentation is saved from another browser or device.</p>", "<p>We recommend reloading the page to get the latest version. If you're sure your local changes are the latest, please ignore this message.</p>"].join(""))
    },
    onReloadClicked : function () {
        window.location.reload()
    },
    destroy : function () {
        this._super()
    }
});