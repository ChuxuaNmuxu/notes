import SL from '../../SL';

SL("components.popup").InsertSnippet = SL.components.popup.Popup.extend({
    TYPE : "insert-snippet",
    init : function (t) {
        this._super($.extend({
                title : "Insert",
                titleItem : '"' + t.snippet.get("title") + '"',
                width : 500,
                headerActions : [{
                        label : "Cancel",
                        className : "outline",
                        callback : this.close.bind(this)
                    }, {
                        label : "Insert",
                        className : "positive",
                        callback : this.insertAndClose.bind(this)
                    }
                ]
            },
                t)),
        this.snippetInserted = new signals.Signal
    },
    render : function () {
        this._super(),
        this.variablesElement = $('<div class="variables sl-form"></div>'),
        this.variablesElement.appendTo(this.bodyElement),
        this.variables = this.options.snippet.getTemplateVariables(),
        this.variables.forEach(function (t) {
            var e = $(['<div class="unit">', "<label>" + t.label + "</label>", '<input type="text" value="' + t.defaultValue + '">', "</div>"].join("")).appendTo(this.variablesElement);
            e.find("input").data("variable", t)
        }
            .bind(this)),
        this.variablesElement.find("input").first().focus().select()
    },
    insertAndClose : function () {
        this.variablesElement.find("input").each(function (t, e) {
            e = $(e),
            e.data("variable").value = e.val()
        }),
        this.snippetInserted.dispatch(this.options.snippet.templatize(this.variables)),
        this.close()
    },
    onKeyDown : function (t) {
        return 13 === t.keyCode ? (this.insertAndClose(), !1) : this._super(t)
    },
    destroy : function () {
        this.snippetInserted.dispose(),
        this._super()
    }
});