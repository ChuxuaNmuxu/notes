import SL from '../SL';

SL("components").Resolution = Class.extend({
	init : function (t) {
		if (this.config = $.extend({
					title : null,
					values : null,
					width : 1,
					height : 1
				},
					t), !this.config.values)
			throw "A list of values must be specified.";
		this.render(),
		this.bind(),
		this.setValue(this.config.width, this.config.height)
	},
	render : function () {
		this.domElement = $(['<div class="sl-resolution">', '<div class="unit size">', this.config.title ? "<label>" + this.config.title + "</label>" : "", '<select class="sl-select""></select>', "</div>", '<div class="custom-size">', '<div class="unit text custom-width">', "<label>Width</label>", '<input size="30" type="text" class="l" maxlength="4" />', "</div>", '<div class="unit text custom-height">', "<label>Height</label>", '<input size="30" type="text" class="l" maxlength="4" />', "</div>", "</div>", "</div>"].join("")),
		this.sizeInput = this.domElement.find(".size select"),
		this.widthInput = this.domElement.find(".custom-width input"),
		this.heightInput = this.domElement.find(".custom-height input"),
		this.renderOptions()
	},
	renderOptions : function () {
		this.sizeInput.html(this.config.values.map(function (t) {
				return '<option value="' + t.width + "x" + t.height + '">' + t.label + "</option>"
			}).join("")),
		this.sizeInput.append('<option class="custom-value" value="custom">Custom</option>')
	},
	bind : function () {
		this.changed = new signals.Signal,
		this.sizeInput.on("change", this.onSizeChange.bind(this)),
		this.widthInput.on("input", this.onCustomSizeChange.bind(this)),
		this.heightInput.on("input", this.onCustomSizeChange.bind(this))
	},
	setValue : function (t, e) {
		var i,
		n,
		s = this.config.values.filter(function (i) {
				return i.width === t && i.height === e
			},
				this)[0];
		s ? (i = s.width, n = s.height) : (i = t, n = e, this.sizeInput.find(".custom-value").attr("value", i + "x" + n)),
		this.sizeInput.val(i + "x" + n),
		this.widthInput.val(i),
		this.heightInput.val(n),
		this.syncCustomSize()
	},
	getValue : function () {
		var t = {};
		if (this.isCustomSize())
			t.width = parseInt(this.widthInput.val(), 10),
			t.height = parseInt(this.heightInput.val(), 10);
		else {
			var e = this.sizeInput.val() || "";
			t.width = parseInt(e.split("x")[0], 10),
			t.height = parseInt(e.split("x")[1], 10)
		}
		return (isNaN(t.width) || isNaN(t.height) || t.width < 1 || t.height < 1) && (t.width = this.config.width, t.height = this.config.height),
		t
	},
	syncCustomSize : function () {
		this.isCustomSize() ? this.domElement.addClass("expanded") : this.domElement.removeClass("expanded")
	},
	isCustomSize : function () {
		return this.sizeInput.find(":selected").hasClass("custom-value")
	},
	destroy : function () {
		this.changed.dispose(),
		this.domElement.remove()
	},
	onSizeChange : function () {
		var t = this.getValue();
		this.widthInput.val(t.width),
		this.heightInput.val(t.height),
		this.syncCustomSize(),
		this.changed.dispatch()
	},
	onCustomSizeChange : function () {
		this.changed.dispatch()
	}
});