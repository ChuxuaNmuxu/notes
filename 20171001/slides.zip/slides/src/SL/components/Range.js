import SL from '../SL';

SL("components").Range = Class.extend({
	init : function (t) {
		this.config = $.extend({
				value : 0,
				width : 300,
				minValue : 0,
				maxValue : 100,
				decimals : 0,
				unit : null
			},
				t),
		this.valueRange = this.config.maxValue - this.config.minValue,
		this.stepSize = this.valueRange < 1 ? this.valueRange / 200 : 1,
		this.changing = !1,
		this.mouseDownValue = 0,
		this.mouseDownX = 0,
		this.render(),
		this.bind(),
		this.setValue(t.value, !1)
	},
	render : function () {
		this.domElement = $('<div class="sl-range"></div>'),
		this.domElement.width(this.config.width),
		this.progressElement = $('<div class="sl-range-progress">').appendTo(this.domElement),
		this.inputElement = $('<input class="sl-range-number input-field" type="text">').appendTo(this.domElement)
	},
	bind : function () {
		this.changed = new signals.Signal,
		this.changeStarted = new signals.Signal,
		this.changeEnded = new signals.Signal,
		this.onMouseDown = this.onMouseDown.bind(this),
		this.onMouseMove = this.onMouseMove.bind(this),
		this.onMouseUp = this.onMouseUp.bind(this),
		this.domElement.on("vmousedown", this.onMouseDown),
		this.inputElement.on("input", this.onInput.bind(this)),
		this.inputElement.on("keydown", this.onInputKeyDown.bind(this)),
		this.inputElement.on("focus", this.onInputFocused.bind(this)),
		this.inputElement.on("blur", this.onInputBlurred.bind(this))
	},
	appendTo : function (t) {
		this.domElement.appendTo(t)
	},
	setValue : function (t, e, i) {
		if (this.value = Math.max(Math.min(t, this.config.maxValue), this.config.minValue), this.value = this.roundValue(this.value), !i) {
			var n = this.value;
			this.config.decimals > 0 && (n = n.toFixed(this.config.decimals)),
			this.config.unit && (n += this.config.unit),
			this.inputElement.val(n)
		}
		var s = this.valueToPercent(this.value) / 100;
		this.progressElement.css("transform", "scaleX(" + s + ")"),
		e && this.changed.dispatch(this.value)
	},
	getValue : function () {
		return this.value
	},
	roundValue : function (t) {
		var e = Math.pow(10, this.config.decimals);
		return Math.round(t * e) / e
	},
	valueToPercent : function (t) {
		var e = (t - this.config.minValue) / (this.config.maxValue - this.config.minValue) * 100;
		return Math.max(Math.min(e, 100), 0)
	},
	isChanging : function () {
		return this.changing
	},
	onChangeStart : function () {
		this.isChanging() || (this.domElement.addClass("is-changing"), this.changing = !0, this.changeStarted.dispatch())
	},
	onChangeEnd : function () {
		this.isChanging() && (this.domElement.removeClass("is-changing"), this.changing = !1, this.changeEnded.dispatch())
	},
	onMouseDown : function (t) {
		this.inputElement.is(":focus") || t.preventDefault(),
		$(document).on("vmousemove", this.onMouseMove),
		$(document).on("vmouseup", this.onMouseUp),
		this.mouseDownX = t.clientX,
		this.mouseDownValue = this.getValue(),
		this.onChangeStart()
	},
	onMouseMove : function (t) {
		this.domElement.addClass("is-scrubbing");
		var e = t.clientX - this.mouseDownX;
		1 === this.stepSize && this.valueRange < 15 ? e *= .25 : 1 === this.stepSize && this.valueRange < 30 && (e *= .5),
		this.setValue(this.mouseDownValue + e * this.stepSize, !0),
		this.changed.dispatch(this.getValue())
	},
	onMouseUp : function (t) {
		$(document).off("vmousemove", this.onMouseMove),
		$(document).off("vmouseup", this.onMouseUp),
		this.domElement.hasClass("is-scrubbing") === !1 ? this.onClick(t) : this.onChangeEnd(),
		this.domElement.removeClass("is-scrubbing")
	},
	onClick : function () {
		this.inputElement.focus()
	},
	onInput : function () {
		this.setValue(parseFloat(this.inputElement.val()), !0, !0)
	},
	onInputKeyDown : function (t) {
		var e = 0;
		38 === t.keyCode ? e = this.stepSize : 40 === t.keyCode && (e = -this.stepSize),
		e && (t.shiftKey && (e *= 10), this.setValue(this.getValue() + e, !0), t.preventDefault())
	},
	onInputFocused : function () {
		this.onChangeStart()
	},
	onInputBlurred : function () {
		this.onChangeEnd(),
		this.setValue(this.getValue(), !0)
	},
	destroy : function () {
		$(document).off("vmousemove", this.onMouseMove),
		$(document).off("vmouseup", this.onMouseUp),
		this.changed.dispose(),
		this.changeStarted.dispose(),
		this.changeEnded.dispose(),
		this.domElement.remove()
	}
});