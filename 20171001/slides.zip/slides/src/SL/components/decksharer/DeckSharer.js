import SL from '../../SL';

SL("components.decksharer").DeckSharer = SL.components.popup.Popup.extend({
    TYPE : "decksharer",
    MODE_PUBLIC : {
        id : "public",
        width : 560,
        height : 380,
        heightEmail : "auto"
    },
    MODE_UPGRADE_OR_PUBLISH : {
        id : "upgrade-or-publish",
        width : 800,
        height : 560,
        heightEmail : "auto"
    },
    MODE_PRIVATE : {
        id : "private",
        width : 800,
        height : 560,
        heightEmail : 730
    },
    MODE_INTERNAL : {
        id : "internal",
        width : 560,
        height : "auto",
        heightEmail : "auto"
    },
    init : function (t) {
        var e = t.deck,
        i = e.belongsTo(SL.current_user);
        this.mode = i && (e.isVisibilitySelf() || e.isVisibilityTeam()) && !SL.current_user.privileges.privateLinks() ? this.MODE_UPGRADE_OR_PUBLISH : i && (e.isVisibilitySelf() || e.isVisibilityTeam()) ? this.MODE_PRIVATE : !i && e.isVisibilityTeam() ? this.MODE_INTERNAL : this.MODE_PUBLIC,
        this._super($.extend({
                title : "Share",
                titleItem : '"' + e.get("title") + '"',
                width : this.mode.width,
                height : this.mode.height
            },
                t))
    },
    switchMode : function (t) {
        this.mode = t,
        this.bodyElement.empty(),
        this.renderMode(),
        this.options.width = this.mode.width,
        this.options.height = this.mode.height,
        this.layout()
    },
    render : function () {
        this._super(),
        this.renderMode()
    },
    renderMode : function () {
        this.mode.id === this.MODE_UPGRADE_OR_PUBLISH.id ? this.renderUpgradeOrPublish() : this.mode.id === this.MODE_PRIVATE.id ? this.renderPrivate() : this.mode.id === this.MODE_INTERNAL.id ? this.renderInternal() : this.renderPublic()
    },
    renderPublic : function () {
        this.shareOptions = new SL.components.decksharer.ShareOptions(this.options.deck, this.options),
        this.shareOptions.pageChanged.add(this.layout.bind(this)),
        this.shareOptions.appendTo(this.bodyElement)
    },
    renderInternal : function () {
        this.bodyElement.append('<p class="decksharer-share-warning">This deck is internal and can only be shared with and viewed by other team members.</p>'),
        this.shareOptions = new SL.components.decksharer.ShareOptions(this.options.deck, $.extend(this.options, {
                    embedEnabled : !1
                })),
        this.shareOptions.pageChanged.add(this.layout.bind(this)),
        this.shareOptions.appendTo(this.bodyElement)
    },
    renderPrivate : function () {
        this.placeholderElement = $(['<div class="decksharer-placeholder">', '<div class="decksharer-placeholder-inner">', '<div class="spinner" data-spinner-color="#999"></div>', "</div>", "</div>"].join("")),
        this.placeholderElement.appendTo(this.bodyElement),
        SL.util.html.generateSpinners(),
        SL.data.tokens.get(this.options.deck.get("id"), {
            success : function (t) {
                this.tokens = t,
                this.tokenList = new SL.components.decksharer.TokenList(this.options.deck, this.tokens),
                this.tokenList.appendTo(this.bodyElement),
                this.tokenList.tokenSelected.add(this.onTokenSelected.bind(this)),
                this.tokenList.tokensEmptied.add(this.onTokensEmptied.bind(this)),
                0 === this.tokens.size() ? this.renderTokenPlaceholder() : this.tokenList.selectDefault()
            }
            .bind(this),
            error : function (t) {
                this.destroy(),
                401 === t ? SL.notify("It looks like you're no longer signed in to Slides. Please open a new tab and sign in.", "negative") : SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
            }
            .bind(this)
        })
    },
    renderUpgradeOrPublish : function () {
        this.placeholderElement = $(['<div class="decksharer-placeholder">', '<div class="decksharer-placeholder-inner">', '<div class="left">', '<div class="lock-icon icon i-lock-stroke"></div>', "</div>", '<div class="right">', "<h2>Upgrade required</h2>", "<p>You can't share privately on your current plan. Please upgrade your account to gain access to private links, password protection and more.</p>", '<a class="button upgrade-button l" href="' + SL.routes.PRICING + '">View plans</a>', '<button class="button publish-button ladda-button l outline" data-style="zoom-out" data-spinner-color="#222">Make my deck public</button>', "</div>", "</div>", "</div>"].join("")),
        this.placeholderElement.appendTo(this.bodyElement);
        var t = this.placeholderElement.find(".publish-button");
        t.on("vclick",
            function () {
            $.ajax({
                type : "POST",
                url : SL.config.AJAX_PUBLISH_DECK(this.options.deck.get("id")),
                context : this,
                data : {
                    visibility : SL.models.Deck.VISIBILITY_ALL
                }
            }).then(function () {
                var e = t.data("data");
                e && e.stop(),
                this.options.deck.set("visibility", SL.models.Deck.VISIBILITY_ALL),
                this.switchMode(this.MODE_PUBLIC),
                SL.notify("Published successfully")
            },
                function () {
                var e = t.data("data");
                e && e.stop(),
                SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
            })
        }
            .bind(this)),
        Ladda.bind(t.get(0))
    },
    layout : function () {
        var t = this.tokenOptions ? this.tokenOptions.shareOptions : this.shareOptions;
        this.options.height = t && t.getPageID() === SL.components.decksharer.ShareOptions.EMAIL_PAGE_ID ? this.mode.heightEmail : this.mode.height,
        this._super()
    },
    resetContentArea : function () {
        this.tokenOptions && (this.tokenOptions.destroy(), this.tokenOptions = null),
        this.placeholderElement && (this.placeholderElement.addClass("hidden"), setTimeout(this.placeholderElement.remove.bind(this.placeholderElement), 300), this.placeholderElement = null)
    },
    renderTokenPlaceholder : function () {
        this.domElement.addClass("is-empty"),
        this.resetContentArea();
        var t = this.options.deck.isVisibilityTeam() ? "This deck is internal" : "This deck is private";
        this.placeholderElement = $(['<div class="decksharer-placeholder">', '<div class="decksharer-placeholder-inner">', '<div class="left">', '<div class="lock-icon icon i-lock-stroke"></div>', "</div>", '<div class="right">', "<h2>" + t + "</h2>", "<p>To share it you'll need to create a private link.</p>", '<button class="button create-button xl ladda-button" data-style="zoom-out">Create private link</button>', "</div>", "</div>", "</div>"].join("")),
        this.placeholderElement.appendTo(this.bodyElement),
        this.placeholderElement.find(".create-button").on("vclick",
            function () {
            this.tokenList.create()
        }
            .bind(this)),
        Ladda.bind(this.placeholderElement.find(".create-button").get(0)),
        this.layout()
    },
    renderTokenOptions : function (t) {
        this.domElement.removeClass("is-empty");
        var e = !this.tokenOptions;
        this.resetContentArea(),
        this.tokenOptions = new SL.components.decksharer.TokenOptions(this.options.deck, t, this.options),
        this.tokenOptions.appendTo(this.bodyElement, e),
        this.tokenOptions.tokenRenamed.add(this.tokenList.setTokenLabel.bind(this.tokenList)),
        this.tokenOptions.shareOptions.pageChanged.add(this.layout.bind(this)),
        this.layout()
    },
    onTokenSelected : function (t) {
        this.renderTokenOptions(t)
    },
    onTokensEmptied : function () {
        this.renderTokenPlaceholder()
    },
    destroy : function () {
        this.shareOptions && (this.shareOptions.destroy(), this.shareOptions = null),
        this.tokenList && (this.tokenList.destroy(), this.tokenList = null),
        this.options.deck = null,
        this.tokens = null,
        this._super()
    }
});