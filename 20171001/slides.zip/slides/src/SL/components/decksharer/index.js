import SL from '../../SL';

import './DeckSharer';
import './ShareOptions';

SL.components.decksharer.ShareOptions.DEFAULT_WIDTH = 576,
SL.components.decksharer.ShareOptions.DEFAULT_HEIGHT = 420,
SL.components.decksharer.ShareOptions.LINK_PAGE_ID = "link",
SL.components.decksharer.ShareOptions.EMBED_PAGE_ID = "embed",
SL.components.decksharer.ShareOptions.EMAIL_PAGE_ID = "email";

import './TokenList';
import './TokenOptions';
