import SL from '../../SL';

SL("components.decksharer").ShareOptions = Class.extend({
    USE_READONLY : !SL.util.device.IS_PHONE && !SL.util.device.IS_TABLET,
    init : function (t, e) {
        this.deck = t,
        this.options = $.extend({
                token : null,
                linkEnabled : !0,
                embedEnabled : !0,
                emailEnabled : !0
            },
                e),
        this.onLinkInputMouseDown = this.onLinkInputMouseDown.bind(this),
        this.onEmbedOutputMouseDown = this.onEmbedOutputMouseDown.bind(this),
        this.onEmbedStyleChanged = this.onEmbedStyleChanged.bind(this),
        this.onEmbedSizeChanged = this.onEmbedSizeChanged.bind(this),
        this.width = SL.components.decksharer.ShareOptions.DEFAULT_WIDTH,
        this.height = SL.components.decksharer.ShareOptions.DEFAULT_HEIGHT,
        this.style = "",
        this.pageChanged = new signals.Signal,
        this.render(),
        this.generate()
    },
    render : function () {
        this.domElement = $('<div class="decksharer-share-options">'),
        this.tabsElement = $('<div class="decksharer-share-options-tabs">').appendTo(this.domElement),
        this.pagesElement = $('<div class="decksharer-share-options-pages">').appendTo(this.domElement),
        this.options.deckView ? (this.tabsElement.hide(), this.renderDeckViewLink(), this.showPage(SL.components.decksharer.ShareOptions.LINK_PAGE_ID)) : (this.options.linkEnabled && this.renderLink(), this.options.embedEnabled && this.renderEmbed(), this.options.emailEnabled && SL.util.user.isLoggedIn() && this.renderEmail(), this.tabsElement.find(".decksharer-share-options-tab").on("vclick",
                function (t) {
                var e = $(t.currentTarget).attr("data-id");
                this.showPage(e),
                SL.analytics.track("Decksharer: Tab clicked", e)
            }
                .bind(this)), this.showPage(this.tabsElement.find(".decksharer-share-options-tab").first().attr("data-id")))
    },
    renderLink : function () {
        this.tabsElement.append('<div class="decksharer-share-options-tab" data-id="' + SL.components.decksharer.ShareOptions.LINK_PAGE_ID + '">Link</div>'),
        this.pagesElement.append(['<div class="decksharer-share-options-page sl-form" data-id="link">', '<div class="unit link-unit">', "<label>Presentation link</label>", "</div>", "</div>"].join("")),
        this.renderLinkInput();
        var t = this.pagesElement.find(".decksharer-share-options-page"),
        e = window.Reveal && window.Reveal.isReady() ? window.Reveal.getIndices() : null;
        e && (e.h > 0 || e.v > 0) && (t.append(['<div class="unit sl-checkbox outline">', '<input id="deeplink-checkbox" type="checkbox" class="deeplink-input" />', '<label for="deeplink-checkbox">Link to current slide</label>', "</div>"].join("")), this.deeplinkInput = this.pagesElement.find('[data-id="link"] .deeplink-input'), this.deeplinkInput.on("change", this.onDeeplinkToggled.bind(this))),
        t.append(['<div class="unit sl-checkbox outline">', '<input id="fullscreen-checkbox" type="checkbox" class="fullscreen-input" />', '<label for="fullscreen-checkbox">Fullscreen</label>', "</div>"].join("")),
        this.fullscreenInput = this.pagesElement.find('[data-id="link"] .fullscreen-input'),
        this.fullscreenInput.on("change", this.onLinkFullscreenToggled.bind(this)),
        2 === t.find(".sl-checkbox").length && t.append($('<div class="half-units">').append(t.find(".sl-checkbox")))
    },
    renderLinkInput : function () {
        this.USE_READONLY ? (this.linkInput = $('<input type="text" class="link-input" readonly="readonly" />'), this.linkInput.on("mousedown", this.onLinkInputMouseDown), this.linkInput.appendTo(this.pagesElement.find('[data-id="link"] .link-unit'))) : (this.linkAnchor = $('<a href="#" class="input-field">'), this.linkAnchor.appendTo(this.pagesElement.find('[data-id="link"] .link-unit')))
    },
    renderDeckViewLink : function () {
        this.pagesElement.append(['<div class="decksharer-share-options-page sl-form" data-id="link">', '<div class="unit link-unit">', "<label>Presentation link</label>", "</div>", "</div>"].join("")),
        "live" === this.options.deckView && (this.pagesElement.find('[data-id="link"] .link-unit label').text("Live presentation link"), this.pagesElement.find('[data-id="link"] .link-unit').append('<p class="unit-description">This links lets viewers follow the presentation in real-time.</p>')),
        this.renderLinkInput()
    },
    renderEmbed : function () {
        this.tabsElement.append('<div class="decksharer-share-options-tab" data-id="' + SL.components.decksharer.ShareOptions.EMBED_PAGE_ID + '">Embed</div>');
        var t = '<option value="dark" selected>Dark</option><option value="light">Light</option>';
        SL.current_user.privileges.hideEmbedFooter() && (t += '<option value="hidden">Hidden</option>'),
        this.pagesElement.append(['<div class="decksharer-share-options-page sl-form" data-id="embed">', '<div class="embed-options">', '<div class="unit">', "<label>Width:</label>", '<input type="text" name="width" maxlength="4" />', "</div>", '<div class="unit">', "<label>Height:</label>", '<input type="text" name="height" maxlength="4" />', "</div>", '<div class="unit">', "<label>Footer style:</label>", '<select class="sl-select" name="style">', t, "</select>", "</div>", "</div>", '<textarea name="output"></textarea>', "</div>"].join("")),
        this.embedElement = this.pagesElement.find('[data-id="embed"]'),
        this.embedStyleElement = this.embedElement.find("select[name=style]"),
        this.embedWidthElement = this.embedElement.find("input[name=width]"),
        this.embedHeightElement = this.embedElement.find("input[name=height]"),
        this.embedOutputElement = this.embedElement.find("textarea"),
        this.embedStyleElement.on("change", this.onEmbedStyleChanged),
        this.embedWidthElement.on("input", this.onEmbedSizeChanged),
        this.embedHeightElement.on("input", this.onEmbedSizeChanged),
        this.USE_READONLY ? (this.embedOutputElement.attr("readonly", "readonly"), this.embedOutputElement.on("mousedown", this.onEmbedOutputMouseDown)) : this.embedOutputElement.on("input", this.generate.bind(this)),
        this.embedWidthElement.val(this.width),
        this.embedHeightElement.val(this.height)
    },
    renderEmail : function () {
        this.tabsElement.append('<div class="decksharer-share-options-tab" data-id="' + SL.components.decksharer.ShareOptions.EMAIL_PAGE_ID + '">Email</div>'),
        this.pagesElement.append(['<div class="decksharer-share-options-page" data-id="email">', '<div class="sl-form">', '<div class="unit" data-validate="none" data-required>', "<label>From</label>", '<input type="text" class="email-from" placeholder="Your Name" maxlength="255" />', "</div>", '<div class="unit" data-validate="none" data-required>', "<label>To</label>", '<input type="text" class="email-to" placeholder="john@example.com, jane@example.com" maxlength="2500" />', "</div>", '<div class="unit text" data-validate="none" data-required>', "<label>Message</label>", '<p class="unit-description">A link to the deck is automatically included after the message.</p>', '<textarea class="email-body" rows="3" maxlength="2500"></textarea>', "</div>", '<div class="submit-wrapper">', '<button type="submit" class="button positive l ladda-button email-submit" data-style="zoom-out">Send</button>', "</div>", "</div>", '<div class="email-success">', '<div class="email-success-icon icon i-checkmark"></div>', '<p class="email-success-description">Email sent!</p>', "</div>", "</div>"].join("")),
        this.emailElement = this.pagesElement.find('[data-id="email"]'),
        this.emailSuccess = this.emailElement.find(".email-success"),
        this.emailForm = this.emailElement.find(".sl-form"),
        this.emailFromElement = this.emailForm.find(".email-from"),
        this.emailToElement = this.emailForm.find(".email-to"),
        this.emailBodyElement = this.emailForm.find(".email-body"),
        this.emailSubmitButton = this.emailForm.find(".email-submit"),
        this.emailFormUnits = [],
        this.emailForm.find(".unit[data-validate]").each(function (t, e) {
            this.emailFormUnits.push(new SL.components.FormUnit(e))
        }
            .bind(this)),
        this.emailSubmitButton.on("vclick", this.onEmailSubmitClicked.bind(this)),
        this.emailSubmitLoader = Ladda.create(this.emailSubmitButton.get(0))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    showPage : function (t) {
        this.tabsElement.find(".decksharer-share-options-tab").removeClass("is-selected"),
        this.pagesElement.find(".decksharer-share-options-page").removeClass("is-selected"),
        this.tabsElement.find('[data-id="' + t + '"]').addClass("is-selected"),
        this.pagesElement.find('[data-id="' + t + '"]').addClass("is-selected"),
        this.pageChanged.dispatch(t)
    },
    getPageID : function () {
        return this.tabsElement.find(".is-selected").attr("data-id")
    },
    generate : function () {
        var t = this.getShareURLs();
        if (this.embedOutputElement) {
            var e = '<iframe src="' + t.embed + '" width="' + this.width + '" height="' + this.height + '" scrolling="no" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
            this.embedOutputElement.text(e)
        }
        var i = this.fullscreenInput && this.fullscreenInput.is(":checked") ? t.fullscreen : t.show;
        if (this.deeplinkInput && this.deeplinkInput.is(":checked")) {
            var n = window.Reveal.getIndices();
            n.h > 0 && n.v > 0 ? i += "#/" + n.h + "/" + n.v : n.h > 0 && (i += "#/" + n.h)
        }
        this.linkInput && this.linkInput.val(i),
        this.linkAnchor && this.linkAnchor.attr("href", i).text(i),
        this.emailElement && (SL.current_user && this.emailFromElement.val(SL.current_user.getNameOrSlug()), this.emailBodyElement.val(this.deck.has("title") && "deck" !== this.deck.get("title") ? 'Check out this deck "' + this.deck.get("title") + '"' : "Check out this deck"))
    },
    getShareURLs : function () {
        var t = {
            show : this.deck.getURL({
                protocol : "http:",
                view : this.options.deckView
            }),
            fullscreen : this.deck.getURL({
                protocol : "http:",
                view : "fullscreen"
            }),
            embed : this.deck.getURL({
                protocol : "",
                view : "embed"
            })
        },
        e = [];
        return this.options.token && this.options.token.has("token") && e.push("token=" + this.options.token.get("token")),
        t.show += e.length ? "?" + e.join("&") : "",
        t.fullscreen += e.length ? "?" + e.join("&") : "",
        "string" == typeof this.style && this.style.length > 0 && e.push("style=" + this.style),
        t.embed += e.length ? "?" + e.join("&") : "",
        t
    },
    onEmbedOutputMouseDown : function (t) {
        t.preventDefault(),
        this.embedOutputElement.focus().select(),
        SL.analytics.track("Decksharer: Embed code selected")
    },
    onLinkInputMouseDown : function (t) {
        t.preventDefault(),
        $(t.target).focus().select(),
        SL.analytics.track("Decksharer: URL selected")
    },
    onDeeplinkToggled : function () {
        this.generate(),
        SL.analytics.track("Decksharer: Deeplink toggled")
    },
    onLinkFullscreenToggled : function () {
        this.generate(),
        SL.analytics.track("Decksharer: URL fullscreen toggled")
    },
    onEmbedSizeChanged : function () {
        this.width = parseInt(this.embedWidthElement.val(), 10) || 1,
        this.height = parseInt(this.embedHeightElement.val(), 10) || 1,
        this.generate()
    },
    onEmbedStyleChanged : function () {
        this.style = this.embedStyleElement.val(),
        this.generate()
    },
    onEmailSubmitClicked : function (t) {
        var e = this.emailFormUnits.every(function (t) {
                return t.beforeSubmit()
            });
        if (e && !this.emailXHR) {
            SL.analytics.track("Decksharer: Submit email");
            var i = this.emailFromElement.val(),
            n = this.emailToElement.val(),
            s = this.emailBodyElement.val();
            this.emailSubmitLoader.start(),
            n = n.split(","),
            n = n.map(function (t) {
                    return t.trim()
                }),
            n = n.join(",");
            var o = {
                deck_share : {
                    emails : n,
                    from : i,
                    body : s
                }
            };
            this.options.token && (o.deck_share.access_token_id = this.options.token.get("id")),
            this.emailXHR = $.ajax({
                    url : SL.config.AJAX_SHARE_DECK_VIA_EMAIL(this.deck.get("id")),
                    type : "POST",
                    context : this,
                    data : o
                }).done(function () {
                    this.emailSuccess.addClass("visible"),
                    setTimeout(function () {
                        this.emailSuccess.removeClass("visible"),
                        this.emailToElement.val(""),
                        this.emailBodyElement.val(""),
                        this.generate()
                    }
                        .bind(this), 3e3),
                    SL.analytics.track("Decksharer: Submit email success")
                }).fail(function () {
                    SL.notify("Failed to send email", "negative"),
                    SL.analytics.track("Decksharer: Submit email error")
                }).always(function () {
                    this.emailXHR = null,
                    this.emailSubmitLoader.stop()
                })
        }
        t.preventDefault()
    },
    destroy : function () {
        this.pageChanged.dispose(),
        this.deck = null,
        this.domElement.remove()
    }
});