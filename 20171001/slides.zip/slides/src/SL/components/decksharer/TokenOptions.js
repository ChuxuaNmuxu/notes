import SL from '../../SL';

SL("components.decksharer").TokenOptions = Class.extend({
    init : function (t, e, i) {
        this.deck = t,
        this.token = e,
        this.options = i,
        this.tokenRenamed = new signals.Signal,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="decksharer-token-options">'),
        this.innerElement = $('<div class="sl-form decksharer-token-options-inner">'),
        this.innerElement.appendTo(this.domElement),
        this.namePasswordElement = $('<div class="split-units">'),
        this.namePasswordElement.appendTo(this.innerElement),
        this.nameUnit = $(['<div class="unit">', '<label class="form-label" for="token-name">Name</label>', '<p class="unit-description">So you can tell your links apart.</p>', '<input class="input-field" type="text" id="token-name" maxlength="255" />', "</div>"].join("")),
        this.nameUnit.appendTo(this.namePasswordElement),
        this.nameInput = this.nameUnit.find("input"),
        this.nameInput.val(this.token.get("name")),
        this.passwordUnit = $(['<div class="unit">', '<label class="form-label" for="token-password">Password<span class="optional-label">(optional)</span></label>', '<p class="unit-description">Viewers need to enter this.</p>', '<input class="input-field" type="password" id="token-password" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;" maxlength="255" />', "</div>"].join("")),
        this.passwordUnit.appendTo(this.namePasswordElement),
        this.passwordInput = this.passwordUnit.find("input"),
        this.passwordInput.val(this.token.get("password")),
        this.saveWrapper = $(['<div class="save-wrapper">', '<button class="button l save-button ladda-button" data-style="expand-left" data-spinner-size="26">Save changes</button>', "</div>"].join("")),
        this.saveWrapper.appendTo(this.innerElement),
        this.saveButton = this.saveWrapper.find(".button"),
        this.saveButtonLoader = Ladda.create(this.saveButton.get(0)),
        this.shareOptions = new SL.components.decksharer.ShareOptions(this.deck, $.extend(this.options, {
                    token : this.token
                })),
        this.shareOptions.appendTo(this.domElement)
    },
    bind : function () {
        this.saveChanges = this.saveChanges.bind(this),
        this.nameInput.on("input", this.onNameInput.bind(this)),
        this.passwordInput.on("input", this.onPasswordInput.bind(this)),
        this.saveButton.on("click", this.saveChanges)
    },
    appendTo : function (t, e) {
        this.domElement.appendTo(t),
        e || SL.util.dom.calculateStyle(this.domElement),
        this.domElement.addClass("visible")
    },
    checkUnsavedChanges : function () {
        var t = this.token.get("name") || "",
        e = this.token.get("password") || "",
        i = this.nameInput.val(),
        n = this.passwordInput.val(),
        s = n !== e || i !== t;
        this.domElement.toggleClass("is-unsaved", s)
    },
    saveChanges : function () {
        this.nameInput.val() ? (this.token.set("name", this.nameInput.val()), this.token.set("password", this.passwordInput.val()), this.saveButtonLoader.start(), this.token.save(["name", "password"]).fail(function () {
                this.saveButtonLoader.stop(),
                SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
            }
                .bind(this)).done(function () {
                this.saveButtonLoader.stop(),
                this.domElement.removeClass("is-unsaved")
            }
                .bind(this))) : SL.notify("Please give the link a name", "negative")
    },
    onNameInput : function () {
        this.tokenRenamed.dispatch(this.token, this.nameInput.val()),
        this.checkUnsavedChanges()
    },
    onPasswordInput : function () {
        this.checkUnsavedChanges()
    },
    destroy : function () {
        this.tokenRenamed.dispatch(this.token),
        this.tokenRenamed.dispose(),
        this.shareOptions && (this.shareOptions.destroy(), this.shareOptions = null),
        this.saveButtonLoader && this.saveButtonLoader.stop(),
        this.deck = null,
        this.token = null,
        this.domElement.addClass("hidden"),
        setTimeout(this.domElement.remove.bind(this.domElement), 500)
    }
});