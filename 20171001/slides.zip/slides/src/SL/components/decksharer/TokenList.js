import SL from '../../SL';

SL("components.decksharer").TokenList = Class.extend({
    init : function (t, e) {
        this.deck = t,
        this.tokens = e,
        this.tokenSelected = new signals.Signal,
        this.tokensEmptied = new signals.Signal,
        this.render()
    },
    render : function () {
        this.domElement = $('<div class="decksharer-token-list">'),
        this.listItems = $('<div class="decksharer-token-list-items">').appendTo(this.domElement),
        this.createButton = $(['<div class="decksharer-token-list-create ladda-button" data-style="zoom-out" data-spinner-color="#222">', '<span class="icon i-plus"></span>', "</div>"].join("")),
        this.createButton.on("vclick", this.create.bind(this)),
        this.createButton.appendTo(this.domElement),
        this.createButtonLoader = Ladda.create(this.createButton.get(0)),
        this.tokens.forEach(this.renderToken.bind(this)),
        this.scrollShadow = new SL.components.ScrollShadow({
                parentElement : this.domElement,
                contentElement : this.listItems,
                footerElement : this.createButton,
                resizeContent : !1
            })
    },
    renderToken : function (t) {
        var e = t.get("deck_view_count") || 0,
        i = e + " " + SL.util.string.pluralize("view", "s", 1 !== e),
        n = $(['<div class="decksharer-token-list-item" data-id="' + t.get("id") + '">', '<span class="label"></span>', '<div class="meta">', '<span class="views">' + i + "</span>", '<span class="icon i-x delete" data-tooltip="Delete link"></span>', "</div>", "</div>"].join(""));
        n.appendTo(this.listItems),
        n.on("vclick",
            function (e) {
            if ($(e.target).closest(".delete").length > 0) {
                SL.prompt({
                    anchor : n,
                    alignment : "r",
                    title : "Are you sure you want to delete this link? It will stop working for anyone you have already shared it with.",
                    type : "select",
                    data : [{
                            html : "<h3>Cancel</h3>"
                        }, {
                            html : "<h3>Delete</h3>",
                            selected : !0,
                            className : "negative",
                            callback : function () {
                                this.remove(t, n)
                            }
                            .bind(this)
                        }
                    ]
                })
            } else
                this.select(t)
        }
            .bind(this)),
        this.setTokenLabel(t)
    },
    setTokenLabel : function (t, e) {
        var i = this.listItems.find(".decksharer-token-list-item[data-id=" + t.get("id") + "]");
        i.length && (e || (e = t.get("name") || t.get("token")), i.find(".label").html(e))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.scrollShadow.sync()
    },
    selectDefault : function () {
        this.select(this.tokens.first()),
        this.scrollShadow.sync()
    },
    select : function (t) {
        if (t && t !== this.selectedToken) {
            var e = this.listItems.find(".decksharer-token-list-item[data-id=" + t.get("id") + "]");
            e.length && (this.listItems.find(".decksharer-token-list-item").removeClass("is-selected"), e.addClass("is-selected"), this.tokenSelected.dispatch(t), this.selectedToken = t)
        }
    },
    create : function (t) {
        var e = 0 === this.tokens.size();
        t && this.createButtonLoader.start(),
        SL.data.tokens.create(this.deck.get("id")).then(function (t) {
            SL.analytics.track(e ? "Decksharer: Created first token" : "Decksharer: Created additional token"),
            this.renderToken(t),
            this.select(t),
            this.createButtonLoader.stop(),
            this.scrollShadow.sync()
        }
            .bind(this),
            function () {
            SL.notify(SL.locale.get("GENERIC_ERROR"), "negative"),
            this.createButtonLoader.stop()
        }
            .bind(this))
    },
    remove : function (t, e) {
        t.destroy().fail(function () {
            SL.notify(SL.locale.get("GENERIC_ERROR"), "negative")
        }
            .bind(this)).done(function () {
            SL.util.anim.collapseListItem(e,
                function () {
                e.remove(),
                this.scrollShadow.sync()
            }
                .bind(this), 300),
            this.tokens.remove(t),
            this.selectedToken === t && (this.selectedToken = null, this.selectDefault()),
            0 === this.tokens.size() && this.tokensEmptied.dispatch(),
            SL.analytics.track("Decksharer: Deleted token")
        }
            .bind(this))
    },
    destroy : function () {
        this.createButtonLoader && this.createButtonLoader.stop(),
        this.scrollShadow && this.scrollShadow.destroy(),
        this.tokens = null,
        this.domElement.remove()
    }
});