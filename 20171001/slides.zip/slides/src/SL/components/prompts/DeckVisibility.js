import SL from '../../SL';

SL("components.prompts").DeckVisibility = SL.components.Prompt.extend({
    init : function (t, e) {
        this.deckModel = t,
        this.visibilitySelected = new signals.Signal,
        this._super($.extend({
                type : "select",
                className : "sl-visibility-prompt",
                data : this.getVisibilityOptions(),
                persistVisibility : !0
            },
                e))
    },
    getVisibilityOptions : function () {
        var t = [],
        e = SL.current_user.isEnterprise(),
        i = !SL.current_user.isEnterprise() || SL.current_team.allowPublicDecks();
        return t.push({
            html : SL.locale.get("DECK_VISIBILITY_CHANGE_SELF"),
            selected : this.deckModel.get("visibility") === SL.models.Deck.VISIBILITY_SELF,
            callback : this.selectVisibility.bind(this, SL.models.Deck.VISIBILITY_SELF)
        }),
        e && t.push({
            html : SL.locale.get("DECK_VISIBILITY_CHANGE_TEAM"),
            selected : this.deckModel.get("visibility") === SL.models.Deck.VISIBILITY_TEAM,
            className : "divider",
            callback : this.selectVisibility.bind(this, SL.models.Deck.VISIBILITY_TEAM)
        }),
        t.push(i ? {
            html : SL.locale.get("DECK_VISIBILITY_CHANGE_ALL"),
            selected : this.deckModel.get("visibility") === SL.models.Deck.VISIBILITY_ALL,
            callback : this.selectVisibility.bind(this, SL.models.Deck.VISIBILITY_ALL)
        }
                : {
            html : SL.locale.get("DECK_VISIBILITY_SHARE_LINK"),
            callback : function () {
                SL.popup.open(SL.components.decksharer.DeckSharer, {
                    deck : this.deckModel
                })
            }
            .bind(this)
        }),
        t
    },
    selectVisibility : function (t) {
        if (this.config.persistVisibility) {
            var e = $.ajax({
                    type : "POST",
                    url : SL.config.AJAX_PUBLISH_DECK(this.deckModel.get("id")),
                    context : this,
                    data : {
                        visibility : t
                    }
                }).done(function (t) {
                    t.deck.visibility === SL.models.Deck.VISIBILITY_SELF ? SL.notify(SL.locale.get("DECK_VISIBILITY_CHANGED_SELF")) : t.deck.visibility === SL.models.Deck.VISIBILITY_TEAM ? SL.notify(SL.locale.get("DECK_VISIBILITY_CHANGED_TEAM")) : t.deck.visibility === SL.models.Deck.VISIBILITY_ALL && SL.notify(SL.locale.get("DECK_VISIBILITY_CHANGED_ALL")),
                    "string" == typeof t.deck.slug && this.deckModel.set("slug", t.deck.slug),
                    "string" == typeof t.deck.visibility && this.deckModel.set("visibility", t.deck.visibility)
                }).fail(function () {
                    SL.notify(SL.locale.get("DECK_VISIBILITY_CHANGED_ERROR"), "negative")
                });
            this.visibilitySelected.dispatch(t, e)
        } else
            this.visibilitySelected.dispatch(t)
    },
    destroy : function () {
        this.visibilitySelected.dispose(),
        this._super.apply(this, arguments)
    }
});