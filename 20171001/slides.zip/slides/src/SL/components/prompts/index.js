import SL from '../../SL';

SL.prompt = function (t) {
	var e = new SL.components.Prompt(t);
	return e.show(),
	e
};

import './DeckVisibility';
import './SMS';