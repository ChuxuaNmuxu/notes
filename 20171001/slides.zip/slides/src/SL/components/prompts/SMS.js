import SL from '../../SL';

SL("components.prompts").SMS = SL.components.Prompt.extend({
    init : function (t) {
        window.SLPhoneCountryCodes || console.warn("SLPhoneCountryCodes must be included on the page for the SMS prompt to work."),
        this._super($.extend({
                type : "custom",
                title : "Send SMS",
                className : "sl-sms-prompt",
                html : this.renderForm(),
                confirmLabel : "Send",
                confirmButton : !0,
                cancelButton : !0,
                destroyAfterConfirm : !1,
                endpoint : SL.config.AJAX_SMS_DECK(SL.current_deck.get("id"))
            },
                t))
    },
    renderForm : function () {
        return this.formElement = $(['<div class="sl-form">', '<select class="sl-select country-selector">', window.SLPhoneCountryCodes.map(function (t) {
                        return '<option value="' + t.code + '">' + t.name + "</option>"
                    }).join(""), "</select>", '<div class="unit text">', '<div class="prefixed-input">', '<div class="prefix"><span class="country-code"></span></div>', '<input class="phone-number" type="text" placeholder="555 5555" maxlength="50" />', "</div>", "</div>", "</div>"].join("")),
        this.countrySelector = this.formElement.find(".country-selector"),
        this.countrySelector.on("change", this.onCountryChanged.bind(this)),
        this.countryCodeOutput = this.formElement.find(".country-code"),
        this.phoneNumberInput = this.formElement.find(".phone-number"),
        this.phoneNumberInput.on("change", this.onPhoneNumberChanged.bind(this)),
        this.restoreSavedFormValues(),
        this.formElement
    },
    restoreSavedFormValues : function () {
        SL.current_user && (this.setCountryCode(SL.current_user.settings.has("phone_country_code") ? SL.current_user.settings.get("phone_country_code") : window.SLPhoneCountryCodes[0].code), SL.current_user.settings.has("phone_number") && this.setPhoneNumber(SL.current_user.settings.get("phone_number")))
    },
    setCountryCode : function (t) {
        this.countrySelector.val(t),
        this.countryCodeOutput.html("+" + t)
    },
    getCountryCode : function () {
        return this.countrySelector.val()
    },
    setPhoneNumber : function (t) {
        this.formatPhoneNumber(t)
    },
    getPhoneNumber : function (t) {
        var e = this.formatPhoneNumber();
        return t && (e = e.replace(/\s/, "")),
        e
    },
    formatPhoneNumber : function (t) {
        switch (t = t || this.phoneNumberInput.val(), t = t.trim(), t = t.replace(/[^0-9]/g, ""), parseInt(this.getCountryCode(), 10)) {
        case 1:
            t = t.replace(/(\d{3})(\d{3})(\d+)/, "$1 $2 $3");
            break;
        case 46:
            t = t.replace(/(\d{2})(\d{3})(\d{2})(\d+)/, "$1 $2 $3 $4")
        }
        return this.phoneNumberInput.val(t),
        t
    },
    show : function () {
        this._super.apply(this, arguments),
        this.countrySelector.focus()
    },
    confirm : function () {
        this._super.apply(this, arguments);
        var t = this.getCountryCode(),
        e = this.getPhoneNumber(!0);
        t && e ? (this.showOverlay("neutral", "Sending", '<div class="spinner" data-spinner-color="#333"></div>'), SL.util.html.generateSpinners(), $.ajax({
                url : this.config.endpoint,
                type : "POST",
                context : this,
                data : {
                    phone_number : e,
                    country_code : t
                }
            }).done(function () {
                this.showOverlay("positive", "SMS sent!", '<span class="icon i-checkmark"></span>', 2e3).then(function () {
                    SL.current_user && (SL.current_user.settings.set("phone_number", e), SL.current_user.settings.set("phone_country_code", t)),
                    this.destroy()
                }
                    .bind(this))
            }).fail(function (t) {
                t.responseJSON && t.responseJSON.phone_number && t.responseJSON.phone_number.length > 0 ? this.showOverlay("negative", 'Failed to send SMS: <br>"' + value + '" ' + t.responseJSON.phone_number[0], '<span class="icon i-x"></span>', 2e3) : this.showOverlay("negative", "Failed to send SMS.", '<span class="icon i-x"></span>', 2e3)
            })) : this.showOverlay("negative", "Please enter a valid phone number", '<span class="icon i-x"></span>', 2e3)
    },
    onCountryChanged : function (t) {
        this.setCountryCode(t.target.value),
        this.formatPhoneNumber(),
        this.phoneNumberInput.focus()
    },
    onPhoneNumberChanged : function () {
        this.formatPhoneNumber()
    },
    destroy : function () {
        this._super.apply(this, arguments)
    }
});