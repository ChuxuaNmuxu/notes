import SL from '../SL';

SL("components").StreamPointer = Class.extend({
	init : function (t) {
		this.options = $.extend({
				publisher : !1,
				stream : null,
				container : document.body,
				easing : .13,
				hideDefault : !1
			},
				t),
		this.x = 0,
		this.y = 0,
		this.isDown = !1,
		this.isOutside = !1,
		this.render(),
		this.bind()
	},
	render : function () {
		this.domElement = $('<div class="sl-stream-pointer">'),
		this.domElement.html('<svg viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M7,2l12,11.2l-5.8,0.5l3.3,7.3l-2.2,1l-3.2-7.4L7,18.5V2z"/></svg>')
	},
	bind : function () {
		this.hide = this.hide.bind(this),
		this.paint = this.paint.bind(this),
		this.onMouseMove = this.onMouseMove.bind(this),
		this.onMouseLeave = this.onMouseLeave.bind(this),
		this.onMouseEnter = this.onMouseEnter.bind(this),
		this.onMouseDown = this.onMouseDown.bind(this),
		this.onMouseUp = this.onMouseUp.bind(this),
		this.onWindowResize = this.onWindowResize.bind(this),
		this.onStreamPointerChanged = this.onStreamPointerChanged.bind(this),
		this.broadcastPosition = $.throttle(this.broadcastPosition, SL.config.STREAM_POINTER_UPDATE_FREQUENCY),
		this.options.stream.pointerChanged.add(this.onStreamPointerChanged),
		this.options.publisher && ($(this.options.container).on("mousemove", this.onMouseMove), $(this.options.container).on("mouseleave", this.onMouseLeave), $(this.options.container).on("mouseenter", this.onMouseEnter), $(this.options.container).on("mousedown", this.onMouseDown))
	},
	setEnabled : function (t) {
		this.enabled = t,
		t ? (this.domElement.appendTo(this.options.container), this.show()) : (this.domElement.detach(), this.hide(), this.moved = !1, this.domElement.removeClass("has-position"))
	},
	isEnabled : function () {
		return this.enabled
	},
	show : function () {
		this.isEnabled() && ($(window).on("resize", this.onWindowResize), this.domElement.addClass("visible"), this.options.hideDefault && (this.options.container.style.cursor = "none"), this.layout())
	},
	hide : function () {
		$(window).off("resize", this.onWindowResize),
		this.domElement.removeClass("visible"),
		this.options.hideDefault && (this.options.container.style.cursor = "")
	},
	move : function (t, e, i) {
		this.layoutIfNecessary(),
		this.x = t,
		this.y = e,
		i ? (this.tx = this.cx = this.x, this.ty = this.cy = this.y) : (this.tx = this.slideX + this.x * this.slideScale, this.ty = this.slideY + this.y * this.slideScale),
		this.cx && this.cy || (this.cx = this.tx, this.cy = this.ty),
		this.painting || this.paint(),
		this.moved || (this.moved = !0, this.domElement.addClass("has-position"))
	},
	layout : function () {
		var t = $(".reveal").get(0).getBoundingClientRect(),
		e = Reveal.getConfig();
		this.slideScale = Reveal.getScale(),
		this.slideX = t.left + (t.width / 2 - e.width * this.slideScale / 2),
		this.slideY = t.top + (t.height / 2 - e.height * this.slideScale / 2),
		this.domElement.css("font-size", Math.round(34 * Math.max(Math.min(this.slideScale, 1), .6)))
	},
	layoutIfNecessary : function () {
		"undefined" == typeof this.slideScale && this.layout()
	},
	paint : function () {
		this.cx += (this.tx - this.cx) * this.options.easing,
		this.cy += (this.ty - this.cy) * this.options.easing,
		this.domElement.css("transform", "translate(" + this.cx + "px," + this.cy + "px)"),
		Math.abs(this.cx - this.tx) > .5 || Math.abs(this.cy - this.ty) > .5 ? (window.requestAnimationFrame(this.paint), this.painting = !0) : this.painting = !1
	},
	broadcastPosition : function (t) {
		if (this.isEnabled() && this.options.publisher) {
			this.layoutIfNecessary();
			var e = Math.round((this.mouseX - this.slideX) / this.slideScale),
			i = Math.round((this.mouseY - this.slideY) / this.slideScale);
			this.options.stream.broadcast($.extend({
					type : "live:pointer",
					x : e,
					y : i
				},
					t))
		}
	},
	destroy : function () {
		window.cancelAnimationFrame(this.paint),
		this.options.stream.pointerChanged.remove(this.onStreamPointerChanged),
		$(window).off("resize", this.onWindowResize),
		$(document).off("mouseup", this.onMouseUp),
		this.options.publisher && ($(this.options.container).off("mousemove", this.onMouseMove), $(this.options.container).off("mouseleave", this.onMouseLeave), $(this.options.container).off("mouseenter", this.onMouseEnter), $(this.options.container).off("mousedown", this.onMouseDown)),
		this.options = null,
		this.domElement.remove()
	},
	onWindowResize : function () {
		this.layout(),
		this.move(this.x, this.y)
	},
	onStreamPointerChanged : function (t) {
		"number" == typeof t.x && "number" == typeof t.y && this.move(t.x, t.y),
		"boolean" == typeof t.outside && (this.isOutside = t.outside, this.isOutside ? this.hide() : this.show()),
		"boolean" == typeof t.down && (this.isDown = t.down, this.domElement.toggleClass("is-down", this.isDown))
	},
	onMouseMove : function (t) {
		this.mouseX = t.clientX,
		this.mouseY = t.clientY,
		this.isEnabled() && (this.move(this.mouseX, this.mouseY, !0), this.broadcastPosition())
	},
	onMouseLeave : function (t) {
		this.isOutside = !0,
		this.hide(),
		this.options.stream.broadcast({
			type : "live:pointer",
			outside : !0,
			down : !1
		}),
		this.isDown && this.onMouseUp(t)
	},
	onMouseEnter : function () {
		this.isOutside = !1,
		this.show(),
		this.options.stream.broadcast({
			type : "live:pointer",
			outside : !1,
			down : !1
		})
	},
	onMouseDown : function () {
		this.isDown = !0,
		this.domElement.toggleClass("is-down", !0),
		this.broadcastPosition({
			down : !0
		}),
		$(document).on("mouseup", this.onMouseUp)
	},
	onMouseUp : function () {
		this.isDown = !1,
		this.domElement.toggleClass("is-down", !1),
		this.broadcastPosition({
			down : !1
		}),
		$(document).off("mouseup", this.onMouseUp)
	}
});