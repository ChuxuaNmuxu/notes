import SL from '../SL';

SL.tooltip = function () {
	function t() {
		a = $("<div>").addClass("sl-tooltip"),
		r = $('<p class="sl-tooltip-inner">').appendTo(a),
		l = $('<div class="sl-tooltip-arrow">').appendTo(a),
		d = $('<div class="sl-tooltip-arrow-fill">').appendTo(l),
		e()
	}
	function e() {
		n = n.bind(this),
		$(document).on("keydown, mousedown",
			function () {
			SL.tooltip.hide()
		}),
		SL.util.device.IS_PHONE || SL.util.device.IS_TABLET || ($(document.body).delegate("[data-tooltip]", "mouseenter",
				function (t) {
				var e = $(t.currentTarget);
				if (!e.is("[no-tooltip]")) {
					var n = e.attr("data-tooltip"),
					s = e.attr("data-tooltip-delay"),
					o = e.attr("data-tooltip-align"),
					a = e.attr("data-tooltip-alignment"),
					r = e.attr("data-tooltip-maxwidth"),
					l = e.attr("data-tooltip-maxheight"),
					d = e.attr("data-tooltip-ox"),
					c = e.attr("data-tooltip-oy"),
					h = e.attr("data-tooltip-x"),
					u = e.attr("data-tooltip-y");
					if (n) {
						var p = {
							anchor : e,
							align : o,
							alignment : a,
							delay : parseInt(s, 10),
							maxwidth : parseInt(r, 10),
							maxheight : parseInt(l, 10)
						};
						d && (p.ox = parseFloat(d)),
						c && (p.oy = parseFloat(c)),
						h && u && (p.x = parseFloat(h), p.y = parseFloat(u), p.anchor = null),
						i(n, p)
					}
				}
			}), $(document.body).delegate("[data-tooltip]", "mouseleave", s))
	}
	function i(t, e) {
		if (!SL.util.device.IS_PHONE && !SL.util.device.IS_TABLET) {
			c = e || {},
			clearTimeout(p);
			var s = Date.now() - m;
			if ("number" == typeof c.delay && s > 500)
				return p = setTimeout(i.bind(this, t, c), c.delay),
				void delete c.delay;
			a.css("opacity", 0),
			a.appendTo(document.body),
			r.html(t),
			a.css({
				left : 0,
				top : 0,
				"max-width" : c.maxwidth ? c.maxwidth : null,
				"max-height" : c.maxheight ? c.maxheight : null
			}),
			c.align && a.css("text-align", c.align),
			n(),
			a.stop(!0, !0).animate({
				opacity : 1
			}, {
				duration : 150
			}),
			$(window).on("resize scroll", n),
			$(c.anchor).parents(".sl-scrollable").on("scroll", n)
		}
	}
	function n() {
		var t = $(c.anchor);
		if (t.length) {
			var e = c.alignment || "auto",
			i = 10,
			n = $(window).scrollLeft(),
			s = $(window).scrollTop(),
			o = t.offset();
			o.x = o.left,
			o.y = o.top,
			c.anchor.parents(".reveal .slides").length && "undefined" != typeof window.Reveal && (o = SL.util.getRevealElementGlobalOffset(c.anchor));
			var d = t.outerWidth(),
			p = t.outerHeight(),
			m = r.outerWidth(),
			f = r.outerHeight(),
			g = o.x - $(window).scrollLeft(),
			v = o.y - $(window).scrollTop(),
			b = m / 2,
			S = f / 2;
			switch ("number" == typeof c.ox && (g += c.ox), "number" == typeof c.oy && (v += c.oy), "auto" === e && (e = o.y - (f + i + h) < s ? "b" : "t"), e) {
			case "t":
				g += (d - m) / 2,
				v -= f + h + u;
				break;
			case "b":
				g += (d - m) / 2,
				v += p + h + u;
				break;
			case "l":
				g -= m + h + u,
				v += (p - f) / 2;
				break;
			case "r":
				g += d + h + u,
				v += (p - f) / 2
			}
			g = Math.min(Math.max(g, i), window.innerWidth - m - i),
			v = Math.min(Math.max(v, i), window.innerHeight - f - i);
			var y = h + 3;
			switch (e) {
			case "t":
				b = o.x - g - n + d / 2,
				S = f,
				b = Math.min(Math.max(b, y), m - y);
				break;
			case "b":
				b = o.x - g - n + d / 2,
				S = -h,
				b = Math.min(Math.max(b, y), m - y);
				break;
			case "l":
				b = m,
				S = o.y - v - s + p / 2,
				S = Math.min(Math.max(S, y), f - y);
				break;
			case "r":
				b = -h,
				S = o.y - v - s + p / 2,
				S = Math.min(Math.max(S, y), f - y)
			}
			l.css({
				left : Math.round(b),
				top : Math.round(S)
			}),
			a.css({
				left : Math.round(g),
				top : Math.round(v)
			}).attr("data-alignment", e)
		}
	}
	function s() {
		o() && (m = Date.now()),
		clearTimeout(p),
		a.remove().stop(!0, !0),
		$(window).off("resize scroll", n),
		c && $(c.anchor).parents(".sl-scrollable").off("scroll", n)
	}
	function o() {
		return a.parent().length > 0
	}
	var a,
	r,
	l,
	d,
	c,
	h = 6,
	u = 4,
	p = -1,
	m = -1;
	return t(), {
		show : function (t, e) {
			i(t, e)
		},
		hide : function () {
			s()
		},
		isVisible : function () {
			return o()
		},
		anchorTo : function (t, e, i) {
			var n = {};
			"undefined" != typeof e && (n["data-tooltip"] = e),
			"number" == typeof i.delay && (n["data-tooltip-delay"] = i.delay),
			"string" == typeof i.alignment && (n["data-tooltip-alignment"] = i.alignment),
			$(t).attr(n)
		}
	}
}();
SL("components").Tutorial = Class.extend({
		init : function (t) {
			this.options = $.extend({
					steps : []
				},
					t),
			this.options.steps.forEach(function (t) {
				"undefined" == typeof t.backwards && (t.backwards = function () {}),
				"undefined" == typeof t.forwards && (t.forwards = function () {})
			}),
			this.skipped = new signals.Signal,
			this.finished = new signals.Signal,
			this.index = -1,
			this.render(),
			this.bind(),
			this.layout(),
			this.paint(),
			this.controlsButtons.css("width", this.controlsButtons.outerWidth() + 10)
		},
		render : function () {
			this.domElement = $('<div class="sl-tutorial">'),
			this.domElement.appendTo(document.body),
			this.canvas = $('<canvas class="sl-tutorial-canvas">'),
			this.canvas.appendTo(this.domElement),
			this.canvas = this.canvas.get(0),
			this.context = this.canvas.getContext("2d"),
			this.controls = $('<div class="sl-tutorial-controls">'),
			this.controls.appendTo(this.domElement),
			this.controlsInner = $('<div class="sl-tutorial-controls-inner">'),
			this.controlsInner.appendTo(this.controls),
			this.renderPagination(),
			this.controlsButtons = $('<div class="sl-tutorial-buttons">'),
			this.controlsButtons.appendTo(this.controlsInner),
			this.nextButton = $('<button class="button no-transition white l sl-tutorial-next">Next</button>'),
			this.nextButton.appendTo(this.controlsButtons),
			this.skipButton = $('<button class="button no-transition outline white l sl-tutorial-skip">Skip tutorial</button>'),
			this.skipButton.appendTo(this.controlsButtons),
			this.messageElement = $('<div class="sl-tutorial-message no-transition">').hide(),
			this.messageElement.appendTo(this.domElement)
		},
		renderPagination : function () {
			this.pagination = $('<div class="sl-tutorial-pagination">'),
			this.pagination.appendTo(this.controlsInner),
			this.options.steps.forEach(function (t, e) {
				$('<li class="sl-tutorial-pagination-number">').appendTo(this.pagination).on("click", this.step.bind(this, e))
			}
				.bind(this))
		},
		updatePagination : function () {
			this.pagination.find(".sl-tutorial-pagination-number").each(function (t, e) {
				e = $(e),
				e.toggleClass("past", t < this.index),
				e.toggleClass("present", t === this.index),
				e.toggleClass("future", t > this.index)
			}
				.bind(this))
		},
		bind : function () {
			this.onKeyDown = this.onKeyDown.bind(this),
			this.onSkipClicked = this.onSkipClicked.bind(this),
			this.onNextClicked = this.onNextClicked.bind(this),
			this.onWindowResize = this.onWindowResize.bind(this),
			SL.keyboard.keydown(this.onKeyDown),
			this.skipButton.on("click", this.onSkipClicked),
			this.nextButton.on("click", this.onNextClicked),
			$(window).on("resize", this.onWindowResize)
		},
		unbind : function () {
			SL.keyboard.release(this.onKeyDown),
			this.skipButton.off("click", this.onSkipClicked),
			this.nextButton.off("click", this.onNextClicked),
			$(window).off("resize", this.onWindowResize)
		},
		prev : function () {
			this.step(Math.max(this.index - 1, 0))
		},
		next : function () {
			this.index + 1 >= this.options.steps.length ? (this.finished.dispatch(), this.destroy()) : this.step(Math.min(this.index + 1, this.options.steps.length - 1))
		},
		step : function (t) {
			if (this.index < t) {
				for (; this.index < t; )
					this.index += 1,
					this.options.steps[this.index].forwards.call(this.options.context);
				this.index + 1 === this.options.steps.length && (this.skipButton.hide(), this.nextButton.text("Get started"), this.domElement.addClass("last-step"))
			} else if (this.index > t) {
				for (this.index + 1 === this.options.steps.length && (this.skipButton.show(), this.nextButton.text("Next"), this.domElement.removeClass("last-step")); this.index > t; )
					this.options.steps[this.index].backwards.call(this.options.context),
					this.index -= 1;
				this.options.steps[this.index].forwards.call(this.options.context)
			}
			this.updatePagination()
		},
		layout : function () {
			this.width = window.innerWidth,
			this.height = window.innerHeight;
			if (this.cutoutElement) {
				var t = this.cutoutElement.offset();
				this.cutoutRect = {
					x : t.left - this.cutoutPadding,
					y : t.top - this.cutoutPadding,
					width : this.cutoutElement.outerWidth() + 2 * this.cutoutPadding,
					height : this.cutoutElement.outerHeight() + 2 * this.cutoutPadding
				}
			}
			if (this.messageElement.is(":visible")) {
				var e = 20,
				i = this.messageElement.outerWidth(),
				n = this.messageElement.outerHeight(),
				s = {
					left : (window.innerWidth - i) / 2,
					top : (window.innerHeight - n) / 2
				};
				if (this.messageOptions.anchor && this.messageOptions.alignment) {
					var o = this.messageOptions.anchor.offset(),
					a = this.messageOptions.anchor.outerWidth(),
					r = this.messageOptions.anchor.outerHeight();
					switch (this.messageOptions.alignment) {
					case "t":
						s.left = o.left + (a - i) / 2,
						s.top = o.top - n - e;
						break;
					case "r":
						s.left = o.left + a + e,
						s.top = o.top + (r - n) / 2;
						break;
					case "b":
						s.left = o.left + (a - i) / 2,
						s.top = o.top + r + e;
						break;
					case "l":
						s.left = o.left - i - e,
						s.top = o.top + (r - n) / 2;
						break;
					case "tl":
						s.left = o.left - i - e,
						s.top = o.top - 20
					}
				}
				s.left = Math.max(s.left, 10),
				s.top = Math.max(s.top, 10);
				var l = "translate(" + Math.round(s.left) + "px," + Math.round(s.top) + "px)";
				this.messageElement.css({
					"-webkit-transform" : l,
					"-moz-transform" : l,
					"-ms-transform" : l,
					transform : l
				}),
				setTimeout(function () {
					this.messageElement.removeClass("no-transition")
				}
					.bind(this), 1)
			}
		},
		paint : function () {
			this.canvas.width = this.width,
			this.canvas.height = this.height,
			this.context.clearRect(0, 0, this.width, this.height),
			this.context.fillStyle = "rgba( 0, 0, 0, 0.7 )",
			this.context.fillRect(0, 0, this.width, this.height),
			this.cutoutElement && (this.context.clearRect(this.cutoutRect.x, this.cutoutRect.y, this.cutoutRect.width, this.cutoutRect.height), this.context.strokeStyle = "#ddd", this.context.lineWidth = 1, this.context.strokeRect(this.cutoutRect.x + .5, this.cutoutRect.y + .5, this.cutoutRect.width - 1, this.cutoutRect.height - 1))
		},
		cutout : function (t, e) {
			e = e || {},
			this.cutoutElement = t,
			this.cutoutPadding = e.padding || 0,
			this.layout(),
			this.paint()
		},
		clearCutout : function () {
			this.cutoutElement = null,
			this.cutoutPadding = 0,
			this.paint()
		},
		message : function (t, e) {
			this.messageOptions = $.extend({
					maxWidth : 320,
					alignment : ""
				},
					e),
			this.messageElement.html(t).show(),
			this.messageElement.css("max-width", this.messageOptions.maxWidth),
			this.messageElement.attr("data-alignment", this.messageOptions.alignment),
			this.layout(),
			this.paint()
		},
		clearMessage : function () {
			this.messageElement.hide(),
			this.messageOptions = {}
		},
		hasNextStep : function () {
			return this.index + 1 < this.options.steps.length
		},
		destroy : function () {
			this.destroyed || (this.destroyed = !0, $(window).off("resize", this.onWindowResize), this.skipped.dispose(), this.finished.dispose(), this.unbind(), this.domElement.fadeOut(400, this.domElement.remove))
		},
		onKeyDown : function (t) {
			return 27 === t.keyCode ? (this.skipped.dispatch(), this.destroy(), !1) : 37 === t.keyCode || 8 === t.keyCode ? (this.prev(), !1) : 39 === t.keyCode || 32 === t.keyCode ? (this.next(), !1) : !0
		},
		onSkipClicked : function () {
			this.skipped.dispatch(),
			this.destroy()
		},
		onNextClicked : function () {
			this.next()
		},
		onWindowResize : function () {
			this.layout(),
			this.paint()
		}
	});