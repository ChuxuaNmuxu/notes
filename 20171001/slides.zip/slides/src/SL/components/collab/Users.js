import SL from '../../SL';

SL("components.collab").Users = Class.extend({
    init : function (t, e) {
        this.controller = t,
        this.options = e,
        this.inviteSent = new signals.Signal,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-users disable-when-disconnected">'),
        this.userList = $('<div class="sl-collab-users-list">').appendTo(this.domElement),
        this.slideGroup = $('<div class="sl-collab-users-group">').appendTo(this.userList),
        this.slideGroup.append('<div class="icon i-eye"></div>'),
        this.slideGroup.find(".icon").attr({
            "data-tooltip" : "People who are viewing the current slide",
            "data-tooltip-alignment" : "l"
        }),
        this.inviteButton = $('<div class="sl-collab-users-invite" data-tooltip="Add a collaborator" data-tooltip-alignment="l"></div>'),
        this.inviteButton.html('<span class="icon i-plus"></span>'),
        this.inviteButton.on("vclick", this.onInviteClicked.bind(this)),
        this.inviteButton.appendTo(this.domElement),
        this.renderUsers()
    },
    renderUsers : function () {
        this.domElement.toggleClass("admin", this.controller.getCurrentDeckUser().isAdmin()),
        this.layoutPrevented = !0,
        this.userList.find(".sl-collab-user").remove(),
        this.options.users.forEach(this.renderUser.bind(this)),
        this.layoutPrevented = !1,
        this.layout()
    },
    renderUser : function (t) {
        if (t.get("user_id") !== SL.current_user.get("id") && t.get("active") !== !1) {
            t._watchingActive || (t._watchingActive = !0, t.watch("active",
                    function () {
                    t.isActive() ? this.onUsersChanged([t]) : this.onUsersChanged(null, [t])
                }
                    .bind(this)));
            var e = this.getUserByID(t.get("user_id"));
            return 0 === e.length && (e = $("<div/>", {
                        "class" : "sl-collab-user",
                        "data-user-id" : t.get("user_id")
                    }), e.html('<div class="picture" style="background-image: url(\'' + t.get("thumbnail_url") + "')\" />"), e.data("model", t), e.on("mouseenter", this.onUserMouseEnter.bind(this)), e.appendTo(this.userList)),
            this.refreshPresence(t),
            e
        }
    },
    renderRoleSelector : function () {
        var t = $(['<select class="sl-select role-selector">', '<option value="' + SL.models.collab.DeckUser.ROLE_EDITOR + '">Editor \u2013 Can comment and edit</option>', '<option value="' + SL.models.collab.DeckUser.ROLE_VIEWER + '">Viewer \u2013 Can comment</option>', "</select>"].join(""));
        return SL.current_deck.get("user.enterprise") && t.prepend('<option value="' + SL.models.collab.DeckUser.ROLE_ADMIN + '">Admin \u2013 Can comment, edit and manage users</option>'),
        t
    },
    renderInviteForm : function () {
        this.inviteForm || (this.inviteForm = $('<div class="sl-collab-invite-form sl-form">'), this.inviteEmail = $('<input class="invite-email" type="text" placeholder="Email address..." />'), this.inviteEmail.on("input", this.onEmailInput.bind(this)), this.inviteEmail.appendTo(this.inviteForm), this.inviteRole = this.renderRoleSelector(), this.inviteRole.appendTo(this.inviteForm), this.inviteOptions = $('<div class="invite-options">'), this.inviteOptions.appendTo(this.inviteForm), this.inviteFooter = $(['<footer class="footer">', '<button class="button l outline cancel-button">Cancel</button>', '<button class="button l confirm-button">Send</button>', "</footer>"].join("")), this.inviteFooter.find(".cancel-button").on("vclick", this.onInviteCancelClicked.bind(this)), this.inviteFooter.find(".confirm-button").on("vclick", this.onInviteConfirmClicked.bind(this)), this.inviteFooter.appendTo(this.inviteForm), SL.current_user.isEnterprise() && (this.inviteEmailAutocomplete = new SL.components.form.Autocomplete(this.inviteEmail, this.searchTeamMembers.bind(this), {
                        className : "light-grey",
                        offsetY : 1
                    }), this.inviteEmailAutocomplete.confirmed.add(this.onEmailInput.bind(this)))),
        this.inviteEmail.val(""),
        this.inviteOptions.empty(),
        this.inviteRole.find("[hidden]").prop("hidden", !1),
        this.inviteRole.find('[value="' + SL.models.collab.DeckUser.ROLE_EDITOR + '"]').prop("selected", !0),
        this.inviteRole.prop("disabled", !1);
        var t = SL.current_deck.user;
        if (SL.current_deck.isVisibilityAll() || !t.isPaid() || t.isEnterprise()) {
            if (t.isEnterprise() && SL.current_user.isEnterpriseManager()) {
                this.inviteOptions.append("<p>Want this person to be able to access internal presentations and create decks of their own?</p>");
                var e = $(['<div class="unit sl-checkbox outline">', '<input id="team-invite-checkbox" class="team-invite-checkbox" type="checkbox" />', '<label for="team-invite-checkbox">Add to team</label>', "</div>"].join("")).appendTo(this.inviteOptions);
                this.inviteToTeamLabel = e.find("label"),
                this.inviteToTeamInput = e.find("input"),
                SL.current_team.isManuallyUpgraded() || this.inviteToTeamLabel.html("Add to team for " + SL.current_team.getCostPerUser())
            }
        } else {
            var i = this.options.users.getEditors().length - 1,
            n = SL.current_deck.get("deck_user_editor_limit") || 50,
            s = n - i;
            i >= n ? (this.inviteRole.find('[value="' + SL.models.collab.DeckUser.ROLE_EDITOR + '"]').prop("hidden", !0), this.inviteRole.find('[value="' + SL.models.collab.DeckUser.ROLE_VIEWER + '"]').prop("selected", !0), this.inviteRole.prop("disabled", !0), this.inviteOptions.html("You can't invite any more editors to this deck on your current plan, but you can add any number of viewers. Please <a href=\"" + SL.routes.PRICING + '" target="_blank">upgrade</a> to add more editors.')) : this.inviteOptions.html('You can invite <span class="semibold">' + s + "</span> more " + SL.util.string.pluralize("editor", "s", s > 1) + ".")
        }
        return this.inviteForm
    },
    renderEditForm : function (t) {
        this.editForm || (this.editForm = $('<div class="sl-collab-edit-form sl-form">'), this.editRole = this.renderRoleSelector(), this.editRole.appendTo(this.editForm), this.editFooter = $(['<footer class="footer">', '<button class="button l negative delete-button" style="float: left;">Remove</button>', '<button class="button l outline cancel-button">Cancel</button>', '<button class="button l confirm-button">Save</button>', "</footer>"].join("")), this.editFooter.find(".delete-button").on("vclick", this.onEditDeleteClicked.bind(this)), this.editFooter.find(".cancel-button").on("vclick", this.onEditCancelClicked.bind(this)), this.editFooter.find(".confirm-button").on("vclick", this.onEditConfirmClicked.bind(this)), this.editFooter.appendTo(this.editForm)),
        this.editRole.find('[value="' + t.get("role") + '"]').prop("selected", !0),
        this.editRole.prop("disabled", !1);
        var e = SL.current_deck.user;
        if (!SL.current_deck.isVisibilityAll() && e.isPaid() && !e.isEnterprise()) {
            var i = this.options.users.getEditors().length - 1,
            n = SL.current_deck.get("deck_user_editor_limit") || 50;
            i >= n && t.get("role") === SL.models.collab.DeckUser.ROLE_VIEWER && this.editRole.prop("disabled", !0)
        }
        return this.editForm
    },
    bind : function () {
        this.options.users.changed.add(this.onUsersChanged.bind(this)),
        this.domElement.delegate(".sl-collab-user", "vclick", this.onUserClicked.bind(this)),
        this.layout = this.layout.bind(this),
        this.controller.expanded.add(this.layout),
        this.controller.collapsed.add(this.layout),
        $(window).on("resize", $.throttle(this.layout, 300))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    refreshPresence : function (t) {
        var e = this.getUserByID(t.get("user_id"));
        e && e.length && (e.removeClass("intro-animation"), e.toggleClass("online", t.isOnline()), e.toggleClass("idle", t.isIdle()), this.layout())
    },
    layout : function () {
        if (this.layoutPrevented)
            return !1;
        var t = 62;
        this.domElement.css("max-height", window.innerHeight - t);
        var e = this.userList.find(".sl-collab-user.online").get(),
        i = this.userList.find(".sl-collab-user:not(.online)").get(),
        n = 30,
        s = 26,
        o = 16,
        a = 10;
        if (this.slideGroup.removeClass("visible"), e.length) {
            var r = SL.util.deck.getSlideID(Reveal.getCurrentSlide()),
            l = 0,
            d = 4;
            e = e.filter(function (t) {
                    return $(t).data("model").get("slide_id") === r ? (t.style.transform = "translateY(" + a + "px)", a += s, l += 1, !1) : !0
                }),
            l > 0 && (this.slideGroup.css({
                    top : d,
                    height : a + 2 * d
                }).addClass("visible"), a += o + 6),
            e.length && (e.forEach(function (t) {
                    t.style.transform = "translateY(" + a + "px)",
                    a += s
                }), a += o)
        }
        i.length && (this.controller.isExpanded() ? (i.forEach(function (t) {
                    t.style.transform = "translateY(" + a + "px)",
                    a += s
                }), a += o) : i.forEach(function (t) {
                t.style.transform = "translateY(" + a + "px)"
            })),
        this.inviteButton && (this.inviteButton.get(0).style.transform = "translateY(" + a + "px)", a += n + o),
        this.userList.css("height", a)
    },
    addUserFromStream : function (t) {
        t.user_id || console.warn("Can not insert collaborator without ID");
        var e = this.options.users.getByProperties({
                user_id : t.user_id
            });
        e ? (e.setAll(t), e.set("active", !0)) : this.options.users.createModel(t)
    },
    removeUserFromStream : function (t) {
        var e = this.options.users.getByProperties({
                user_id : t
            });
        e && e.set("active", !1)
    },
    getUserByID : function (t) {
        return this.domElement.find('.sl-collab-user[data-user-id="' + t + '"]')
    },
    showInvitePrompt : function (t) {
        this.invitePrompt || (this.invitePrompt = SL.prompt({
                    anchor : t || this.inviteButton,
                    alignment : "l",
                    type : "custom",
                    title : "Add a collaborator",
                    html : this.renderInviteForm(),
                    destroyAfterConfirm : !1,
                    confirmOnEnter : !0
                }), this.invitePrompt.confirmed.add(function () {
                this.inviteEmail.blur(),
                this.confirmInvitePrompt().then(function () {
                    this.inviteSent.dispatch(),
                    this.invitePrompt && this.invitePrompt.destroy()
                }
                    .bind(this),
                    function () {})
            }
                .bind(this)), this.invitePrompt.destroyed.add(function () {
                this.inviteForm.detach(),
                this.invitePrompt = null
            }
                .bind(this)), this.inviteEmail.focus())
    },
    confirmInvitePrompt : function () {
        var t = this.inviteEmail.val().trim(),
        e = this.inviteRole.val(),
        i = !(!this.inviteToTeamInput || !this.inviteToTeamInput.val());
        return new Promise(function (n, s) {
            if (/^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$/gi.test(t)) {
                this.invitePrompt.showOverlay("neutral", "Inviting " + t, '<div class="spinner" data-spinner-color="#333"></div>'),
                SL.util.html.generateSpinners();
                var o = {
                    user : {
                        email : t,
                        role : e
                    }
                };
                i && (o.user.add_to_team = !0);
                var a = {
                    url : SL.config.AJAX_DECKUSER_CREATE(SLConfig.deck.id),
                    createModel : !1
                },
                r = this.options.users.getByProperties({
                        email : t
                    });
                r && (a.model = r),
                this.options.users.create(o, a).then(function () {
                    this.invitePrompt.showOverlay("positive", "Invite sent!", '<span class="icon i-checkmark"></span>', 2e3).then(n)
                }
                    .bind(this),
                    function () {
                    this.invitePrompt.showOverlay("negative", "Failed to send invite. Please try again.", '<span class="icon i-x"></span>', 2e3).then(s),
                    this.inviteEmail.focus().select()
                }
                    .bind(this))
            } else
                SL.notify("Please enter a valid email", "negative"),
                this.inviteEmail.focus().select(),
                s()
        }
            .bind(this))
    },
    showEditPrompt : function (t) {
        if (!this.editPrompt) {
            var e = t.data("model");
            if (e.get("role") === SL.models.collab.DeckUser.ROLE_OWNER)
                return;
            this.editUserElement = t,
            this.editUserModel = e,
            this.editPrompt = SL.prompt({
                    anchor : t,
                    alignment : "l",
                    type : "custom",
                    title : e.get("email"),
                    html : this.renderEditForm(e),
                    destroyAfterConfirm : !1,
                    confirmOnEnter : !0
                }),
            this.editPrompt.confirmed.add(function () {
                this.confirmEditPrompt().then(function () {
                    this.editPrompt && this.editPrompt.destroy()
                }
                    .bind(this))
            }
                .bind(this)),
            this.editPrompt.destroyed.add(function () {
                this.editForm.detach(),
                this.editPrompt = null
            }
                .bind(this))
        }
    },
    confirmEditPrompt : function () {
        var t = this.editUserModel;
        return new Promise(function (e, i) {
            var n = this.editRole.val();
            n && n !== t.get("role") ? (this.editPrompt.showOverlay("neutral", "Saving", '<div class="spinner" data-spinner-color="#333"></div>'), SL.util.html.generateSpinners(), t.set("role", n), t.save(["role"]).then(function () {
                    e()
                }
                    .bind(this),
                    function () {
                    this.editPrompt.showOverlay("negative", "Failed to save changes. Please try again.", '<span class="icon i-x"></span>', 2e3).then(i)
                }
                    .bind(this))) : e()
        }
            .bind(this))
    },
    searchTeamMembers : function (t) {
        return this.searchTeamMembersXHR && this.searchTeamMembersXHR.abort(),
        this.searchTeamMemberEmailCache || (this.searchTeamMemberEmailCache = {}),
        new Promise(function (e, i) {
            this.searchTeamMembersXHR = $.ajax({
                    type : "POST",
                    url : SL.config.AJAX_TEAM_MEMBER_SEARCH,
                    context : this,
                    data : {
                        q : t
                    }
                }).done(function (t) {
                    var i = t.results;
                    i = i.filter(function (t) {
                            return t.id !== SL.current_user.get("id")
                        }),
                    i.forEach(function (t) {
                        this.searchTeamMemberEmailCache[t.email] = !0
                    }
                        .bind(this)),
                    i = i.slice(0, 5).map(function (t) {
                            return {
                                value : t.email,
                                label : '<div class="label">' + t.name + '</div><div class="value">' + t.email + "</div>"
                            }
                        }),
                    e(i)
                }).fail(i)
        }
            .bind(this))
    },
    dismissPrompts : function () {
        this.editPrompt && this.editPrompt.destroy(),
        this.invitePrompt && this.invitePrompt.destroy()
    },
    onUsersChanged : function (t, e) {
        t && t.forEach(function (t) {
            var e = this.renderUser(t);
            e && (setTimeout(function () {
                    e.addClass("intro-animation")
                },
                    1), this.layout())
        }
            .bind(this)),
        e && e.forEach(function (t) {
            var e = $('.sl-collab-user[data-user-id="' + t.get("user_id") + '"]');
            SL.util.anim.collapseListItem(e,
                function () {
                e.remove(),
                this.layout()
            }
                .bind(this), 300)
        },
            this)
    },
    onInviteClicked : function (t) {
        t.preventDefault(),
        this.showInvitePrompt()
    },
    onInviteCancelClicked : function () {
        this.invitePrompt && this.invitePrompt.cancel()
    },
    onInviteConfirmClicked : function () {
        this.invitePrompt && this.invitePrompt.confirm()
    },
    onEditCancelClicked : function () {
        this.editPrompt && this.editPrompt.cancel()
    },
    onEditConfirmClicked : function () {
        this.editPrompt && this.editPrompt.confirm()
    },
    onEditDeleteClicked : function () {
        this.editPrompt && this.editPrompt.destroy();
        var t = this.editUserModel;
        SL.prompt({
            anchor : this.editUserElement,
            title : SL.locale.get("COLLABORATOR_REMOVE_CONFIRM"),
            alignment : "l",
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Remove</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        t.destroy().then(function () {
                            t.set("active", !1)
                        })
                    }
                    .bind(this)
                }
            ]
        })
    },
    onEmailInput : function () {
        this.inviteOptions && this.searchTeamMemberEmailCache && (this.searchTeamMemberEmailCache[this.inviteEmail.val().trim()] ? this.inviteOptions.addClass("disabled") : this.inviteOptions.removeClass("disabled"))
    },
    onUserClicked : function (t) {
        this.controller.getCurrentDeckUser().isAdmin() && this.showEditPrompt($(t.currentTarget)),
        t.preventDefault()
    },
    onUserMouseEnter : function (t) {
        var e = $(t.currentTarget),
        i = e.data("model");
        if (i) {
            var n = [i.getDisplayName() + '<span class="sl-collab-tooltip-status" data-status="' + i.get("status") + '"></span>', '<span style="opacity: 0.70;">' + i.get("email") + "</span>"].join("<br>");
            SL.tooltip.show(n, {
                alignment : "l",
                anchor : e
            }),
            e.one("mouseleave", SL.tooltip.hide.bind(SL.tooltip))
        }
    },
    destroy : function () {
        this.inviteEmailAutocomplete && this.inviteEmailAutocomplete.destroy(),
        this.options = null,
        this.domElement.remove()
    }
});