import SL from '../../SL';

import './Collaboration';
import './CommentThread';
import './Comments';

SL.components.collab.Comments.DECK_THREAD = "deck",
SL.components.collab.Comments.SLIDE_THREAD = "slide";

import './Handover';
import './Menu';
import './Notifications';
import './Users';
