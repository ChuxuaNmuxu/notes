import SL from '../../SL';

SL("components.collab").Menu = Class.extend({
    init : function (t, e) {
        this.controller = t,
        this.options = e,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-menu">'),
        this.innerElement = $('<div class="sl-collab-menu-inner">'),
        this.innerElement.appendTo(this.domElement),
        this.renderProfile()
    },
    renderProfile : function () {
        this.enableButton = $('<div class="sl-collab-menu-item sl-collab-menu-enable ladda-button" data-style="zoom-in" data-spinner-color="#444" data-tooltip="Add a collaborator" data-tooltip-alignment="l">'),
        this.enableButton.append('<span class="users-icon icon i-users"></span>'),
        this.enableButton.appendTo(this.innerElement),
        this.toggleButton = $('<div class="sl-collab-menu-item sl-collab-menu-toggle">'),
        this.toggleButton.append('<div class="users-icon icon i-users"></div>'),
        this.toggleButton.append('<div class="close-icon icon i-x"></div>'),
        this.toggleButton.appendTo(this.innerElement),
        this.unreadComments = $('<div class="unread-comments" data-tooltip="Unread comments" data-tooltip-alignment="l">'),
        this.unreadComments.appendTo(this.toggleButton)
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    bind : function () {
        this.onEnableClicked = this.onEnableClicked.bind(this),
        this.onToggleClicked = this.onToggleClicked.bind(this),
        this.enableButton.on("vclick", this.onEnableClicked),
        this.toggleButton.on("vclick", this.onToggleClicked),
        this.controller.enabled.add(this.onCollaborationEnabled.bind(this)),
        this.controller.expanded.add(this.onCollaborationExpanded.bind(this))
    },
    setUnreadComments : function (t) {
        0 === t ? this.clearUnreadComments() : this.unreadComments.text(t).addClass("visible")
    },
    clearUnreadComments : function () {
        this.unreadComments.removeClass("visible")
    },
    destroy : function () {
        this.domElement.remove()
    },
    getPrimaryButton : function () {
        return this.toggleButton
    },
    onEnableClicked : function (t) {
        this.enableButton.off("vclick", this.onEnableClicked),
        this.enableLoader = Ladda.create(this.enableButton.get(0)),
        this.enableLoader.start(),
        SL.view.isNewDeck() ? SL.view.save(function () {
            this.controller.makeDeckCollaborative()
        }
            .bind(this)) : this.controller.makeDeckCollaborative(),
        t.preventDefault()
    },
    onToggleClicked : function (t) {
        this.controller.toggle(),
        t.preventDefault()
    },
    onCollaborationEnabled : function () {
        this.enableLoader && (this.enableLoader.stop(), this.enableLoader = null)
    },
    onCollaborationExpanded : function () {
        this.clearUnreadComments()
    }
});