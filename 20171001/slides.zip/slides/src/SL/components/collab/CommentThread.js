import SL from '../../SL';

SL("components.collab").CommentThread = Class.extend({
    init : function (t, e) {
        this.id = t,
        this.options = e,
        this.comments = new SL.collections.collab.Comments,
        this.strings = {
            loadMoreComments : "Load older comments",
            loadingMoreComments : "Loading..."
        },
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-comment-thread empty"></div>'),
        this.domElement.attr("data-thread-id", this.id),
        this.domElement.data("thread", this),
        this.loadMoreButton = $('<button class="load-more-button">' + this.strings.loadMoreComments + "</button>"),
        this.loadMoreButton.on("vclick", this.onLoadMoreClicked.bind(this)),
        this.loadMoreButton.appendTo(this.domElement)
    },
    renderComment : function (t, e) {
        if (e = e || {},
            !t.rendered) {
            t.rendered = !0;
            var i = this.options.users.getByUserID(t.get("user_id"));
            "undefined" == typeof i && (i = new SL.models.collab.DeckUser({
                        username : "unknown"
                    }));
            var n = moment(t.get("created_at")),
            s = n.format("h:mm A"),
            o = n.format("MMM Do") + " at " + n.format("h:mm:ss A"),
            a = i ? i.get("first_name") : "N/A";
            a = (a || "").toLowerCase();
            var r = $(['<div class="sl-collab-comment">', '<div class="comment-sidebar">', '<div class="avatar" style="background-image: url(\'' + i.get("thumbnail_url") + "')\" />", "</div>", '<div class="comment-body">', '<span class="author">' + a + "</span>", '<div class="meta">', '<span class="meta-time" data-tooltip="' + o + '">' + s + "</span>", "</div>", '<p class="message"></p>', "</div>", "</div>"].join(""));
            r.data("model", t),
            this.refreshComment(r),
            this.refreshSlideNumber(r),
            SL.util.device.IS_PHONE || SL.util.device.IS_TABLET || this.renderCommentOptions(r, t),
            t.stateChanged.add(this.onCommentStateChanged.bind(this, r)),
            e.prepend ? this.domElement.prepend(r) : this.domElement.append(r),
            this.checkOverflow()
        }
    },
    renderCommentOptions : function (t, e) {
        var i = this.getCommentPrivileges(e);
        if (i.canDelete || i.canEdit) {
            var n = $('<button class="button options-button icon disable-when-disconnected"></button>').appendTo(t.find(".comment-sidebar"));
            i.canDelete && i.canEdit ? (n.addClass("i-cog"), n.on("click", this.onCommentOptionsClicked.bind(this, t))) : i.canDelete ? (n.addClass("i-trash-stroke"), n.on("click", this.onDeleteComment.bind(this, t))) : i.canEdit && (n.addClass("i-i-pen-alt2"), n.on("click", this.onEditComment.bind(this, t)))
        }
    },
    refreshComment : function (t) {
        if (t) {
            var e = t.data("model");
            e && (t.find(".message").text(e.get("message")), t.attr("data-id", e.get("id")), t.attr("data-state", e.getState()))
        }
    },
    refreshCommentByID : function (t) {
        this.refreshComment(this.getCommentByID(t))
    },
    refreshSlideNumbers : function () {
        this.options.slideNumbers && this.domElement.find(".sl-collab-comment").each(function (t, e) {
            this.refreshSlideNumber($(e))
        }
            .bind(this))
    },
    refreshSlideNumber : function (t) {
        if (this.options.slideNumbers) {
            var e = SL.util.deck.getSlideNumber(t.data("model").get("slide_hash"));
            if (e) {
                var i = "slide " + e,
                n = t.find(".meta-slide-number");
                n.length ? n.text(i) : t.find(".meta").prepend('<button class="meta-slide-number" data-tooltip="Click to view slide">' + i + "</button>")
            } else
                t.find(".meta-slide-number").remove()
        }
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    bind : function () {
        this.comments.loadStarted.add(this.onLoadStarted.bind(this)),
        this.comments.loadCompleted.add(this.onLoadCompleted.bind(this)),
        this.comments.loadFailed.add(this.onLoadFailed.bind(this)),
        this.comments.changed.add(this.onCommentsChanged.bind(this)),
        this.viewSlideCommentsClicked = new signals.Signal,
        this.layout = this.layout.bind(this),
        this.onWindowResize = this.onWindowResize.bind(this),
        this.domElement.delegate(".meta-slide-number", "vclick", this.onSlideNumberClicked.bind(this)),
        SL.util.dom.preventTouchOverflowScrolling(this.domElement)
    },
    show : function (t) {
        t = t || {},
        this.getID() === SL.components.collab.Comments.DECK_THREAD ? this.comments.isLoaded() || this.comments.isLoading() ? (this.refresh(), this.scrollToLatestComment()) : this.load() : this.load(t.slide_hash || Reveal.getCurrentSlide().getAttribute("data-id")),
        $(window).on("resize", this.onWindowResize)
    },
    hide : function () {
        $(window).off("resize", this.onWindowResize)
    },
    load : function (t) {
        var e = SL.config.AJAX_COMMENTS_LIST(SL.current_deck.get("id"), t);
        this.slideHash = t,
        this.domElement.find(".sl-collab-comment").remove(),
        this.comments.unload(),
        this.domElement.addClass("empty"),
        this.comments.load(e).then(SL.util.noop, SL.util.noop)
    },
    reload : function () {
        this.getID() === SL.components.collab.Comments.DECK_THREAD ? this.load() : this.load(this.slideHash || Reveal.getCurrentSlide().getAttribute("data-id"))
    },
    refresh : function () {
        this.checkIfEmpty(),
        this.checkOverflow(),
        this.checkPagination()
    },
    layout : function () {
        this.checkOverflow()
    },
    checkIfEmpty : function () {
        if (this.comments.isLoaded())
            if (this.comments.isEmpty()) {
                var t = this.getID() === SL.components.collab.Comments.SLIDE_THREAD ? "No comments on this slide" : "Nothing here yet.<br>Be the first to comment.";
                this.getPlaceholder().html('<div class="icon i-comment-stroke"></div><p>' + t + "</p>")
            } else
                this.hidePlaceholder(),
                this.domElement.removeClass("empty")
    },
    checkPagination : function () {
        this.loadMoreButton.toggleClass("visible", !this.comments.isLoading() && this.comments.isLoaded() && this.comments.hasNextPage())
    },
    checkOverflow : function () {
        this.domElement.toggleClass("overflowing", this.domElement.prop("scrollHeight") > this.domElement.prop("offsetHeight"))
    },
    hidePlaceholder : function () {
        this.placeholder && (this.placeholder.remove(), this.placeholder = null)
    },
    getCommentPrivileges : function (t) {
        var e = {
            canEdit : !1,
            canDelete : !1
        },
        i = this.options.users.getByUserID(SL.current_user.get("id")),
        n = this.options.users.getByUserID(t.get("user_id"));
        if (n && i) {
            var s = i.get("user_id") === n.get("user_id"),
            o = i.get("role") === SL.models.collab.DeckUser.ROLE_ADMIN || i.get("role") === SL.models.collab.DeckUser.ROLE_OWNER;
            s ? (e.canEdit = !0, e.canDelete = !0) : o && (e.canDelete = !0)
        }
        return e
    },
    scrollToLatestComment : function () {
        this.domElement.scrollTop(this.domElement.prop("scrollHeight"))
    },
    scrollToLatestCommentUnlessScrolled : function () {
        return this.getScrollOffset() < 600 ? (this.scrollToLatestComment(), !0) : !1
    },
    commentExists : function (t) {
        return this.getComments().getByID(t.id) ? !0 : SL.current_user.get("id") === t.user_id ? this.getTemporaryComments().some(function (e) {
            return e.get("user_id") === t.user_id && e.get("message") === t.message
        }) : !1
    },
    getScrollOffset : function () {
        var t = this.domElement.get(0);
        return t.scrollHeight - t.offsetHeight - t.scrollTop
    },
    getPlaceholder : function () {
        return this.placeholder || (this.placeholder = $('<div class="placeholder">'), this.placeholder.appendTo(this.domElement)),
        this.placeholder
    },
    getComments : function () {
        return this.comments
    },
    getTemporaryComments : function () {
        return this.comments.filter(function (t) {
            return !t.has("id")
        })
    },
    getCommentByID : function (t) {
        return this.domElement.find('.sl-collab-comment[data-id="' + t + '"]')
    },
    getSlideHash : function () {
        return this.slideHash
    },
    getID : function () {
        return this.id
    },
    onLoadStarted : function () {
        this.getPlaceholder().html('<div class="spinner centered" data-spinner-color="#999"></div>'),
        SL.util.html.generateSpinners()
    },
    onLoadCompleted : function () {
        this.comments.forEach(this.renderComment.bind(this)),
        this.refresh(),
        this.scrollToLatestComment()
    },
    onLoadFailed : function () {
        this.getPlaceholder().html('<p class="error">Failed to load comments.</p>')
    },
    onWindowResize : function () {
        this.scrollToLatestComment(),
        this.layout()
    },
    onCommentsChanged : function (t, e) {
        t && t.length && t.forEach(this.renderComment.bind(this)),
        e && e.length && e.forEach(function (t) {
            this.getCommentByID(t.get("id")).remove()
        }
            .bind(this)),
        this.refresh()
    },
    onCommentStateChanged : function (t, e) {
        var i = e.getState();
        t.attr("data-id", e.get("id")),
        t.attr("data-state", i),
        i === SL.models.collab.Comment.STATE_FAILED ? 0 === t.find(".retry").length && (t.append(['<div class="retry">', '<span class="retry-info">Failed to send</span>', '<button class="button outline retry-button">Retry</button>', "</div>"].join("")), t.find(".retry-button").on("click",
                function () {
                this.comments.retryCreate(e)
            }
                .bind(this)), this.scrollToLatestCommentUnlessScrolled()) : t.find(".retry").remove()
    },
    onCommentOptionsClicked : function (t) {
        var e = new SL.components.Menu({
                anchor : t.find(".options-button"),
                anchorSpacing : 15,
                alignment : "l",
                destroyOnHide : !0,
                options : [{
                        label : "Edit",
                        icon : "pen-alt2",
                        callback : this.onEditComment.bind(this, t)
                    }, {
                        label : "Delete",
                        icon : "trash-fill",
                        callback : this.onDeleteComment.bind(this, t)
                    }
                ]
            });
        e.show()
    },
    onEditComment : function (t) {
        var e = t.data("model"),
        i = SL.prompt({
                anchor : t.find(".options-button"),
                alignment : "l",
                title : "Edit comment",
                type : "input",
                confirmLabel : "Save",
                data : {
                    value : e.get("message"),
                    placeholder : "Comment...",
                    multiline : !0
                }
            });
        i.confirmed.add(function (i) {
            "string" == typeof i && i.trim().length > 0 && (e.set("message", i), e.save(["message"]).done(this.refreshComment.bind(this, t)))
        }
            .bind(this)),
        SL.analytics.trackCollaboration("Edit comment")
    },
    onDeleteComment : function (t) {
        var e = t.data("model");
        SL.prompt({
            anchor : t.find(".options-button"),
            alignment : "l",
            title : "Are you sure you want to delete this comment?",
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Delete</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        this.comments.remove(e),
                        e.destroy()
                    }
                    .bind(this)
                }
            ]
        }),
        SL.analytics.trackCollaboration("Delete comment")
    },
    onLoadMoreClicked : function () {
        this.loadMoreButton.prop("disabled", !0).text(this.strings.loadingMoreComments),
        this.comments.loadNextPage().then(function (t) {
            var e = this.domElement.scrollTop(),
            i = this.domElement.prop("scrollHeight");
            t.reverse().forEach(function (t) {
                this.renderComment(t, {
                    prepend : !0
                })
            }
                .bind(this));
            var n = this.domElement.prop("scrollHeight");
            this.domElement.scrollTop(n - i + e),
            this.checkPagination()
        }
            .bind(this)).catch (function () {
            SL.notify("Failed to load comments", "negative")
        }
            .bind(this))
            .then(function () {
                this.loadMoreButton.prop("disabled", !1).text(this.strings.loadMoreComments),
                this.loadMoreButton.prependTo(this.domElement)
            }
                .bind(this))
    },
    onSlideNumberClicked : function (t) {
        var e = $(t.target).closest(".sl-collab-comment");
        e.length && e.data("model") && this.viewSlideCommentsClicked.dispatch(e.data("model").get("slide_hash"))
    },
    destroy : function () {
        this.viewSlideCommentsClicked.dispose(),
        this.domElement.remove()
    }
});