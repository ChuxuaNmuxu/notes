import SL from '../../SL';

SL("components.collab").Comments = Class.extend({
    init : function (t, e) {
        this.controller = t,
        this.options = e,
        this.render(),
        this.bind(),
        this.getCurrentThread() || this.showThread(SL.components.collab.Comments.DECK_THREAD),
        this.refreshCommentInput(),
        this.refreshCurrentSlide(),
        this.getCurrentThread().scrollToLatestComment(),
        this.layout()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-page sl-collab-comments"></div>'),
        this.renderHeader(),
        this.bodyElement = $('<div class="sl-collab-page-body sl-collab-comments-body">'),
        this.bodyElement.appendTo(this.domElement),
        this.footerElement = $('<footer class="sl-collab-page-footer">'),
        this.footerElement.appendTo(this.domElement),
        this.renderThreads(),
        this.renderCommentForm()
    },
    renderHeader : function () {
        this.headerElement = $('<header class="sl-collab-page-header sl-collab-comments-header"></header>'),
        this.headerElement.appendTo(this.domElement),
        this.headerElement.html(['<div class="header-tab selected" data-thread-id="deck">All comments</div>', '<div class="header-tab header-tab-slide" data-thread-id="slide">Current slide</div>'].join("")),
        this.headerElement.find(".header-tab").on("vclick",
            function (t) {
            this.showThread($(t.currentTarget).attr("data-thread-id")),
            SL.util.device.IS_PHONE || SL.util.device.IS_TABLET || this.commentInput.focus()
        }
            .bind(this))
    },
    renderThreads : function () {
        this.threads = {},
        this.threads.deck = new SL.components.collab.CommentThread(SL.components.collab.Comments.DECK_THREAD, {
                users : this.options.users,
                slideNumbers : !0
            }),
        this.threads.deck.viewSlideCommentsClicked.add(this.onViewSlideCommentsClicked.bind(this)),
        this.threads.deck.appendTo(this.bodyElement),
        this.threads.slide = new SL.components.collab.CommentThread(SL.components.collab.Comments.SLIDE_THREAD, {
                users : this.options.users
            }),
        this.threads.slide.appendTo(this.bodyElement)
    },
    renderCommentForm : function () {
        this.commentForm = $('<form action="#" class="sl-collab-comment-form sl-form disable-when-disconnected" novalidate>'),
        this.commentForm.on("submit", this.onCommentSubmit.bind(this)),
        this.commentInput = $(SL.util.device.IS_PHONE || SL.util.device.IS_TABLET ? '<input type="text" autocapitalize="sentences" class="comment-input" placeholder="Add a comment..." required maxlength="' + SL.config.COLLABORATION_COMMENT_MAXLENGTH + '" />' : '<textarea class="comment-input" placeholder="Add a comment..." required maxlength="' + SL.config.COLLABORATION_COMMENT_MAXLENGTH + '"></textarea>'),
        this.commentInput.on("keydown", this.onCommentKeyDown.bind(this)),
        this.commentInput.on("input", this.onCommentChanged.bind(this)),
        this.commentInput.on("focus", this.onCommentInputFocus.bind(this)),
        this.commentInput.appendTo(this.commentForm),
        this.commentInputFooter = $('<div class="comment-footer"></div>'),
        this.commentInputFooter.appendTo(this.commentForm),
        this.commentTyping = $('<div class="comment-typing"></div>'),
        this.commentTyping.appendTo(this.commentInputFooter),
        this.commentSubmitButton = $('<input class="comment-submit" type="submit" value="Send" />'),
        this.commentSubmitButton.on("vclick", this.submitComment.bind(this)),
        this.commentSubmitButton.appendTo(this.commentInputFooter),
        this.commentInputFooter.append('<div class="clear"></div>'),
        this.commentForm.appendTo(this.footerElement)
    },
    bind : function () {
        this.layout = this.layout.bind(this),
        this.startTyping = this.startTyping.bind(this),
        this.stopTyping = this.stopTyping.bind(this),
        $(window).on("resize", this.layout),
        this.controller.expanded.add(this.onCollaborationExpanded.bind(this)),
        this.controller.isInEditor() && SL.editor.controllers.Markup.slidesChanged.add(this.refreshSlideNumbers.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    layout : function () {
        this.checkOverflow()
    },
    reload : function () {
        this.threads.deck.reload();
        var t = this.getCurrentThread();
        t && t.getID() === SL.components.collab.Comments.SLIDE_THREAD && t.reload()
    },
    focus : function () {
        this.commentInput.focus()
    },
    blur : function () {
        this.commentInput.blur()
    },
    checkOverflow : function () {
        this.domElement.toggleClass("overflowing", this.bodyElement.prop("scrollHeight") > this.bodyElement.prop("offsetHeight"))
    },
    showCommentNotification : function (t) {
        var e = this.options.users.getByUserID(t.get("user_id"));
        if (e && e.get("user_id") !== SL.current_user.get("id")) {
            var i = "<strong>" + e.getDisplayName() + "</strong>",
            n = SL.util.deck.getSlideNumber(t.get("slide_hash"));
            n && (i += '<span class="slide-number">slide ' + n + "</span>"),
            i += "<br>" + t.get("message"),
            this.controller.notifications.show(i, {
                sender : e,
                callback : function () {
                    this.showSlideComments(t.get("slide_hash")),
                    this.commentInput.focus()
                }
                .bind(this)
            })
        }
    },
    showSlideComments : function (t) {
        this.controller.isExpanded() === !1 && this.controller.expand();
        var e = $('.reveal .slides section[data-id="' + t + '"]').get(0);
        SL.util.deck.navigateToSlide(e);
        var i = this.getCurrentThread();
        i && i.getID() !== SL.components.collab.Comments.SLIDE_THREAD && (this.showThread(SL.components.collab.Comments.SLIDE_THREAD, {
                slide_hash : t
            }), SL.util.device.IS_PHONE || SL.util.device.IS_TABLET || this.commentInput.focus())
    },
    showThread : function (t, e) {
        var i = this.getCurrentThread(),
        n = this.bodyElement.find('[data-thread-id="' + t + '"]'),
        s = n.data("thread");
        s && (i && i !== s && i.hide(), this.bodyElement.find(".sl-collab-comment-thread").removeClass("visible"), n.addClass("visible"), this.headerElement.find(".header-tab").removeClass("selected"), this.headerElement.find('.header-tab[data-thread-id="' + t + '"]').addClass("selected"), s.show(e))
    },
    getCurrentThread : function () {
        return this.domElement.find(".sl-collab-comment-thread.visible").data("thread")
    },
    addCommentFromStream : function (t) {
        if (t.id || console.warn("Can not insert comment without ID"), !this.threads.deck.commentExists(t)) {
            var e = this.controller.isExpanded(),
            i = this.threads.deck.getComments().createModel(t),
            n = !1;
            return this.getCurrentThread().getID() === SL.components.collab.Comments.DECK_THREAD ? n = this.threads.deck.scrollToLatestCommentUnlessScrolled() : this.getCurrentThread().getID() === SL.components.collab.Comments.SLIDE_THREAD && t.slide_hash && t.slide_hash === this.getCurrentThread().getSlideHash() && !this.getCurrentThread().commentExists(t) && (this.threads.slide.getComments().createModel(t), n = this.threads.slide.scrollToLatestCommentUnlessScrolled()),
            e && n || this.showCommentNotification(i),
            !0
        }
        return !1
    },
    updateCommentFromStream : function (t) {
        t.id || console.warn("Can not update comment without ID");
        var e = this.threads.deck.getComments().getByID(t.id);
        if (e) {
            for (var i in t)
                e.set(i, t[i]);
            this.threads.deck.refreshCommentByID(e.get("id")),
            this.getCurrentThread().getID() === SL.components.collab.Comments.SLIDE_THREAD && this.threads.slide.refreshCommentByID(e.get("id"))
        }
    },
    removeCommentFromStream : function (t) {
        return this.threads.deck.getComments().removeByProperties({
            id : t
        })
    },
    refreshCommentInput : function () {
        this.commentInput.attr("rows", 2);
        var t = Math.ceil(parseFloat(this.commentInput.css("line-height"))),
        e = this.commentInput.prop("scrollHeight"),
        i = this.commentInput.prop("clientHeight"),
        n = 10;
        e > i && this.commentInput.attr("rows", Math.min(Math.floor(e / t), n)),
        this.getCurrentThread().scrollToLatestCommentUnlessScrolled(t * n)
    },
    refreshTyping : function () {
        var t = this.commentInput.val();
        t ? this.startTyping() : this.stopTyping()
    },
    startTyping : function () {
        var t = Date.now();
        this.typing = !0,
        (!this.lastTypingEvent || t - this.lastTypingEvent > SL.config.COLLABORATION_SEND_WRITING_INTERVAL) && (this.lastTypingEvent = t, SL.helpers.StreamEditor.singleton().broadcast({
                type : "collaboration:user-typing",
                user_id : SL.current_user.get("id")
            }))
    },
    stopTyping : function () {
        this.typing && (this.typing = !1, this.lastTypingEvent = null, SL.helpers.StreamEditor.singleton().broadcast({
                type : "collaboration:user-typing-stopped",
                user_id : SL.current_user.get("id")
            }))
    },
    refreshTypingIndicators : function () {
        var t = this.options.users.filter(function (t) {
                return t.get("typing") === !0
            });
        0 === t.length ? this.commentTyping.empty().removeAttr("data-tooltip") : 1 === t.length ? this.commentTyping.html("<strong>" + t[0].getDisplayName() + "</strong> is typing").removeAttr("data-tooltip") : t.length > 1 && (this.commentTyping.html("<strong>" + t.length + " people</strong> are typing"), this.commentTyping.attr("data-tooltip", t.map(function (t) {
                    return t.getDisplayName()
                }).join("<br>")))
    },
    refreshCurrentSlide : function () {
        var t = this.getCurrentThread();
        t && t.getID() === SL.components.collab.Comments.SLIDE_THREAD && this.showThread(SL.components.collab.Comments.SLIDE_THREAD, {
            slide_hash : Reveal.getCurrentSlide().getAttribute("data-id")
        });
        var e = SL.util.deck.getSlideNumber(Reveal.getCurrentSlide());
        e && this.headerElement.find(".header-tab-slide").text("Slide " + e)
    },
    refreshSlideNumbers : function () {
        this.threads.deck.refreshSlideNumbers()
    },
    submitComment : function () {
        var t = this.commentInput.val();
        t = t.trim(),
        t = t.replace(/(\n|\r){3,}/gim, "\n\n"),
        t.length && (this.getCurrentThread().getComments().create({
                comment : {
                    slide_hash : Reveal.getCurrentSlide().getAttribute("data-id"),
                    message : t,
                    user_id : SL.current_user.get("id"),
                    created_at : Date.now()
                }
            }), this.commentInput.val(""), this.stopTyping(), this.refreshCommentInput(), this.getCurrentThread().scrollToLatestComment())
    },
    onCommentSubmit : function (t) {
        this.submitComment(),
        t.preventDefault()
    },
    onCommentKeyDown : function (t) {
        13 !== t.keyCode || t.shiftKey || (this.submitComment(), t.preventDefault(), t.stopPropagation())
    },
    onCommentChanged : function () {
        this.refreshCommentInput(),
        this.refreshTyping()
    },
    onCommentInputFocus : function () {
        this.refreshTyping()
    },
    onViewSlideCommentsClicked : function (t) {
        this.showSlideComments(t)
    },
    onSlideChanged : function () {
        this.refreshCurrentSlide()
    },
    onCollaborationExpanded : function () {
        this.refreshCurrentSlide(),
        setTimeout(this.focus.bind(this), 100)
    },
    destroy : function () {
        this.threads.deck.destroy(),
        this.threads.slide.destroy(),
        this.options = null,
        this.domElement.remove()
    }
});