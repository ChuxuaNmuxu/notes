import SL from '../../SL';

SL("components.collab").Notifications = Class.extend({
    init : function (t, e) {
        this.controller = t,
        this.options = e,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-notifications">')
    },
    bind : function () {
        this.domElement.delegate(".sl-collab-notification.optional", "mouseenter", this.onNotificationMouseEnter.bind(this)),
        this.domElement.delegate(".sl-collab-notification.optional", "vclick", this.onNotificationClick.bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    show : function (t, e) {
        e = $.extend({
                optional : !0,
                duration : 5e3
            },
                e);
        var i;
        e.id && (i = this.getNotificationByID(e.id)),
        i && 0 !== i.length || (i = this.addNotification(t, e), e.optional && (this.holding ? i.addClass("on-hold") : this.hideAfter(i, e.duration)))
    },
    hide : function (t) {
        var e = this.getNotificationByID(t);
        return e.length ? (this.removeNotification(e), !0) : !1
    },
    hideAfter : function (t, e) {
        setTimeout(function () {
            t.addClass("hide"),
            setTimeout(this.removeNotification.bind(this, t), 500)
        }
            .bind(this), e)
    },
    hold : function () {
        this.holding = !0
    },
    release : function () {
        this.holding = !1;
        var t = this.domElement.find(".sl-collab-notification.on-hold").get().reverse();
        t.forEach(function (t, e) {
            this.hideAfter($(t), 5e3 + 1e3 * e)
        },
            this)
    },
    addNotification : function (t, e) {
        var i = $('<div class="sl-collab-notification" />').data("options", e).toggleClass("optional", e.optional).prependTo(this.domElement),
        t = $('<div class="message" />').append(t).appendTo(i);
        return i.toggleClass("multiline", t.height() > 24),
        e.sender ? $('<div class="status-picture" />').css("background-image", 'url("' + e.sender.get("thumbnail_url") + '")').prependTo(i) : $('<div class="status-icon icon" />').addClass(e.icon || "i-info").prependTo(i),
        e.id && i.attr("data-id", e.id),
        this.layout(),
        setTimeout(function () {
            i.addClass("show")
        },
            1),
        i
    },
    removeNotification : function (t) {
        t.removeData(),
        t.remove(),
        this.layout()
    },
    getNotificationByID : function (t) {
        return this.domElement.find(".sl-collab-notification[data-id=" + t + "]")
    },
    layout : function () {
        var t = 0;
        this.domElement.find(".sl-collab-notification").each(function (e, i) {
            i.style.top = t + "px",
            t += i.offsetHeight + 10
        })
    },
    destroy : function () {
        this.domElement.remove()
    },
    onNotificationMouseEnter : function (t) {
        var e = $(t.currentTarget);
        0 === e.find(".dismiss").length && $('<div class="dismiss"><span class="icon i-x"></span></div>').appendTo(e)
    },
    onNotificationClick : function (t) {
        var e = $(t.currentTarget);
        if (0 === $(t.target).closest(e.find(".dismiss")).length) {
            var i = e.data("options").callback;
            "function" == typeof i && i.call()
        }
        this.removeNotification(e)
    }
});