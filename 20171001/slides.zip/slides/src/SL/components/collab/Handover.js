import SL from '../../SL';

SL("components.collab").Handover = Class.extend({
    init : function (t, e) {
        this.controller = t,
        this.options = e,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="sl-collab-handover">'),
        this.editButtonWrapper = $('<div class="edit-button-wrapper">').appendTo(this.domElement),
        this.editButton = $('<div class="edit-button">'),
        this.editButton.append('<span class="label">Edit </span><span class="icon i-pen-alt2"></span>'),
        this.editButton.appendTo(this.editButtonWrapper),
        this.user = $('<div class="user"></div>'),
        this.userAvatar = $('<div class="user-avatar"></div>').appendTo(this.user),
        this.userDescription = $('<div class="user-description"></div>').appendTo(this.user),
        this.userStatus = $('<div class="user-status"></div>').appendTo(this.userDescription),
        this.userSlide = $('<div class="user-slide"></div>').appendTo(this.userDescription)
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    bind : function () {
        this.editButtonWrapper.on("vclick", this.onEditClicked.bind(this))
    },
    refresh : function () {
        this.controller.getCurrentDeckUser().isEditing() || !this.controller.getCurrentDeckUser().canEdit() ? (this.editButtonWrapper.removeClass("visible"), this.editButtonWrapper.removeAttr("data-tooltip"), this.user.remove()) : (this.editButtonWrapper.addClass("visible"), this.currentEditor = this.options.users.getByProperties({
                    editing : !0
                }), this.currentEditor && this.currentEditor.isOnline() ? (this.currentAvatarURL !== this.currentEditor.get("thumbnail_url") && (this.currentAvatarURL = this.currentEditor.get("thumbnail_url"), this.userAvatar.css("background-image", 'url("' + this.currentAvatarURL + '")')), 0 === this.user.parent().length && this.user.appendTo(this.editButtonWrapper), this.refreshSlideNumbers(), this.currentEditor.isIdle() ? (this.editButtonWrapper.attr("data-tooltip", "<strong>" + this.currentEditor.get("username") + "</strong> is editing but has been idle for a while.<br>Click to start editing."), this.userStatus.html('<span class="username">' + this.currentEditor.get("username") + "</span> is idle"), this.user.addClass("idle")) : (this.editButtonWrapper.attr("data-tooltip", "Ask <strong>" + this.currentEditor.get("username") + "</strong> to make you the active editor"), this.userStatus.html('<span class="username">' + this.currentEditor.get("username") + "</span> is editing"), this.user.removeClass("idle"))) : (this.user.remove(), this.editButtonWrapper.removeAttr("data-tooltip")))
    },
    refreshSlideNumbers : function () {
        if (this.currentEditor) {
            var t = SL.util.deck.getSlideNumber(this.currentEditor.get("slide_id"));
            t ? this.userSlide.addClass("visible").html("slide " + t).data("data-slide-id", this.currentEditor.get("slide_id")).attr("data-tooltip", "Click to view slide") : this.userSlide.removeClass("visible")
        }
    },
    onEditClicked : function (t) {
        if ($(t.target).closest(".user-slide").length) {
            var e = this.userSlide.data("data-slide-id"),
            i = $('.reveal .slides section[data-id="' + e + '"]').get(0);
            i && SL.util.deck.navigateToSlide(i)
        } else if (!this.controller.getCurrentDeckUser().isEditing()) {
            var n = this.options.users.getByProperties({
                    editing : !0
                });
            n && n.isOnline() && !n.isIdle() ? (SL.helpers.StreamEditor.singleton().broadcast({
                    type : "collaboration:handover-requested",
                    user_id : SL.current_user.get("id")
                }), this.controller.showHandoverRequestPending(n)) : this.controller.becomeEditor()
        }
    },
    destroy : function () {
        this.domElement.remove()
    }
});