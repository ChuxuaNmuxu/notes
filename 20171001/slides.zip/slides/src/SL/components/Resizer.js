import SL from '../SL';

SL("components").Resizer = Class.extend({
	init : function (t, e) {
		this.domElement = $(t),
		this.revealElement = this.domElement.closest(".reveal"),
		this.options = $.extend({
				padding : 10,
				preserveAspectRatio : !1,
				useOverlay : !1
			},
				e),
		this.mouse = {
			x : 0,
			y : 0
		},
		this.mouseStart = {
			x : 0,
			y : 0
		},
		this.origin = {
			x : 0,
			y : 0,
			width : 0,
			height : 0
		},
		this.resizing = !1,
		this.domElement.length ? (this.onAnchorMouseDown = this.onAnchorMouseDown.bind(this), this.onDocumentMouseMove = this.onDocumentMouseMove.bind(this), this.onDocumentMouseUp = this.onDocumentMouseUp.bind(this), this.onElementDrop = this.onElementDrop.bind(this), this.layout = this.layout.bind(this), this.build(), this.bind(), this.layout()) : console.warn("Resizer: invalid resize target.")
	},
	build : function () {
		this.options.useOverlay && (this.overlay = $('<div class="editing-ui resizer-overlay"></div>').appendTo(document.body).hide()),
		this.anchorN = $('<div class="editing-ui resizer-anchor" data-direction="n"></div>').appendTo(document.body),
		this.anchorE = $('<div class="editing-ui resizer-anchor" data-direction="e"></div>').appendTo(document.body),
		this.anchorS = $('<div class="editing-ui resizer-anchor" data-direction="s"></div>').appendTo(document.body),
		this.anchorW = $('<div class="editing-ui resizer-anchor" data-direction="w"></div>').appendTo(document.body)
	},
	bind : function () {
		this.resizeStarted = new signals.Signal,
		this.resizeUpdated = new signals.Signal,
		this.resizeEnded = new signals.Signal,
		this.getAnchors().on("mousedown", this.onAnchorMouseDown),
		this.revealElement.on("drop", this.onElementDrop),
		$(document).on("keyup", this.layout),
		$(document).on("mouseup", this.layout),
		$(document).on("mousewheel", this.layout),
		$(document).on("DOMMouseScroll", this.layout),
		$(window).on("resize", this.layout)
	},
	layout : function () {
		if (!this.destroyIfDetached()) {
			var t = SL.util.getRevealElementGlobalOffset(this.domElement),
			e = Reveal.getScale(),
			i = parseInt(this.domElement.css("margin-right"), 10);
			marginBottom = parseInt(this.domElement.css("margin-bottom"), 10);
			var n = t.x - this.options.padding,
			s = t.y - this.options.padding,
			o = (this.domElement.width() + i) * e + 2 * this.options.padding;
			height = (this.domElement.height() + marginBottom) * e + 2 * this.options.padding;
			var a = -this.anchorN.outerWidth() / 2;
			this.anchorN.css({
				left : n + o / 2 + a,
				top : s + a
			}),
			this.anchorE.css({
				left : n + o + a,
				top : s + height / 2 + a
			}),
			this.anchorS.css({
				left : n + o / 2 + a,
				top : s + height + a
			}),
			this.anchorW.css({
				left : n + a,
				top : s + height / 2 + a
			}),
			this.overlay && this.overlay.css({
				left : n,
				top : s,
				width : o,
				height : height
			})
		}
	},
	show : function () {
		this.getAnchors().addClass("visible"),
		this.layout()
	},
	hide : function () {
		this.getAnchors().removeClass("visible")
	},
	destroyIfDetached : function () {
		return 0 === this.domElement.closest("body").length ? (this.destroy(), !0) : !1
	},
	getOptions : function () {
		return this.options
	},
	getAnchors : function () {
		return this.anchorN.add(this.anchorE).add(this.anchorS).add(this.anchorW)
	},
	isResizing : function () {
		return !!this.resizing
	},
	isDestroyed : function () {
		return !!this.destroyed
	},
	onAnchorMouseDown : function (t) {
		var e = $(t.target).attr("data-direction");
		if (e) {
			t.preventDefault(),
			this.resizeDirection = e,
			this.mouseStart.x = t.clientX,
			this.mouseStart.y = t.clientY;
			var i = SL.util.getRevealElementOffset(this.domElement);
			this.origin.x = i.x,
			this.origin.y = i.y,
			this.origin.width = this.domElement.width(),
			this.origin.height = this.domElement.height(),
			this.overlay && this.overlay.show(),
			this.resizing = !0,
			$(document).on("mousemove", this.onDocumentMouseMove),
			$(document).on("mouseup", this.onDocumentMouseUp),
			this.resizeStarted.dispatch()
		}
	},
	onDocumentMouseMove : function (t) {
		if (!this.destroyIfDetached() && (this.mouse.x = t.clientX, this.mouse.y = t.clientY, this.resizing)) {
			var e = Reveal.getScale(),
			i = (this.mouse.x - this.mouseStart.x) / e,
			n = (this.mouse.y - this.mouseStart.y) / e,
			s = "",
			o = "";
			switch (this.resizeDirection) {
			case "e":
				s = Math.max(this.origin.width + i, 1);
				break;
			case "w":
				s = Math.max(this.origin.width - i, 1);
				break;
			case "s":
				o = Math.max(this.origin.height + n, 1);
				break;
			case "n":
				o = Math.max(this.origin.height - n, 1)
			}
			if (this.options.preserveAspectRatio ? ("" === s && (s = this.origin.width * (o / this.origin.height)), "" === o && (o = this.origin.height * (s / this.origin.width))) : ("" === s && (s = this.domElement.css("width")), "" === o && (o = this.domElement.css("height"))), "absolute" === this.domElement.css("position") && ("n" === this.resizeDirection || "w" === this.resizeDirection))
				switch (this.resizeDirection) {
				case "w":
					this.domElement.css("left", Math.round(this.origin.x + i));
					break;
				case "n":
					this.domElement.css("top", Math.round(this.origin.y + n))
				}
			this.domElement.css({
				width : s ? s : "",
				height : o ? o : "",
				maxHeight : "none",
				maxWidth : "none"
			}),
			this.layout(),
			this.resizeUpdated.dispatch()
		}
	},
	onDocumentMouseUp : function () {
		this.resizing = !1,
		$(document).off("mousemove", this.onDocumentMouseMove),
		$(document).off("mouseup", this.onDocumentMouseUp),
		this.overlay && this.overlay.hide(),
		this.resizeEnded.dispatch()
	},
	onElementDrop : function () {
		setTimeout(this.layout, 1)
	},
	destroy : function () {
		this.destroyed || (this.destroyed = !0, this.resizeStarted.dispose(), this.resizeUpdated.dispose(), this.resizeEnded.dispose(), $(document).off("mousemove", this.onDocumentMouseMove), $(document).off("mouseup", this.onDocumentMouseUp), $(document).off("keyup", this.layout), $(document).off("mouseup", this.layout), $(document).off("mousewheel", this.layout), $(document).off("DOMMouseScroll", this.layout), $(window).off("resize", this.layout), this.revealElement.off("drop", this.onElementDrop), this.getAnchors().off("mousedown", this.onAnchorMouseDown), this.anchorN.remove(), this.anchorE.remove(), this.anchorS.remove(), this.anchorW.remove(), this.overlay && this.overlay.remove())
	}
});

SL.components.Resizer.delegateOnHover = function (t, e, i) {
	function n() {
		d && (d.destroy(), d = null, $(document).off("mousemove", a), $(document).off("mouseup", r))
	}
	function s(t, e) {
		if (d && d.isResizing())
			return !1;
		if (d && c && !c.is(t) && n(), !d) {
			var s = {};
			$.extend(s, i),
			$.extend(s, e),
			c = $(t),
			d = new SL.components.Resizer(c, s),
			d.resizeUpdated.add(l),
			d.show(),
			$(document).on("mousemove", a),
			$(document).on("mouseup", r)
		}
	}
	function o(t) {
		var e = $(t.currentTarget),
		i = null;
		e.data("resizer-options") && (i = e.data("resizer-options")),
		e.data("target-element") && (e = e.data("target-element")),
		s(e, i)
	}
	function a(t) {
		if (d)
			if (d.isDestroyed())
				n();
			else if (!d.isResizing()) {
				var e = Reveal.getScale(),
				i = SL.util.getRevealElementGlobalOffset(c),
				s = 3 * d.getOptions().padding,
				o = {
					top : i.y - s,
					right : i.x + c.outerWidth(!0) * e + s,
					bottom : i.y + c.outerHeight(!0) * e + s,
					left : i.x - s
				};
				(t.clientX < o.left || t.clientX > o.right || t.clientY < o.top || t.clientY > o.bottom) && n()
			}
	}
	function r(t) {
		setTimeout(function () {
			a(t)
		},
			1)
	}
	function l() {
		h.dispatch(c)
	}
	t.delegate(e, "mouseover", o);
	var d = null,
	c = null,
	h = new signals.Signal;
	return {
		show : s,
		updated : h,
		layout : function () {
			d && d.layout()
		},
		destroy : function () {
			n(),
			h.dispose(),
			t.undelegate(e, "mouseover", o)
		}
	}
};