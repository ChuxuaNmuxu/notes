import SL from '../../SL';

SL("components.medialibrary").ListDrag = Class.extend({
    init : function () {
        this.items = [],
        this.onMouseMove = this.onMouseMove.bind(this),
        this.onMouseUp = this.onMouseUp.bind(this)
    },
    reset : function () {
        this.items = [],
        this.ghostElement && this.ghostElement.remove(),
        this.currentDropTarget = null,
        $(".media-drop-target").removeClass("drag-over"),
        $(".media-drop-area").removeClass("media-drop-area-active"),
        $(document).off("vmousemove", this.onMouseMove),
        $(document).off("vmouseup", this.onMouseUp)
    },
    startDrag : function (t, e, i) {
        this.items = i;
        var n = e.offset();
        this.ghostOffset = {
            x : n.left - t.clientX,
            y : n.top - t.clientY
        },
        this.ghostWidth = e.width(),
        this.ghostHeight = e.height(),
        this.ghostElement = $('<div class="media-library-drag-ghost">'),
        this.ghostElement.css({
            border : e.css("border"),
            backgroundImage : e.css("background-image"),
            backgroundSize : e.css("background-size"),
            backgroundPosition : e.css("background-position"),
            width : this.ghostWidth,
            height : this.ghostHeight,
            marginLeft : this.ghostOffset.x,
            marginTop : this.ghostOffset.y
        }),
        this.ghostElement.appendTo(document.body),
        i.length > 1 && (this.ghostElement.append('<span class="count">' + i.length + "</span>"), this.ghostElement.attr("data-depth", Math.min(i.length, 3))),
        this.dropTargets = $(".media-drop-target"),
        $(".media-drop-area").addClass("media-drop-area-active"),
        $(document).on("vmousemove", this.onMouseMove),
        $(document).on("vmouseup", this.onMouseUp)
    },
    stopDrag : function () {
        this.reset()
    },
    onMouseMove : function (t) {
        t.preventDefault();
        var e = t.clientX,
        i = t.clientY,
        n = "translate(" + e + "px," + i + "px)";
        this.ghostElement.css({
            webkitTransform : n,
            transform : n
        }),
        this.currentDropTarget = null,
        this.dropTargets.each(function (t, n) {
            var s = $(n),
            o = n.getBoundingClientRect();
            e > o.left && e < o.right && i > o.top && i < o.bottom ? (s.addClass("drag-over"), this.currentDropTarget = s) : s.removeClass("drag-over")
        }
            .bind(this))
    },
    onMouseUp : function (t) {
        if (t.preventDefault(), this.currentDropTarget) {
            this.currentDropTarget.data("dropReceiver").call(null, this.items),
            SL.analytics.trackEditor("Media: Drop items on tag");
            var e = this.ghostElement,
            i = this.currentDropTarget.get(0).getBoundingClientRect(),
            n = i.left + (i.width - this.ghostWidth) / 2 - this.ghostOffset.x,
            s = i.top + (i.height - this.ghostHeight) / 2 - this.ghostOffset.y,
            o = "translate(" + n + "px," + s + "px) scale(0.2)";
            e.css({
                webkitTransition : "all 0.2s ease",
                transition : "all 0.2s ease",
                webkitTransform : o,
                transform : o,
                opacity : 0
            }),
            setTimeout(function () {
                e.remove()
            },
                500),
            this.ghostElement = null
        }
        this.stopDrag()
    }
});