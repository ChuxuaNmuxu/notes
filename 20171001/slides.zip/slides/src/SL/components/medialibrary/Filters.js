import SL from '../../SL';

SL("components.medialibrary").Filters = Class.extend({
    init : function (t, e, i) {
        this.options = $.extend({
                editable : !0
            },
                i),
        this.media = t,
        this.media.changed.add(this.onMediaChanged.bind(this)),
        this.tags = e,
        this.tags.changed.add(this.onTagsChanged.bind(this)),
        this.tags.associationChanged.add(this.onTagAssociationChanged.bind(this)),
        this.filterChanged = new signals.Signal,
        this.onSearchInput = $.throttle(this.onSearchInput, 300),
        this.render(),
        this.recount(),
        this.selectDefaultFilter(!0)
    },
    render : function () {
        this.domElement = $('<div class="media-library-filters">'),
        this.domElement.toggleClass("editable", this.options.editable),
        this.innerElement = $('<div class="media-library-filters-inner">').appendTo(this.domElement),
        this.scrollElement = this.innerElement,
        this.renderSearch(),
        this.renderTypes(),
        this.renderTags()
    },
    renderTypes : function () {
        this.renderType(SL.models.Media.IMAGE.id,
            function () {
            return !0
        },
            "All Images", "All Images")
    },
    renderType : function (t, e, i, n) {
        var s = $(['<div class="media-library-filter media-library-type-filter">', '<span class="label">' + i + "</span>", '<span class="count"></span>', "</div>"].join(""));
        return s.attr({
            "data-id" : t,
            "data-label" : i,
            "data-exclusive-label" : n
        }),
        s.on("vclick", this.onFilterClicked.bind(this)),
        s.data("filter", e),
        s.appendTo(this.innerElement),
        s
    },
    renderTags : function () {
        this.tagsElement = $(['<div class="media-library-tags media-drop-area">', '<div class="tags-list"></div>', "</div>"].join("")),
        this.tagsElement.appendTo(this.innerElement),
        this.tagsList = this.tagsElement.find(".tags-list"),
        this.options.editable && (this.tagsElement.append(['<div class="tags-create">', '<div class="tags-create-inner ladda-button" data-style="expand-right" data-spinner-color="#666" data-spinner-size="28">New tag</div>', "</div>"].join("")), this.tagsElement.find(".tags-create").on("vclick", this.onCreateTagClicked.bind(this)), this.tagsCreateLoader = Ladda.create(this.tagsElement.find(".tags-create-inner").get(0))),
        this.tags.forEach(this.renderTag.bind(this)),
        this.sortTags()
    },
    renderTag : function (t) {
        var e = $(['<div class="media-library-filter media-drop-target" data-id="' + t.get("id") + '">', '<div class="front">', '<span class="label-output"></span>', '<div class="controls-out">', '<span class="count"></span>', "</div>", "</div>", "</div>", "</div>"].join(""));
        return e.find(".label-output").text(t.get("name")),
        e.on("vclick", this.onTagClicked.bind(this)),
        e.data({
            model : t,
            filter : t.createFilter()
        }),
        this.options.editable ? (e.find(".front").append(['<div class="controls-over">', '<span class="controls-button edit-button">Edit</span>', "</div>"].join("")), e.append(['<div class="back">', '<input class="label-input" value="" type="text">', '<div class="controls">', '<span class="controls-button delete-button negative icon i-trash-stroke"></span>', '<span class="controls-button save-button">Save</span>', "</div>", "</div>"].join("")), e.find(".label-input").val(t.get("name")), e.data("dropReceiver",
                function (e) {
                this.tags.addTagTo(t, e)
            }
                .bind(this))) : e.find(".controls-out").removeClass("controls-out").addClass("controls-permanent"),
        e.appendTo(this.tagsList),
        e
    },
    renderSearch : function () {
        this.searchElement = $(['<div class="media-library-filter media-library-search-filter" data-id="search">', '<input class="search-input" type="text" placeholder="Search..." maxlength="50" />', "</div>"].join("")),
        this.searchElement.on("vclick", this.onSearchClicked.bind(this)),
        this.searchElement.data("filter",
            function () {
            return !1
        }),
        this.searchElement.appendTo(this.innerElement),
        this.searchInput = this.searchElement.find(".search-input"),
        this.searchInput.on("input", this.onSearchInput.bind(this))
    },
    recount : function (t) {
        t = t || this.domElement.find(".media-library-filter"),
        t.each(function (t, e) {
            var i = $(e),
            n = i.find(".count");
            n.length && n.text(this.media.filter(i.data("filter")).length)
        }
            .bind(this))
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    selectFilter : function (t, e) {
        var i = this.domElement.find('.media-library-filter[data-id="' + t + '"]');
        this.domElement.find(".is-selected").removeClass("is-selected"),
        i.addClass("is-selected"),
        this.selectedFilter = i.data("filter"),
        this.selectedFilterData = {},
        i.closest(this.tagsList).length ? (this.selectedFilterData.type = SL.components.medialibrary.Filters.FILTER_TYPE_TAG, this.selectedFilterData.tag = i.data("model"), this.selectedFilterData.placeholder = "No media has been added to this tag", this.options.editable && (this.selectedFilterData.placeholder = "This tag is empty. To add media, drag and drop it onto the tag in the sidebar.")) : (this.selectedFilterData.type = SL.components.medialibrary.Filters.FILTER_TYPE_MEDIA, this.selectedFilterData.placeholder = "There is no media of this type"),
        e || this.filterChanged.dispatch(this.selectedFilter, this.selectedFilterData)
    },
    selectDefaultFilter : function (t) {
        this.selectFilter(this.domElement.find(".media-library-filter:not(.media-library-search-filter)").first().attr("data-id"), t)
    },
    showAllTypes : function () {
        this.domElement.find(".media-library-type-filter").each(function () {
            var t = $(this);
            t.css("display", ""),
            t.find(".label").text(t.attr("data-label"))
        })
    },
    hideAllTypesExcept : function (t) {
        this.domElement.find(".media-library-type-filter").each(function () {
            var e = $(this);
            e.attr("data-id") === t ? (e.css("display", ""), e.find(".label").text(e.attr("data-exclusive-label"))) : (e.css("display", "none"), e.find(".label").text(e.attr("data-label")))
        })
    },
    startEditingTag : function (t, e) {
        if (this.tagsList.find(".is-editing").length)
            return !1;
        var i = (t.data("model"), t.find(".label-input"));
        this.domElement.addClass("is-editing"),
        e === !0 && (t.addClass("collapsed"), t.find(".label-output").empty(), setTimeout(function () {
                t.removeClass("collapsed")
            },
                1), this.scrollElement.animate({
                scrollTop : t.prop("offsetTop") + 80 - this.scrollElement.height()
            },
                300)),
        t.addClass("is-editing");
        var n = this.scrollElement.prop("scrollTop");
        i.focus().select(),
        this.scrollElement.prop("scrollTop", n),
        i.on("keydown",
            function (e) {
            13 === e.keyCode && (e.preventDefault(), this.stopEditingTag(t))
        }
            .bind(this))
    },
    stopEditingTag : function (t, e) {
        var i = t.data("model"),
        n = t.find(".label-input"),
        s = t.find(".label-output");
        this.domElement.removeClass("is-editing");
        var o = n.val();
        o && !e && (i.set("name", o), i.save(["name"])),
        s.text(i.get("name")),
        n.off("keydown"),
        setTimeout(function () {
            t.removeClass("is-editing")
        },
            1)
    },
    sortTags : function () {
        var t = this.tagsList.find(".media-library-filter").toArray();
        t.sort(function (t, e) {
            return t = $(t).data("model").get("name").toLowerCase(),
            e = $(e).data("model").get("name").toLowerCase(),
            e > t ? -1 : t > e ? 1 : 0
        }),
        t.forEach(function (t) {
            $(t).appendTo(this.tagsList)
        }
            .bind(this))
    },
    getTagElementByID : function (t) {
        return this.tagsList.find('.media-library-filter[data-id="' + t + '"]')
    },
    confirmTagRemoval : function (t) {
        var e = t.data("model");
        SL.prompt({
            anchor : t.find(".delete-button"),
            title : SL.locale.get("MEDIA_TAG_DELETE_CONFIRM"),
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Delete</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        SL.analytics.trackEditor("Media: Delete tag"),
                        e.destroy().done(function () {
                            this.domElement.removeClass("is-editing"),
                            this.tags.remove(e),
                            SL.notify(SL.locale.get("MEDIA_TAG_DELETE_SUCCESS"))
                        }
                            .bind(this)).fail(function () {
                            SL.notify(SL.locale.get("MEDIA_TAG_DELETE_ERROR"), "negative")
                        }
                            .bind(this))
                    }
                    .bind(this)
                }
            ]
        })
    },
    getSelectedFilterData : function () {
        return this.selectedFilterData
    },
    destroy : function () {
        this.filterChanged.dispose(),
        this.domElement.remove()
    },
    onMediaChanged : function () {
        this.recount()
    },
    onTagsChanged : function (t, e) {
        t && t.length && t.forEach(function (t) {
            this.startEditingTag(this.renderTag(t), !0)
        }
            .bind(this)),
        e && e.length && e.forEach(function (t) {
            var e = this.tagsElement.find('[data-id="' + t.get("id") + '"]');
            this.stopEditingTag(e, !0),
            e.css({
                height : 0,
                padding : 0,
                opacity : 0
            }),
            setTimeout(function () {
                e.remove()
            },
                300),
            e.hasClass("is-selected") && this.selectDefaultFilter()
        }
            .bind(this))
    },
    onTagAssociationChanged : function (t) {
        this.recount(this.getTagElementByID(t.get("id")))
    },
    onFilterClicked : function (t) {
        this.selectFilter($(t.currentTarget).attr("data-id"))
    },
    onCreateTagClicked : function () {
        this.tagsCreateLoader.start(),
        this.tags.create().then(function (t) {
            this.recount(this.getTagElementByID(t.get("id"))),
            this.tagsCreateLoader.stop()
        }
            .bind(this),
            function () {
            SL.notify(SL.locale.get("GENERIC_ERROR"), "negative"),
            this.tagsCreateLoader.stop()
        }
            .bind(this)),
        SL.analytics.trackEditor("Media: Create tag")
    },
    onTagClicked : function (t) {
        var e = $(t.target),
        i = e.closest(".media-library-filter");
        i.length && (e.closest(".edit-button").length ? this.startEditingTag(i) : e.closest(".save-button").length ? this.stopEditingTag(i) : e.closest(".delete-button").length ? this.confirmTagRemoval(i) : i.hasClass("is-editing") || this.onFilterClicked(t))
    },
    onSearchClicked : function () {
        this.selectFilter(this.searchElement.attr("data-id"), !0),
        this.searchInput.focus(),
        this.onSearchInput(),
        SL.analytics.trackEditor("Media: Search clicked")
    },
    onSearchInput : function () {
        var t = this.searchInput.val();
        this.selectedFilter = this.media.createSearchFilter(t),
        this.selectedFilterData = {
            type : SL.components.medialibrary.Filters.FILTER_TYPE_SEARCH,
            placeholder : "Please enter a search term"
        },
        this.searchElement.data("filter", this.selectedFilter),
        t.length > 0 && (this.selectedFilterData.placeholder = 'No results for "' + t + '"'),
        this.filterChanged.dispatch(this.selectedFilter, this.selectedFilterData)
    }
});