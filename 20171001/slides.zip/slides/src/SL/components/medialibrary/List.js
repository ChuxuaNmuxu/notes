import SL from '../../SL';

SL("components.medialibrary").List = Class.extend({
    init : function (t, e, i) {
        this.options = $.extend({
                editable : !0
            },
                i),
        this.media = t,
        this.media.changed.add(this.onMediaChanged.bind(this)),
        this.tags = e,
        this.tags.associationChanged.add(this.onTagAssociationChanged.bind(this)),
        this.items = [],
        this.filteredItems = [],
        this.selectedItems = new SL.collections.Collection,
        this.overlayPool = [],
        this.itemSelected = new signals.Signal,
        this.drag = new SL.components.medialibrary.ListDrag,
        this.render(),
        this.bind()
    },
    render : function () {
        this.domElement = $('<div class="media-library-list">'),
        this.trayElement = $(['<div class="media-library-tray">', '<div class="status"></div>', '<div class="button negative delete-button">Delete</div>', '<div class="button outline white untag-button">Remove tag</div>', '<div class="button outline white clear-button">Clear selection</div>', "</div>"].join("")),
        this.placeholderElement = $(['<div class="media-library-list-placeholder">', "Empty", "</div>"].join("")),
        this.media.forEach(this.addItem.bind(this)),
        this.filteredItems = this.items
    },
    bind : function () {
        if (this.loadItemsInView = $.throttle(this.loadItemsInView, 200), this.onMouseMove = this.onMouseMove.bind(this), this.onMouseUp = this.onMouseUp.bind(this), this.domElement.on("scroll", this.onListScrolled.bind(this)), this.trayElement.find(".delete-button").on("vclick", this.onDeleteSelectionClicked.bind(this)), this.trayElement.find(".untag-button").on("vclick", this.onUntagSelectionClicked.bind(this)), this.trayElement.find(".clear-button").on("vclick", this.onClearSelectionClicked.bind(this)), SL.util.device.IS_PHONE || SL.util.device.IS_TABLET) {
            var t = new Hammer(this.domElement.get(0));
            t.on("tap", this.onMouseUp),
            t.on("press",
                function (t) {
                var e = $(t.target).closest(".media-library-list-item").data("item");
                e && (this.lastSelectedItem = e, this.toggleSelection(e)),
                t.preventDefault()
            }
                .bind(this))
        } else
            this.domElement.on("vmousedown", this.onMouseDown.bind(this))
    },
    layout : function () {
        var t = $(".media-library-list-item").first();
        this.cellWidth = t.outerWidth(!0),
        this.cellHeight = t.outerHeight(!0),
        this.columnCount = Math.floor(this.domElement.outerWidth() / this.cellWidth)
    },
    appendTo : function (t) {
        this.domElement.appendTo(t),
        this.trayElement.appendTo(t),
        this.placeholderElement.appendTo(t),
        this.layout(),
        this.loadItemsInView()
    },
    addItem : function (t, e, i) {
        var n = $('<div class="media-library-list-item"></div>'),
        s = {
            model : t,
            element : n,
            elementNode : n.get(0),
            selected : !1,
            visible : !0
        };
        n.data("item", s),
        e === !0 ? (n.prependTo(this.domElement), this.items.unshift(s)) : (n.appendTo(this.domElement), this.items.push(s)),
        i === !0 && (n.addClass("has-intro hidden"), setTimeout(function () {
                n.removeClass("hidden")
            },
                1))
    },
    removeItem : function (t) {
        for (var e = this.items.length; --e >= 0; ) {
            var i = this.items[e];
            i.model === t && (i.model = null, i.element.remove(), this.items.splice(e, 1))
        }
    },
    setPrimaryFilter : function (t) {
        this.filterA = t,
        this.applyFilter()
    },
    clearPrimaryFilter : function () {
        this.filterA = null,
        this.applyFilter()
    },
    setSecondaryFilter : function (t, e) {
        this.clearSelection(),
        this.filterB = t,
        this.filterBData = e,
        this.applyFilter(),
        this.setPlaceholderContent(e.placeholder),
        this.afterSelectionChange()
    },
    clearSecondaryFilter : function () {
        this.filterB = null,
        this.filterBData = null,
        this.applyFilter(),
        this.setPlaceholderContent("Empty")
    },
    applyFilter : function () {
        this.filteredItems = [];
        for (var t = 0,
            e = this.items.length; e > t; t++) {
            var i = this.items[t];
            this.filterA && !this.filterA(i.model) || this.filterB && !this.filterB(i.model) ? (i.elementNode.style.display = "none", i.visible = !1, this.detachOverlay(i)) : (this.filteredItems.push(i), i.visible = !0, i.elementNode.style.display = "")
        }
        this.domElement.scrollTop(0),
        this.loadItemsInView(),
        this.placeholderElement.toggleClass("visible", 0 === this.filteredItems.length)
    },
    loadItemsInView : function () {
        if (SL.tooltip.isVisible() && SL.tooltip.hide(), this.filteredItems.length)
            for (var t, e, i = this.domElement.scrollTop(), n = 100, s = this.domElement.outerHeight(), o = 0, a = this.filteredItems.length; a > o; o++)
                t = this.filteredItems[o],
                e = Math.floor(o / this.columnCount) * this.cellHeight,
                e + this.cellHeight - i > -n && s + n > e - i ? (t.overlay || this.attachOverlay(t), t.elementNode.hasAttribute("data-thumb-loaded") || (t.elementNode.style.backgroundImage = 'url("' + t.model.get("thumb_url") + '")', t.elementNode.setAttribute("data-thumb-loaded", "true"))) : t.overlay && !t.selected && this.detachOverlay(t)
    },
    setPlaceholderContent : function (t) {
        this.placeholderElement.html(this.media.isEmpty() ? this.options.editable ? "You haven't uploaded any media yet.<br>Use the upload button to the left or drag media from your desktop." : "No media has been uploaded yet." : t || "Empty")
    },
    attachOverlay : function (t) {
        return t.overlay || !this.options.editable ? !1 : (0 === this.overlayPool.length && this.overlayPool.push($(['<div class="info-overlay">', '<span class="info-overlay-action inline-button icon i-embed" data-tooltip="Insert SVG inline"></span>', '<span class="info-overlay-action label-button icon i-type" data-tooltip="Rename"></span>', '<span class="info-overlay-action select-button" data-tooltip="Select">', '<span class="icon i-checkmark checkmark"></span>', "</span>", "</div>"].join(""))), t.overlay = this.overlayPool.pop(), t.overlay.appendTo(t.element), void this.refreshOverlay(t))
    },
    refreshOverlay : function (t) {
        if (t.overlay) {
            var e = t.model.get("label");
            e && "" !== e || (e = "Label"),
            t.overlay.attr("data-tooltip", e),
            t.model.isSVG() ? (t.overlay.addClass("has-inline-option"), t.overlay.find(".inline-button").toggleClass("is-on", !!t.model.get("inline"))) : t.overlay.removeClass("has-inline-option")
        }
    },
    detachOverlay : function (t) {
        t && t.overlay && (this.overlayPool.push(t.overlay), t.overlay = null)
    },
    toggleSelection : function (t, e) {
        t.visible && (t.selected = "boolean" == typeof e ? e : !t.selected, t.selected ? (t.element.addClass("is-selected"), this.selectedItems.push(t)) : (t.element.removeClass("is-selected"), this.selectedItems.remove(t)), this.afterSelectionChange())
    },
    toggleSelectionThrough : function (t) {
        if (this.lastSelectedItem) {
            var e = !t.selected,
            i = this.lastSelectedItem.element.index(),
            n = t.element.index();
            if (n > i)
                for (var s = i + 1; n >= s; s++)
                    this.toggleSelection(this.items[s], e);
            else if (i > n)
                for (var s = n; i > s; s++)
                    this.toggleSelection(this.items[s], e)
        }
    },
    clearSelection : function () {
        this.selectedItems.forEach(function (t) {
            t.selected = !1,
            t.element.removeClass("is-selected")
        }
            .bind(this)),
        this.selectedItems.clear(),
        this.lastSelectedItem = null,
        this.afterSelectionChange()
    },
    afterSelectionChange : function () {
        var t = this.selectedItems.size();
        this.domElement.toggleClass("is-selecting", t > 0),
        this.trayElement.toggleClass("visible", t > 0),
        this.trayElement.find(".status").text(t + " " + SL.util.string.pluralize("item", "s", 1 !== t) + " selected"),
        this.filterBData && this.filterBData.type === SL.components.medialibrary.Filters.FILTER_TYPE_TAG ? this.trayElement.find(".untag-button").show() : this.trayElement.find(".untag-button").hide()
    },
    deleteSelection : function () {
        var t = "Do you want to permanently delete this media from all existing presentations or remove it from the library?";
        this.selectedItems.size() > 1 && (t = "Do you want to permanently delete these items from all existing presentations or remove them from the library?"),
        SL.prompt({
            anchor : this.trayElement.find(".delete-button"),
            title : t,
            type : "select",
            data : [{
                    html : "<h3>Cancel</h3>"
                }, {
                    html : "<h3>Remove from library</h3>",
                    callback : function () {
                        this.selectedItems.forEach(function (t) {
                            t.model.set("hidden", !0),
                            t.model.save(["hidden"]).fail(function () {
                                SL.notify("An error occurred, media was not removed", "negative")
                            }
                                .bind(this)),
                            this.media.remove(t.model)
                        }
                            .bind(this)),
                        this.clearSelection()
                    }
                    .bind(this)
                }, {
                    html : "<h3>Delete permanently</h3>",
                    selected : !0,
                    className : "negative",
                    callback : function () {
                        this.selectedItems.forEach(function (t) {
                            t.model.destroy().fail(function () {
                                SL.notify("An error occurred, media was not deleted", "negative")
                            }
                                .bind(this)),
                            this.media.remove(t.model)
                        }
                            .bind(this)),
                        this.clearSelection()
                    }
                    .bind(this)
                }
            ]
        }),
        SL.analytics.trackEditor("Media: Delete items")
    },
    editLabel : function (t) {
        t.element.addClass("hover");
        var e = SL.prompt({
                anchor : t.element.find(".label-button"),
                title : "Rename",
                type : "input",
                confirmLabel : "Save",
                data : {
                    value : t.model.get("label"),
                    placeholder : "Label...",
                    maxlength : SL.config.MEDIA_LABEL_MAXLENGTH,
                    width : 400
                }
            });
        e.confirmed.add(function (e) {
            t.element.removeClass("hover"),
            e && "" !== e.trim() ? (t.model.set("label", e), t.model.save(["label"]), this.refreshOverlay(t)) : SL.notify("Label can't be empty", "negative")
        }
            .bind(this)),
        e.canceled.add(function () {
            t.element.removeClass("hover")
        }
            .bind(this)),
        SL.analytics.trackEditor("Media: Edit item label")
    },
    toggleInline : function (t) {
        t.model.set("inline", !t.model.get("inline")),
        t.model.save(["inline"]),
        this.refreshOverlay(t),
        SL.analytics.trackEditor("Media: Toggle inline SVG")
    },
    onMediaChanged : function (t, e) {
        t && t.length && (t.forEach(function (t) {
                this.addItem(t, !0, !0)
            }
                .bind(this)), this.applyFilter()),
        e && e.length && (e.forEach(this.removeItem.bind(this)), this.media.isEmpty() ? this.applyFilter() : this.loadItemsInView())
    },
    onTagAssociationChanged : function (t) {
        var e = this.filterBData && this.filterBData.type === SL.components.medialibrary.Filters.FILTER_TYPE_TAG && this.filterBData.tag.get("id") === t.get("id");
        e && this.applyFilter()
    },
    onMouseDown : function (t) {
        2 !== t.button && (this.mouseDownTarget = $(t.target), this.mouseDownX = t.clientX, this.mouseDownY = t.clientY, this.domElement.on("vmousemove", this.onMouseMove), this.domElement.on("vmouseup", this.onMouseUp))
    },
    onMouseMove : function (t) {
        var e = SL.util.trig.distanceBetween({
                x : this.mouseDownX,
                y : this.mouseDownY
            }, {
                x : t.clientX,
                y : t.clientY
            });
        if (e > 10 && this.options.editable) {
            var i = this.mouseDownTarget.closest(".media-library-list-item").data("item");
            if (i) {
                this.domElement.off("vmousemove", this.onMouseMove),
                this.domElement.off("vmouseup", this.onMouseUp);
                var n = [i.model];
                this.selectedItems.size() > 0 && i.selected && (n = this.selectedItems.map(function (t) {
                            return t.model
                        })),
                this.drag.startDrag(t, i.element, n),
                SL.analytics.trackEditor("Media: Start drag", n.length > 1 ? "multiple" : "single")
            }
        }
        t.preventDefault()
    },
    onMouseUp : function (t) {
        var e = $(t.target),
        i = e.closest(".media-library-list-item").data("item");
        i && (this.selectedItems.size() > 0 || e.closest(".select-button").length ? t.shiftKey ? this.toggleSelectionThrough(i) : (this.lastSelectedItem = i, this.toggleSelection(i)) : e.closest(".label-button").length ? this.editLabel(i) : e.closest(".inline-button").length ? this.toggleInline(i) : this.itemSelected.dispatch(i.model)),
        this.domElement.off("vmousemove", this.onMouseMove),
        this.domElement.off("vmouseup", this.onMouseUp),
        t.preventDefault()
    },
    onListScrolled : function () {
        this.loadItemsInView()
    },
    onDeleteSelectionClicked : function () {
        this.deleteSelection()
    },
    onUntagSelectionClicked : function () {
        if (this.filterBData && this.filterBData.type === SL.components.medialibrary.Filters.FILTER_TYPE_TAG) {
            var t = this.selectedItems.map(function (t) {
                    return t.model
                });
            this.tags.removeTagFrom(this.filterBData.tag, t),
            this.applyFilter(),
            this.clearSelection()
        }
    },
    onClearSelectionClicked : function () {
        this.clearSelection()
    }
});