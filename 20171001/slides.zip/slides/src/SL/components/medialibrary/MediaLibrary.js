import SL from '../../SL';

SL("components.medialibrary").MediaLibrary = SL.components.popup.Popup.extend({
    TYPE : "media-library",
    init : function (t) {
        this._super($.extend({
                title : "Media Library",
                width : 1110,
                height : 660,
                singleton : !0
            },
                t)),
        this.selected = new signals.Signal
    },
    render : function () {
        if (this._super(), this.innerElement.addClass("media-library"), this.userPage = new SL.components.medialibrary.MediaLibraryPage(new SL.collections.Media, new SL.collections.MediaTags), this.userPage.selected.add(this.onMediaSelected.bind(this)), this.userPage.load(), SL.current_user.isEnterprise()) {
            var t = new SL.collections.TeamMedia;
            this.headerTabs = $(['<div class="media-library-header-tabs">', '<div class="media-library-header-tab user-tab">Your Media</div>', '<div class="media-library-header-tab team-tab" data-tooltip-alignment="r">Team Media</div>', "</div>"].join("")),
            this.userTab = this.headerTabs.find(".user-tab"),
            this.teamTab = this.headerTabs.find(".team-tab"),
            this.userTab.on("vclick", this.showUserPage.bind(this)),
            this.teamTab.on("vclick", this.showTeamPage.bind(this)),
            this.innerElement.addClass("has-header-tabs"),
            this.headerTitleElement.replaceWith(this.headerTabs),
            t.loadCompleted.add(function () {
                !SL.current_user.isEnterpriseManager() && t.isEmpty() && (this.teamTab.addClass("is-disabled"), this.teamTab.attr("data-tooltip", "Your team doesn't have any shared media yet.<br>Only admins can upload team media."))
            }
                .bind(this)),
            t.loadFailed.add(function () {
                this.teamTab.attr("data-tooltip", "Failed to load")
            }
                .bind(this)),
            this.teamPage = new SL.components.medialibrary.MediaLibraryPage(t, new SL.collections.TeamMediaTags, {
                    editable : SL.current_user.isEnterpriseManager(),
                    selectAfterUpload : !1
                }),
            this.teamPage.selected.add(this.onMediaSelected.bind(this)),
            this.teamPage.load()
        }
        this.showUserPage()
    },
    showUserPage : function () {
        this.currentPage = this.userPage,
        this.teamPage && (this.teamPage.hide(), this.teamTab.removeClass("is-selected"), this.userTab.addClass("is-selected")),
        this.userPage.show(this.bodyElement),
        this.userPage.configure(this.options),
        this.refresh(),
        this.layout()
    },
    showTeamPage : function () {
        this.currentPage = this.teamPage,
        this.userPage.hide(),
        this.userTab.removeClass("is-selected"),
        this.teamPage.show(this.bodyElement),
        this.teamPage.configure(this.options),
        this.teamTab.addClass("is-selected"),
        this.refresh(),
        this.layout()
    },
    open : function (t) {
        t = $.extend({
                select : null
            },
                t),
        this._super(t),
        this.currentPage.configure(t),
        this.currentPage.bind(),
        this.refresh(),
        this.layout()
    },
    close : function () {
        this._super.apply(this, arguments),
        this.selected.removeAll(),
        this.currentPage.unbind()
    },
    layout : function () {
        this._super.apply(this, arguments),
        this.currentPage.layout()
    },
    refresh : function () {
        this.currentPage.refresh()
    },
    isSelecting : function () {
        return !!this.options.select
    },
    onMediaSelected : function (t) {
        this.isSelecting() ? this.selected.dispatch(t) : SL.editor.controllers.Blocks.add({
            type : "image",
            afterInit : function (e) {
                e.setImageModel(t)
            }
        }),
        this.close()
    }
});