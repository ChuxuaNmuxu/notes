import SL from '../../SL';

SL("components.medialibrary").Uploader = Class.extend({
    MAX_CONCURRENT_UPLOADS : 2,
    FILE_FORMATS : [{
            validator : /image.*/,
            maxSize : SL.config.MAX_IMAGE_UPLOAD_SIZE
        }
    ],
    init : function (t) {
        this.media = t,
        this.options = {
            multiple : !0
        },
        this.queue = new SL.collections.Collection,
        this.render(),
        this.renderInput(),
        this.bind()
    },
    bind : function () {
        this.onUploadCompleted = this.onUploadCompleted.bind(this),
        this.onUploadFailed = this.onUploadFailed.bind(this),
        this.uploadEnqueued = new signals.Signal,
        this.uploadStarted = new signals.Signal,
        this.uploadCompleted = new signals.Signal
    },
    render : function () {
        this.domElement = $('<div class="media-library-uploader">'),
        this.uploadButton = $('<div class="media-library-uploader-button">Upload <span class="icon i-cloud-upload2"></span></div>'),
        this.uploadButton.appendTo(this.domElement),
        this.uploadList = $('<div class="media-library-uploader-list">'),
        this.uploadList.appendTo(this.domElement)
    },
    renderInput : function () {
        this.fileInput && this.fileInput.remove(),
        this.fileInput = $('<input class="file-input" type="file">'),
        this.fileInput.on("change", this.onInputChanged.bind(this)),
        this.fileInput.appendTo(this.uploadButton),
        this.options.multiple ? this.fileInput.attr("multiple", "multiple") : this.fileInput.removeAttr("multiple", "multiple")
    },
    configure : function (t) {
        this.options = $.extend(this.options, t),
        this.renderInput()
    },
    appendTo : function (t) {
        this.domElement.appendTo(t)
    },
    isUploading : function () {
        return this.queue.some(function (t) {
            return t.isUploading()
        })
    },
    validateFile : function (t) {
        var e = "number" == typeof t.size ? t.size / 1024 : 0;
        return this.FILE_FORMATS.some(function (i) {
            return t.type.match(i.validator) ? i.maxSize && e > i.maxSize ? !1 : !0 : !1
        })
    },
    enqueue : function (t) {
        if (this.queue.size() >= 100)
            return SL.notify("Upload queue is full, please wait", "negative"),
            !1;
        var e = new SL.models.Media(null, this.media.crud, t);
        e.uploaderElement = $(['<div class="media-library-uploader-item">', '<div class="item-text">', '<span class="status"><span class="icon i-clock"></span></span>', '<span class="filename">' + (t.name || "untitled") + "</span>", "</div>", '<div class="item-progress">', '<span class="bar"></span>', "</div>", "</div>"].join("")),
        e.uploaderElement.appendTo(this.uploadList),
        setTimeout(e.uploaderElement.addClass.bind(e.uploaderElement, "animate-in"), 1),
        e.uploadCompleted.add(this.onUploadCompleted),
        e.uploadFailed.add(this.onUploadFailed),
        e.uploadProgressed.add(function (t) {
            var i = "scaleX(" + t + ")";
            e.uploaderElement.find(".bar").css({
                "-webkit-transform" : i,
                "-moz-transform" : i,
                transform : i
            })
        }
            .bind(this)),
        this.queue.push(e),
        this.uploadEnqueued.dispatch(e),
        this.checkQueue()
    },
    dequeue : function (t, e, i) {
        var n = t.uploaderElement;
        n && (t.uploaderElement = null, n.addClass(e), n.find(".status").html(i), setTimeout(function () {
                n.removeClass("animate-in").addClass("animate-out"),
                setTimeout(n.remove.bind(n), 500)
            }
                .bind(this), 2e3), this.queue.remove(t), t.isUploaded() && this.uploadCompleted.dispatch(t))
    },
    checkQueue : function () {
        this.queue.forEach(function (t) {
            t.isUploaded() ? this.dequeue(t, "completed", '<span class="icon i-checkmark"></span>') : t.isUploadFailed() && this.dequeue(t, "failed", '<span class="icon i-denied"></span>')
        }
            .bind(this));
        var t = 0;
        this.queue.forEach(function (e) {
            t < this.MAX_CONCURRENT_UPLOADS && (e.isUploading() ? t += 1 : e.isWaitingToUpload() && (e.upload(), e.uploaderElement.find(".status").html('<div class="upload-spinner"></div>'), t += 1, this.uploadStarted.dispatch(e)))
        }
            .bind(this)),
        this.domElement.toggleClass("is-uploading", t > 0)
    },
    onUploadCompleted : function () {
        this.checkQueue()
    },
    onUploadFailed : function (t) {
        SL.notify(t || "An error occurred while uploading your image.", "negative"),
        this.checkQueue()
    },
    onInputChanged : function (t) {
        var e = SL.util.toArray(this.fileInput.get(0).files);
        e = e.filter(this.validateFile.bind(this)),
        e.length ? (e.forEach(this.enqueue.bind(this)), SL.analytics.trackEditor("Media: Upload file", "file input")) : SL.notify("Invalid file. We support <strong>PNG</strong>, <strong>JPG</strong>, <strong>GIF</strong> and <strong>SVG</strong> files up to <strong>10 MB</strong>", "negative"),
        this.renderInput(),
        t.preventDefault()
    },
    destroy : function () {
        this.queue = null,
        this.uploadStarted.dispose(),
        this.uploadCompleted.dispose()
    }
});