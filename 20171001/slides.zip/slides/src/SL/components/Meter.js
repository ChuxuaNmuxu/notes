import SL from '../SL';

SL("components").Meter = Class.extend({
		init : function (t) {
			this.domElement = $(t),
			this.labelElement = $('<div class="label">').appendTo(this.domElement),
			this.progressElement = $('<div class="progress">').appendTo(this.domElement),
			this.read(),
			this.paint()
		},
		read : function () {
			switch (this.unit = "", this.type = this.domElement.attr("data-type"), this.value = parseInt(this.domElement.attr("data-value"), 10) || 0, this.total = parseInt(this.domElement.attr("data-total"), 10) || 0, this.type) {
			case "storage":
				var t = 1024,
				e = 1024 * t,
				i = 1024 * e;
				this.value < e && this.total < e && (this.value = Math.round(this.value / t), this.total = Math.round(this.total / t), this.unit = "KB"),
				this.value < i && this.total < i ? (this.value = Math.round(this.value / e), this.total = Math.round(this.total / e), this.unit = "MB") : (this.value = (this.value / i).toFixed(2), this.total = (this.total / i).toFixed(2), this.unit = "GB")
			}
		},
		paint : function () {
			var t = Math.min(Math.max(this.value / this.total, 0), 1) || 0;
			this.labelElement.text(this.value + " / " + this.total + " " + this.unit),
			this.progressElement.width(100 * t + "%"),
			0 === this.total ? this.domElement.attr("data-state", "invalid") : t > .9 ? this.domElement.attr("data-state", "negative") : t > .7 ? this.domElement.attr("data-state", "warning") : this.domElement.attr("data-state", "positive")
		}
	});