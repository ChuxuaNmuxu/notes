import SL from './SL';
import './analytics';
import './draganddrop';
import './fonts';
import './keyboard';
import './locale';
import './pointer';
import './popup';
import './routes';
import './session';
import './settings';
import './visibility';
import './warnings';
import './util';
import './collections';
import './config';
import './components';
import './data';
import './helpers';
import './models';
import './views';
import './editor';

$(function () {
	function t() {
		e(),
		SL.helpers && SL.helpers.PageLoader.hide(),
		SL.settings.init(),
		SL.keyboard.init(),
		SL.pointer.init(),
		SL.warnings.init(),
		SL.draganddrop.init(),
		SL.fonts.init(),
		SL.visibility.init(),
		"undefined" == typeof SLConfig && (window.SLConfig = {}),
		i(),
		n()
	}
	function e() {
		var t = $("html");
		t.addClass("loaded"),
		SL.util.device.HAS_TOUCH && t.addClass("touch"),
		SL.util.device.isMac() ? t.addClass("ua-mac") : SL.util.device.isWindows() ? t.addClass("ua-windows") : SL.util.device.isLinux() && t.addClass("ua-linux"),
		SL.util.device.isChrome() ? t.addClass("ua-chrome") : SL.util.device.isSafari() ? t.addClass("ua-safari") : SL.util.device.isFirefox() ? t.addClass("ua-firefox") : SL.util.device.isIE() && t.addClass("ua-ie"),
		SL.util.device.getScrollBarWidth() > 0 && t.addClass("has-visible-scrollbars")
	}
	function i() {
		"object" == typeof window.SLConfig &&
		(
			SLConfig.deck && !SLConfig.deck.notes && (SLConfig.deck.notes = {}),
			SL.current_user = new SL.models.User(SLConfig.current_user),
			"object" == typeof SLConfig.deck && (SL.current_deck = new SL.models.Deck(SLConfig.deck)),
			"object" == typeof SLConfig.theme && (SL.current_theme = new SL.models.Theme(SLConfig.theme)),
			"object" == typeof SLConfig.team && (SL.current_team = new SL.models.Team(SLConfig.team))
		)
	}
	function n() {
		var t = $("html");
		SL.util.hideAddressBar(),
		t.hasClass("home index") && (SL.view = new SL.views.home.Index),
		SL.view = t.hasClass("home explore") ? new SL.views.home.Explore : t.hasClass("users show") ? new SL.views.users.Show : t.hasClass("decks show") ? new SL.views.decks.Show : t.hasClass("decks edit") ? new SL.editor.Editor : t.hasClass("decks edit-requires-upgrade") ? new SL.views.decks.EditRequiresUpgrade : t.hasClass("decks embed") ? new SL.views.decks.Embed : t.is(".decks.live-client") ? new SL.views.decks.LiveClient : t.is(".decks.live-server") ? new SL.views.decks.LiveServer : t.hasClass("speaker-view") ? new SL.views.decks.Speaker : t.hasClass("decks export") ? new SL.views.decks.Export : t.hasClass("decks fullscreen") ? new SL.views.decks.Fullscreen : t.hasClass("decks review") ? new SL.views.decks.Review : t.hasClass("decks password") ? new SL.views.decks.Password : t.hasClass("teams-subscriptions-show") ? new SL.views.teams.subscriptions.Show : t.hasClass("registrations") && (t.hasClass("edit") || t.hasClass("update")) ? new SL.views.devise.Edit : t.hasClass("registrations") || t.hasClass("team_registrations") || t.hasClass("sessions") || t.hasClass("passwords") || t.hasClass("invitations show") ? new SL.views.devise.All : t.hasClass("subscriptions new") || t.hasClass("subscriptions edit") ? new SL.views.subscriptions.New : t.hasClass("subscriptions show") ? new SL.views.subscriptions.Show : t.hasClass("subscriptions edit_period") ? new SL.views.subscriptions.EditPeriod : t.hasClass("teams-reactivate") ? new SL.views.teams.subscriptions.Reactivate : t.hasClass("teams-signup") ? new SL.views.teams.New : t.hasClass("teams edit") ? new SL.views.teams.teams.Edit : t.hasClass("teams edit_members") ? new SL.views.teams.teams.EditMembers : t.hasClass("teams show") ? new SL.views.teams.teams.Show : t.hasClass("themes edit") ? new SL.views.themes.Edit : t.hasClass("themes preview") ? new SL.views.themes.Preview : t.hasClass("pricing") ? new SL.views.statik.Pricing : t.hasClass("static") ? new SL.views.statik.All : new SL.views.Base,
		Placement.sync()
	}
	setTimeout(t, 1)
});

export default window.SL = SL;