import SL from './SL';

SL.fonts = {
	INIT_TIMEOUT : 5e3,
	FONTS_URL : SLConfig.fonts_url || "https://s3.amazonaws.com/static.slid.es/fonts/",
	FAMILIES : {
		montserrat : {
			id : "montserrat",
			name : "Montserrat",
			path : "montserrat/montserrat.css"
		},
		opensans : {
			id : "opensans",
			name : "Open Sans",
			path : "opensans/opensans.css"
		},
		lato : {
			id : "lato",
			name : "Lato",
			path : "lato/lato.css"
		},
		asul : {
			id : "asul",
			name : "Asul",
			path : "asul/asul.css"
		},
		josefinsans : {
			id : "josefinsans",
			name : "Josefin Sans",
			path : "josefinsans/josefinsans.css"
		},
		league : {
			id : "league",
			name : "League Gothic",
			path : "league/league_gothic.css"
		},
		merriweathersans : {
			id : "merriweathersans",
			name : "Merriweather Sans",
			path : "merriweathersans/merriweathersans.css"
		},
		overpass : {
			id : "overpass",
			name : "Overpass",
			path : "overpass/overpass.css"
		},
		overpass2 : {
			id : "overpass2",
			name : "Overpass 2",
			path : "overpass2/overpass2.css"
		},
		quicksand : {
			id : "quicksand",
			name : "Quicksand",
			path : "quicksand/quicksand.css"
		},
		cabinsketch : {
			id : "cabinsketch",
			name : "Cabin Sketch",
			path : "cabinsketch/cabinsketch.css"
		},
		newscycle : {
			id : "newscycle",
			name : "News Cycle",
			path : "newscycle/newscycle.css"
		},
		oxygen : {
			id : "oxygen",
			name : "Oxygen",
			path : "oxygen/oxygen.css"
		}
	},
	PACKAGES : {
		asul : ["asul"],
		helvetica : [],
		josefine : ["josefinsans", "lato"],
		league : ["league", "lato"],
		merriweather : ["merriweathersans", "oxygen"],
		news : ["newscycle", "lato"],
		montserrat : ["montserrat", "opensans"],
		opensans : ["opensans"],
		overpass : ["overpass"],
		overpass2 : ["overpass2"],
		palatino : [],
		quicksand : ["quicksand", "opensans"],
		sketch : ["cabinsketch", "oxygen"]
	},
	init : function () {
		if (this._isReady = !1, this.ready = new signals.Signal, this.loaded = new signals.Signal, this.fontactive = new signals.Signal, this.fontinactive = new signals.Signal, this.debugMode = !!SL.util.getQuery().debug, $("link[data-application-font]").each(function () {
				var t = $(this).attr("data-application-font");
				SL.fonts.FAMILIES[t] && (SL.fonts.FAMILIES[t].loaded = !0)
			}), SLConfig && SLConfig.deck) {
			var t = this.loadDeckFont([SLConfig.deck.theme_font || SL.config.DEFAULT_THEME_FONT], {
					active : this.onInitialFontsActive.bind(this),
					inactive : this.onInitialFontsInactive.bind(this)
				});
			t ? this.initTimeout = setTimeout(function () {
					this.debugMode && console.log("SL.fonts", "timed out"),
					this.finishLoading()
				}
					.bind(this), SL.fonts.INIT_TIMEOUT) : this.finishLoading()
		} else
			this.finishLoading()
	},
	load : function (t, e) {
		var i = $.extend({
				classes : !1,
				fontactive : this.onFontActive.bind(this),
				fontinactive : this.onFontInactive.bind(this),
				custom : {
					families : [],
					urls : []
				}
			},
				e);
		return t.forEach(function (t) {
			var e = SL.fonts.FAMILIES[t];
			e ? e.loaded ? "function" == typeof i.fontactive && i.fontactive(e.name) : (e.loaded = !0, i.custom.families.push(e.name), i.custom.urls.push(SL.fonts.FONTS_URL + e.path)) : console.warn('Could not find font family with id "' + t + '"')
		}),
		SLConfig && SLConfig.deck && (SLConfig.deck.font_typekit && (i.typekit = {
					id : SLConfig.deck.font_typekit
				}), SLConfig.deck.font_google && (i.google = i.google || {
					families : []
				},
				i.google.families = i.google.families.concat(SL.fonts.parseGoogleFontFamilies(SLConfig.deck.font_google)))),
		SLConfig && SLConfig.theme && (SLConfig.theme.font_typekit && (i.typekit = {
					id : SLConfig.theme.font_typekit
				}), SLConfig.theme.font_google && (i.google = i.google || {
					families : []
				},
				i.google.families = i.google.families.concat(SL.fonts.parseGoogleFontFamilies(SLConfig.theme.font_google)))),
		this.debugMode && console.log("SL.fonts.load", i.custom.families),
		i.custom.families.length || i.typekit || i.google ? (WebFont.load(i), !0) : !1
	},
	loadAll : function (t) {
		var e = [];
		for (var i in SL.fonts.FAMILIES)
			e.push(i);
		this.load(e, t)
	},
	loadDeckFont : function (t, e) {
		var i = SL.fonts.PACKAGES[t];
		return i ? SL.fonts.load(i, e) : !1
	},
	loadGoogleFont : function (t) {
		WebFont.load({
			google : {
				families : SL.fonts.parseGoogleFontFamilies(t)
			}
		})
	},
	loadTypekitFont : function (t) {
		WebFont.load({
			typekit : {
				id : t
			}
		})
	},
	parseGoogleFontFamilies : function (t) {
		return t = (t || "").trim().split(", "),
		t = t.map(function (t) {
				return t.trim().replace(/(^,)|(,$)/gi, "")
			}),
		t = t.filter(function (t) {
				return "string" == typeof t && t.length > 0
			})
	},
	unload : function (t) {
		t.forEach(function (t) {
			var e = SL.fonts.FAMILIES[t];
			e && (e.loaded = !1, $('link[href="' + SL.fonts.FONTS_URL + e.path + '"]').remove())
		})
	},
	finishLoading : function () {
		clearTimeout(this.initTimeout),
		$("html").addClass("fonts-are-ready"),
		this._isReady === !1 && (this._isReady = !0, this.ready.dispatch()),
		this.loaded.dispatch()
	},
	getPackageIDs : function () {
		return Object.keys(SL.fonts.PACKAGES)
	},
	getFamilyByName : function (t) {
		for (var e in SL.fonts.FAMILIES) {
			var i = SL.fonts.FAMILIES[e];
			if (t === i.name)
				return i
		}
	},
	isPackageLoaded : function (t) {
		var e = SL.fonts.PACKAGES[t];
		return e ? 0 === e.length ? !0 : e.every(function (t) {
			var e = SL.fonts.FAMILIES[t];
			return e.active || e.inactive
		}) : !0
	},
	isReady : function () {
		return this._isReady
	},
	onFontActive : function (t) {
		var e = SL.fonts.getFamilyByName(t);
		e && (e.active = !0),
		this.fontactive.dispatch(e)
	},
	onFontInactive : function (t) {
		var e = SL.fonts.getFamilyByName(t);
		e && (e.inactive = !0),
		this.fontinactive.dispatch(e)
	},
	onInitialFontsActive : function () {
		this.finishLoading()
	},
	onInitialFontsInactive : function () {
		this.finishLoading()
	}
};