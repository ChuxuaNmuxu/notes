import SL from './SL';

SL.visibility = {
	init : function () {
		this.changed = new signals.Signal,
		"undefined" != typeof document.hidden ? (this.hiddenProperty = "hidden", this.visibilityChangeEvent = "visibilitychange") : "undefined" != typeof document.msHidden ? (this.hiddenProperty = "msHidden", this.visibilityChangeEvent = "msvisibilitychange") : "undefined" != typeof document.webkitHidden && (this.hiddenProperty = "webkitHidden", this.visibilityChangeEvent = "webkitvisibilitychange"),
		this.supported = "boolean" == typeof document[this.hiddenProperty],
		this.supported && this.bind()
	},
	isVisible : function () {
		return this.supported ? !document[this.hiddenProperty] : !0
	},
	isHidden : function () {
		return this.supported ? document[this.hiddenProperty] : !1
	},
	bind : function () {
		document.addEventListener(this.visibilityChangeEvent, this.onVisibilityChange.bind(this))
	},
	onVisibilityChange : function () {
		this.changed.dispatch()
	}
};