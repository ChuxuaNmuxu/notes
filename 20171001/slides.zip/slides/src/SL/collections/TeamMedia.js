import SL from '../SL';

SL("collections").TeamMedia = SL.collections.Media.extend({
	init : function (t) {
		this._super(t, SL.models.Media, {
			list : SL.config.AJAX_TEAM_MEDIA_LIST,
			create : SL.config.AJAX_TEAM_MEDIA_CREATE,
			update : SL.config.AJAX_TEAM_MEDIA_UPDATE,
			"delete" : SL.config.AJAX_TEAM_MEDIA_DELETE
		})
	},
	createModelInstance : function (t) {
		return this._super(t, this.crud)
	}
});