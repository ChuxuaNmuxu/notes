import SL from '../../SL';

SL("collections.collab").Comments = SL.collections.Loadable.extend({
    init : function (t, e) {
        this._super(t, e || SL.models.collab.Comment, {
            list : SL.config.AJAX_COMMENTS_LIST(SL.current_deck.get("id")),
            create : SL.config.AJAX_COMMENTS_CREATE(SL.current_deck.get("id")),
            "delete" : SL.config.AJAX_COMMENTS_DELETE(SL.current_deck.get("id"))
        })
    },
    load : function (t) {
        return this.isLoading() ? void 0 : (this.url = t || this.crud.list, this.onLoadStarted(), new Promise(function (t, e) {
                this.loadXHR = $.ajax({
                        type : "GET",
                        url : this.url,
                        context : this
                    }).done(function (e) {
                        this.pagesLoaded = 1,
                        this.pagesTotal = 1,
                        e.total > e.results.length && (this.pagesTotal = Math.ceil(e.total / e.results.length)),
                        this.setData(e.results.reverse()),
                        this.pageOffsetID = this.isEmpty() ? null : this.first().get("id"),
                        this.loadXHR = null,
                        this.onLoadCompleted(),
                        t()
                    }).fail(function () {
                        this.loadXHR = null,
                        this.onLoadFailed(),
                        e()
                    })
            }
                .bind(this)))
    },
    hasNextPage : function () {
        return this.pagesLoaded < this.pagesTotal
    },
    loadNextPage : function () {
        return this.hasNextPage() ? new Promise(function (t, e) {
            $.ajax({
                type : "GET",
                url : this.url + "?page=" + this.pagesLoaded + "&offset_id=" + this.pageOffsetID,
                context : this
            }).done(function (e) {
                this.pagesLoaded += 1,
                t(this.prependData(e.results.reverse()))
            }).fail(function () {
                e()
            })
        }
            .bind(this)) : Promise.resolve([])
    },
    create : function (t, e) {
        e = $.extend({
                url : this.crud.create
            },
                e),
        e.model ? e.model.setState(SL.models.collab.Comment.STATE_SAVING) : e.model = this.createModel(t.comment);
        var i = JSON.parse(JSON.stringify(t));
        return delete i.comment.user_id,
        delete i.comment.created_at,
        this._super(i, e).then(function () {
            e.model.setState(SL.models.collab.Comment.STATE_SAVED)
        }
            .bind(this),
            function () {
            e.model.setState(SL.models.collab.Comment.STATE_FAILED)
        }
            .bind(this)),
        Promise.resolve(e.model)
    },
    retryCreate : function (t) {
        return this.create({
            comment : t.toJSON()
        }, {
            model : t
        })
    }
});