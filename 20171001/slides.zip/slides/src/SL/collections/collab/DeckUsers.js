import SL from '../../SL';

SL("collections.collab").DeckUsers = SL.collections.Loadable.extend({
    init : function (t, e, i) {
        this._super(t, e || SL.models.collab.DeckUser, i || {
            list : SL.config.AJAX_DECKUSER_LIST(SLConfig.deck.id),
            create : SL.config.AJAX_DECKUSER_CREATE(SLConfig.deck.id)
        })
    },
    load : function () {
        return this.isLoading() ? void 0 : (this.onLoadStarted(), new Promise(function (t, e) {
                $.ajax({
                    type : "GET",
                    url : this.crud.list,
                    context : this
                }).done(function (e) {
                    this.setData(e.results),
                    this.onLoadCompleted(),
                    t()
                }).fail(function () {
                    this.onLoadFailed(),
                    e()
                })
            }
                .bind(this)))
    },
    hasMoreThanOneEditor : function () {
        return this.getEditors().length > 1
    },
    hasMoreThanOnePresentEditor : function () {
        return this.getPresentEditors().length > 1
    },
    setEditing : function (t) {
        this.forEach(function (e) {
            e.set("editing", e.get("user_id") === t)
        })
    },
    getByUserID : function (t) {
        return this.getByProperties({
            user_id : t
        })
    },
    getEditors : function () {
        return this.filter(function (t) {
            return t.canEdit() && t.isActive()
        })
    },
    getPresentEditors : function () {
        return this.filter(function (t) {
            return t.canEdit() && t.isOnline()
        })
    }
});