import SL from '../SL';

SL("collections").Paginatable = SL.collections.Loadable.extend({
    init : function () {
        this._super.apply(this, arguments)
    },
    load : function (t) {
        return this.isLoading() ? void 0 : (this.listURL = t || this.crud.list, this.onLoadStarted(), new Promise(function (t, e) {
                this.loadXHR = $.ajax({
                        type : "GET",
                        url : this.listURL,
                        context : this
                    }).done(function (e) {
                        this.totalResults = e.total,
                        this.pagesLoaded = 1,
                        this.pagesTotal = 1,
                        e.total > e.results.length && (this.pagesTotal = Math.ceil(e.total / e.results.length)),
                        this.setData(e.results),
                        this.loadXHR = null,
                        this.onLoadCompleted(),
                        t()
                    }).fail(function () {
                        this.loadXHR = null,
                        this.onLoadFailed(),
                        e()
                    })
            }
                .bind(this)))
    },
    hasNextPage : function () {
        return this.pagesLoaded < this.pagesTotal
    },
    loadNextPage : function () {
        return this.hasNextPage() ? new Promise(function (t, e) {
            $.ajax({
                type : "GET",
                url : this.listURL + "?page=" + (this.pagesLoaded + 1),
                context : this
            }).done(function (e) {
                this.pagesLoaded += 1,
                t(this.appendData(e.results))
            }).fail(function () {
                e()
            })
        }
            .bind(this)) : Promise.resolve([])
    },
    getTotalResults : function () {
        return this.totalResults
    },
    getLoadedResults : function () {
        return this.size()
    }
});