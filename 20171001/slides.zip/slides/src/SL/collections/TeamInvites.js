import SL from '../SL';

SL("collections").TeamInvites = SL.collections.Paginatable.extend({
	init : function (t, e) {
		this._super(t, e || SL.models.Model, {
			list : SL.config.AJAX_TEAM_INVITATIONS_LIST
		})
	}
});