import SL from '../SL';

SL("collections").TeamMembers = SL.collections.Paginatable.extend({
	init : function (t, e) {
		this._super(t, e || SL.models.User, {
			list : SL.config.AJAX_TEAM_MEMBERS_LIST
		})
	}
});