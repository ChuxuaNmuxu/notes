import SL from '../SL';

SL("collections").TeamMediaTags = SL.collections.MediaTags.extend({
	init : function (t) {
		this._super(t, SL.models.MediaTag, {
			list : SL.config.AJAX_TEAM_MEDIA_TAG_LIST,
			create : SL.config.AJAX_TEAM_MEDIA_TAG_CREATE,
			update : SL.config.AJAX_TEAM_MEDIA_TAG_UPDATE,
			"delete" : SL.config.AJAX_TEAM_MEDIA_TAG_DELETE,
			add_media : SL.config.AJAX_TEAM_MEDIA_TAG_ADD_MEDIA,
			remove_media : SL.config.AJAX_TEAM_MEDIA_TAG_REMOVE_MEDIA
		})
	},
	createModelInstance : function (t) {
		return this._super(t, this.crud)
	}
});