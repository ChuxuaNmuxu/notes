import SL from '../SL';

SL("data").templates = {
	NEW_DECK_TEMPLATE : {
		html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 34%;">', '<div class="sl-block-content" data-placeholder-tag="h1" data-placeholder-text="Title Text">', "<h1>Title Text</h1>", "</div>", "</div>", "</section>"].join("")
	},
	DEFAULT_TEMPLATES : [{
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 38%;">', '<div class="sl-block-content" data-placeholder-tag="h1" data-placeholder-text="Title Text">', "<h1>Title Text</h1>", "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 27%;">', '<div class="sl-block-content" data-placeholder-tag="h1" data-placeholder-text="Title Text">', "<h1>Title Text</h1>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 37%;" data-layout-method="belowPreviousBlock">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Subtitle">', "<h2>Subtitle</h2>", "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 27%;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text">', "<h2>Title Text</h2>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 37%;" data-layout-method="belowPreviousBlock">', '<div class="sl-block-content">', "<ul>", "<li>Bullet One</li>", "<li>Bullet Two</li>", "<li>Bullet Three</li>", "</ul>", "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 40%; left: 5%; top: 15%; height: auto;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text" style="text-align: left;">', "<h2>Title Text</h2>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 40%; left: 5%; top: 30%; height: auto;">', '<div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis." style="text-align: left;">', "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis.</p>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 40%; left: 55%; top: 15%; height: auto;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text" style="text-align: left;">', "<h2>Title Text</h2>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 40%; left: 55%; top: 30%; height: auto;">', '<div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis." style="text-align: left;">', "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis.</p>", "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 90%; left: 30px; top: 58px; height: auto;">', '<div class="sl-block-content" data-placeholder-tag="h1" style="font-size: 200%; text-align: left;">', "<h1>One<br>Two<br>Three</h1>", "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 6%;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text">', "<h2>Title Text</h2>", "</div>", "</div>", '<div class="sl-block" data-block-type="image" style="width: 74%; height: 68%; left: 13%; top: 22%;">', '<div class="sl-block-content">', '<div class="editing-ui sl-block-overlay sl-block-placeholder"></div>', "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="text" style="width: 43%; left: 3%; top: 12%;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text" style="text-align: left;">', "<h2>Title Text</h2>", "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 43%; left: 3%; top: 24%;" data-layout-method="belowPreviousBlock">', '<div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi nec metus justo. Aliquam erat volutpat." style="z-index: 13; text-align: left;">', "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi nec metus justo. Aliquam erat volutpat.</p>", "</div>", "</div>", '<div class="sl-block" data-block-type="image" style="width: 47%; height: 90%; left: 50%; top: 5%;">', '<div class="sl-block-content">', '<div class="editing-ui sl-block-overlay sl-block-placeholder"></div>', "</div>", "</div>", "</section>"].join("")
		}, {
			html : ["<section>", '<div class="sl-block" data-block-type="image" style="width: 74%; height: 68%; left: 13%; top: 6%;">', '<div class="sl-block-content">', '<div class="editing-ui sl-block-overlay sl-block-placeholder"></div>', "</div>", "</div>", '<div class="sl-block" data-block-type="text" style="width: 84%; left: 8%; top: 82%;">', '<div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text">', "<h2>Title Text</h2>", "</div>", "</div>", "</section>"].join("")
		}
	],
	LAYOUT_METHODS : {
		belowPreviousBlock : function (t, e) {
			var i = e.prev().get(0);
			i && e.css("top", i.offsetTop + i.offsetHeight)
		},
		horizontalCenter : function (t, e) {
			e.css("left", .5 * (t.width() - e.width()))
		}
	},
	getNewDeckTemplate : function () {
		return new SL.models.Template(SL.data.templates.NEW_DECK_TEMPLATE)
	},
	getDefaultTemplates : function () {
		return new SL.collections.Collection(SL.data.templates.DEFAULT_TEMPLATES, SL.models.Template)
	},
	userTemplatesLoaded : !1,
	userTemplatesLoading : !1,
	userTemplatesCallbacks : [],
	getUserTemplates : function (t) {
		t = t ||
		function () {},
		SL.data.templates.userTemplatesLoading === !1 && SL.data.templates.userTemplatesLoaded === !1 ? (SL.data.templates.userTemplatesLoading = !0, SL.data.templates.userTemplatesCallbacks.push(t), $.ajax({
				type : "GET",
				url : SL.config.AJAX_SLIDE_TEMPLATES_LIST,
				context : this
			}).done(function (t) {
				SL.data.templates.userTemplates = new SL.collections.Collection(t.results, SL.models.Template),
				SL.data.templates.userTemplatesLoaded = !0,
				SL.data.templates.userTemplatesLoading = !1,
				SL.data.templates.userTemplatesCallbacks.forEach(function (t) {
					t.call(null, SL.data.templates.userTemplates)
				}),
				SL.data.templates.userTemplatesCallbacks.length = 0
			}).fail(function () {
				SL.data.templates.userTemplatesLoading = !1,
				SL.notify(SL.locale.get("TEMPLATE_LOAD_ERROR"), "negative")
			})) : SL.data.templates.userTemplatesLoading ? SL.data.templates.userTemplatesCallbacks.push(t) : t.call(null, SL.data.templates.userTemplates)
	},
	teamTemplatesLoaded : !1,
	teamTemplatesLoading : !1,
	teamTemplatesCallbacks : [],
	getTeamTemplates : function (t) {
		SL.current_user.isEnterprise() && (t = t ||
			function () {},
			SL.data.templates.teamTemplatesLoading === !1 && SL.data.templates.teamTemplatesLoaded === !1 ? (SL.data.templates.teamTemplatesLoading = !0, SL.data.templates.teamTemplatesCallbacks.push(t), $.ajax({
					type : "GET",
					url : SL.config.AJAX_TEAM_SLIDE_TEMPLATES_LIST,
					context : this
				}).done(function (t) {
					SL.data.templates.teamTemplates = new SL.collections.Collection(t.results, SL.models.Template),
					SL.data.templates.teamTemplatesLoaded = !0,
					SL.data.templates.teamTemplatesLoading = !1,
					SL.data.templates.teamTemplatesCallbacks.forEach(function (t) {
						t.call(null, SL.data.templates.teamTemplates)
					}),
					SL.data.templates.teamTemplatesCallbacks.length = 0
				}).fail(function () {
					SL.data.templates.teamTemplatesLoading = !1,
					SL.notify(SL.locale.get("TEMPLATE_LOAD_ERROR"), "negative")
				})) : SL.data.templates.teamTemplatesLoading ? SL.data.templates.teamTemplatesCallbacks.push(t) : t.call(null, SL.data.templates.teamTemplates))
	},
	layoutTemplate : function (t, e) {
		t.find(".sl-block").each(function (i, n) {
			block = $(n);
			var s = block.attr("data-layout-method");
			s && s.split(",").forEach(function (i) {
				i = i.trim(),
				i.length && "function" == typeof SL.data.templates.LAYOUT_METHODS[i] && (e || block.removeAttr("data-layout-method"), SL.data.templates.LAYOUT_METHODS[i](t, block))
			}),
			e || /%/.test(n.style.width + n.style.height + n.style.left + n.style.top) && block.css({
				left : n.offsetLeft,
				top : n.offsetTop,
				width : "auto" === n.style.width ? "auto" : n.offsetWidth,
				height : "auto" === n.style.height ? "auto" : n.offsetHeight
			})
		})
	},
	templatize : function (t, e) {
		t = $(t),
		e = $.extend({
				placeholderText : !1,
				zIndex : !0
			},
				e);
		var i = SL.editor.controllers.Serialize.getSlideAsString(t, {
				templatize : !0,
				inner : !0
			}),
		n = $("<section>" + i + "</section>");
		return n.children().each(function (t, i) {
			i = $(i),
			i.css({
				"min-width" : "",
				"min-height" : ""
			});
			var n = i.find(".sl-block-content");
			if (e.placeholderText && "text" === i.attr("data-block-type") && 1 === n.children().length) {
				var s = $(n.children()[0]);
				s.is("h1, h2") ? (s.html("Title Text"), n.attr("data-placeholder-text", "Title Text")) : s.is("p") && n.attr("data-placeholder-text", s.text().trim())
			}
			e.zIndex === !1 && n.css("z-index", "")
		}),
		["class", "data-autoslide", "data-transition", "data-transition-speed", "data-background", "data-background-color", "data-background-image", "data-background-video", "data-background-iframe", "data-background-size", "data-background-position"].forEach(function (e) {
			t.attr(e) && n.attr(e, t.attr(e))
		}),
		n.removeClass("past present future"),
		n.prop("outerHTML").trim()
	},
	generateFullSizeImageBlock : function (t, e, i, n, s) {
		var o = Math.min(n / e, s / i),
		a = e * o,
		r = i * o,
		l = SL.util.deck.getSlideSize(),
		d = Math.round((l.width - a) / 2),
		c = Math.round((l.height - r) / 2);
		return ['<div class="sl-block" data-block-type="image" style="width: ' + a + "px; height: " + r + "px; left: " + d + "px; top: " + c + 'px;">', '<div class="sl-block-content">', '<img src="' + t + '" style="" data-natural-width="' + e + '" data-natural-height="' + i + '"/>', "</div>", "</div>"].join("")
	}
};