import SL from '../SL';

SL("data").tokens = {
	get : function (t, e) {
		e = e || {},
		this._addCallbacks(t, e.success, e.error),
		"object" == typeof this.cache[t] ? this._triggerSuccessCallback(t, this.cache[t]) : "loading" !== this.cache[t] && (this.cache[t] = "loading", $.ajax({
				type : "GET",
				context : this,
				url : SL.config.AJAX_ACCESS_TOKENS_LIST(t)
			}).done(function (e) {
				var i = new SL.collections.Collection(e.results, SL.models.AccessToken);
				this.cache[t] = i,
				this._triggerSuccessCallback(t, i)
			}).fail(function (e) {
				delete this.cache[t],
				this._triggerErrorCallback(t, e.status)
			}))
	},
	create : function (t) {
		return new Promise(function (e, i) {
			SL.data.tokens.get(t, {
				success : function (n) {
					$.ajax({
						type : "POST",
						context : this,
						url : SL.config.AJAX_ACCESS_TOKENS_CREATE(t),
						data : {
							access_token : {
								name : n.getUniqueName("Link", "name", !0)
							}
						}
					}).done(function (t) {
						n.create(t).then(e, i)
					}).fail(i)
				}
				.bind(this),
				error : function () {
					console.warn("Failed to load token collection for deck " + t),
					i()
				}
				.bind(this)
			})
		}
			.bind(this))
	},
	cache : {},
	callbacks : {},
	_addCallbacks : function (t, e, i) {
		this.callbacks[t] || (this.callbacks[t] = {
				success : [],
				error : []
			}),
		e && this.callbacks[t].success.push(e),
		i && this.callbacks[t].error.push(i)
	},
	_triggerSuccessCallback : function (t, e) {
		var i = this.callbacks[t];
		if (i) {
			for (; i.success.length; )
				i.success.pop().call(null, e);
			i.success = [],
			i.error = []
		}
	},
	_triggerErrorCallback : function (t, e) {
		var i = this.callbacks[t];
		if (i) {
			for (; i.error.length; )
				i.error.pop().call(null, e);
			i.success = [],
			i.error = []
		}
	}
};