import SL from '../SL';

SL.util.user = {
	isLoggedIn : function () {
		return "object" == typeof SLConfig && "object" == typeof SLConfig.current_user
	},
	isPseudoLoggedIn : function () {
		return "object" == typeof SLConfig && !!SLConfig.pseudo_signed_in
	}
};