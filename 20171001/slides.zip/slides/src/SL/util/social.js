import SL from '../SL';

SL.util.social = {
	getFacebookShareLink : function (t, e, i, n) {
		return "http://www.facebook.com/sharer.php?s=100&p[title]=" + encodeURIComponent(e) + "&p[summary]=" + encodeURIComponent(i) + "&p[url]=" + t + "&p[images][0]=" + n
	},
	getTwitterShareLink : function (t, e) {
		return "http://twitter.com/share?text=" + encodeURIComponent(e) + "&url=" + encodeURIComponent(t) + "&via=slides"
	},
	getGoogleShareLink : function (t) {
		return "https://plus.google.com/share?url=" + encodeURIComponent(t)
	}
};