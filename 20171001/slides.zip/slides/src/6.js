!function() {
    var t, e, i, n, s, o, a, r, l, d, c, h, u, p, m, f, g, v, b, S = [].slice,
    y = [].indexOf ||
    function(t) {
        for (var e = 0,
        i = this.length; i > e; e++) if (e in this && this[e] === t) return e;
        return - 1
    };
    t = jQuery,
    t.payment = {},
    t.payment.fn = {},
    t.fn.payment = function() {
        var e, i;
        return i = arguments[0],
        e = 2 <= arguments.length ? S.call(arguments, 1) : [],
        t.payment.fn[i].apply(this, e)
    },
    s = /(\d{1,4})/g,
    n = [{
        type: "maestro",
        pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
        format: s,
        length: [12, 13, 14, 15, 16, 17, 18, 19],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "dinersclub",
        pattern: /^(36|38|30[0-5])/,
        format: s,
        length: [14],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "laser",
        pattern: /^(6706|6771|6709)/,
        format: s,
        length: [16, 17, 18, 19],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "jcb",
        pattern: /^35/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "unionpay",
        pattern: /^62/,
        format: s,
        length: [16, 17, 18, 19],
        cvcLength: [3],
        luhn: !1
    },
    {
        type: "discover",
        pattern: /^(6011|65|64[4-9]|622)/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "mastercard",
        pattern: /^5[1-5]/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "amex",
        pattern: /^3[47]/,
        format: /(\d{1,4})(\d{1,6})?(\d{1,5})?/,
        length: [15],
        cvcLength: [3, 4],
        luhn: !0
    },
    {
        type: "visa",
        pattern: /^4/,
        format: s,
        length: [13, 14, 15, 16],
        cvcLength: [3],
        luhn: !0
    }],
    e = function(t) {
        var e, i, s;
        for (t = (t + "").replace(/\D/g, ""), i = 0, s = n.length; s > i; i++) if (e = n[i], e.pattern.test(t)) return e
    },
    i = function(t) {
        var e, i, s;
        for (i = 0, s = n.length; s > i; i++) if (e = n[i], e.type === t) return e
    },
    u = function(t) {
        var e, i, n, s, o, a;
        for (n = !0, s = 0, i = (t + "").split("").reverse(), o = 0, a = i.length; a > o; o++) e = i[o],
        e = parseInt(e, 10),
        (n = !n) && (e *= 2),
        e > 9 && (e -= 9),
        s += e;
        return s % 10 === 0
    },
    h = function(t) {
        var e;
        return null != t.prop("selectionStart") && t.prop("selectionStart") !== t.prop("selectionEnd") ? !0 : ("undefined" != typeof document && null !== document && null != (e = document.selection) && "function" == typeof e.createRange ? e.createRange().text: void 0) ? !0 : !1
    },
    p = function(e) {
        return setTimeout(function() {
            var i, n;
            return i = t(e.currentTarget),
            n = i.val(),
            n = t.payment.formatCardNumber(n),
            i.val(n)
        })
    },
    r = function(i) {
        var n, s, o, a, r, l, d;
        return o = String.fromCharCode(i.which),
        !/^\d+$/.test(o) || (n = t(i.currentTarget), d = n.val(), s = e(d + o), a = (d.replace(/\D/g, "") + o).length, l = 16, s && (l = s.length[s.length.length - 1]), a >= l || null != n.prop("selectionStart") && n.prop("selectionStart") !== d.length) ? void 0 : (r = s && "amex" === s.type ? /^(\d{4}|\d{4}\s\d{6})$/: /(?:^|\s)(\d{4})$/, r.test(d) ? (i.preventDefault(), n.val(d + " " + o)) : r.test(d + o) ? (i.preventDefault(), n.val(d + o + " ")) : void 0)
    },
    o = function(e) {
        var i, n;
        return i = t(e.currentTarget),
        n = i.val(),
        e.meta || null != i.prop("selectionStart") && i.prop("selectionStart") !== n.length ? void 0 : 8 === e.which && /\s\d?$/.test(n) ? (e.preventDefault(), i.val(n.replace(/\s\d?$/, ""))) : void 0
    },
    l = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (i = t(e.currentTarget), s = i.val() + n, /^\d$/.test(s) && "0" !== s && "1" !== s ? (e.preventDefault(), i.val("0" + s + " / ")) : /^\d\d$/.test(s) ? (e.preventDefault(), i.val("" + s + " / ")) : void 0) : void 0
    },
    d = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (i = t(e.currentTarget), s = i.val(), /^\d\d$/.test(s) ? i.val("" + s + " / ") : void 0) : void 0
    },
    c = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        "/" === n ? (i = t(e.currentTarget), s = i.val(), /^\d$/.test(s) && "0" !== s ? i.val("0" + s + " / ") : void 0) : void 0
    },
    a = function(e) {
        var i, n;
        if (!e.meta && (i = t(e.currentTarget), n = i.val(), 8 === e.which && (null == i.prop("selectionStart") || i.prop("selectionStart") === n.length))) return /\s\/\s?\d?$/.test(n) ? (e.preventDefault(), i.val(n.replace(/\s\/\s?\d?$/, ""))) : void 0
    },
    v = function(t) {
        var e;
        return t.metaKey || t.ctrlKey ? !0 : 32 === t.which ? !1 : 0 === t.which ? !0 : t.which < 33 ? !0 : (e = String.fromCharCode(t.which), !!/[\d\s]/.test(e))
    },
    f = function(i) {
        var n, s, o, a;
        return n = t(i.currentTarget),
        o = String.fromCharCode(i.which),
        /^\d+$/.test(o) && !h(n) ? (a = (n.val() + o).replace(/\D/g, ""), s = e(a), s ? a.length <= s.length[s.length.length - 1] : a.length <= 16) : void 0
    },
    g = function(e) {
        var i, n, s;
        return i = t(e.currentTarget),
        n = String.fromCharCode(e.which),
        /^\d+$/.test(n) && !h(i) ? (s = i.val() + n, s = s.replace(/\D/g, ""), s.length > 6 ? !1 : void 0) : void 0
    },
    m = function(e) {
        var i, n, s;
        return i = t(e.currentTarget),
        n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (s = i.val() + n, s.length <= 4) : void 0
    },
    b = function(e) {
        var i, s, o, a, r;
        return i = t(e.currentTarget),
        r = i.val(),
        a = t.payment.cardType(r) || "unknown",
        i.hasClass(a) ? void 0 : (s = function() {
            var t, e, i;
            for (i = [], t = 0, e = n.length; e > t; t++) o = n[t],
            i.push(o.type);
            return i
        } (), i.removeClass("unknown"), i.removeClass(s.join(" ")), i.addClass(a), i.toggleClass("identified", "unknown" !== a), i.trigger("payment.cardType", a))
    },
    t.payment.fn.formatCardCVC = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", m),
        this
    },
    t.payment.fn.formatCardExpiry = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", g),
        this.on("keypress", l),
        this.on("keypress", c),
        this.on("keypress", d),
        this.on("keydown", a),
        this
    },
    t.payment.fn.formatCardNumber = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", f),
        this.on("keypress", r),
        this.on("keydown", o),
        this.on("keyup", b),
        this.on("paste", p),
        this
    },
    t.payment.fn.restrictNumeric = function() {
        return this.on("keypress", v),
        this
    },
    t.payment.fn.cardExpiryVal = function() {
        return t.payment.cardExpiryVal(t(this).val())
    },
    t.payment.cardExpiryVal = function(t) {
        var e, i, n, s;
        return t = t.replace(/\s/g, ""),
        s = t.split("/", 2),
        e = s[0],
        n = s[1],
        2 === (null != n ? n.length: void 0) && /^\d+$/.test(n) && (i = (new Date).getFullYear(), i = i.toString().slice(0, 2), n = i + n),
        e = parseInt(e, 10),
        n = parseInt(n, 10),
        {
            month: e,
            year: n
        }
    },
    t.payment.validateCardNumber = function(t) {
        var i, n;
        return t = (t + "").replace(/\s+|-/g, ""),
        /^\d+$/.test(t) ? (i = e(t), i ? (n = t.length, y.call(i.length, n) >= 0 && (i.luhn === !1 || u(t))) : !1) : !1
    },
    t.payment.validateCardExpiry = function(e, i) {
        var n, s, o, a;
        return "object" == typeof e && "month" in e && (a = e, e = a.month, i = a.year),
        e && i ? (e = t.trim(e), i = t.trim(i), /^\d+$/.test(e) && /^\d+$/.test(i) && parseInt(e, 10) <= 12 ? (2 === i.length && (o = (new Date).getFullYear(), o = o.toString().slice(0, 2), i = o + i), s = new Date(i, e), n = new Date, s.setMonth(s.getMonth() - 1), s.setMonth(s.getMonth() + 1, 1), s > n) : !1) : !1
    },
    t.payment.validateCardCVC = function(e, n) {
        var s, o;
        return e = t.trim(e),
        /^\d+$/.test(e) ? n ? (s = e.length, y.call(null != (o = i(n)) ? o.cvcLength: void 0, s) >= 0) : e.length >= 3 && e.length <= 4 : !1
    },
    t.payment.cardType = function(t) {
        var i;
        return t ? (null != (i = e(t)) ? i.type: void 0) || null: null
    },
    t.payment.formatCardNumber = function(t) {
        var i, n, s, o;
        return (i = e(t)) ? (s = i.length[i.length.length - 1], t = t.replace(/\D/g, ""), t = t.slice(0, +s + 1 || 9e9), i.format.global ? null != (o = t.match(i.format)) ? o.join(" ") : void 0 : (n = i.format.exec(t), null != n && n.shift(), null != n ? n.join(" ") : void 0)) : t
    }
}.call(this);