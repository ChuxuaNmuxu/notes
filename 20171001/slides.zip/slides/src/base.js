!
function(t, e, i) {
    function n(t, e) {
        return typeof t === e
    }
    function s() {
        var t, e, i, s, o, a, r;
        for (var l in b) {
            if (t = [], e = b[l], e.name && (t.push(e.name.toLowerCase()), e.options && e.options.aliases && e.options.aliases.length)) for (i = 0; i < e.options.aliases.length; i++) t.push(e.options.aliases[i].toLowerCase());
            for (s = n(e.fn, "function") ? e.fn() : e.fn, o = 0; o < t.length; o++) a = t[o],
            r = a.split("."),
            1 === r.length ? y[r[0]] = s: 2 === r.length && (!y[r[0]] || y[r[0]] instanceof Boolean || (y[r[0]] = new Boolean(y[r[0]])), y[r[0]][r[1]] = s),
            v.push((s ? "": "no-") + r.join("-"))
        }
    }
    function o(t) {
        var e = T.className,
        i = y._config.classPrefix || "",
        n = new RegExp("(^|\\s)" + i + "no-js(\\s|$)");
        e = e.replace(n, "$1" + i + "js$2"),
        y._config.enableClasses && (e += " " + i + t.join(" " + i), T.className = e)
    }
    function a() {
        var t = e.body;
        return t || (t = _("body"), t.fake = !0),
        t
    }
    function r(t, e, i, n) {
        var s, o, r, l, d = "modernizr",
        c = _("div"),
        h = a();
        if (parseInt(i, 10)) for (; i--;) r = _("div"),
        r.id = n ? n[i] : d + (i + 1),
        c.appendChild(r);
        return s = ["\xad", '<style id="s', d, '">', t, "</style>"].join(""),
        c.id = d,
        (h.fake ? h: c).innerHTML += s,
        h.appendChild(c),
        h.fake && (h.style.background = "", h.style.overflow = "hidden", l = T.style.overflow, T.style.overflow = "hidden", T.appendChild(h)),
        o = e(c, t),
        h.fake ? (h.parentNode.removeChild(h), T.style.overflow = l, T.offsetHeight) : c.parentNode.removeChild(c),
        !!o
    }
    function l(t, e) {
        return !! ~ ("" + t).indexOf(e)
    }
    function d(t) {
        return t.replace(/([a-z])-([a-z])/g,
        function(t, e, i) {
            return e + i.toUpperCase()
        }).replace(/^-/, "")
    }
    function c(t) {
        return t.replace(/([A-Z])/g,
        function(t, e) {
            return "-" + e.toLowerCase()
        }).replace(/^ms-/, "-ms-")
    }
    function h(e, n) {
        var s = e.length;
        if ("CSS" in t && "supports" in t.CSS) {
            for (; s--;) if (t.CSS.supports(c(e[s]), n)) return ! 0;
            return ! 1
        }
        if ("CSSSupportsRule" in t) {
            for (var o = []; s--;) o.push("(" + c(e[s]) + ":" + n + ")");
            return o = o.join(" or "),
            r("@supports (" + o + ") { #modernizr { position: absolute; } }",
            function(e) {
                return "absolute" == (t.getComputedStyle ? getComputedStyle(e, null) : e.currentStyle).position
            })
        }
        return i
    }
    function u(t, e, s, o) {
        function a() {
            d && (delete D.style, delete D.modElem)
        }
        if (o = n(o, "undefined") ? !1 : o, !n(s, "undefined")) {
            var r = h(t, s);
            if (!n(r, "undefined")) return r
        }
        var d, c, u, p;
        D.style || (d = !0, D.modElem = _("modernizr"), D.style = D.modElem.style);
        for (c in t) if (u = t[c], p = D.style[u], !l(u, "-") && D.style[u] !== i) {
            if (o || n(s, "undefined")) return a(),
            "pfx" == e ? u: !0;
            try {
                D.style[u] = s
            } catch(m) {}
            if (D.style[u] != p) return a(),
            "pfx" == e ? u: !0
        }
        return a(),
        !1
    }
    function p(t, e) {
        return function() {
            return t.apply(e, arguments)
        }
    }
    function m(t, e, i) {
        var s;
        for (var o in t) if (t[o] in e) return i === !1 ? t[o] : (s = e[t[o]], n(s, "function") ? p(s, i || e) : s);
        return ! 1
    }
    function f(t, e, i, s, o) {
        var a = t.charAt(0).toUpperCase() + t.slice(1),
        r = (t + " " + C.join(a + " ") + a).split(" ");
        return n(e, "string") || n(e, "undefined") ? u(r, e, s, o) : (r = (t + " " + w.join(a + " ") + a).split(" "), m(r, e, i))
    }
    function g(t, e, n) {
        return f(t, i, i, e, n)
    }
    var v = [],
    b = [],
    S = {
        _version: "v3.0.0pre",
        _config: {
            classPrefix: "mz-",
            enableClasses: !0,
            usePrefixes: !0
        },
        _q: [],
        on: function(t, e) {
            setTimeout(function() {
                e(this[t])
            },
            0)
        },
        addTest: function(t, e, i) {
            b.push({
                name: t,
                fn: e,
                options: i
            })
        },
        addAsyncTest: function(t) {
            b.push({
                name: null,
                fn: t
            })
        }
    },
    y = function() {};
    y.prototype = S,
    y = new y,
    y.addTest("applicationcache", "applicationCache" in t),
    y.addTest("history",
    function() {
        var e = navigator.userAgent;
        return - 1 === e.indexOf("Android 2.") && -1 === e.indexOf("Android 4.0") || -1 === e.indexOf("Mobile Safari") || -1 !== e.indexOf("Chrome") ? t.history && "pushState" in t.history: !1
    }),
    y.addTest("localstorage",
    function() {
        var t = "modernizr";
        try {
            return localStorage.setItem(t, t),
            localStorage.removeItem(t),
            !0
        } catch(e) {
            return ! 1
        }
    }),
    y.addTest("svg", !!e.createElementNS && !!e.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect);
    var E = S._config.usePrefixes ? " -webkit- -moz- -o- -ms- ".split(" ") : [];
    S._prefixes = E;
    var T = e.documentElement,
    L = "Webkit Moz O ms",
    w = S._config.usePrefixes ? L.toLowerCase().split(" ") : [];
    S._domPrefixes = w;
    var _ = function() {
        return e.createElement.apply(e, arguments)
    };
    y.addTest("opacity",
    function() {
        var t = _("div"),
        e = t.style;
        return e.cssText = E.join("opacity:.55;"),
        /^0.55$/.test(e.opacity)
    }),
    y.addTest("rgba",
    function() {
        var t = _("div"),
        e = t.style;
        return e.cssText = "background-color:rgba(150,255,150,.5)",
        ("" + e.backgroundColor).indexOf("rgba") > -1
    });
    var k = S.testStyles = r,
    C = S._config.usePrefixes ? L.split(" ") : [];
    S._cssomPrefixes = C;
    var A = {
        elem: _("modernizr")
    };
    y._q.push(function() {
        delete A.elem
    });
    var D = {
        style: A.elem.style
    };
    y._q.unshift(function() {
        delete D.style
    });
    S.testProp = function(t, e, n) {
        return u([t], i, e, n)
    };
    S.testAllProps = f,
    S.testAllProps = g,
    y.addTest("backgroundsize", g("backgroundSize", "100%", !0)),
    y.addTest("cssanimations", g("animationName", "a", !0)),
    y.addTest("csstransforms", g("transform", "scale(1)", !0)),
    y.addTest("csstransforms3d",
    function() {
        var t = !!g("perspective", "1px", !0),
        e = y._config.usePrefixes;
        if (t && (!e || "webkitPerspective" in T.style)) {
            var i = "@media (transform-3d)";
            e && (i += ",(-webkit-transform-3d)"),
            i += "{#modernizr{left:9px;position:absolute;height:5px;margin:0;padding:0;border:0}}",
            k(i,
            function(e) {
                t = 9 === e.offsetLeft && 5 === e.offsetHeight
            })
        }
        return t
    }),
    y.addTest("csstransitions", g("transition", "all", !0)),
    y.addTest("flexbox", g("flexBasis", "1px", !0)),
    y.addTest("flexboxlegacy", g("boxDirection", "reverse", !0));
    var I = S.prefixed = function(t, e, i) {
        return - 1 != t.indexOf("-") && (t = d(t)),
        e ? f(t, e, i) : f(t, "pfx")
    };
    y.addTest("fullscreen", !(!I("exitFullscreen", e, !1) && !I("cancelFullScreen", e, !1))),
    s(),
    o(v),
    delete S.addTest,
    delete S.addAsyncTest;
    for (var x = 0; x < y._q.length; x++) y._q[x]();
    t.Modernizr = y
} (this, document);
!function(t, e) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = t.document ? e(t, !0) : function(t) {
        if (!t.document) throw new Error("jQuery requires a window with a document");
        return e(t)
    }: e(t)
} ("undefined" != typeof window ? window: this,
function(t, e) {
    function i(t) {
        var e = t.length,
        i = se.type(t);
        return "function" === i || se.isWindow(t) ? !1 : 1 === t.nodeType && e ? !0 : "array" === i || 0 === e || "number" == typeof e && e > 0 && e - 1 in t
    }
    function n(t, e, i) {
        if (se.isFunction(e)) return se.grep(t,
        function(t, n) {
            return !! e.call(t, n, t) !== i
        });
        if (e.nodeType) return se.grep(t,
        function(t) {
            return t === e !== i
        });
        if ("string" == typeof e) {
            if (ue.test(e)) return se.filter(e, t, i);
            e = se.filter(e, t)
        }
        return se.grep(t,
        function(t) {
            return se.inArray(t, e) >= 0 !== i
        })
    }
    function s(t, e) {
        do t = t[e];
        while (t && 1 !== t.nodeType);
        return t
    }
    function o(t) {
        var e = ye[t] = {};
        return se.each(t.match(Se) || [],
        function(t, i) {
            e[i] = !0
        }),
        e
    }
    function a() {
        me.addEventListener ? (me.removeEventListener("DOMContentLoaded", r, !1), t.removeEventListener("load", r, !1)) : (me.detachEvent("onreadystatechange", r), t.detachEvent("onload", r))
    }
    function r() { (me.addEventListener || "load" === event.type || "complete" === me.readyState) && (a(), se.ready())
    }
    function l(t, e, i) {
        if (void 0 === i && 1 === t.nodeType) {
            var n = "data-" + e.replace(_e, "-$1").toLowerCase();
            if (i = t.getAttribute(n), "string" == typeof i) {
                try {
                    i = "true" === i ? !0 : "false" === i ? !1 : "null" === i ? null: +i + "" === i ? +i: we.test(i) ? se.parseJSON(i) : i
                } catch(s) {}
                se.data(t, e, i)
            } else i = void 0
        }
        return i
    }
    function d(t) {
        var e;
        for (e in t) if (("data" !== e || !se.isEmptyObject(t[e])) && "toJSON" !== e) return ! 1;
        return ! 0
    }
    function c(t, e, i, n) {
        if (se.acceptData(t)) {
            var s, o, a = se.expando,
            r = t.nodeType,
            l = r ? se.cache: t,
            d = r ? t[a] : t[a] && a;
            if (d && l[d] && (n || l[d].data) || void 0 !== i || "string" != typeof e) return d || (d = r ? t[a] = J.pop() || se.guid++:a),
            l[d] || (l[d] = r ? {}: {
                toJSON: se.noop
            }),
            ("object" == typeof e || "function" == typeof e) && (n ? l[d] = se.extend(l[d], e) : l[d].data = se.extend(l[d].data, e)),
            o = l[d],
            n || (o.data || (o.data = {}), o = o.data),
            void 0 !== i && (o[se.camelCase(e)] = i),
            "string" == typeof e ? (s = o[e], null == s && (s = o[se.camelCase(e)])) : s = o,
            s
        }
    }
    function h(t, e, i) {
        if (se.acceptData(t)) {
            var n, s, o = t.nodeType,
            a = o ? se.cache: t,
            r = o ? t[se.expando] : se.expando;
            if (a[r]) {
                if (e && (n = i ? a[r] : a[r].data)) {
                    se.isArray(e) ? e = e.concat(se.map(e, se.camelCase)) : e in n ? e = [e] : (e = se.camelCase(e), e = e in n ? [e] : e.split(" ")),
                    s = e.length;
                    for (; s--;) delete n[e[s]];
                    if (i ? !d(n) : !se.isEmptyObject(n)) return
                } (i || (delete a[r].data, d(a[r]))) && (o ? se.cleanData([t], !0) : ie.deleteExpando || a != a.window ? delete a[r] : a[r] = null)
            }
        }
    }
    function u() {
        return ! 0
    }
    function p() {
        return ! 1
    }
    function m() {
        try {
            return me.activeElement
        } catch(t) {}
    }
    function f(t) {
        var e = Pe.split("|"),
        i = t.createDocumentFragment();
        if (i.createElement) for (; e.length;) i.createElement(e.pop());
        return i
    }
    function g(t, e) {
        var i, n, s = 0,
        o = typeof t.getElementsByTagName !== Le ? t.getElementsByTagName(e || "*") : typeof t.querySelectorAll !== Le ? t.querySelectorAll(e || "*") : void 0;
        if (!o) for (o = [], i = t.childNodes || t; null != (n = i[s]); s++) ! e || se.nodeName(n, e) ? o.push(n) : se.merge(o, g(n, e));
        return void 0 === e || e && se.nodeName(t, e) ? se.merge([t], o) : o
    }
    function v(t) {
        Ie.test(t.type) && (t.defaultChecked = t.checked)
    }
    function b(t, e) {
        return se.nodeName(t, "table") && se.nodeName(11 !== e.nodeType ? e: e.firstChild, "tr") ? t.getElementsByTagName("tbody")[0] || t.appendChild(t.ownerDocument.createElement("tbody")) : t
    }
    function S(t) {
        return t.type = (null !== se.find.attr(t, "type")) + "/" + t.type,
        t
    }
    function y(t) {
        var e = We.exec(t.type);
        return e ? t.type = e[1] : t.removeAttribute("type"),
        t
    }
    function E(t, e) {
        for (var i, n = 0; null != (i = t[n]); n++) se._data(i, "globalEval", !e || se._data(e[n], "globalEval"))
    }
    function T(t, e) {
        if (1 === e.nodeType && se.hasData(t)) {
            var i, n, s, o = se._data(t),
            a = se._data(e, o),
            r = o.events;
            if (r) {
                delete a.handle,
                a.events = {};
                for (i in r) for (n = 0, s = r[i].length; s > n; n++) se.event.add(e, i, r[i][n])
            }
            a.data && (a.data = se.extend({},
            a.data))
        }
    }
    function L(t, e) {
        var i, n, s;
        if (1 === e.nodeType) {
            if (i = e.nodeName.toLowerCase(), !ie.noCloneEvent && e[se.expando]) {
                s = se._data(e);
                for (n in s.events) se.removeEvent(e, n, s.handle);
                e.removeAttribute(se.expando)
            }
            "script" === i && e.text !== t.text ? (S(e).text = t.text, y(e)) : "object" === i ? (e.parentNode && (e.outerHTML = t.outerHTML), ie.html5Clone && t.innerHTML && !se.trim(e.innerHTML) && (e.innerHTML = t.innerHTML)) : "input" === i && Ie.test(t.type) ? (e.defaultChecked = e.checked = t.checked, e.value !== t.value && (e.value = t.value)) : "option" === i ? e.defaultSelected = e.selected = t.defaultSelected: ("input" === i || "textarea" === i) && (e.defaultValue = t.defaultValue)
        }
    }
    function w(e, i) {
        var n, s = se(i.createElement(e)).appendTo(i.body),
        o = t.getDefaultComputedStyle && (n = t.getDefaultComputedStyle(s[0])) ? n.display: se.css(s[0], "display");
        return s.detach(),
        o
    }
    function _(t) {
        var e = me,
        i = Ze[t];
        return i || (i = w(t, e), "none" !== i && i || (Qe = (Qe || se("<iframe frameborder='0' width='0' height='0'/>")).appendTo(e.documentElement), e = (Qe[0].contentWindow || Qe[0].contentDocument).document, e.write(), e.close(), i = w(t, e), Qe.detach()), Ze[t] = i),
        i
    }
    function k(t, e) {
        return {
            get: function() {
                var i = t();
                if (null != i) return i ? void delete this.get: (this.get = e).apply(this, arguments)
            }
        }
    }
    function C(t, e) {
        if (e in t) return e;
        for (var i = e.charAt(0).toUpperCase() + e.slice(1), n = e, s = ui.length; s--;) if (e = ui[s] + i, e in t) return e;
        return n
    }
    function A(t, e) {
        for (var i, n, s, o = [], a = 0, r = t.length; r > a; a++) n = t[a],
        n.style && (o[a] = se._data(n, "olddisplay"), i = n.style.display, e ? (o[a] || "none" !== i || (n.style.display = ""), "" === n.style.display && Ae(n) && (o[a] = se._data(n, "olddisplay", _(n.nodeName)))) : (s = Ae(n), (i && "none" !== i || !s) && se._data(n, "olddisplay", s ? i: se.css(n, "display"))));
        for (a = 0; r > a; a++) n = t[a],
        n.style && (e && "none" !== n.style.display && "" !== n.style.display || (n.style.display = e ? o[a] || "": "none"));
        return t
    }
    function D(t, e, i) {
        var n = li.exec(e);
        return n ? Math.max(0, n[1] - (i || 0)) + (n[2] || "px") : e
    }
    function I(t, e, i, n, s) {
        for (var o = i === (n ? "border": "content") ? 4 : "width" === e ? 1 : 0, a = 0; 4 > o; o += 2)"margin" === i && (a += se.css(t, i + Ce[o], !0, s)),
        n ? ("content" === i && (a -= se.css(t, "padding" + Ce[o], !0, s)), "margin" !== i && (a -= se.css(t, "border" + Ce[o] + "Width", !0, s))) : (a += se.css(t, "padding" + Ce[o], !0, s), "padding" !== i && (a += se.css(t, "border" + Ce[o] + "Width", !0, s)));
        return a
    }
    function x(t, e, i) {
        var n = !0,
        s = "width" === e ? t.offsetWidth: t.offsetHeight,
        o = ti(t),
        a = ie.boxSizing && "border-box" === se.css(t, "boxSizing", !1, o);
        if (0 >= s || null == s) {
            if (s = ei(t, e, o), (0 > s || null == s) && (s = t.style[e]), ni.test(s)) return s;
            n = a && (ie.boxSizingReliable() || s === t.style[e]),
            s = parseFloat(s) || 0
        }
        return s + I(t, e, i || (a ? "border": "content"), n, o) + "px"
    }
    function M(t, e, i, n, s) {
        return new M.prototype.init(t, e, i, n, s)
    }
    function R() {
        return setTimeout(function() {
            pi = void 0
        }),
        pi = se.now()
    }
    function O(t, e) {
        var i, n = {
            height: t
        },
        s = 0;
        for (e = e ? 1 : 0; 4 > s; s += 2 - e) i = Ce[s],
        n["margin" + i] = n["padding" + i] = t;
        return e && (n.opacity = n.width = t),
        n
    }
    function N(t, e, i) {
        for (var n, s = (Si[e] || []).concat(Si["*"]), o = 0, a = s.length; a > o; o++) if (n = s[o].call(i, e, t)) return n
    }
    function P(t, e, i) {
        var n, s, o, a, r, l, d, c, h = this,
        u = {},
        p = t.style,
        m = t.nodeType && Ae(t),
        f = se._data(t, "fxshow");
        i.queue || (r = se._queueHooks(t, "fx"), null == r.unqueued && (r.unqueued = 0, l = r.empty.fire, r.empty.fire = function() {
            r.unqueued || l()
        }), r.unqueued++, h.always(function() {
            h.always(function() {
                r.unqueued--,
                se.queue(t, "fx").length || r.empty.fire()
            })
        })),
        1 === t.nodeType && ("height" in e || "width" in e) && (i.overflow = [p.overflow, p.overflowX, p.overflowY], d = se.css(t, "display"), c = "none" === d ? se._data(t, "olddisplay") || _(t.nodeName) : d, "inline" === c && "none" === se.css(t, "float") && (ie.inlineBlockNeedsLayout && "inline" !== _(t.nodeName) ? p.zoom = 1 : p.display = "inline-block")),
        i.overflow && (p.overflow = "hidden", ie.shrinkWrapBlocks() || h.always(function() {
            p.overflow = i.overflow[0],
            p.overflowX = i.overflow[1],
            p.overflowY = i.overflow[2]
        }));
        for (n in e) if (s = e[n], fi.exec(s)) {
            if (delete e[n], o = o || "toggle" === s, s === (m ? "hide": "show")) {
                if ("show" !== s || !f || void 0 === f[n]) continue;
                m = !0
            }
            u[n] = f && f[n] || se.style(t, n)
        } else d = void 0;
        if (se.isEmptyObject(u))"inline" === ("none" === d ? _(t.nodeName) : d) && (p.display = d);
        else {
            f ? "hidden" in f && (m = f.hidden) : f = se._data(t, "fxshow", {}),
            o && (f.hidden = !m),
            m ? se(t).show() : h.done(function() {
                se(t).hide()
            }),
            h.done(function() {
                var e;
                se._removeData(t, "fxshow");
                for (e in u) se.style(t, e, u[e])
            });
            for (n in u) a = N(m ? f[n] : 0, n, h),
            n in f || (f[n] = a.start, m && (a.end = a.start, a.start = "width" === n || "height" === n ? 1 : 0))
        }
    }
    function $(t, e) {
        var i, n, s, o, a;
        for (i in t) if (n = se.camelCase(i), s = e[n], o = t[i], se.isArray(o) && (s = o[1], o = t[i] = o[0]), i !== n && (t[n] = o, delete t[i]), a = se.cssHooks[n], a && "expand" in a) {
            o = a.expand(o),
            delete t[n];
            for (i in o) i in t || (t[i] = o[i], e[i] = s)
        } else e[n] = s
    }
    function U(t, e, i) {
        var n, s, o = 0,
        a = bi.length,
        r = se.Deferred().always(function() {
            delete l.elem
        }),
        l = function() {
            if (s) return ! 1;
            for (var e = pi || R(), i = Math.max(0, d.startTime + d.duration - e), n = i / d.duration || 0, o = 1 - n, a = 0, l = d.tweens.length; l > a; a++) d.tweens[a].run(o);
            return r.notifyWith(t, [d, o, i]),
            1 > o && l ? i: (r.resolveWith(t, [d]), !1)
        },
        d = r.promise({
            elem: t,
            props: se.extend({},
            e),
            opts: se.extend(!0, {
                specialEasing: {}
            },
            i),
            originalProperties: e,
            originalOptions: i,
            startTime: pi || R(),
            duration: i.duration,
            tweens: [],
            createTween: function(e, i) {
                var n = se.Tween(t, d.opts, e, i, d.opts.specialEasing[e] || d.opts.easing);
                return d.tweens.push(n),
                n
            },
            stop: function(e) {
                var i = 0,
                n = e ? d.tweens.length: 0;
                if (s) return this;
                for (s = !0; n > i; i++) d.tweens[i].run(1);
                return e ? r.resolveWith(t, [d, e]) : r.rejectWith(t, [d, e]),
                this
            }
        }),
        c = d.props;
        for ($(c, d.opts.specialEasing); a > o; o++) if (n = bi[o].call(d, t, c, d.opts)) return n;
        return se.map(c, N, d),
        se.isFunction(d.opts.start) && d.opts.start.call(t, d),
        se.fx.timer(se.extend(l, {
            elem: t,
            anim: d,
            queue: d.opts.queue
        })),
        d.progress(d.opts.progress).done(d.opts.done, d.opts.complete).fail(d.opts.fail).always(d.opts.always)
    }
    function F(t) {
        return function(e, i) {
            "string" != typeof e && (i = e, e = "*");
            var n, s = 0,
            o = e.toLowerCase().match(Se) || [];
            if (se.isFunction(i)) for (; n = o[s++];)"+" === n.charAt(0) ? (n = n.slice(1) || "*", (t[n] = t[n] || []).unshift(i)) : (t[n] = t[n] || []).push(i)
        }
    }
    function B(t, e, i, n) {
        function s(r) {
            var l;
            return o[r] = !0,
            se.each(t[r] || [],
            function(t, r) {
                var d = r(e, i, n);
                return "string" != typeof d || a || o[d] ? a ? !(l = d) : void 0 : (e.dataTypes.unshift(d), s(d), !1)
            }),
            l
        }
        var o = {},
        a = t === zi;
        return s(e.dataTypes[0]) || !o["*"] && s("*")
    }
    function H(t, e) {
        var i, n, s = se.ajaxSettings.flatOptions || {};
        for (n in e) void 0 !== e[n] && ((s[n] ? t: i || (i = {}))[n] = e[n]);
        return i && se.extend(!0, t, i),
        t
    }
    function j(t, e, i) {
        for (var n, s, o, a, r = t.contents,
        l = t.dataTypes;
        "*" === l[0];) l.shift(),
        void 0 === s && (s = t.mimeType || e.getResponseHeader("Content-Type"));
        if (s) for (a in r) if (r[a] && r[a].test(s)) {
            l.unshift(a);
            break
        }
        if (l[0] in i) o = l[0];
        else {
            for (a in i) {
                if (!l[0] || t.converters[a + " " + l[0]]) {
                    o = a;
                    break
                }
                n || (n = a)
            }
            o = o || n
        }
        return o ? (o !== l[0] && l.unshift(o), i[o]) : void 0
    }
    function z(t, e, i, n) {
        var s, o, a, r, l, d = {},
        c = t.dataTypes.slice();
        if (c[1]) for (a in t.converters) d[a.toLowerCase()] = t.converters[a];
        for (o = c.shift(); o;) if (t.responseFields[o] && (i[t.responseFields[o]] = e), !l && n && t.dataFilter && (e = t.dataFilter(e, t.dataType)), l = o, o = c.shift()) if ("*" === o) o = l;
        else if ("*" !== l && l !== o) {
            if (a = d[l + " " + o] || d["* " + o], !a) for (s in d) if (r = s.split(" "), r[1] === o && (a = d[l + " " + r[0]] || d["* " + r[0]])) {
                a === !0 ? a = d[s] : d[s] !== !0 && (o = r[0], c.unshift(r[1]));
                break
            }
            if (a !== !0) if (a && t["throws"]) e = a(e);
            else try {
                e = a(e)
            } catch(h) {
                return {
                    state: "parsererror",
                    error: a ? h: "No conversion from " + l + " to " + o
                }
            }
        }
        return {
            state: "success",
            data: e
        }
    }
    function V(t, e, i, n) {
        var s;
        if (se.isArray(e)) se.each(e,
        function(e, s) {
            i || Wi.test(t) ? n(t, s) : V(t + "[" + ("object" == typeof s ? e: "") + "]", s, i, n)
        });
        else if (i || "object" !== se.type(e)) n(t, e);
        else for (s in e) V(t + "[" + s + "]", e[s], i, n)
    }
    function X() {
        try {
            return new t.XMLHttpRequest
        } catch(e) {}
    }
    function G() {
        try {
            return new t.ActiveXObject("Microsoft.XMLHTTP")
        } catch(e) {}
    }
    function W(t) {
        return se.isWindow(t) ? t: 9 === t.nodeType ? t.defaultView || t.parentWindow: !1
    }
    var J = [],
    Y = J.slice,
    K = J.concat,
    q = J.push,
    Q = J.indexOf,
    Z = {},
    te = Z.toString,
    ee = Z.hasOwnProperty,
    ie = {},
    ne = "1.11.1",
    se = function(t, e) {
        return new se.fn.init(t, e)
    },
    oe = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
    ae = /^-ms-/,
    re = /-([\da-z])/gi,
    le = function(t, e) {
        return e.toUpperCase()
    };
    se.fn = se.prototype = {
        jquery: ne,
        constructor: se,
        selector: "",
        length: 0,
        toArray: function() {
            return Y.call(this)
        },
        get: function(t) {
            return null != t ? 0 > t ? this[t + this.length] : this[t] : Y.call(this)
        },
        pushStack: function(t) {
            var e = se.merge(this.constructor(), t);
            return e.prevObject = this,
            e.context = this.context,
            e
        },
        each: function(t, e) {
            return se.each(this, t, e)
        },
        map: function(t) {
            return this.pushStack(se.map(this,
            function(e, i) {
                return t.call(e, i, e)
            }))
        },
        slice: function() {
            return this.pushStack(Y.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq( - 1)
        },
        eq: function(t) {
            var e = this.length,
            i = +t + (0 > t ? e: 0);
            return this.pushStack(i >= 0 && e > i ? [this[i]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: q,
        sort: J.sort,
        splice: J.splice
    },
    se.extend = se.fn.extend = function() {
        var t, e, i, n, s, o, a = arguments[0] || {},
        r = 1,
        l = arguments.length,
        d = !1;
        for ("boolean" == typeof a && (d = a, a = arguments[r] || {},
        r++), "object" == typeof a || se.isFunction(a) || (a = {}), r === l && (a = this, r--); l > r; r++) if (null != (s = arguments[r])) for (n in s) t = a[n],
        i = s[n],
        a !== i && (d && i && (se.isPlainObject(i) || (e = se.isArray(i))) ? (e ? (e = !1, o = t && se.isArray(t) ? t: []) : o = t && se.isPlainObject(t) ? t: {},
        a[n] = se.extend(d, o, i)) : void 0 !== i && (a[n] = i));
        return a
    },
    se.extend({
        expando: "jQuery" + (ne + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(t) {
            throw new Error(t)
        },
        noop: function() {},
        isFunction: function(t) {
            return "function" === se.type(t)
        },
        isArray: Array.isArray ||
        function(t) {
            return "array" === se.type(t)
        },
        isWindow: function(t) {
            return null != t && t == t.window
        },
        isNumeric: function(t) {
            return ! se.isArray(t) && t - parseFloat(t) >= 0
        },
        isEmptyObject: function(t) {
            var e;
            for (e in t) return ! 1;
            return ! 0
        },
        isPlainObject: function(t) {
            var e;
            if (!t || "object" !== se.type(t) || t.nodeType || se.isWindow(t)) return ! 1;
            try {
                if (t.constructor && !ee.call(t, "constructor") && !ee.call(t.constructor.prototype, "isPrototypeOf")) return ! 1
            } catch(i) {
                return ! 1
            }
            if (ie.ownLast) for (e in t) return ee.call(t, e);
            for (e in t);
            return void 0 === e || ee.call(t, e)
        },
        type: function(t) {
            return null == t ? t + "": "object" == typeof t || "function" == typeof t ? Z[te.call(t)] || "object": typeof t
        },
        globalEval: function(e) {
            e && se.trim(e) && (t.execScript ||
            function(e) {
                t.eval.call(t, e)
            })(e)
        },
        camelCase: function(t) {
            return t.replace(ae, "ms-").replace(re, le)
        },
        nodeName: function(t, e) {
            return t.nodeName && t.nodeName.toLowerCase() === e.toLowerCase()
        },
        each: function(t, e, n) {
            var s, o = 0,
            a = t.length,
            r = i(t);
            if (n) {
                if (r) for (; a > o && (s = e.apply(t[o], n), s !== !1); o++);
                else for (o in t) if (s = e.apply(t[o], n), s === !1) break
            } else if (r) for (; a > o && (s = e.call(t[o], o, t[o]), s !== !1); o++);
            else for (o in t) if (s = e.call(t[o], o, t[o]), s === !1) break;
            return t
        },
        trim: function(t) {
            return null == t ? "": (t + "").replace(oe, "")
        },
        makeArray: function(t, e) {
            var n = e || [];
            return null != t && (i(Object(t)) ? se.merge(n, "string" == typeof t ? [t] : t) : q.call(n, t)),
            n
        },
        inArray: function(t, e, i) {
            var n;
            if (e) {
                if (Q) return Q.call(e, t, i);
                for (n = e.length, i = i ? 0 > i ? Math.max(0, n + i) : i: 0; n > i; i++) if (i in e && e[i] === t) return i
            }
            return - 1
        },
        merge: function(t, e) {
            for (var i = +e.length,
            n = 0,
            s = t.length; i > n;) t[s++] = e[n++];
            if (i !== i) for (; void 0 !== e[n];) t[s++] = e[n++];
            return t.length = s,
            t
        },
        grep: function(t, e, i) {
            for (var n, s = [], o = 0, a = t.length, r = !i; a > o; o++) n = !e(t[o], o),
            n !== r && s.push(t[o]);
            return s
        },
        map: function(t, e, n) {
            var s, o = 0,
            a = t.length,
            r = i(t),
            l = [];
            if (r) for (; a > o; o++) s = e(t[o], o, n),
            null != s && l.push(s);
            else for (o in t) s = e(t[o], o, n),
            null != s && l.push(s);
            return K.apply([], l)
        },
        guid: 1,
        proxy: function(t, e) {
            var i, n, s;
            return "string" == typeof e && (s = t[e], e = t, t = s),
            se.isFunction(t) ? (i = Y.call(arguments, 2), n = function() {
                return t.apply(e || this, i.concat(Y.call(arguments)))
            },
            n.guid = t.guid = t.guid || se.guid++, n) : void 0
        },
        now: function() {
            return + new Date
        },
        support: ie
    }),
    se.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),
    function(t, e) {
        Z["[object " + e + "]"] = e.toLowerCase()
    });
    var de = function(t) {
        function e(t, e, i, n) {
            var s, o, a, r, l, d, h, p, m, f;
            if ((e ? e.ownerDocument || e: B) !== M && x(e), e = e || M, i = i || [], !t || "string" != typeof t) return i;
            if (1 !== (r = e.nodeType) && 9 !== r) return [];
            if (O && !n) {
                if (s = be.exec(t)) if (a = s[1]) {
                    if (9 === r) {
                        if (o = e.getElementById(a), !o || !o.parentNode) return i;
                        if (o.id === a) return i.push(o),
                        i
                    } else if (e.ownerDocument && (o = e.ownerDocument.getElementById(a)) && U(e, o) && o.id === a) return i.push(o),
                    i
                } else {
                    if (s[2]) return Z.apply(i, e.getElementsByTagName(t)),
                    i;
                    if ((a = s[3]) && E.getElementsByClassName && e.getElementsByClassName) return Z.apply(i, e.getElementsByClassName(a)),
                    i
                }
                if (E.qsa && (!N || !N.test(t))) {
                    if (p = h = F, m = e, f = 9 === r && t, 1 === r && "object" !== e.nodeName.toLowerCase()) {
                        for (d = _(t), (h = e.getAttribute("id")) ? p = h.replace(ye, "\\$&") : e.setAttribute("id", p), p = "[id='" + p + "'] ", l = d.length; l--;) d[l] = p + u(d[l]);
                        m = Se.test(t) && c(e.parentNode) || e,
                        f = d.join(",")
                    }
                    if (f) try {
                        return Z.apply(i, m.querySelectorAll(f)),
                        i
                    } catch(g) {} finally {
                        h || e.removeAttribute("id")
                    }
                }
            }
            return C(t.replace(le, "$1"), e, i, n)
        }
        function i() {
            function t(i, n) {
                return e.push(i + " ") > T.cacheLength && delete t[e.shift()],
                t[i + " "] = n
            }
            var e = [];
            return t
        }
        function n(t) {
            return t[F] = !0,
            t
        }
        function s(t) {
            var e = M.createElement("div");
            try {
                return !! t(e)
            } catch(i) {
                return ! 1
            } finally {
                e.parentNode && e.parentNode.removeChild(e),
                e = null
            }
        }
        function o(t, e) {
            for (var i = t.split("|"), n = t.length; n--;) T.attrHandle[i[n]] = e
        }
        function a(t, e) {
            var i = e && t,
            n = i && 1 === t.nodeType && 1 === e.nodeType && (~e.sourceIndex || J) - (~t.sourceIndex || J);
            if (n) return n;
            if (i) for (; i = i.nextSibling;) if (i === e) return - 1;
            return t ? 1 : -1
        }
        function r(t) {
            return function(e) {
                var i = e.nodeName.toLowerCase();
                return "input" === i && e.type === t
            }
        }
        function l(t) {
            return function(e) {
                var i = e.nodeName.toLowerCase();
                return ("input" === i || "button" === i) && e.type === t
            }
        }
        function d(t) {
            return n(function(e) {
                return e = +e,
                n(function(i, n) {
                    for (var s, o = t([], i.length, e), a = o.length; a--;) i[s = o[a]] && (i[s] = !(n[s] = i[s]))
                })
            })
        }
        function c(t) {
            return t && typeof t.getElementsByTagName !== W && t
        }
        function h() {}
        function u(t) {
            for (var e = 0,
            i = t.length,
            n = ""; i > e; e++) n += t[e].value;
            return n
        }
        function p(t, e, i) {
            var n = e.dir,
            s = i && "parentNode" === n,
            o = j++;
            return e.first ?
            function(e, i, o) {
                for (; e = e[n];) if (1 === e.nodeType || s) return t(e, i, o)
            }: function(e, i, a) {
                var r, l, d = [H, o];
                if (a) {
                    for (; e = e[n];) if ((1 === e.nodeType || s) && t(e, i, a)) return ! 0
                } else for (; e = e[n];) if (1 === e.nodeType || s) {
                    if (l = e[F] || (e[F] = {}), (r = l[n]) && r[0] === H && r[1] === o) return d[2] = r[2];
                    if (l[n] = d, d[2] = t(e, i, a)) return ! 0
                }
            }
        }
        function m(t) {
            return t.length > 1 ?
            function(e, i, n) {
                for (var s = t.length; s--;) if (!t[s](e, i, n)) return ! 1;
                return ! 0
            }: t[0]
        }
        function f(t, i, n) {
            for (var s = 0,
            o = i.length; o > s; s++) e(t, i[s], n);
            return n
        }
        function g(t, e, i, n, s) {
            for (var o, a = [], r = 0, l = t.length, d = null != e; l > r; r++)(o = t[r]) && (!i || i(o, n, s)) && (a.push(o), d && e.push(r));
            return a
        }
        function v(t, e, i, s, o, a) {
            return s && !s[F] && (s = v(s)),
            o && !o[F] && (o = v(o, a)),
            n(function(n, a, r, l) {
                var d, c, h, u = [],
                p = [],
                m = a.length,
                v = n || f(e || "*", r.nodeType ? [r] : r, []),
                b = !t || !n && e ? v: g(v, u, t, r, l),
                S = i ? o || (n ? t: m || s) ? [] : a: b;
                if (i && i(b, S, r, l), s) for (d = g(S, p), s(d, [], r, l), c = d.length; c--;)(h = d[c]) && (S[p[c]] = !(b[p[c]] = h));
                if (n) {
                    if (o || t) {
                        if (o) {
                            for (d = [], c = S.length; c--;)(h = S[c]) && d.push(b[c] = h);
                            o(null, S = [], d, l)
                        }
                        for (c = S.length; c--;)(h = S[c]) && (d = o ? ee.call(n, h) : u[c]) > -1 && (n[d] = !(a[d] = h))
                    }
                } else S = g(S === a ? S.splice(m, S.length) : S),
                o ? o(null, a, S, l) : Z.apply(a, S)
            })
        }
        function b(t) {
            for (var e, i, n, s = t.length,
            o = T.relative[t[0].type], a = o || T.relative[" "], r = o ? 1 : 0, l = p(function(t) {
                return t === e
            },
            a, !0), d = p(function(t) {
                return ee.call(e, t) > -1
            },
            a, !0), c = [function(t, i, n) {
                return ! o && (n || i !== A) || ((e = i).nodeType ? l(t, i, n) : d(t, i, n))
            }]; s > r; r++) if (i = T.relative[t[r].type]) c = [p(m(c), i)];
            else {
                if (i = T.filter[t[r].type].apply(null, t[r].matches), i[F]) {
                    for (n = ++r; s > n && !T.relative[t[n].type]; n++);
                    return v(r > 1 && m(c), r > 1 && u(t.slice(0, r - 1).concat({
                        value: " " === t[r - 2].type ? "*": ""
                    })).replace(le, "$1"), i, n > r && b(t.slice(r, n)), s > n && b(t = t.slice(n)), s > n && u(t))
                }
                c.push(i)
            }
            return m(c)
        }
        function S(t, i) {
            var s = i.length > 0,
            o = t.length > 0,
            a = function(n, a, r, l, d) {
                var c, h, u, p = 0,
                m = "0",
                f = n && [],
                v = [],
                b = A,
                S = n || o && T.find.TAG("*", d),
                y = H += null == b ? 1 : Math.random() || .1,
                E = S.length;
                for (d && (A = a !== M && a); m !== E && null != (c = S[m]); m++) {
                    if (o && c) {
                        for (h = 0; u = t[h++];) if (u(c, a, r)) {
                            l.push(c);
                            break
                        }
                        d && (H = y)
                    }
                    s && ((c = !u && c) && p--, n && f.push(c))
                }
                if (p += m, s && m !== p) {
                    for (h = 0; u = i[h++];) u(f, v, a, r);
                    if (n) {
                        if (p > 0) for (; m--;) f[m] || v[m] || (v[m] = q.call(l));
                        v = g(v)
                    }
                    Z.apply(l, v),
                    d && !n && v.length > 0 && p + i.length > 1 && e.uniqueSort(l)
                }
                return d && (H = y, A = b),
                f
            };
            return s ? n(a) : a
        }
        var y, E, T, L, w, _, k, C, A, D, I, x, M, R, O, N, P, $, U, F = "sizzle" + -new Date,
        B = t.document,
        H = 0,
        j = 0,
        z = i(),
        V = i(),
        X = i(),
        G = function(t, e) {
            return t === e && (I = !0),
            0
        },
        W = "undefined",
        J = 1 << 31,
        Y = {}.hasOwnProperty,
        K = [],
        q = K.pop,
        Q = K.push,
        Z = K.push,
        te = K.slice,
        ee = K.indexOf ||
        function(t) {
            for (var e = 0,
            i = this.length; i > e; e++) if (this[e] === t) return e;
            return - 1
        },
        ie = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
        ne = "[\\x20\\t\\r\\n\\f]",
        se = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
        oe = se.replace("w", "w#"),
        ae = "\\[" + ne + "*(" + se + ")(?:" + ne + "*([*^$|!~]?=)" + ne + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + oe + "))|)" + ne + "*\\]",
        re = ":(" + se + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + ae + ")*)|.*)\\)|)",
        le = new RegExp("^" + ne + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ne + "+$", "g"),
        de = new RegExp("^" + ne + "*," + ne + "*"),
        ce = new RegExp("^" + ne + "*([>+~]|" + ne + ")" + ne + "*"),
        he = new RegExp("=" + ne + "*([^\\]'\"]*?)" + ne + "*\\]", "g"),
        ue = new RegExp(re),
        pe = new RegExp("^" + oe + "$"),
        me = {
            ID: new RegExp("^#(" + se + ")"),
            CLASS: new RegExp("^\\.(" + se + ")"),
            TAG: new RegExp("^(" + se.replace("w", "w*") + ")"),
            ATTR: new RegExp("^" + ae),
            PSEUDO: new RegExp("^" + re),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ne + "*(even|odd|(([+-]|)(\\d*)n|)" + ne + "*(?:([+-]|)" + ne + "*(\\d+)|))" + ne + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + ie + ")$", "i"),
            needsContext: new RegExp("^" + ne + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ne + "*((?:-\\d)?\\d*)" + ne + "*\\)|)(?=[^-]|$)", "i")
        },
        fe = /^(?:input|select|textarea|button)$/i,
        ge = /^h\d$/i,
        ve = /^[^{]+\{\s*\[native \w/,
        be = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
        Se = /[+~]/,
        ye = /'|\\/g,
        Ee = new RegExp("\\\\([\\da-f]{1,6}" + ne + "?|(" + ne + ")|.)", "ig"),
        Te = function(t, e, i) {
            var n = "0x" + e - 65536;
            return n !== n || i ? e: 0 > n ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)
        };
        try {
            Z.apply(K = te.call(B.childNodes), B.childNodes),
            K[B.childNodes.length].nodeType
        } catch(Le) {
            Z = {
                apply: K.length ?
                function(t, e) {
                    Q.apply(t, te.call(e))
                }: function(t, e) {
                    for (var i = t.length,
                    n = 0; t[i++] = e[n++];);
                    t.length = i - 1
                }
            }
        }
        E = e.support = {},
        w = e.isXML = function(t) {
            var e = t && (t.ownerDocument || t).documentElement;
            return e ? "HTML" !== e.nodeName: !1
        },
        x = e.setDocument = function(t) {
            var e, i = t ? t.ownerDocument || t: B,
            n = i.defaultView;
            return i !== M && 9 === i.nodeType && i.documentElement ? (M = i, R = i.documentElement, O = !w(i), n && n !== n.top && (n.addEventListener ? n.addEventListener("unload",
            function() {
                x()
            },
            !1) : n.attachEvent && n.attachEvent("onunload",
            function() {
                x()
            })), E.attributes = s(function(t) {
                return t.className = "i",
                !t.getAttribute("className")
            }), E.getElementsByTagName = s(function(t) {
                return t.appendChild(i.createComment("")),
                !t.getElementsByTagName("*").length
            }), E.getElementsByClassName = ve.test(i.getElementsByClassName) && s(function(t) {
                return t.innerHTML = "<div class='a'></div><div class='a i'></div>",
                t.firstChild.className = "i",
                2 === t.getElementsByClassName("i").length
            }), E.getById = s(function(t) {
                return R.appendChild(t).id = F,
                !i.getElementsByName || !i.getElementsByName(F).length
            }), E.getById ? (T.find.ID = function(t, e) {
                if (typeof e.getElementById !== W && O) {
                    var i = e.getElementById(t);
                    return i && i.parentNode ? [i] : []
                }
            },
            T.filter.ID = function(t) {
                var e = t.replace(Ee, Te);
                return function(t) {
                    return t.getAttribute("id") === e
                }
            }) : (delete T.find.ID, T.filter.ID = function(t) {
                var e = t.replace(Ee, Te);
                return function(t) {
                    var i = typeof t.getAttributeNode !== W && t.getAttributeNode("id");
                    return i && i.value === e
                }
            }), T.find.TAG = E.getElementsByTagName ?
            function(t, e) {
                return typeof e.getElementsByTagName !== W ? e.getElementsByTagName(t) : void 0
            }: function(t, e) {
                var i, n = [],
                s = 0,
                o = e.getElementsByTagName(t);
                if ("*" === t) {
                    for (; i = o[s++];) 1 === i.nodeType && n.push(i);
                    return n
                }
                return o
            },
            T.find.CLASS = E.getElementsByClassName &&
            function(t, e) {
                return typeof e.getElementsByClassName !== W && O ? e.getElementsByClassName(t) : void 0
            },
            P = [], N = [], (E.qsa = ve.test(i.querySelectorAll)) && (s(function(t) {
                t.innerHTML = "<select msallowclip=''><option selected=''></option></select>",
                t.querySelectorAll("[msallowclip^='']").length && N.push("[*^$]=" + ne + "*(?:''|\"\")"),
                t.querySelectorAll("[selected]").length || N.push("\\[" + ne + "*(?:value|" + ie + ")"),
                t.querySelectorAll(":checked").length || N.push(":checked")
            }), s(function(t) {
                var e = i.createElement("input");
                e.setAttribute("type", "hidden"),
                t.appendChild(e).setAttribute("name", "D"),
                t.querySelectorAll("[name=d]").length && N.push("name" + ne + "*[*^$|!~]?="),
                t.querySelectorAll(":enabled").length || N.push(":enabled", ":disabled"),
                t.querySelectorAll("*,:x"),
                N.push(",.*:")
            })), (E.matchesSelector = ve.test($ = R.matches || R.webkitMatchesSelector || R.mozMatchesSelector || R.oMatchesSelector || R.msMatchesSelector)) && s(function(t) {
                E.disconnectedMatch = $.call(t, "div"),
                $.call(t, "[s!='']:x"),
                P.push("!=", re)
            }), N = N.length && new RegExp(N.join("|")), P = P.length && new RegExp(P.join("|")), e = ve.test(R.compareDocumentPosition), U = e || ve.test(R.contains) ?
            function(t, e) {
                var i = 9 === t.nodeType ? t.documentElement: t,
                n = e && e.parentNode;
                return t === n || !(!n || 1 !== n.nodeType || !(i.contains ? i.contains(n) : t.compareDocumentPosition && 16 & t.compareDocumentPosition(n)))
            }: function(t, e) {
                if (e) for (; e = e.parentNode;) if (e === t) return ! 0;
                return ! 1
            },
            G = e ?
            function(t, e) {
                if (t === e) return I = !0,
                0;
                var n = !t.compareDocumentPosition - !e.compareDocumentPosition;
                return n ? n: (n = (t.ownerDocument || t) === (e.ownerDocument || e) ? t.compareDocumentPosition(e) : 1, 1 & n || !E.sortDetached && e.compareDocumentPosition(t) === n ? t === i || t.ownerDocument === B && U(B, t) ? -1 : e === i || e.ownerDocument === B && U(B, e) ? 1 : D ? ee.call(D, t) - ee.call(D, e) : 0 : 4 & n ? -1 : 1)
            }: function(t, e) {
                if (t === e) return I = !0,
                0;
                var n, s = 0,
                o = t.parentNode,
                r = e.parentNode,
                l = [t],
                d = [e];
                if (!o || !r) return t === i ? -1 : e === i ? 1 : o ? -1 : r ? 1 : D ? ee.call(D, t) - ee.call(D, e) : 0;
                if (o === r) return a(t, e);
                for (n = t; n = n.parentNode;) l.unshift(n);
                for (n = e; n = n.parentNode;) d.unshift(n);
                for (; l[s] === d[s];) s++;
                return s ? a(l[s], d[s]) : l[s] === B ? -1 : d[s] === B ? 1 : 0
            },
            i) : M
        },
        e.matches = function(t, i) {
            return e(t, null, null, i)
        },
        e.matchesSelector = function(t, i) {
            if ((t.ownerDocument || t) !== M && x(t), i = i.replace(he, "='$1']"), !(!E.matchesSelector || !O || P && P.test(i) || N && N.test(i))) try {
                var n = $.call(t, i);
                if (n || E.disconnectedMatch || t.document && 11 !== t.document.nodeType) return n
            } catch(s) {}
            return e(i, M, null, [t]).length > 0
        },
        e.contains = function(t, e) {
            return (t.ownerDocument || t) !== M && x(t),
            U(t, e)
        },
        e.attr = function(t, e) { (t.ownerDocument || t) !== M && x(t);
            var i = T.attrHandle[e.toLowerCase()],
            n = i && Y.call(T.attrHandle, e.toLowerCase()) ? i(t, e, !O) : void 0;
            return void 0 !== n ? n: E.attributes || !O ? t.getAttribute(e) : (n = t.getAttributeNode(e)) && n.specified ? n.value: null
        },
        e.error = function(t) {
            throw new Error("Syntax error, unrecognized expression: " + t)
        },
        e.uniqueSort = function(t) {
            var e, i = [],
            n = 0,
            s = 0;
            if (I = !E.detectDuplicates, D = !E.sortStable && t.slice(0), t.sort(G), I) {
                for (; e = t[s++];) e === t[s] && (n = i.push(s));
                for (; n--;) t.splice(i[n], 1)
            }
            return D = null,
            t
        },
        L = e.getText = function(t) {
            var e, i = "",
            n = 0,
            s = t.nodeType;
            if (s) {
                if (1 === s || 9 === s || 11 === s) {
                    if ("string" == typeof t.textContent) return t.textContent;
                    for (t = t.firstChild; t; t = t.nextSibling) i += L(t)
                } else if (3 === s || 4 === s) return t.nodeValue
            } else for (; e = t[n++];) i += L(e);
            return i
        },
        T = e.selectors = {
            cacheLength: 50,
            createPseudo: n,
            match: me,
            attrHandle: {},
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(t) {
                    return t[1] = t[1].replace(Ee, Te),
                    t[3] = (t[3] || t[4] || t[5] || "").replace(Ee, Te),
                    "~=" === t[2] && (t[3] = " " + t[3] + " "),
                    t.slice(0, 4)
                },
                CHILD: function(t) {
                    return t[1] = t[1].toLowerCase(),
                    "nth" === t[1].slice(0, 3) ? (t[3] || e.error(t[0]), t[4] = +(t[4] ? t[5] + (t[6] || 1) : 2 * ("even" === t[3] || "odd" === t[3])), t[5] = +(t[7] + t[8] || "odd" === t[3])) : t[3] && e.error(t[0]),
                    t
                },
                PSEUDO: function(t) {
                    var e, i = !t[6] && t[2];
                    return me.CHILD.test(t[0]) ? null: (t[3] ? t[2] = t[4] || t[5] || "": i && ue.test(i) && (e = _(i, !0)) && (e = i.indexOf(")", i.length - e) - i.length) && (t[0] = t[0].slice(0, e), t[2] = i.slice(0, e)), t.slice(0, 3))
                }
            },
            filter: {
                TAG: function(t) {
                    var e = t.replace(Ee, Te).toLowerCase();
                    return "*" === t ?
                    function() {
                        return ! 0
                    }: function(t) {
                        return t.nodeName && t.nodeName.toLowerCase() === e
                    }
                },
                CLASS: function(t) {
                    var e = z[t + " "];
                    return e || (e = new RegExp("(^|" + ne + ")" + t + "(" + ne + "|$)")) && z(t,
                    function(t) {
                        return e.test("string" == typeof t.className && t.className || typeof t.getAttribute !== W && t.getAttribute("class") || "")
                    })
                },
                ATTR: function(t, i, n) {
                    return function(s) {
                        var o = e.attr(s, t);
                        return null == o ? "!=" === i: i ? (o += "", "=" === i ? o === n: "!=" === i ? o !== n: "^=" === i ? n && 0 === o.indexOf(n) : "*=" === i ? n && o.indexOf(n) > -1 : "$=" === i ? n && o.slice( - n.length) === n: "~=" === i ? (" " + o + " ").indexOf(n) > -1 : "|=" === i ? o === n || o.slice(0, n.length + 1) === n + "-": !1) : !0
                    }
                },
                CHILD: function(t, e, i, n, s) {
                    var o = "nth" !== t.slice(0, 3),
                    a = "last" !== t.slice( - 4),
                    r = "of-type" === e;
                    return 1 === n && 0 === s ?
                    function(t) {
                        return !! t.parentNode
                    }: function(e, i, l) {
                        var d, c, h, u, p, m, f = o !== a ? "nextSibling": "previousSibling",
                        g = e.parentNode,
                        v = r && e.nodeName.toLowerCase(),
                        b = !l && !r;
                        if (g) {
                            if (o) {
                                for (; f;) {
                                    for (h = e; h = h[f];) if (r ? h.nodeName.toLowerCase() === v: 1 === h.nodeType) return ! 1;
                                    m = f = "only" === t && !m && "nextSibling"
                                }
                                return ! 0
                            }
                            if (m = [a ? g.firstChild: g.lastChild], a && b) {
                                for (c = g[F] || (g[F] = {}), d = c[t] || [], p = d[0] === H && d[1], u = d[0] === H && d[2], h = p && g.childNodes[p]; h = ++p && h && h[f] || (u = p = 0) || m.pop();) if (1 === h.nodeType && ++u && h === e) {
                                    c[t] = [H, p, u];
                                    break
                                }
                            } else if (b && (d = (e[F] || (e[F] = {}))[t]) && d[0] === H) u = d[1];
                            else for (; (h = ++p && h && h[f] || (u = p = 0) || m.pop()) && ((r ? h.nodeName.toLowerCase() !== v: 1 !== h.nodeType) || !++u || (b && ((h[F] || (h[F] = {}))[t] = [H, u]), h !== e)););
                            return u -= s,
                            u === n || u % n === 0 && u / n >= 0
                        }
                    }
                },
                PSEUDO: function(t, i) {
                    var s, o = T.pseudos[t] || T.setFilters[t.toLowerCase()] || e.error("unsupported pseudo: " + t);
                    return o[F] ? o(i) : o.length > 1 ? (s = [t, t, "", i], T.setFilters.hasOwnProperty(t.toLowerCase()) ? n(function(t, e) {
                        for (var n, s = o(t, i), a = s.length; a--;) n = ee.call(t, s[a]),
                        t[n] = !(e[n] = s[a])
                    }) : function(t) {
                        return o(t, 0, s)
                    }) : o
                }
            },
            pseudos: {
                not: n(function(t) {
                    var e = [],
                    i = [],
                    s = k(t.replace(le, "$1"));
                    return s[F] ? n(function(t, e, i, n) {
                        for (var o, a = s(t, null, n, []), r = t.length; r--;)(o = a[r]) && (t[r] = !(e[r] = o))
                    }) : function(t, n, o) {
                        return e[0] = t,
                        s(e, null, o, i),
                        !i.pop()
                    }
                }),
                has: n(function(t) {
                    return function(i) {
                        return e(t, i).length > 0
                    }
                }),
                contains: n(function(t) {
                    return function(e) {
                        return (e.textContent || e.innerText || L(e)).indexOf(t) > -1
                    }
                }),
                lang: n(function(t) {
                    return pe.test(t || "") || e.error("unsupported lang: " + t),
                    t = t.replace(Ee, Te).toLowerCase(),
                    function(e) {
                        var i;
                        do
                        if (i = O ? e.lang: e.getAttribute("xml:lang") || e.getAttribute("lang")) return i = i.toLowerCase(),
                        i === t || 0 === i.indexOf(t + "-");
                        while ((e = e.parentNode) && 1 === e.nodeType);
                        return ! 1
                    }
                }),
                target: function(e) {
                    var i = t.location && t.location.hash;
                    return i && i.slice(1) === e.id
                },
                root: function(t) {
                    return t === R
                },
                focus: function(t) {
                    return t === M.activeElement && (!M.hasFocus || M.hasFocus()) && !!(t.type || t.href || ~t.tabIndex)
                },
                enabled: function(t) {
                    return t.disabled === !1
                },
                disabled: function(t) {
                    return t.disabled === !0
                },
                checked: function(t) {
                    var e = t.nodeName.toLowerCase();
                    return "input" === e && !!t.checked || "option" === e && !!t.selected
                },
                selected: function(t) {
                    return t.parentNode && t.parentNode.selectedIndex,
                    t.selected === !0
                },
                empty: function(t) {
                    for (t = t.firstChild; t; t = t.nextSibling) if (t.nodeType < 6) return ! 1;
                    return ! 0
                },
                parent: function(t) {
                    return ! T.pseudos.empty(t)
                },
                header: function(t) {
                    return ge.test(t.nodeName)
                },
                input: function(t) {
                    return fe.test(t.nodeName)
                },
                button: function(t) {
                    var e = t.nodeName.toLowerCase();
                    return "input" === e && "button" === t.type || "button" === e
                },
                text: function(t) {
                    var e;
                    return "input" === t.nodeName.toLowerCase() && "text" === t.type && (null == (e = t.getAttribute("type")) || "text" === e.toLowerCase())
                },
                first: d(function() {
                    return [0]
                }),
                last: d(function(t, e) {
                    return [e - 1]
                }),
                eq: d(function(t, e, i) {
                    return [0 > i ? i + e: i]
                }),
                even: d(function(t, e) {
                    for (var i = 0; e > i; i += 2) t.push(i);
                    return t
                }),
                odd: d(function(t, e) {
                    for (var i = 1; e > i; i += 2) t.push(i);
                    return t
                }),
                lt: d(function(t, e, i) {
                    for (var n = 0 > i ? i + e: i; --n >= 0;) t.push(n);
                    return t
                }),
                gt: d(function(t, e, i) {
                    for (var n = 0 > i ? i + e: i; ++n < e;) t.push(n);
                    return t
                })
            }
        },
        T.pseudos.nth = T.pseudos.eq;
        for (y in {
            radio: !0,
            checkbox: !0,
            file: !0,
            password: !0,
            image: !0
        }) T.pseudos[y] = r(y);
        for (y in {
            submit: !0,
            reset: !0
        }) T.pseudos[y] = l(y);
        return h.prototype = T.filters = T.pseudos,
        T.setFilters = new h,
        _ = e.tokenize = function(t, i) {
            var n, s, o, a, r, l, d, c = V[t + " "];
            if (c) return i ? 0 : c.slice(0);
            for (r = t, l = [], d = T.preFilter; r;) { (!n || (s = de.exec(r))) && (s && (r = r.slice(s[0].length) || r), l.push(o = [])),
                n = !1,
                (s = ce.exec(r)) && (n = s.shift(), o.push({
                    value: n,
                    type: s[0].replace(le, " ")
                }), r = r.slice(n.length));
                for (a in T.filter) ! (s = me[a].exec(r)) || d[a] && !(s = d[a](s)) || (n = s.shift(), o.push({
                    value: n,
                    type: a,
                    matches: s
                }), r = r.slice(n.length));
                if (!n) break
            }
            return i ? r.length: r ? e.error(t) : V(t, l).slice(0)
        },
        k = e.compile = function(t, e) {
            var i, n = [],
            s = [],
            o = X[t + " "];
            if (!o) {
                for (e || (e = _(t)), i = e.length; i--;) o = b(e[i]),
                o[F] ? n.push(o) : s.push(o);
                o = X(t, S(s, n)),
                o.selector = t
            }
            return o
        },
        C = e.select = function(t, e, i, n) {
            var s, o, a, r, l, d = "function" == typeof t && t,
            h = !n && _(t = d.selector || t);
            if (i = i || [], 1 === h.length) {
                if (o = h[0] = h[0].slice(0), o.length > 2 && "ID" === (a = o[0]).type && E.getById && 9 === e.nodeType && O && T.relative[o[1].type]) {
                    if (e = (T.find.ID(a.matches[0].replace(Ee, Te), e) || [])[0], !e) return i;
                    d && (e = e.parentNode),
                    t = t.slice(o.shift().value.length)
                }
                for (s = me.needsContext.test(t) ? 0 : o.length; s--&&(a = o[s], !T.relative[r = a.type]);) if ((l = T.find[r]) && (n = l(a.matches[0].replace(Ee, Te), Se.test(o[0].type) && c(e.parentNode) || e))) {
                    if (o.splice(s, 1), t = n.length && u(o), !t) return Z.apply(i, n),
                    i;
                    break
                }
            }
            return (d || k(t, h))(n, e, !O, i, Se.test(t) && c(e.parentNode) || e),
            i
        },
        E.sortStable = F.split("").sort(G).join("") === F,
        E.detectDuplicates = !!I,
        x(),
        E.sortDetached = s(function(t) {
            return 1 & t.compareDocumentPosition(M.createElement("div"))
        }),
        s(function(t) {
            return t.innerHTML = "<a href='#'></a>",
            "#" === t.firstChild.getAttribute("href")
        }) || o("type|href|height|width",
        function(t, e, i) {
            return i ? void 0 : t.getAttribute(e, "type" === e.toLowerCase() ? 1 : 2)
        }),
        E.attributes && s(function(t) {
            return t.innerHTML = "<input/>",
            t.firstChild.setAttribute("value", ""),
            "" === t.firstChild.getAttribute("value")
        }) || o("value",
        function(t, e, i) {
            return i || "input" !== t.nodeName.toLowerCase() ? void 0 : t.defaultValue
        }),
        s(function(t) {
            return null == t.getAttribute("disabled")
        }) || o(ie,
        function(t, e, i) {
            var n;
            return i ? void 0 : t[e] === !0 ? e.toLowerCase() : (n = t.getAttributeNode(e)) && n.specified ? n.value: null
        }),
        e
    } (t);
    se.find = de,
    se.expr = de.selectors,
    se.expr[":"] = se.expr.pseudos,
    se.unique = de.uniqueSort,
    se.text = de.getText,
    se.isXMLDoc = de.isXML,
    se.contains = de.contains;
    var ce = se.expr.match.needsContext,
    he = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
    ue = /^.[^:#\[\.,]*$/;
    se.filter = function(t, e, i) {
        var n = e[0];
        return i && (t = ":not(" + t + ")"),
        1 === e.length && 1 === n.nodeType ? se.find.matchesSelector(n, t) ? [n] : [] : se.find.matches(t, se.grep(e,
        function(t) {
            return 1 === t.nodeType
        }))
    },
    se.fn.extend({
        find: function(t) {
            var e, i = [],
            n = this,
            s = n.length;
            if ("string" != typeof t) return this.pushStack(se(t).filter(function() {
                for (e = 0; s > e; e++) if (se.contains(n[e], this)) return ! 0
            }));
            for (e = 0; s > e; e++) se.find(t, n[e], i);
            return i = this.pushStack(s > 1 ? se.unique(i) : i),
            i.selector = this.selector ? this.selector + " " + t: t,
            i
        },
        filter: function(t) {
            return this.pushStack(n(this, t || [], !1))
        },
        not: function(t) {
            return this.pushStack(n(this, t || [], !0))
        },
        is: function(t) {
            return !! n(this, "string" == typeof t && ce.test(t) ? se(t) : t || [], !1).length
        }
    });
    var pe, me = t.document,
    fe = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
    ge = se.fn.init = function(t, e) {
        var i, n;
        if (!t) return this;
        if ("string" == typeof t) {
            if (i = "<" === t.charAt(0) && ">" === t.charAt(t.length - 1) && t.length >= 3 ? [null, t, null] : fe.exec(t), !i || !i[1] && e) return ! e || e.jquery ? (e || pe).find(t) : this.constructor(e).find(t);
            if (i[1]) {
                if (e = e instanceof se ? e[0] : e, se.merge(this, se.parseHTML(i[1], e && e.nodeType ? e.ownerDocument || e: me, !0)), he.test(i[1]) && se.isPlainObject(e)) for (i in e) se.isFunction(this[i]) ? this[i](e[i]) : this.attr(i, e[i]);
                return this
            }
            if (n = me.getElementById(i[2]), n && n.parentNode) {
                if (n.id !== i[2]) return pe.find(t);
                this.length = 1,
                this[0] = n
            }
            return this.context = me,
            this.selector = t,
            this
        }
        return t.nodeType ? (this.context = this[0] = t, this.length = 1, this) : se.isFunction(t) ? "undefined" != typeof pe.ready ? pe.ready(t) : t(se) : (void 0 !== t.selector && (this.selector = t.selector, this.context = t.context), se.makeArray(t, this))
    };
    ge.prototype = se.fn,
    pe = se(me);
    var ve = /^(?:parents|prev(?:Until|All))/,
    be = {
        children: !0,
        contents: !0,
        next: !0,
        prev: !0
    };
    se.extend({
        dir: function(t, e, i) {
            for (var n = [], s = t[e]; s && 9 !== s.nodeType && (void 0 === i || 1 !== s.nodeType || !se(s).is(i));) 1 === s.nodeType && n.push(s),
            s = s[e];
            return n
        },
        sibling: function(t, e) {
            for (var i = []; t; t = t.nextSibling) 1 === t.nodeType && t !== e && i.push(t);
            return i
        }
    }),
    se.fn.extend({
        has: function(t) {
            var e, i = se(t, this),
            n = i.length;
            return this.filter(function() {
                for (e = 0; n > e; e++) if (se.contains(this, i[e])) return ! 0
            })
        },
        closest: function(t, e) {
            for (var i, n = 0,
            s = this.length,
            o = [], a = ce.test(t) || "string" != typeof t ? se(t, e || this.context) : 0; s > n; n++) for (i = this[n]; i && i !== e; i = i.parentNode) if (i.nodeType < 11 && (a ? a.index(i) > -1 : 1 === i.nodeType && se.find.matchesSelector(i, t))) {
                o.push(i);
                break
            }
            return this.pushStack(o.length > 1 ? se.unique(o) : o)
        },
        index: function(t) {
            return t ? "string" == typeof t ? se.inArray(this[0], se(t)) : se.inArray(t.jquery ? t[0] : t, this) : this[0] && this[0].parentNode ? this.first().prevAll().length: -1
        },
        add: function(t, e) {
            return this.pushStack(se.unique(se.merge(this.get(), se(t, e))))
        },
        addBack: function(t) {
            return this.add(null == t ? this.prevObject: this.prevObject.filter(t))
        }
    }),
    se.each({
        parent: function(t) {
            var e = t.parentNode;
            return e && 11 !== e.nodeType ? e: null
        },
        parents: function(t) {
            return se.dir(t, "parentNode")
        },
        parentsUntil: function(t, e, i) {
            return se.dir(t, "parentNode", i)
        },
        next: function(t) {
            return s(t, "nextSibling")
        },
        prev: function(t) {
            return s(t, "previousSibling")
        },
        nextAll: function(t) {
            return se.dir(t, "nextSibling")
        },
        prevAll: function(t) {
            return se.dir(t, "previousSibling")
        },
        nextUntil: function(t, e, i) {
            return se.dir(t, "nextSibling", i)
        },
        prevUntil: function(t, e, i) {
            return se.dir(t, "previousSibling", i)
        },
        siblings: function(t) {
            return se.sibling((t.parentNode || {}).firstChild, t)
        },
        children: function(t) {
            return se.sibling(t.firstChild)
        },
        contents: function(t) {
            return se.nodeName(t, "iframe") ? t.contentDocument || t.contentWindow.document: se.merge([], t.childNodes)
        }
    },
    function(t, e) {
        se.fn[t] = function(i, n) {
            var s = se.map(this, e, i);
            return "Until" !== t.slice( - 5) && (n = i),
            n && "string" == typeof n && (s = se.filter(n, s)),
            this.length > 1 && (be[t] || (s = se.unique(s)), ve.test(t) && (s = s.reverse())),
            this.pushStack(s)
        }
    });
    var Se = /\S+/g,
    ye = {};
    se.Callbacks = function(t) {
        t = "string" == typeof t ? ye[t] || o(t) : se.extend({},
        t);
        var e, i, n, s, a, r, l = [],
        d = !t.once && [],
        c = function(o) {
            for (i = t.memory && o, n = !0, a = r || 0, r = 0, s = l.length, e = !0; l && s > a; a++) if (l[a].apply(o[0], o[1]) === !1 && t.stopOnFalse) {
                i = !1;
                break
            }
            e = !1,
            l && (d ? d.length && c(d.shift()) : i ? l = [] : h.disable())
        },
        h = {
            add: function() {
                if (l) {
                    var n = l.length; !
                    function o(e) {
                        se.each(e,
                        function(e, i) {
                            var n = se.type(i);
                            "function" === n ? t.unique && h.has(i) || l.push(i) : i && i.length && "string" !== n && o(i)
                        })
                    } (arguments),
                    e ? s = l.length: i && (r = n, c(i))
                }
                return this
            },
            remove: function() {
                return l && se.each(arguments,
                function(t, i) {
                    for (var n; (n = se.inArray(i, l, n)) > -1;) l.splice(n, 1),
                    e && (s >= n && s--, a >= n && a--)
                }),
                this
            },
            has: function(t) {
                return t ? se.inArray(t, l) > -1 : !(!l || !l.length)
            },
            empty: function() {
                return l = [],
                s = 0,
                this
            },
            disable: function() {
                return l = d = i = void 0,
                this
            },
            disabled: function() {
                return ! l
            },
            lock: function() {
                return d = void 0,
                i || h.disable(),
                this
            },
            locked: function() {
                return ! d
            },
            fireWith: function(t, i) {
                return ! l || n && !d || (i = i || [], i = [t, i.slice ? i.slice() : i], e ? d.push(i) : c(i)),
                this
            },
            fire: function() {
                return h.fireWith(this, arguments),
                this
            },
            fired: function() {
                return !! n
            }
        };
        return h
    },
    se.extend({
        Deferred: function(t) {
            var e = [["resolve", "done", se.Callbacks("once memory"), "resolved"], ["reject", "fail", se.Callbacks("once memory"), "rejected"], ["notify", "progress", se.Callbacks("memory")]],
            i = "pending",
            n = {
                state: function() {
                    return i
                },
                always: function() {
                    return s.done(arguments).fail(arguments),
                    this
                },
                then: function() {
                    var t = arguments;
                    return se.Deferred(function(i) {
                        se.each(e,
                        function(e, o) {
                            var a = se.isFunction(t[e]) && t[e];
                            s[o[1]](function() {
                                var t = a && a.apply(this, arguments);
                                t && se.isFunction(t.promise) ? t.promise().done(i.resolve).fail(i.reject).progress(i.notify) : i[o[0] + "With"](this === n ? i.promise() : this, a ? [t] : arguments)
                            })
                        }),
                        t = null
                    }).promise()
                },
                promise: function(t) {
                    return null != t ? se.extend(t, n) : n
                }
            },
            s = {};
            return n.pipe = n.then,
            se.each(e,
            function(t, o) {
                var a = o[2],
                r = o[3];
                n[o[1]] = a.add,
                r && a.add(function() {
                    i = r
                },
                e[1 ^ t][2].disable, e[2][2].lock),
                s[o[0]] = function() {
                    return s[o[0] + "With"](this === s ? n: this, arguments),
                    this
                },
                s[o[0] + "With"] = a.fireWith
            }),
            n.promise(s),
            t && t.call(s, s),
            s
        },
        when: function(t) {
            var e, i, n, s = 0,
            o = Y.call(arguments),
            a = o.length,
            r = 1 !== a || t && se.isFunction(t.promise) ? a: 0,
            l = 1 === r ? t: se.Deferred(),
            d = function(t, i, n) {
                return function(s) {
                    i[t] = this,
                    n[t] = arguments.length > 1 ? Y.call(arguments) : s,
                    n === e ? l.notifyWith(i, n) : --r || l.resolveWith(i, n)
                }
            };
            if (a > 1) for (e = new Array(a), i = new Array(a), n = new Array(a); a > s; s++) o[s] && se.isFunction(o[s].promise) ? o[s].promise().done(d(s, n, o)).fail(l.reject).progress(d(s, i, e)) : --r;
            return r || l.resolveWith(n, o),
            l.promise()
        }
    });
    var Ee;
    se.fn.ready = function(t) {
        return se.ready.promise().done(t),
        this
    },
    se.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function(t) {
            t ? se.readyWait++:se.ready(!0)
        },
        ready: function(t) {
            if (t === !0 ? !--se.readyWait: !se.isReady) {
                if (!me.body) return setTimeout(se.ready);
                se.isReady = !0,
                t !== !0 && --se.readyWait > 0 || (Ee.resolveWith(me, [se]), se.fn.triggerHandler && (se(me).triggerHandler("ready"), se(me).off("ready")))
            }
        }
    }),
    se.ready.promise = function(e) {
        if (!Ee) if (Ee = se.Deferred(), "complete" === me.readyState) setTimeout(se.ready);
        else if (me.addEventListener) me.addEventListener("DOMContentLoaded", r, !1),
        t.addEventListener("load", r, !1);
        else {
            me.attachEvent("onreadystatechange", r),
            t.attachEvent("onload", r);
            var i = !1;
            try {
                i = null == t.frameElement && me.documentElement
            } catch(n) {}
            i && i.doScroll && !
            function s() {
                if (!se.isReady) {
                    try {
                        i.doScroll("left")
                    } catch(t) {
                        return setTimeout(s, 50)
                    }
                    a(),
                    se.ready()
                }
            } ()
        }
        return Ee.promise(e)
    };
    var Te, Le = "undefined";
    for (Te in se(ie)) break;
    ie.ownLast = "0" !== Te,
    ie.inlineBlockNeedsLayout = !1,
    se(function() {
        var t, e, i, n;
        i = me.getElementsByTagName("body")[0],
        i && i.style && (e = me.createElement("div"), n = me.createElement("div"), n.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", i.appendChild(n).appendChild(e), typeof e.style.zoom !== Le && (e.style.cssText = "display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1", ie.inlineBlockNeedsLayout = t = 3 === e.offsetWidth, t && (i.style.zoom = 1)), i.removeChild(n))
    }),
    function() {
        var t = me.createElement("div");
        if (null == ie.deleteExpando) {
            ie.deleteExpando = !0;
            try {
                delete t.test
            } catch(e) {
                ie.deleteExpando = !1
            }
        }
        t = null
    } (),
    se.acceptData = function(t) {
        var e = se.noData[(t.nodeName + " ").toLowerCase()],
        i = +t.nodeType || 1;
        return 1 !== i && 9 !== i ? !1 : !e || e !== !0 && t.getAttribute("classid") === e
    };
    var we = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    _e = /([A-Z])/g;
    se.extend({
        cache: {},
        noData: {
            "applet ": !0,
            "embed ": !0,
            "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function(t) {
            return t = t.nodeType ? se.cache[t[se.expando]] : t[se.expando],
            !!t && !d(t)
        },
        data: function(t, e, i) {
            return c(t, e, i)
        },
        removeData: function(t, e) {
            return h(t, e)
        },
        _data: function(t, e, i) {
            return c(t, e, i, !0)
        },
        _removeData: function(t, e) {
            return h(t, e, !0)
        }
    }),
    se.fn.extend({
        data: function(t, e) {
            var i, n, s, o = this[0],
            a = o && o.attributes;
            if (void 0 === t) {
                if (this.length && (s = se.data(o), 1 === o.nodeType && !se._data(o, "parsedAttrs"))) {
                    for (i = a.length; i--;) a[i] && (n = a[i].name, 0 === n.indexOf("data-") && (n = se.camelCase(n.slice(5)), l(o, n, s[n])));
                    se._data(o, "parsedAttrs", !0)
                }
                return s
            }
            return "object" == typeof t ? this.each(function() {
                se.data(this, t)
            }) : arguments.length > 1 ? this.each(function() {
                se.data(this, t, e)
            }) : o ? l(o, t, se.data(o, t)) : void 0
        },
        removeData: function(t) {
            return this.each(function() {
                se.removeData(this, t)
            })
        }
    }),
    se.extend({
        queue: function(t, e, i) {
            var n;
            return t ? (e = (e || "fx") + "queue", n = se._data(t, e), i && (!n || se.isArray(i) ? n = se._data(t, e, se.makeArray(i)) : n.push(i)), n || []) : void 0
        },
        dequeue: function(t, e) {
            e = e || "fx";
            var i = se.queue(t, e),
            n = i.length,
            s = i.shift(),
            o = se._queueHooks(t, e),
            a = function() {
                se.dequeue(t, e)
            };
            "inprogress" === s && (s = i.shift(), n--),
            s && ("fx" === e && i.unshift("inprogress"), delete o.stop, s.call(t, a, o)),
            !n && o && o.empty.fire()
        },
        _queueHooks: function(t, e) {
            var i = e + "queueHooks";
            return se._data(t, i) || se._data(t, i, {
                empty: se.Callbacks("once memory").add(function() {
                    se._removeData(t, e + "queue"),
                    se._removeData(t, i)
                })
            })
        }
    }),
    se.fn.extend({
        queue: function(t, e) {
            var i = 2;
            return "string" != typeof t && (e = t, t = "fx", i--),
            arguments.length < i ? se.queue(this[0], t) : void 0 === e ? this: this.each(function() {
                var i = se.queue(this, t, e);
                se._queueHooks(this, t),
                "fx" === t && "inprogress" !== i[0] && se.dequeue(this, t)
            })
        },
        dequeue: function(t) {
            return this.each(function() {
                se.dequeue(this, t)
            })
        },
        clearQueue: function(t) {
            return this.queue(t || "fx", [])
        },
        promise: function(t, e) {
            var i, n = 1,
            s = se.Deferred(),
            o = this,
            a = this.length,
            r = function() {--n || s.resolveWith(o, [o])
            };
            for ("string" != typeof t && (e = t, t = void 0), t = t || "fx"; a--;) i = se._data(o[a], t + "queueHooks"),
            i && i.empty && (n++, i.empty.add(r));
            return r(),
            s.promise(e)
        }
    });
    var ke = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    Ce = ["Top", "Right", "Bottom", "Left"],
    Ae = function(t, e) {
        return t = e || t,
        "none" === se.css(t, "display") || !se.contains(t.ownerDocument, t)
    },
    De = se.access = function(t, e, i, n, s, o, a) {
        var r = 0,
        l = t.length,
        d = null == i;
        if ("object" === se.type(i)) {
            s = !0;
            for (r in i) se.access(t, e, r, i[r], !0, o, a)
        } else if (void 0 !== n && (s = !0, se.isFunction(n) || (a = !0), d && (a ? (e.call(t, n), e = null) : (d = e, e = function(t, e, i) {
            return d.call(se(t), i)
        })), e)) for (; l > r; r++) e(t[r], i, a ? n: n.call(t[r], r, e(t[r], i)));
        return s ? t: d ? e.call(t) : l ? e(t[0], i) : o
    },
    Ie = /^(?:checkbox|radio)$/i; !
    function() {
        var t = me.createElement("input"),
        e = me.createElement("div"),
        i = me.createDocumentFragment();
        if (e.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", ie.leadingWhitespace = 3 === e.firstChild.nodeType, ie.tbody = !e.getElementsByTagName("tbody").length, ie.htmlSerialize = !!e.getElementsByTagName("link").length, ie.html5Clone = "<:nav></:nav>" !== me.createElement("nav").cloneNode(!0).outerHTML, t.type = "checkbox", t.checked = !0, i.appendChild(t), ie.appendChecked = t.checked, e.innerHTML = "<textarea>x</textarea>", ie.noCloneChecked = !!e.cloneNode(!0).lastChild.defaultValue, i.appendChild(e), e.innerHTML = "<input type='radio' checked='checked' name='t'/>", ie.checkClone = e.cloneNode(!0).cloneNode(!0).lastChild.checked, ie.noCloneEvent = !0, e.attachEvent && (e.attachEvent("onclick",
        function() {
            ie.noCloneEvent = !1
        }), e.cloneNode(!0).click()), null == ie.deleteExpando) {
            ie.deleteExpando = !0;
            try {
                delete e.test
            } catch(n) {
                ie.deleteExpando = !1
            }
        }
    } (),
    function() {
        var e, i, n = me.createElement("div");
        for (e in {
            submit: !0,
            change: !0,
            focusin: !0
        }) i = "on" + e,
        (ie[e + "Bubbles"] = i in t) || (n.setAttribute(i, "t"), ie[e + "Bubbles"] = n.attributes[i].expando === !1);
        n = null
    } ();
    var xe = /^(?:input|select|textarea)$/i,
    Me = /^key/,
    Re = /^(?:mouse|pointer|contextmenu)|click/,
    Oe = /^(?:focusinfocus|focusoutblur)$/,
    Ne = /^([^.]*)(?:\.(.+)|)$/;
    se.event = {
        global: {},
        add: function(t, e, i, n, s) {
            var o, a, r, l, d, c, h, u, p, m, f, g = se._data(t);
            if (g) {
                for (i.handler && (l = i, i = l.handler, s = l.selector), i.guid || (i.guid = se.guid++), (a = g.events) || (a = g.events = {}), (c = g.handle) || (c = g.handle = function(t) {
                    return typeof se === Le || t && se.event.triggered === t.type ? void 0 : se.event.dispatch.apply(c.elem, arguments)
                },
                c.elem = t), e = (e || "").match(Se) || [""], r = e.length; r--;) o = Ne.exec(e[r]) || [],
                p = f = o[1],
                m = (o[2] || "").split(".").sort(),
                p && (d = se.event.special[p] || {},
                p = (s ? d.delegateType: d.bindType) || p, d = se.event.special[p] || {},
                h = se.extend({
                    type: p,
                    origType: f,
                    data: n,
                    handler: i,
                    guid: i.guid,
                    selector: s,
                    needsContext: s && se.expr.match.needsContext.test(s),
                    namespace: m.join(".")
                },
                l), (u = a[p]) || (u = a[p] = [], u.delegateCount = 0, d.setup && d.setup.call(t, n, m, c) !== !1 || (t.addEventListener ? t.addEventListener(p, c, !1) : t.attachEvent && t.attachEvent("on" + p, c))), d.add && (d.add.call(t, h), h.handler.guid || (h.handler.guid = i.guid)), s ? u.splice(u.delegateCount++, 0, h) : u.push(h), se.event.global[p] = !0);
                t = null
            }
        },
        remove: function(t, e, i, n, s) {
            var o, a, r, l, d, c, h, u, p, m, f, g = se.hasData(t) && se._data(t);
            if (g && (c = g.events)) {
                for (e = (e || "").match(Se) || [""], d = e.length; d--;) if (r = Ne.exec(e[d]) || [], p = f = r[1], m = (r[2] || "").split(".").sort(), p) {
                    for (h = se.event.special[p] || {},
                    p = (n ? h.delegateType: h.bindType) || p, u = c[p] || [], r = r[2] && new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = o = u.length; o--;) a = u[o],
                    !s && f !== a.origType || i && i.guid !== a.guid || r && !r.test(a.namespace) || n && n !== a.selector && ("**" !== n || !a.selector) || (u.splice(o, 1), a.selector && u.delegateCount--, h.remove && h.remove.call(t, a));
                    l && !u.length && (h.teardown && h.teardown.call(t, m, g.handle) !== !1 || se.removeEvent(t, p, g.handle), delete c[p])
                } else for (p in c) se.event.remove(t, p + e[d], i, n, !0);
                se.isEmptyObject(c) && (delete g.handle, se._removeData(t, "events"))
            }
        },
        trigger: function(e, i, n, s) {
            var o, a, r, l, d, c, h, u = [n || me],
            p = ee.call(e, "type") ? e.type: e,
            m = ee.call(e, "namespace") ? e.namespace.split(".") : [];
            if (r = c = n = n || me, 3 !== n.nodeType && 8 !== n.nodeType && !Oe.test(p + se.event.triggered) && (p.indexOf(".") >= 0 && (m = p.split("."), p = m.shift(), m.sort()), a = p.indexOf(":") < 0 && "on" + p, e = e[se.expando] ? e: new se.Event(p, "object" == typeof e && e), e.isTrigger = s ? 2 : 3, e.namespace = m.join("."), e.namespace_re = e.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = n), i = null == i ? [e] : se.makeArray(i, [e]), d = se.event.special[p] || {},
            s || !d.trigger || d.trigger.apply(n, i) !== !1)) {
                if (!s && !d.noBubble && !se.isWindow(n)) {
                    for (l = d.delegateType || p, Oe.test(l + p) || (r = r.parentNode); r; r = r.parentNode) u.push(r),
                    c = r;
                    c === (n.ownerDocument || me) && u.push(c.defaultView || c.parentWindow || t)
                }
                for (h = 0; (r = u[h++]) && !e.isPropagationStopped();) e.type = h > 1 ? l: d.bindType || p,
                o = (se._data(r, "events") || {})[e.type] && se._data(r, "handle"),
                o && o.apply(r, i),
                o = a && r[a],
                o && o.apply && se.acceptData(r) && (e.result = o.apply(r, i), e.result === !1 && e.preventDefault());
                if (e.type = p, !s && !e.isDefaultPrevented() && (!d._default || d._default.apply(u.pop(), i) === !1) && se.acceptData(n) && a && n[p] && !se.isWindow(n)) {
                    c = n[a],
                    c && (n[a] = null),
                    se.event.triggered = p;
                    try {
                        n[p]()
                    } catch(f) {}
                    se.event.triggered = void 0,
                    c && (n[a] = c)
                }
                return e.result
            }
        },
        dispatch: function(t) {
            t = se.event.fix(t);
            var e, i, n, s, o, a = [],
            r = Y.call(arguments),
            l = (se._data(this, "events") || {})[t.type] || [],
            d = se.event.special[t.type] || {};
            if (r[0] = t, t.delegateTarget = this, !d.preDispatch || d.preDispatch.call(this, t) !== !1) {
                for (a = se.event.handlers.call(this, t, l), e = 0; (s = a[e++]) && !t.isPropagationStopped();) for (t.currentTarget = s.elem, o = 0; (n = s.handlers[o++]) && !t.isImmediatePropagationStopped();)(!t.namespace_re || t.namespace_re.test(n.namespace)) && (t.handleObj = n, t.data = n.data, i = ((se.event.special[n.origType] || {}).handle || n.handler).apply(s.elem, r), void 0 !== i && (t.result = i) === !1 && (t.preventDefault(), t.stopPropagation()));
                return d.postDispatch && d.postDispatch.call(this, t),
                t.result
            }
        },
        handlers: function(t, e) {
            var i, n, s, o, a = [],
            r = e.delegateCount,
            l = t.target;
            if (r && l.nodeType && (!t.button || "click" !== t.type)) for (; l != this; l = l.parentNode || this) if (1 === l.nodeType && (l.disabled !== !0 || "click" !== t.type)) {
                for (s = [], o = 0; r > o; o++) n = e[o],
                i = n.selector + " ",
                void 0 === s[i] && (s[i] = n.needsContext ? se(i, this).index(l) >= 0 : se.find(i, this, null, [l]).length),
                s[i] && s.push(n);
                s.length && a.push({
                    elem: l,
                    handlers: s
                })
            }
            return r < e.length && a.push({
                elem: this,
                handlers: e.slice(r)
            }),
            a
        },
        fix: function(t) {
            if (t[se.expando]) return t;
            var e, i, n, s = t.type,
            o = t,
            a = this.fixHooks[s];
            for (a || (this.fixHooks[s] = a = Re.test(s) ? this.mouseHooks: Me.test(s) ? this.keyHooks: {}), n = a.props ? this.props.concat(a.props) : this.props, t = new se.Event(o), e = n.length; e--;) i = n[e],
            t[i] = o[i];
            return t.target || (t.target = o.srcElement || me),
            3 === t.target.nodeType && (t.target = t.target.parentNode),
            t.metaKey = !!t.metaKey,
            a.filter ? a.filter(t, o) : t
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(t, e) {
                return null == t.which && (t.which = null != e.charCode ? e.charCode: e.keyCode),
                t
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(t, e) {
                var i, n, s, o = e.button,
                a = e.fromElement;
                return null == t.pageX && null != e.clientX && (n = t.target.ownerDocument || me, s = n.documentElement, i = n.body, t.pageX = e.clientX + (s && s.scrollLeft || i && i.scrollLeft || 0) - (s && s.clientLeft || i && i.clientLeft || 0), t.pageY = e.clientY + (s && s.scrollTop || i && i.scrollTop || 0) - (s && s.clientTop || i && i.clientTop || 0)),
                !t.relatedTarget && a && (t.relatedTarget = a === t.target ? e.toElement: a),
                t.which || void 0 === o || (t.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0),
                t
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    if (this !== m() && this.focus) try {
                        return this.focus(),
                        !1
                    } catch(t) {}
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    return this === m() && this.blur ? (this.blur(), !1) : void 0
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    return se.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : void 0
                },
                _default: function(t) {
                    return se.nodeName(t.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function(t) {
                    void 0 !== t.result && t.originalEvent && (t.originalEvent.returnValue = t.result)
                }
            }
        },
        simulate: function(t, e, i, n) {
            var s = se.extend(new se.Event, i, {
                type: t,
                isSimulated: !0,
                originalEvent: {}
            });
            n ? se.event.trigger(s, null, e) : se.event.dispatch.call(e, s),
            s.isDefaultPrevented() && i.preventDefault()
        }
    },
    se.removeEvent = me.removeEventListener ?
    function(t, e, i) {
        t.removeEventListener && t.removeEventListener(e, i, !1)
    }: function(t, e, i) {
        var n = "on" + e;
        t.detachEvent && (typeof t[n] === Le && (t[n] = null), t.detachEvent(n, i))
    },
    se.Event = function(t, e) {
        return this instanceof se.Event ? (t && t.type ? (this.originalEvent = t, this.type = t.type, this.isDefaultPrevented = t.defaultPrevented || void 0 === t.defaultPrevented && t.returnValue === !1 ? u: p) : this.type = t, e && se.extend(this, e), this.timeStamp = t && t.timeStamp || se.now(), void(this[se.expando] = !0)) : new se.Event(t, e)
    },
    se.Event.prototype = {
        isDefaultPrevented: p,
        isPropagationStopped: p,
        isImmediatePropagationStopped: p,
        preventDefault: function() {
            var t = this.originalEvent;
            this.isDefaultPrevented = u,
            t && (t.preventDefault ? t.preventDefault() : t.returnValue = !1)
        },
        stopPropagation: function() {
            var t = this.originalEvent;
            this.isPropagationStopped = u,
            t && (t.stopPropagation && t.stopPropagation(), t.cancelBubble = !0)
        },
        stopImmediatePropagation: function() {
            var t = this.originalEvent;
            this.isImmediatePropagationStopped = u,
            t && t.stopImmediatePropagation && t.stopImmediatePropagation(),
            this.stopPropagation()
        }
    },
    se.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    },
    function(t, e) {
        se.event.special[t] = {
            delegateType: e,
            bindType: e,
            handle: function(t) {
                var i, n = this,
                s = t.relatedTarget,
                o = t.handleObj;
                return (!s || s !== n && !se.contains(n, s)) && (t.type = o.origType, i = o.handler.apply(this, arguments), t.type = e),
                i
            }
        }
    }),
    ie.submitBubbles || (se.event.special.submit = {
        setup: function() {
            return se.nodeName(this, "form") ? !1 : void se.event.add(this, "click._submit keypress._submit",
            function(t) {
                var e = t.target,
                i = se.nodeName(e, "input") || se.nodeName(e, "button") ? e.form: void 0;
                i && !se._data(i, "submitBubbles") && (se.event.add(i, "submit._submit",
                function(t) {
                    t._submit_bubble = !0
                }), se._data(i, "submitBubbles", !0))
            })
        },
        postDispatch: function(t) {
            t._submit_bubble && (delete t._submit_bubble, this.parentNode && !t.isTrigger && se.event.simulate("submit", this.parentNode, t, !0))
        },
        teardown: function() {
            return se.nodeName(this, "form") ? !1 : void se.event.remove(this, "._submit")
        }
    }),
    ie.changeBubbles || (se.event.special.change = {
        setup: function() {
            return xe.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (se.event.add(this, "propertychange._change",
            function(t) {
                "checked" === t.originalEvent.propertyName && (this._just_changed = !0)
            }), se.event.add(this, "click._change",
            function(t) {
                this._just_changed && !t.isTrigger && (this._just_changed = !1),
                se.event.simulate("change", this, t, !0)
            })), !1) : void se.event.add(this, "beforeactivate._change",
            function(t) {
                var e = t.target;
                xe.test(e.nodeName) && !se._data(e, "changeBubbles") && (se.event.add(e, "change._change",
                function(t) { ! this.parentNode || t.isSimulated || t.isTrigger || se.event.simulate("change", this.parentNode, t, !0)
                }), se._data(e, "changeBubbles", !0))
            })
        },
        handle: function(t) {
            var e = t.target;
            return this !== e || t.isSimulated || t.isTrigger || "radio" !== e.type && "checkbox" !== e.type ? t.handleObj.handler.apply(this, arguments) : void 0
        },
        teardown: function() {
            return se.event.remove(this, "._change"),
            !xe.test(this.nodeName)
        }
    }),
    ie.focusinBubbles || se.each({
        focus: "focusin",
        blur: "focusout"
    },
    function(t, e) {
        var i = function(t) {
            se.event.simulate(e, t.target, se.event.fix(t), !0)
        };
        se.event.special[e] = {
            setup: function() {
                var n = this.ownerDocument || this,
                s = se._data(n, e);
                s || n.addEventListener(t, i, !0),
                se._data(n, e, (s || 0) + 1)
            },
            teardown: function() {
                var n = this.ownerDocument || this,
                s = se._data(n, e) - 1;
                s ? se._data(n, e, s) : (n.removeEventListener(t, i, !0), se._removeData(n, e))
            }
        }
    }),
    se.fn.extend({
        on: function(t, e, i, n, s) {
            var o, a;
            if ("object" == typeof t) {
                "string" != typeof e && (i = i || e, e = void 0);
                for (o in t) this.on(o, e, i, t[o], s);
                return this
            }
            if (null == i && null == n ? (n = e, i = e = void 0) : null == n && ("string" == typeof e ? (n = i, i = void 0) : (n = i, i = e, e = void 0)), n === !1) n = p;
            else if (!n) return this;
            return 1 === s && (a = n, n = function(t) {
                return se().off(t),
                a.apply(this, arguments)
            },
            n.guid = a.guid || (a.guid = se.guid++)),
            this.each(function() {
                se.event.add(this, t, n, i, e)
            })
        },
        one: function(t, e, i, n) {
            return this.on(t, e, i, n, 1)
        },
        off: function(t, e, i) {
            var n, s;
            if (t && t.preventDefault && t.handleObj) return n = t.handleObj,
            se(t.delegateTarget).off(n.namespace ? n.origType + "." + n.namespace: n.origType, n.selector, n.handler),
            this;
            if ("object" == typeof t) {
                for (s in t) this.off(s, e, t[s]);
                return this
            }
            return (e === !1 || "function" == typeof e) && (i = e, e = void 0),
            i === !1 && (i = p),
            this.each(function() {
                se.event.remove(this, t, i, e)
            })
        },
        trigger: function(t, e) {
            return this.each(function() {
                se.event.trigger(t, e, this)
            })
        },
        triggerHandler: function(t, e) {
            var i = this[0];
            return i ? se.event.trigger(t, e, i, !0) : void 0
        }
    });
    var Pe = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
    $e = / jQuery\d+="(?:null|\d+)"/g,
    Ue = new RegExp("<(?:" + Pe + ")[\\s/>]", "i"),
    Fe = /^\s+/,
    Be = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
    He = /<([\w:]+)/,
    je = /<tbody/i,
    ze = /<|&#?\w+;/,
    Ve = /<(?:script|style|link)/i,
    Xe = /checked\s*(?:[^=]|=\s*.checked.)/i,
    Ge = /^$|\/(?:java|ecma)script/i,
    We = /^true\/(.*)/,
    Je = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
    Ye = {
        option: [1, "<select multiple='multiple'>", "</select>"],
        legend: [1, "<fieldset>", "</fieldset>"],
        area: [1, "<map>", "</map>"],
        param: [1, "<object>", "</object>"],
        thead: [1, "<table>", "</table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: ie.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
    },
    Ke = f(me),
    qe = Ke.appendChild(me.createElement("div"));
    Ye.optgroup = Ye.option,
    Ye.tbody = Ye.tfoot = Ye.colgroup = Ye.caption = Ye.thead,
    Ye.th = Ye.td,
    se.extend({
        clone: function(t, e, i) {
            var n, s, o, a, r, l = se.contains(t.ownerDocument, t);
            if (ie.html5Clone || se.isXMLDoc(t) || !Ue.test("<" + t.nodeName + ">") ? o = t.cloneNode(!0) : (qe.innerHTML = t.outerHTML, qe.removeChild(o = qe.firstChild)), !(ie.noCloneEvent && ie.noCloneChecked || 1 !== t.nodeType && 11 !== t.nodeType || se.isXMLDoc(t))) for (n = g(o), r = g(t), a = 0; null != (s = r[a]); ++a) n[a] && L(s, n[a]);
            if (e) if (i) for (r = r || g(t), n = n || g(o), a = 0; null != (s = r[a]); a++) T(s, n[a]);
            else T(t, o);
            return n = g(o, "script"),
            n.length > 0 && E(n, !l && g(t, "script")),
            n = r = s = null,
            o
        },
        buildFragment: function(t, e, i, n) {
            for (var s, o, a, r, l, d, c, h = t.length,
            u = f(e), p = [], m = 0; h > m; m++) if (o = t[m], o || 0 === o) if ("object" === se.type(o)) se.merge(p, o.nodeType ? [o] : o);
            else if (ze.test(o)) {
                for (r = r || u.appendChild(e.createElement("div")), l = (He.exec(o) || ["", ""])[1].toLowerCase(), c = Ye[l] || Ye._default, r.innerHTML = c[1] + o.replace(Be, "<$1></$2>") + c[2], s = c[0]; s--;) r = r.lastChild;
                if (!ie.leadingWhitespace && Fe.test(o) && p.push(e.createTextNode(Fe.exec(o)[0])), !ie.tbody) for (o = "table" !== l || je.test(o) ? "<table>" !== c[1] || je.test(o) ? 0 : r: r.firstChild, s = o && o.childNodes.length; s--;) se.nodeName(d = o.childNodes[s], "tbody") && !d.childNodes.length && o.removeChild(d);
                for (se.merge(p, r.childNodes), r.textContent = ""; r.firstChild;) r.removeChild(r.firstChild);
                r = u.lastChild
            } else p.push(e.createTextNode(o));
            for (r && u.removeChild(r), ie.appendChecked || se.grep(g(p, "input"), v), m = 0; o = p[m++];) if ((!n || -1 === se.inArray(o, n)) && (a = se.contains(o.ownerDocument, o), r = g(u.appendChild(o), "script"), a && E(r), i)) for (s = 0; o = r[s++];) Ge.test(o.type || "") && i.push(o);
            return r = null,
            u
        },
        cleanData: function(t, e) {
            for (var i, n, s, o, a = 0,
            r = se.expando,
            l = se.cache,
            d = ie.deleteExpando,
            c = se.event.special; null != (i = t[a]); a++) if ((e || se.acceptData(i)) && (s = i[r], o = s && l[s])) {
                if (o.events) for (n in o.events) c[n] ? se.event.remove(i, n) : se.removeEvent(i, n, o.handle);
                l[s] && (delete l[s], d ? delete i[r] : typeof i.removeAttribute !== Le ? i.removeAttribute(r) : i[r] = null, J.push(s))
            }
        }
    }),
    se.fn.extend({
        text: function(t) {
            return De(this,
            function(t) {
                return void 0 === t ? se.text(this) : this.empty().append((this[0] && this[0].ownerDocument || me).createTextNode(t))
            },
            null, t, arguments.length)
        },
        append: function() {
            return this.domManip(arguments,
            function(t) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var e = b(this, t);
                    e.appendChild(t)
                }
            })
        },
        prepend: function() {
            return this.domManip(arguments,
            function(t) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var e = b(this, t);
                    e.insertBefore(t, e.firstChild)
                }
            })
        },
        before: function() {
            return this.domManip(arguments,
            function(t) {
                this.parentNode && this.parentNode.insertBefore(t, this)
            })
        },
        after: function() {
            return this.domManip(arguments,
            function(t) {
                this.parentNode && this.parentNode.insertBefore(t, this.nextSibling)
            })
        },
        remove: function(t, e) {
            for (var i, n = t ? se.filter(t, this) : this, s = 0; null != (i = n[s]); s++) e || 1 !== i.nodeType || se.cleanData(g(i)),
            i.parentNode && (e && se.contains(i.ownerDocument, i) && E(g(i, "script")), i.parentNode.removeChild(i));
            return this
        },
        empty: function() {
            for (var t, e = 0; null != (t = this[e]); e++) {
                for (1 === t.nodeType && se.cleanData(g(t, !1)); t.firstChild;) t.removeChild(t.firstChild);
                t.options && se.nodeName(t, "select") && (t.options.length = 0)
            }
            return this
        },
        clone: function(t, e) {
            return t = null == t ? !1 : t,
            e = null == e ? t: e,
            this.map(function() {
                return se.clone(this, t, e)
            })
        },
        html: function(t) {
            return De(this,
            function(t) {
                var e = this[0] || {},
                i = 0,
                n = this.length;
                if (void 0 === t) return 1 === e.nodeType ? e.innerHTML.replace($e, "") : void 0;
                if (! ("string" != typeof t || Ve.test(t) || !ie.htmlSerialize && Ue.test(t) || !ie.leadingWhitespace && Fe.test(t) || Ye[(He.exec(t) || ["", ""])[1].toLowerCase()])) {
                    t = t.replace(Be, "<$1></$2>");
                    try {
                        for (; n > i; i++) e = this[i] || {},
                        1 === e.nodeType && (se.cleanData(g(e, !1)), e.innerHTML = t);
                        e = 0
                    } catch(s) {}
                }
                e && this.empty().append(t)
            },
            null, t, arguments.length)
        },
        replaceWith: function() {
            var t = arguments[0];
            return this.domManip(arguments,
            function(e) {
                t = this.parentNode,
                se.cleanData(g(this)),
                t && t.replaceChild(e, this)
            }),
            t && (t.length || t.nodeType) ? this: this.remove()
        },
        detach: function(t) {
            return this.remove(t, !0)
        },
        domManip: function(t, e) {
            t = K.apply([], t);
            var i, n, s, o, a, r, l = 0,
            d = this.length,
            c = this,
            h = d - 1,
            u = t[0],
            p = se.isFunction(u);
            if (p || d > 1 && "string" == typeof u && !ie.checkClone && Xe.test(u)) return this.each(function(i) {
                var n = c.eq(i);
                p && (t[0] = u.call(this, i, n.html())),
                n.domManip(t, e)
            });
            if (d && (r = se.buildFragment(t, this[0].ownerDocument, !1, this), i = r.firstChild, 1 === r.childNodes.length && (r = i), i)) {
                for (o = se.map(g(r, "script"), S), s = o.length; d > l; l++) n = r,
                l !== h && (n = se.clone(n, !0, !0), s && se.merge(o, g(n, "script"))),
                e.call(this[l], n, l);
                if (s) for (a = o[o.length - 1].ownerDocument, se.map(o, y), l = 0; s > l; l++) n = o[l],
                Ge.test(n.type || "") && !se._data(n, "globalEval") && se.contains(a, n) && (n.src ? se._evalUrl && se._evalUrl(n.src) : se.globalEval((n.text || n.textContent || n.innerHTML || "").replace(Je, "")));
                r = i = null
            }
            return this
        }
    }),
    se.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    },
    function(t, e) {
        se.fn[t] = function(t) {
            for (var i, n = 0,
            s = [], o = se(t), a = o.length - 1; a >= n; n++) i = n === a ? this: this.clone(!0),
            se(o[n])[e](i),
            q.apply(s, i.get());
            return this.pushStack(s)
        }
    });
    var Qe, Ze = {}; !
    function() {
        var t;
        ie.shrinkWrapBlocks = function() {
            if (null != t) return t;
            t = !1;
            var e, i, n;
            return i = me.getElementsByTagName("body")[0],
            i && i.style ? (e = me.createElement("div"), n = me.createElement("div"), n.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", i.appendChild(n).appendChild(e), typeof e.style.zoom !== Le && (e.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1", e.appendChild(me.createElement("div")).style.width = "5px", t = 3 !== e.offsetWidth), i.removeChild(n), t) : void 0
        }
    } ();
    var ti, ei, ii = /^margin/,
    ni = new RegExp("^(" + ke + ")(?!px)[a-z%]+$", "i"),
    si = /^(top|right|bottom|left)$/;
    t.getComputedStyle ? (ti = function(t) {
        return t.ownerDocument.defaultView.getComputedStyle(t, null)
    },
    ei = function(t, e, i) {
        var n, s, o, a, r = t.style;
        return i = i || ti(t),
        a = i ? i.getPropertyValue(e) || i[e] : void 0,
        i && ("" !== a || se.contains(t.ownerDocument, t) || (a = se.style(t, e)), ni.test(a) && ii.test(e) && (n = r.width, s = r.minWidth, o = r.maxWidth, r.minWidth = r.maxWidth = r.width = a, a = i.width, r.width = n, r.minWidth = s, r.maxWidth = o)),
        void 0 === a ? a: a + ""
    }) : me.documentElement.currentStyle && (ti = function(t) {
        return t.currentStyle
    },
    ei = function(t, e, i) {
        var n, s, o, a, r = t.style;
        return i = i || ti(t),
        a = i ? i[e] : void 0,
        null == a && r && r[e] && (a = r[e]),
        ni.test(a) && !si.test(e) && (n = r.left, s = t.runtimeStyle, o = s && s.left, o && (s.left = t.currentStyle.left), r.left = "fontSize" === e ? "1em": a, a = r.pixelLeft + "px", r.left = n, o && (s.left = o)),
        void 0 === a ? a: a + "" || "auto"
    }),
    function() {
        function e() {
            var e, i, n, s;
            i = me.getElementsByTagName("body")[0],
            i && i.style && (e = me.createElement("div"), n = me.createElement("div"), n.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", i.appendChild(n).appendChild(e), e.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute", o = a = !1, l = !0, t.getComputedStyle && (o = "1%" !== (t.getComputedStyle(e, null) || {}).top, a = "4px" === (t.getComputedStyle(e, null) || {
                width: "4px"
            }).width, s = e.appendChild(me.createElement("div")), s.style.cssText = e.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", s.style.marginRight = s.style.width = "0", e.style.width = "1px", l = !parseFloat((t.getComputedStyle(s, null) || {}).marginRight)), e.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", s = e.getElementsByTagName("td"), s[0].style.cssText = "margin:0;border:0;padding:0;display:none", r = 0 === s[0].offsetHeight, r && (s[0].style.display = "", s[1].style.display = "none", r = 0 === s[0].offsetHeight), i.removeChild(n))
        }
        var i, n, s, o, a, r, l;
        i = me.createElement("div"),
        i.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        s = i.getElementsByTagName("a")[0],
        n = s && s.style,
        n && (n.cssText = "float:left;opacity:.5", ie.opacity = "0.5" === n.opacity, ie.cssFloat = !!n.cssFloat, i.style.backgroundClip = "content-box", i.cloneNode(!0).style.backgroundClip = "", ie.clearCloneStyle = "content-box" === i.style.backgroundClip, ie.boxSizing = "" === n.boxSizing || "" === n.MozBoxSizing || "" === n.WebkitBoxSizing, se.extend(ie, {
            reliableHiddenOffsets: function() {
                return null == r && e(),
                r
            },
            boxSizingReliable: function() {
                return null == a && e(),
                a
            },
            pixelPosition: function() {
                return null == o && e(),
                o
            },
            reliableMarginRight: function() {
                return null == l && e(),
                l
            }
        }))
    } (),
    se.swap = function(t, e, i, n) {
        var s, o, a = {};
        for (o in e) a[o] = t.style[o],
        t.style[o] = e[o];
        s = i.apply(t, n || []);
        for (o in e) t.style[o] = a[o];
        return s
    };
    var oi = /alpha\([^)]*\)/i,
    ai = /opacity\s*=\s*([^)]*)/,
    ri = /^(none|table(?!-c[ea]).+)/,
    li = new RegExp("^(" + ke + ")(.*)$", "i"),
    di = new RegExp("^([+-])=(" + ke + ")", "i"),
    ci = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    },
    hi = {
        letterSpacing: "0",
        fontWeight: "400"
    },
    ui = ["Webkit", "O", "Moz", "ms"];
    se.extend({
        cssHooks: {
            opacity: {
                get: function(t, e) {
                    if (e) {
                        var i = ei(t, "opacity");
                        return "" === i ? "1": i
                    }
                }
            }
        },
        cssNumber: {
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": ie.cssFloat ? "cssFloat": "styleFloat"
        },
        style: function(t, e, i, n) {
            if (t && 3 !== t.nodeType && 8 !== t.nodeType && t.style) {
                var s, o, a, r = se.camelCase(e),
                l = t.style;
                if (e = se.cssProps[r] || (se.cssProps[r] = C(l, r)), a = se.cssHooks[e] || se.cssHooks[r], void 0 === i) return a && "get" in a && void 0 !== (s = a.get(t, !1, n)) ? s: l[e];
                if (o = typeof i, "string" === o && (s = di.exec(i)) && (i = (s[1] + 1) * s[2] + parseFloat(se.css(t, e)), o = "number"), null != i && i === i && ("number" !== o || se.cssNumber[r] || (i += "px"), ie.clearCloneStyle || "" !== i || 0 !== e.indexOf("background") || (l[e] = "inherit"), !(a && "set" in a && void 0 === (i = a.set(t, i, n))))) try {
                    l[e] = i
                } catch(d) {}
            }
        },
        css: function(t, e, i, n) {
            var s, o, a, r = se.camelCase(e);
            return e = se.cssProps[r] || (se.cssProps[r] = C(t.style, r)),
            a = se.cssHooks[e] || se.cssHooks[r],
            a && "get" in a && (o = a.get(t, !0, i)),
            void 0 === o && (o = ei(t, e, n)),
            "normal" === o && e in hi && (o = hi[e]),
            "" === i || i ? (s = parseFloat(o), i === !0 || se.isNumeric(s) ? s || 0 : o) : o
        }
    }),
    se.each(["height", "width"],
    function(t, e) {
        se.cssHooks[e] = {
            get: function(t, i, n) {
                return i ? ri.test(se.css(t, "display")) && 0 === t.offsetWidth ? se.swap(t, ci,
                function() {
                    return x(t, e, n)
                }) : x(t, e, n) : void 0
            },
            set: function(t, i, n) {
                var s = n && ti(t);
                return D(t, i, n ? I(t, e, n, ie.boxSizing && "border-box" === se.css(t, "boxSizing", !1, s), s) : 0)
            }
        }
    }),
    ie.opacity || (se.cssHooks.opacity = {
        get: function(t, e) {
            return ai.test((e && t.currentStyle ? t.currentStyle.filter: t.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "": e ? "1": ""
        },
        set: function(t, e) {
            var i = t.style,
            n = t.currentStyle,
            s = se.isNumeric(e) ? "alpha(opacity=" + 100 * e + ")": "",
            o = n && n.filter || i.filter || "";
            i.zoom = 1,
            (e >= 1 || "" === e) && "" === se.trim(o.replace(oi, "")) && i.removeAttribute && (i.removeAttribute("filter"), "" === e || n && !n.filter) || (i.filter = oi.test(o) ? o.replace(oi, s) : o + " " + s)
        }
    }),
    se.cssHooks.marginRight = k(ie.reliableMarginRight,
    function(t, e) {
        return e ? se.swap(t, {
            display: "inline-block"
        },
        ei, [t, "marginRight"]) : void 0
    }),
    se.each({
        margin: "",
        padding: "",
        border: "Width"
    },
    function(t, e) {
        se.cssHooks[t + e] = {
            expand: function(i) {
                for (var n = 0,
                s = {},
                o = "string" == typeof i ? i.split(" ") : [i]; 4 > n; n++) s[t + Ce[n] + e] = o[n] || o[n - 2] || o[0];
                return s
            }
        },
        ii.test(t) || (se.cssHooks[t + e].set = D)
    }),
    se.fn.extend({
        css: function(t, e) {
            return De(this,
            function(t, e, i) {
                var n, s, o = {},
                a = 0;
                if (se.isArray(e)) {
                    for (n = ti(t), s = e.length; s > a; a++) o[e[a]] = se.css(t, e[a], !1, n);
                    return o
                }
                return void 0 !== i ? se.style(t, e, i) : se.css(t, e)
            },
            t, e, arguments.length > 1)
        },
        show: function() {
            return A(this, !0)
        },
        hide: function() {
            return A(this)
        },
        toggle: function(t) {
            return "boolean" == typeof t ? t ? this.show() : this.hide() : this.each(function() {
                Ae(this) ? se(this).show() : se(this).hide()
            })
        }
    }),
    se.Tween = M,
    M.prototype = {
        constructor: M,
        init: function(t, e, i, n, s, o) {
            this.elem = t,
            this.prop = i,
            this.easing = s || "swing",
            this.options = e,
            this.start = this.now = this.cur(),
            this.end = n,
            this.unit = o || (se.cssNumber[i] ? "": "px")
        },
        cur: function() {
            var t = M.propHooks[this.prop];
            return t && t.get ? t.get(this) : M.propHooks._default.get(this)
        },
        run: function(t) {
            var e, i = M.propHooks[this.prop];
            return this.pos = e = this.options.duration ? se.easing[this.easing](t, this.options.duration * t, 0, 1, this.options.duration) : t,
            this.now = (this.end - this.start) * e + this.start,
            this.options.step && this.options.step.call(this.elem, this.now, this),
            i && i.set ? i.set(this) : M.propHooks._default.set(this),
            this
        }
    },
    M.prototype.init.prototype = M.prototype,
    M.propHooks = {
        _default: {
            get: function(t) {
                var e;
                return null == t.elem[t.prop] || t.elem.style && null != t.elem.style[t.prop] ? (e = se.css(t.elem, t.prop, ""), e && "auto" !== e ? e: 0) : t.elem[t.prop]
            },
            set: function(t) {
                se.fx.step[t.prop] ? se.fx.step[t.prop](t) : t.elem.style && (null != t.elem.style[se.cssProps[t.prop]] || se.cssHooks[t.prop]) ? se.style(t.elem, t.prop, t.now + t.unit) : t.elem[t.prop] = t.now
            }
        }
    },
    M.propHooks.scrollTop = M.propHooks.scrollLeft = {
        set: function(t) {
            t.elem.nodeType && t.elem.parentNode && (t.elem[t.prop] = t.now)
        }
    },
    se.easing = {
        linear: function(t) {
            return t
        },
        swing: function(t) {
            return.5 - Math.cos(t * Math.PI) / 2
        }
    },
    se.fx = M.prototype.init,
    se.fx.step = {};
    var pi, mi, fi = /^(?:toggle|show|hide)$/,
    gi = new RegExp("^(?:([+-])=|)(" + ke + ")([a-z%]*)$", "i"),
    vi = /queueHooks$/,
    bi = [P],
    Si = {
        "*": [function(t, e) {
            var i = this.createTween(t, e),
            n = i.cur(),
            s = gi.exec(e),
            o = s && s[3] || (se.cssNumber[t] ? "": "px"),
            a = (se.cssNumber[t] || "px" !== o && +n) && gi.exec(se.css(i.elem, t)),
            r = 1,
            l = 20;
            if (a && a[3] !== o) {
                o = o || a[3],
                s = s || [],
                a = +n || 1;
                do r = r || ".5",
                a /= r,
                se.style(i.elem, t, a + o);
                while (r !== (r = i.cur() / n) && 1 !== r && --l)
            }
            return s && (a = i.start = +a || +n || 0, i.unit = o, i.end = s[1] ? a + (s[1] + 1) * s[2] : +s[2]),
            i
        }]
    };
    se.Animation = se.extend(U, {
        tweener: function(t, e) {
            se.isFunction(t) ? (e = t, t = ["*"]) : t = t.split(" ");
            for (var i, n = 0,
            s = t.length; s > n; n++) i = t[n],
            Si[i] = Si[i] || [],
            Si[i].unshift(e)
        },
        prefilter: function(t, e) {
            e ? bi.unshift(t) : bi.push(t)
        }
    }),
    se.speed = function(t, e, i) {
        var n = t && "object" == typeof t ? se.extend({},
        t) : {
            complete: i || !i && e || se.isFunction(t) && t,
            duration: t,
            easing: i && e || e && !se.isFunction(e) && e
        };
        return n.duration = se.fx.off ? 0 : "number" == typeof n.duration ? n.duration: n.duration in se.fx.speeds ? se.fx.speeds[n.duration] : se.fx.speeds._default,
        (null == n.queue || n.queue === !0) && (n.queue = "fx"),
        n.old = n.complete,
        n.complete = function() {
            se.isFunction(n.old) && n.old.call(this),
            n.queue && se.dequeue(this, n.queue)
        },
        n
    },
    se.fn.extend({
        fadeTo: function(t, e, i, n) {
            return this.filter(Ae).css("opacity", 0).show().end().animate({
                opacity: e
            },
            t, i, n)
        },
        animate: function(t, e, i, n) {
            var s = se.isEmptyObject(t),
            o = se.speed(e, i, n),
            a = function() {
                var e = U(this, se.extend({},
                t), o); (s || se._data(this, "finish")) && e.stop(!0)
            };
            return a.finish = a,
            s || o.queue === !1 ? this.each(a) : this.queue(o.queue, a)
        },
        stop: function(t, e, i) {
            var n = function(t) {
                var e = t.stop;
                delete t.stop,
                e(i)
            };
            return "string" != typeof t && (i = e, e = t, t = void 0),
            e && t !== !1 && this.queue(t || "fx", []),
            this.each(function() {
                var e = !0,
                s = null != t && t + "queueHooks",
                o = se.timers,
                a = se._data(this);
                if (s) a[s] && a[s].stop && n(a[s]);
                else for (s in a) a[s] && a[s].stop && vi.test(s) && n(a[s]);
                for (s = o.length; s--;) o[s].elem !== this || null != t && o[s].queue !== t || (o[s].anim.stop(i), e = !1, o.splice(s, 1)); (e || !i) && se.dequeue(this, t)
            })
        },
        finish: function(t) {
            return t !== !1 && (t = t || "fx"),
            this.each(function() {
                var e, i = se._data(this),
                n = i[t + "queue"],
                s = i[t + "queueHooks"],
                o = se.timers,
                a = n ? n.length: 0;
                for (i.finish = !0, se.queue(this, t, []), s && s.stop && s.stop.call(this, !0), e = o.length; e--;) o[e].elem === this && o[e].queue === t && (o[e].anim.stop(!0), o.splice(e, 1));
                for (e = 0; a > e; e++) n[e] && n[e].finish && n[e].finish.call(this);
                delete i.finish
            })
        }
    }),
    se.each(["toggle", "show", "hide"],
    function(t, e) {
        var i = se.fn[e];
        se.fn[e] = function(t, n, s) {
            return null == t || "boolean" == typeof t ? i.apply(this, arguments) : this.animate(O(e, !0), t, n, s)
        }
    }),
    se.each({
        slideDown: O("show"),
        slideUp: O("hide"),
        slideToggle: O("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    },
    function(t, e) {
        se.fn[t] = function(t, i, n) {
            return this.animate(e, t, i, n)
        }
    }),
    se.timers = [],
    se.fx.tick = function() {
        var t, e = se.timers,
        i = 0;
        for (pi = se.now(); i < e.length; i++) t = e[i],
        t() || e[i] !== t || e.splice(i--, 1);
        e.length || se.fx.stop(),
        pi = void 0
    },
    se.fx.timer = function(t) {
        se.timers.push(t),
        t() ? se.fx.start() : se.timers.pop()
    },
    se.fx.interval = 13,
    se.fx.start = function() {
        mi || (mi = setInterval(se.fx.tick, se.fx.interval))
    },
    se.fx.stop = function() {
        clearInterval(mi),
        mi = null
    },
    se.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    },
    se.fn.delay = function(t, e) {
        return t = se.fx ? se.fx.speeds[t] || t: t,
        e = e || "fx",
        this.queue(e,
        function(e, i) {
            var n = setTimeout(e, t);
            i.stop = function() {
                clearTimeout(n)
            }
        })
    },
    function() {
        var t, e, i, n, s;
        e = me.createElement("div"),
        e.setAttribute("className", "t"),
        e.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        n = e.getElementsByTagName("a")[0],
        i = me.createElement("select"),
        s = i.appendChild(me.createElement("option")),
        t = e.getElementsByTagName("input")[0],
        n.style.cssText = "top:1px",
        ie.getSetAttribute = "t" !== e.className,
        ie.style = /top/.test(n.getAttribute("style")),
        ie.hrefNormalized = "/a" === n.getAttribute("href"),
        ie.checkOn = !!t.value,
        ie.optSelected = s.selected,
        ie.enctype = !!me.createElement("form").enctype,
        i.disabled = !0,
        ie.optDisabled = !s.disabled,
        t = me.createElement("input"),
        t.setAttribute("value", ""),
        ie.input = "" === t.getAttribute("value"),
        t.value = "t",
        t.setAttribute("type", "radio"),
        ie.radioValue = "t" === t.value
    } ();
    var yi = /\r/g;
    se.fn.extend({
        val: function(t) {
            var e, i, n, s = this[0]; {
                if (arguments.length) return n = se.isFunction(t),
                this.each(function(i) {
                    var s;
                    1 === this.nodeType && (s = n ? t.call(this, i, se(this).val()) : t, null == s ? s = "": "number" == typeof s ? s += "": se.isArray(s) && (s = se.map(s,
                    function(t) {
                        return null == t ? "": t + ""
                    })), e = se.valHooks[this.type] || se.valHooks[this.nodeName.toLowerCase()], e && "set" in e && void 0 !== e.set(this, s, "value") || (this.value = s))
                });
                if (s) return e = se.valHooks[s.type] || se.valHooks[s.nodeName.toLowerCase()],
                e && "get" in e && void 0 !== (i = e.get(s, "value")) ? i: (i = s.value, "string" == typeof i ? i.replace(yi, "") : null == i ? "": i)
            }
        }
    }),
    se.extend({
        valHooks: {
            option: {
                get: function(t) {
                    var e = se.find.attr(t, "value");
                    return null != e ? e: se.trim(se.text(t))
                }
            },
            select: {
                get: function(t) {
                    for (var e, i, n = t.options,
                    s = t.selectedIndex,
                    o = "select-one" === t.type || 0 > s,
                    a = o ? null: [], r = o ? s + 1 : n.length, l = 0 > s ? r: o ? s: 0; r > l; l++) if (i = n[l], !(!i.selected && l !== s || (ie.optDisabled ? i.disabled: null !== i.getAttribute("disabled")) || i.parentNode.disabled && se.nodeName(i.parentNode, "optgroup"))) {
                        if (e = se(i).val(), o) return e;
                        a.push(e)
                    }
                    return a
                },
                set: function(t, e) {
                    for (var i, n, s = t.options,
                    o = se.makeArray(e), a = s.length; a--;) if (n = s[a], se.inArray(se.valHooks.option.get(n), o) >= 0) try {
                        n.selected = i = !0
                    } catch(r) {
                        n.scrollHeight
                    } else n.selected = !1;
                    return i || (t.selectedIndex = -1),
                    s
                }
            }
        }
    }),
    se.each(["radio", "checkbox"],
    function() {
        se.valHooks[this] = {
            set: function(t, e) {
                return se.isArray(e) ? t.checked = se.inArray(se(t).val(), e) >= 0 : void 0
            }
        },
        ie.checkOn || (se.valHooks[this].get = function(t) {
            return null === t.getAttribute("value") ? "on": t.value
        })
    });
    var Ei, Ti, Li = se.expr.attrHandle,
    wi = /^(?:checked|selected)$/i,
    _i = ie.getSetAttribute,
    ki = ie.input;
    se.fn.extend({
        attr: function(t, e) {
            return De(this, se.attr, t, e, arguments.length > 1)
        },
        removeAttr: function(t) {
            return this.each(function() {
                se.removeAttr(this, t)
            })
        }
    }),
    se.extend({
        attr: function(t, e, i) {
            var n, s, o = t.nodeType;
            if (t && 3 !== o && 8 !== o && 2 !== o) return typeof t.getAttribute === Le ? se.prop(t, e, i) : (1 === o && se.isXMLDoc(t) || (e = e.toLowerCase(), n = se.attrHooks[e] || (se.expr.match.bool.test(e) ? Ti: Ei)), void 0 === i ? n && "get" in n && null !== (s = n.get(t, e)) ? s: (s = se.find.attr(t, e), null == s ? void 0 : s) : null !== i ? n && "set" in n && void 0 !== (s = n.set(t, i, e)) ? s: (t.setAttribute(e, i + ""), i) : void se.removeAttr(t, e))
        },
        removeAttr: function(t, e) {
            var i, n, s = 0,
            o = e && e.match(Se);
            if (o && 1 === t.nodeType) for (; i = o[s++];) n = se.propFix[i] || i,
            se.expr.match.bool.test(i) ? ki && _i || !wi.test(i) ? t[n] = !1 : t[se.camelCase("default-" + i)] = t[n] = !1 : se.attr(t, i, ""),
            t.removeAttribute(_i ? i: n)
        },
        attrHooks: {
            type: {
                set: function(t, e) {
                    if (!ie.radioValue && "radio" === e && se.nodeName(t, "input")) {
                        var i = t.value;
                        return t.setAttribute("type", e),
                        i && (t.value = i),
                        e
                    }
                }
            }
        }
    }),
    Ti = {
        set: function(t, e, i) {
            return e === !1 ? se.removeAttr(t, i) : ki && _i || !wi.test(i) ? t.setAttribute(!_i && se.propFix[i] || i, i) : t[se.camelCase("default-" + i)] = t[i] = !0,
            i
        }
    },
    se.each(se.expr.match.bool.source.match(/\w+/g),
    function(t, e) {
        var i = Li[e] || se.find.attr;
        Li[e] = ki && _i || !wi.test(e) ?
        function(t, e, n) {
            var s, o;
            return n || (o = Li[e], Li[e] = s, s = null != i(t, e, n) ? e.toLowerCase() : null, Li[e] = o),
            s
        }: function(t, e, i) {
            return i ? void 0 : t[se.camelCase("default-" + e)] ? e.toLowerCase() : null
        }
    }),
    ki && _i || (se.attrHooks.value = {
        set: function(t, e, i) {
            return se.nodeName(t, "input") ? void(t.defaultValue = e) : Ei && Ei.set(t, e, i)
        }
    }),
    _i || (Ei = {
        set: function(t, e, i) {
            var n = t.getAttributeNode(i);
            return n || t.setAttributeNode(n = t.ownerDocument.createAttribute(i)),
            n.value = e += "",
            "value" === i || e === t.getAttribute(i) ? e: void 0
        }
    },
    Li.id = Li.name = Li.coords = function(t, e, i) {
        var n;
        return i ? void 0 : (n = t.getAttributeNode(e)) && "" !== n.value ? n.value: null
    },
    se.valHooks.button = {
        get: function(t, e) {
            var i = t.getAttributeNode(e);
            return i && i.specified ? i.value: void 0
        },
        set: Ei.set
    },
    se.attrHooks.contenteditable = {
        set: function(t, e, i) {
            Ei.set(t, "" === e ? !1 : e, i)
        }
    },
    se.each(["width", "height"],
    function(t, e) {
        se.attrHooks[e] = {
            set: function(t, i) {
                return "" === i ? (t.setAttribute(e, "auto"), i) : void 0
            }
        }
    })),
    ie.style || (se.attrHooks.style = {
        get: function(t) {
            return t.style.cssText || void 0
        },
        set: function(t, e) {
            return t.style.cssText = e + ""
        }
    });
    var Ci = /^(?:input|select|textarea|button|object)$/i,
    Ai = /^(?:a|area)$/i;
    se.fn.extend({
        prop: function(t, e) {
            return De(this, se.prop, t, e, arguments.length > 1)
        },
        removeProp: function(t) {
            return t = se.propFix[t] || t,
            this.each(function() {
                try {
                    this[t] = void 0,
                    delete this[t]
                } catch(e) {}
            })
        }
    }),
    se.extend({
        propFix: {
            "for": "htmlFor",
            "class": "className"
        },
        prop: function(t, e, i) {
            var n, s, o, a = t.nodeType;
            if (t && 3 !== a && 8 !== a && 2 !== a) return o = 1 !== a || !se.isXMLDoc(t),
            o && (e = se.propFix[e] || e, s = se.propHooks[e]),
            void 0 !== i ? s && "set" in s && void 0 !== (n = s.set(t, i, e)) ? n: t[e] = i: s && "get" in s && null !== (n = s.get(t, e)) ? n: t[e]
        },
        propHooks: {
            tabIndex: {
                get: function(t) {
                    var e = se.find.attr(t, "tabindex");
                    return e ? parseInt(e, 10) : Ci.test(t.nodeName) || Ai.test(t.nodeName) && t.href ? 0 : -1
                }
            }
        }
    }),
    ie.hrefNormalized || se.each(["href", "src"],
    function(t, e) {
        se.propHooks[e] = {
            get: function(t) {
                return t.getAttribute(e, 4)
            }
        }
    }),
    ie.optSelected || (se.propHooks.selected = {
        get: function(t) {
            var e = t.parentNode;
            return e && (e.selectedIndex, e.parentNode && e.parentNode.selectedIndex),
            null
        }
    }),
    se.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"],
    function() {
        se.propFix[this.toLowerCase()] = this
    }),
    ie.enctype || (se.propFix.enctype = "encoding");
    var Di = /[\t\r\n\f]/g;
    se.fn.extend({
        addClass: function(t) {
            var e, i, n, s, o, a, r = 0,
            l = this.length,
            d = "string" == typeof t && t;
            if (se.isFunction(t)) return this.each(function(e) {
                se(this).addClass(t.call(this, e, this.className))
            });
            if (d) for (e = (t || "").match(Se) || []; l > r; r++) if (i = this[r], n = 1 === i.nodeType && (i.className ? (" " + i.className + " ").replace(Di, " ") : " ")) {
                for (o = 0; s = e[o++];) n.indexOf(" " + s + " ") < 0 && (n += s + " ");
                a = se.trim(n),
                i.className !== a && (i.className = a)
            }
            return this
        },
        removeClass: function(t) {
            var e, i, n, s, o, a, r = 0,
            l = this.length,
            d = 0 === arguments.length || "string" == typeof t && t;
            if (se.isFunction(t)) return this.each(function(e) {
                se(this).removeClass(t.call(this, e, this.className))
            });
            if (d) for (e = (t || "").match(Se) || []; l > r; r++) if (i = this[r], n = 1 === i.nodeType && (i.className ? (" " + i.className + " ").replace(Di, " ") : "")) {
                for (o = 0; s = e[o++];) for (; n.indexOf(" " + s + " ") >= 0;) n = n.replace(" " + s + " ", " ");
                a = t ? se.trim(n) : "",
                i.className !== a && (i.className = a)
            }
            return this
        },
        toggleClass: function(t, e) {
            var i = typeof t;
            return "boolean" == typeof e && "string" === i ? e ? this.addClass(t) : this.removeClass(t) : this.each(se.isFunction(t) ?
            function(i) {
                se(this).toggleClass(t.call(this, i, this.className, e), e)
            }: function() {
                if ("string" === i) for (var e, n = 0,
                s = se(this), o = t.match(Se) || []; e = o[n++];) s.hasClass(e) ? s.removeClass(e) : s.addClass(e);
                else(i === Le || "boolean" === i) && (this.className && se._data(this, "__className__", this.className), this.className = this.className || t === !1 ? "": se._data(this, "__className__") || "")
            })
        },
        hasClass: function(t) {
            for (var e = " " + t + " ",
            i = 0,
            n = this.length; n > i; i++) if (1 === this[i].nodeType && (" " + this[i].className + " ").replace(Di, " ").indexOf(e) >= 0) return ! 0;
            return ! 1
        }
    }),
    se.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),
    function(t, e) {
        se.fn[e] = function(t, i) {
            return arguments.length > 0 ? this.on(e, null, t, i) : this.trigger(e)
        }
    }),
    se.fn.extend({
        hover: function(t, e) {
            return this.mouseenter(t).mouseleave(e || t)
        },
        bind: function(t, e, i) {
            return this.on(t, null, e, i)
        },
        unbind: function(t, e) {
            return this.off(t, null, e)
        },
        delegate: function(t, e, i, n) {
            return this.on(e, t, i, n)
        },
        undelegate: function(t, e, i) {
            return 1 === arguments.length ? this.off(t, "**") : this.off(e, t || "**", i)
        }
    });
    var Ii = se.now(),
    xi = /\?/,
    Mi = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    se.parseJSON = function(e) {
        if (t.JSON && t.JSON.parse) return t.JSON.parse(e + "");
        var i, n = null,
        s = se.trim(e + "");
        return s && !se.trim(s.replace(Mi,
        function(t, e, s, o) {
            return i && e && (n = 0),
            0 === n ? t: (i = s || e, n += !o - !s, "")
        })) ? Function("return " + s)() : se.error("Invalid JSON: " + e)
    },
    se.parseXML = function(e) {
        var i, n;
        if (!e || "string" != typeof e) return null;
        try {
            t.DOMParser ? (n = new DOMParser, i = n.parseFromString(e, "text/xml")) : (i = new ActiveXObject("Microsoft.XMLDOM"), i.async = "false", i.loadXML(e))
        } catch(s) {
            i = void 0
        }
        return i && i.documentElement && !i.getElementsByTagName("parsererror").length || se.error("Invalid XML: " + e),
        i
    };
    var Ri, Oi, Ni = /#.*$/,
    Pi = /([?&])_=[^&]*/,
    $i = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
    Ui = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
    Fi = /^(?:GET|HEAD)$/,
    Bi = /^\/\//,
    Hi = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
    ji = {},
    zi = {},
    Vi = "*/".concat("*");
    try {
        Oi = location.href
    } catch(Xi) {
        Oi = me.createElement("a"),
        Oi.href = "",
        Oi = Oi.href
    }
    Ri = Hi.exec(Oi.toLowerCase()) || [],
    se.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Oi,
            type: "GET",
            isLocal: Ui.test(Ri[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Vi,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": se.parseJSON,
                "text xml": se.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(t, e) {
            return e ? H(H(t, se.ajaxSettings), e) : H(se.ajaxSettings, t)
        },
        ajaxPrefilter: F(ji),
        ajaxTransport: F(zi),
        ajax: function(t, e) {
            function i(t, e, i, n) {
                var s, c, v, b, y, T = e;
                2 !== S && (S = 2, r && clearTimeout(r), d = void 0, a = n || "", E.readyState = t > 0 ? 4 : 0, s = t >= 200 && 300 > t || 304 === t, i && (b = j(h, E, i)), b = z(h, b, E, s), s ? (h.ifModified && (y = E.getResponseHeader("Last-Modified"), y && (se.lastModified[o] = y), y = E.getResponseHeader("etag"), y && (se.etag[o] = y)), 204 === t || "HEAD" === h.type ? T = "nocontent": 304 === t ? T = "notmodified": (T = b.state, c = b.data, v = b.error, s = !v)) : (v = T, (t || !T) && (T = "error", 0 > t && (t = 0))), E.status = t, E.statusText = (e || T) + "", s ? m.resolveWith(u, [c, T, E]) : m.rejectWith(u, [E, T, v]), E.statusCode(g), g = void 0, l && p.trigger(s ? "ajaxSuccess": "ajaxError", [E, h, s ? c: v]), f.fireWith(u, [E, T]), l && (p.trigger("ajaxComplete", [E, h]), --se.active || se.event.trigger("ajaxStop")))
            }
            "object" == typeof t && (e = t, t = void 0),
            e = e || {};
            var n, s, o, a, r, l, d, c, h = se.ajaxSetup({},
            e),
            u = h.context || h,
            p = h.context && (u.nodeType || u.jquery) ? se(u) : se.event,
            m = se.Deferred(),
            f = se.Callbacks("once memory"),
            g = h.statusCode || {},
            v = {},
            b = {},
            S = 0,
            y = "canceled",
            E = {
                readyState: 0,
                getResponseHeader: function(t) {
                    var e;
                    if (2 === S) {
                        if (!c) for (c = {}; e = $i.exec(a);) c[e[1].toLowerCase()] = e[2];
                        e = c[t.toLowerCase()]
                    }
                    return null == e ? null: e
                },
                getAllResponseHeaders: function() {
                    return 2 === S ? a: null
                },
                setRequestHeader: function(t, e) {
                    var i = t.toLowerCase();
                    return S || (t = b[i] = b[i] || t, v[t] = e),
                    this
                },
                overrideMimeType: function(t) {
                    return S || (h.mimeType = t),
                    this
                },
                statusCode: function(t) {
                    var e;
                    if (t) if (2 > S) for (e in t) g[e] = [g[e], t[e]];
                    else E.always(t[E.status]);
                    return this
                },
                abort: function(t) {
                    var e = t || y;
                    return d && d.abort(e),
                    i(0, e),
                    this
                }
            };
            if (m.promise(E).complete = f.add, E.success = E.done, E.error = E.fail, h.url = ((t || h.url || Oi) + "").replace(Ni, "").replace(Bi, Ri[1] + "//"), h.type = e.method || e.type || h.method || h.type, h.dataTypes = se.trim(h.dataType || "*").toLowerCase().match(Se) || [""], null == h.crossDomain && (n = Hi.exec(h.url.toLowerCase()), h.crossDomain = !(!n || n[1] === Ri[1] && n[2] === Ri[2] && (n[3] || ("http:" === n[1] ? "80": "443")) === (Ri[3] || ("http:" === Ri[1] ? "80": "443")))), h.data && h.processData && "string" != typeof h.data && (h.data = se.param(h.data, h.traditional)), B(ji, h, e, E), 2 === S) return E;
            l = h.global,
            l && 0 === se.active++&&se.event.trigger("ajaxStart"),
            h.type = h.type.toUpperCase(),
            h.hasContent = !Fi.test(h.type),
            o = h.url,
            h.hasContent || (h.data && (o = h.url += (xi.test(o) ? "&": "?") + h.data, delete h.data), h.cache === !1 && (h.url = Pi.test(o) ? o.replace(Pi, "$1_=" + Ii++) : o + (xi.test(o) ? "&": "?") + "_=" + Ii++)),
            h.ifModified && (se.lastModified[o] && E.setRequestHeader("If-Modified-Since", se.lastModified[o]), se.etag[o] && E.setRequestHeader("If-None-Match", se.etag[o])),
            (h.data && h.hasContent && h.contentType !== !1 || e.contentType) && E.setRequestHeader("Content-Type", h.contentType),
            E.setRequestHeader("Accept", h.dataTypes[0] && h.accepts[h.dataTypes[0]] ? h.accepts[h.dataTypes[0]] + ("*" !== h.dataTypes[0] ? ", " + Vi + "; q=0.01": "") : h.accepts["*"]);
            for (s in h.headers) E.setRequestHeader(s, h.headers[s]);
            if (h.beforeSend && (h.beforeSend.call(u, E, h) === !1 || 2 === S)) return E.abort();
            y = "abort";
            for (s in {
                success: 1,
                error: 1,
                complete: 1
            }) E[s](h[s]);
            if (d = B(zi, h, e, E)) {
                E.readyState = 1,
                l && p.trigger("ajaxSend", [E, h]),
                h.async && h.timeout > 0 && (r = setTimeout(function() {
                    E.abort("timeout")
                },
                h.timeout));
                try {
                    S = 1,
                    d.send(v, i)
                } catch(T) {
                    if (! (2 > S)) throw T;
                    i( - 1, T)
                }
            } else i( - 1, "No Transport");
            return E
        },
        getJSON: function(t, e, i) {
            return se.get(t, e, i, "json")
        },
        getScript: function(t, e) {
            return se.get(t, void 0, e, "script")
        }
    }),
    se.each(["get", "post"],
    function(t, e) {
        se[e] = function(t, i, n, s) {
            return se.isFunction(i) && (s = s || n, n = i, i = void 0),
            se.ajax({
                url: t,
                type: e,
                dataType: s,
                data: i,
                success: n
            })
        }
    }),
    se.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"],
    function(t, e) {
        se.fn[e] = function(t) {
            return this.on(e, t)
        }
    }),
    se._evalUrl = function(t) {
        return se.ajax({
            url: t,
            type: "GET",
            dataType: "script",
            async: !1,
            global: !1,
            "throws": !0
        })
    },
    se.fn.extend({
        wrapAll: function(t) {
            if (se.isFunction(t)) return this.each(function(e) {
                se(this).wrapAll(t.call(this, e))
            });
            if (this[0]) {
                var e = se(t, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && e.insertBefore(this[0]),
                e.map(function() {
                    for (var t = this; t.firstChild && 1 === t.firstChild.nodeType;) t = t.firstChild;
                    return t
                }).append(this)
            }
            return this
        },
        wrapInner: function(t) {
            return this.each(se.isFunction(t) ?
            function(e) {
                se(this).wrapInner(t.call(this, e))
            }: function() {
                var e = se(this),
                i = e.contents();
                i.length ? i.wrapAll(t) : e.append(t)
            })
        },
        wrap: function(t) {
            var e = se.isFunction(t);
            return this.each(function(i) {
                se(this).wrapAll(e ? t.call(this, i) : t)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                se.nodeName(this, "body") || se(this).replaceWith(this.childNodes)
            }).end()
        }
    }),
    se.expr.filters.hidden = function(t) {
        return t.offsetWidth <= 0 && t.offsetHeight <= 0 || !ie.reliableHiddenOffsets() && "none" === (t.style && t.style.display || se.css(t, "display"))
    },
    se.expr.filters.visible = function(t) {
        return ! se.expr.filters.hidden(t)
    };
    var Gi = /%20/g,
    Wi = /\[\]$/,
    Ji = /\r?\n/g,
    Yi = /^(?:submit|button|image|reset|file)$/i,
    Ki = /^(?:input|select|textarea|keygen)/i;
    se.param = function(t, e) {
        var i, n = [],
        s = function(t, e) {
            e = se.isFunction(e) ? e() : null == e ? "": e,
            n[n.length] = encodeURIComponent(t) + "=" + encodeURIComponent(e)
        };
        if (void 0 === e && (e = se.ajaxSettings && se.ajaxSettings.traditional), se.isArray(t) || t.jquery && !se.isPlainObject(t)) se.each(t,
        function() {
            s(this.name, this.value)
        });
        else for (i in t) V(i, t[i], e, s);
        return n.join("&").replace(Gi, "+")
    },
    se.fn.extend({
        serialize: function() {
            return se.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var t = se.prop(this, "elements");
                return t ? se.makeArray(t) : this
            }).filter(function() {
                var t = this.type;
                return this.name && !se(this).is(":disabled") && Ki.test(this.nodeName) && !Yi.test(t) && (this.checked || !Ie.test(t))
            }).map(function(t, e) {
                var i = se(this).val();
                return null == i ? null: se.isArray(i) ? se.map(i,
                function(t) {
                    return {
                        name: e.name,
                        value: t.replace(Ji, "\r\n")
                    }
                }) : {
                    name: e.name,
                    value: i.replace(Ji, "\r\n")
                }
            }).get()
        }
    }),
    se.ajaxSettings.xhr = void 0 !== t.ActiveXObject ?
    function() {
        return ! this.isLocal && /^(get|post|head|put|delete|options)$/i.test(this.type) && X() || G()
    }: X;
    var qi = 0,
    Qi = {},
    Zi = se.ajaxSettings.xhr();
    t.ActiveXObject && se(t).on("unload",
    function() {
        for (var t in Qi) Qi[t](void 0, !0)
    }),
    ie.cors = !!Zi && "withCredentials" in Zi,
    Zi = ie.ajax = !!Zi,
    Zi && se.ajaxTransport(function(t) {
        if (!t.crossDomain || ie.cors) {
            var e;
            return {
                send: function(i, n) {
                    var s, o = t.xhr(),
                    a = ++qi;
                    if (o.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields) for (s in t.xhrFields) o[s] = t.xhrFields[s];
                    t.mimeType && o.overrideMimeType && o.overrideMimeType(t.mimeType),
                    t.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest");
                    for (s in i) void 0 !== i[s] && o.setRequestHeader(s, i[s] + "");
                    o.send(t.hasContent && t.data || null),
                    e = function(i, s) {
                        var r, l, d;
                        if (e && (s || 4 === o.readyState)) if (delete Qi[a], e = void 0, o.onreadystatechange = se.noop, s) 4 !== o.readyState && o.abort();
                        else {
                            d = {},
                            r = o.status,
                            "string" == typeof o.responseText && (d.text = o.responseText);
                            try {
                                l = o.statusText
                            } catch(c) {
                                l = ""
                            }
                            r || !t.isLocal || t.crossDomain ? 1223 === r && (r = 204) : r = d.text ? 200 : 404
                        }
                        d && n(r, l, d, o.getAllResponseHeaders())
                    },
                    t.async ? 4 === o.readyState ? setTimeout(e) : o.onreadystatechange = Qi[a] = e: e()
                },
                abort: function() {
                    e && e(void 0, !0)
                }
            }
        }
    }),
    se.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function(t) {
                return se.globalEval(t),
                t
            }
        }
    }),
    se.ajaxPrefilter("script",
    function(t) {
        void 0 === t.cache && (t.cache = !1),
        t.crossDomain && (t.type = "GET", t.global = !1)
    }),
    se.ajaxTransport("script",
    function(t) {
        if (t.crossDomain) {
            var e, i = me.head || se("head")[0] || me.documentElement;
            return {
                send: function(n, s) {
                    e = me.createElement("script"),
                    e.async = !0,
                    t.scriptCharset && (e.charset = t.scriptCharset),
                    e.src = t.url,
                    e.onload = e.onreadystatechange = function(t, i) { (i || !e.readyState || /loaded|complete/.test(e.readyState)) && (e.onload = e.onreadystatechange = null, e.parentNode && e.parentNode.removeChild(e), e = null, i || s(200, "success"))
                    },
                    i.insertBefore(e, i.firstChild)
                },
                abort: function() {
                    e && e.onload(void 0, !0)
                }
            }
        }
    });
    var tn = [],
    en = /(=)\?(?=&|$)|\?\?/;
    se.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var t = tn.pop() || se.expando + "_" + Ii++;
            return this[t] = !0,
            t
        }
    }),
    se.ajaxPrefilter("json jsonp",
    function(e, i, n) {
        var s, o, a, r = e.jsonp !== !1 && (en.test(e.url) ? "url": "string" == typeof e.data && !(e.contentType || "").indexOf("application/x-www-form-urlencoded") && en.test(e.data) && "data");
        return r || "jsonp" === e.dataTypes[0] ? (s = e.jsonpCallback = se.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, r ? e[r] = e[r].replace(en, "$1" + s) : e.jsonp !== !1 && (e.url += (xi.test(e.url) ? "&": "?") + e.jsonp + "=" + s), e.converters["script json"] = function() {
            return a || se.error(s + " was not called"),
            a[0]
        },
        e.dataTypes[0] = "json", o = t[s], t[s] = function() {
            a = arguments
        },
        n.always(function() {
            t[s] = o,
            e[s] && (e.jsonpCallback = i.jsonpCallback, tn.push(s)),
            a && se.isFunction(o) && o(a[0]),
            a = o = void 0
        }), "script") : void 0
    }),
    se.parseHTML = function(t, e, i) {
        if (!t || "string" != typeof t) return null;
        "boolean" == typeof e && (i = e, e = !1),
        e = e || me;
        var n = he.exec(t),
        s = !i && [];
        return n ? [e.createElement(n[1])] : (n = se.buildFragment([t], e, s), s && s.length && se(s).remove(), se.merge([], n.childNodes))
    };
    var nn = se.fn.load;
    se.fn.load = function(t, e, i) {
        if ("string" != typeof t && nn) return nn.apply(this, arguments);
        var n, s, o, a = this,
        r = t.indexOf(" ");
        return r >= 0 && (n = se.trim(t.slice(r, t.length)), t = t.slice(0, r)),
        se.isFunction(e) ? (i = e, e = void 0) : e && "object" == typeof e && (o = "POST"),
        a.length > 0 && se.ajax({
            url: t,
            type: o,
            dataType: "html",
            data: e
        }).done(function(t) {
            s = arguments,
            a.html(n ? se("<div>").append(se.parseHTML(t)).find(n) : t)
        }).complete(i &&
        function(t, e) {
            a.each(i, s || [t.responseText, e, t])
        }),
        this
    },
    se.expr.filters.animated = function(t) {
        return se.grep(se.timers,
        function(e) {
            return t === e.elem
        }).length
    };
    var sn = t.document.documentElement;
    se.offset = {
        setOffset: function(t, e, i) {
            var n, s, o, a, r, l, d, c = se.css(t, "position"),
            h = se(t),
            u = {};
            "static" === c && (t.style.position = "relative"),
            r = h.offset(),
            o = se.css(t, "top"),
            l = se.css(t, "left"),
            d = ("absolute" === c || "fixed" === c) && se.inArray("auto", [o, l]) > -1,
            d ? (n = h.position(), a = n.top, s = n.left) : (a = parseFloat(o) || 0, s = parseFloat(l) || 0),
            se.isFunction(e) && (e = e.call(t, i, r)),
            null != e.top && (u.top = e.top - r.top + a),
            null != e.left && (u.left = e.left - r.left + s),
            "using" in e ? e.using.call(t, u) : h.css(u)
        }
    },
    se.fn.extend({
        offset: function(t) {
            if (arguments.length) return void 0 === t ? this: this.each(function(e) {
                se.offset.setOffset(this, t, e)
            });
            var e, i, n = {
                top: 0,
                left: 0
            },
            s = this[0],
            o = s && s.ownerDocument;
            if (o) return e = o.documentElement,
            se.contains(e, s) ? (typeof s.getBoundingClientRect !== Le && (n = s.getBoundingClientRect()), i = W(o), {
                top: n.top + (i.pageYOffset || e.scrollTop) - (e.clientTop || 0),
                left: n.left + (i.pageXOffset || e.scrollLeft) - (e.clientLeft || 0)
            }) : n
        },
        position: function() {
            if (this[0]) {
                var t, e, i = {
                    top: 0,
                    left: 0
                },
                n = this[0];
                return "fixed" === se.css(n, "position") ? e = n.getBoundingClientRect() : (t = this.offsetParent(), e = this.offset(), se.nodeName(t[0], "html") || (i = t.offset()), i.top += se.css(t[0], "borderTopWidth", !0), i.left += se.css(t[0], "borderLeftWidth", !0)),
                {
                    top: e.top - i.top - se.css(n, "marginTop", !0),
                    left: e.left - i.left - se.css(n, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var t = this.offsetParent || sn; t && !se.nodeName(t, "html") && "static" === se.css(t, "position");) t = t.offsetParent;
                return t || sn
            })
        }
    }),
    se.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    },
    function(t, e) {
        var i = /Y/.test(e);
        se.fn[t] = function(n) {
            return De(this,
            function(t, n, s) {
                var o = W(t);
                return void 0 === s ? o ? e in o ? o[e] : o.document.documentElement[n] : t[n] : void(o ? o.scrollTo(i ? se(o).scrollLeft() : s, i ? s: se(o).scrollTop()) : t[n] = s)
            },
            t, n, arguments.length, null)
        }
    }),
    se.each(["top", "left"],
    function(t, e) {
        se.cssHooks[e] = k(ie.pixelPosition,
        function(t, i) {
            return i ? (i = ei(t, e), ni.test(i) ? se(t).position()[e] + "px": i) : void 0
        })
    }),
    se.each({
        Height: "height",
        Width: "width"
    },
    function(t, e) {
        se.each({
            padding: "inner" + t,
            content: e,
            "": "outer" + t
        },
        function(i, n) {
            se.fn[n] = function(n, s) {
                var o = arguments.length && (i || "boolean" != typeof n),
                a = i || (n === !0 || s === !0 ? "margin": "border");
                return De(this,
                function(e, i, n) {
                    var s;
                    return se.isWindow(e) ? e.document.documentElement["client" + t] : 9 === e.nodeType ? (s = e.documentElement, Math.max(e.body["scroll" + t], s["scroll" + t], e.body["offset" + t], s["offset" + t], s["client" + t])) : void 0 === n ? se.css(e, i, a) : se.style(e, i, n, a)
                },
                e, o ? n: void 0, o, null)
            }
        })
    }),
    se.fn.size = function() {
        return this.length
    },
    se.fn.andSelf = se.fn.addBack,
    "function" == typeof define && define.amd && define("jquery", [],
    function() {
        return se
    });
    var on = t.jQuery,
    an = t.$;
    return se.noConflict = function(e) {
        return t.$ === se && (t.$ = an),
        e && t.jQuery === se && (t.jQuery = on),
        se
    },
    typeof e === Le && (t.jQuery = t.$ = se),
    se
});
!function(t, e) {
    t.rails !== e && t.error("jquery-ujs has already been loaded!");
    var i, n = t(document);
    t.rails = i = {
        linkClickSelector: "a[data-confirm], a[data-method], a[data-remote], a[data-disable-with], a[data-disable]",
        buttonClickSelector: "button[data-remote]:not(form button), button[data-confirm]:not(form button)",
        inputChangeSelector: "select[data-remote], input[data-remote], textarea[data-remote]",
        formSubmitSelector: "form",
        formInputClickSelector: "form input[type=submit], form input[type=image], form button[type=submit], form button:not([type]), input[type=submit][form], input[type=image][form], button[type=submit][form], button[form]:not([type])",
        disableSelector: "input[data-disable-with]:enabled, button[data-disable-with]:enabled, textarea[data-disable-with]:enabled, input[data-disable]:enabled, button[data-disable]:enabled, textarea[data-disable]:enabled",
        enableSelector: "input[data-disable-with]:disabled, button[data-disable-with]:disabled, textarea[data-disable-with]:disabled, input[data-disable]:disabled, button[data-disable]:disabled, textarea[data-disable]:disabled",
        requiredInputSelector: "input[name][required]:not([disabled]),textarea[name][required]:not([disabled])",
        fileInputSelector: "input[type=file]",
        linkDisableSelector: "a[data-disable-with], a[data-disable]",
        buttonDisableSelector: "button[data-remote][data-disable-with], button[data-remote][data-disable]",
        CSRFProtection: function(e) {
            var i = t('meta[name="csrf-token"]').attr("content");
            i && e.setRequestHeader("X-CSRF-Token", i)
        },
        refreshCSRFTokens: function() {
            var e = t("meta[name=csrf-token]").attr("content"),
            i = t("meta[name=csrf-param]").attr("content");
            t('form input[name="' + i + '"]').val(e)
        },
        fire: function(e, i, n) {
            var s = t.Event(i);
            return e.trigger(s, n),
            s.result !== !1
        },
        confirm: function(t) {
            return confirm(t)
        },
        ajax: function(e) {
            return t.ajax(e)
        },
        href: function(t) {
            return t.attr("href")
        },
        handleRemote: function(n) {
            var s, o, a, r, l, d, c, h;
            if (i.fire(n, "ajax:before")) {
                if (r = n.data("cross-domain"), l = r === e ? null: r, d = n.data("with-credentials") || null, c = n.data("type") || t.ajaxSettings && t.ajaxSettings.dataType, n.is("form")) {
                    s = n.attr("method"),
                    o = n.attr("action"),
                    a = n.serializeArray();
                    var u = n.data("ujs:submit-button");
                    u && (a.push(u), n.data("ujs:submit-button", null))
                } else n.is(i.inputChangeSelector) ? (s = n.data("method"), o = n.data("url"), a = n.serialize(), n.data("params") && (a = a + "&" + n.data("params"))) : n.is(i.buttonClickSelector) ? (s = n.data("method") || "get", o = n.data("url"), a = n.serialize(), n.data("params") && (a = a + "&" + n.data("params"))) : (s = n.data("method"), o = i.href(n), a = n.data("params") || null);
                return h = {
                    type: s || "GET",
                    data: a,
                    dataType: c,
                    beforeSend: function(t, s) {
                        return s.dataType === e && t.setRequestHeader("accept", "*/*;q=0.5, " + s.accepts.script),
                        i.fire(n, "ajax:beforeSend", [t, s]) ? void n.trigger("ajax:send", t) : !1
                    },
                    success: function(t, e, i) {
                        n.trigger("ajax:success", [t, e, i])
                    },
                    complete: function(t, e) {
                        n.trigger("ajax:complete", [t, e])
                    },
                    error: function(t, e, i) {
                        n.trigger("ajax:error", [t, e, i])
                    },
                    crossDomain: l
                },
                d && (h.xhrFields = {
                    withCredentials: d
                }),
                o && (h.url = o),
                i.ajax(h)
            }
            return ! 1
        },
        handleMethod: function(n) {
            var s = i.href(n),
            o = n.data("method"),
            a = n.attr("target"),
            r = t("meta[name=csrf-token]").attr("content"),
            l = t("meta[name=csrf-param]").attr("content"),
            d = t('<form method="post" action="' + s + '"></form>'),
            c = '<input name="_method" value="' + o + '" type="hidden" />';
            l !== e && r !== e && (c += '<input name="' + l + '" value="' + r + '" type="hidden" />'),
            a && d.attr("target", a),
            d.hide().append(c).appendTo("body"),
            d.submit()
        },
        formElements: function(e, i) {
            return e.is("form") ? t(e[0].elements).filter(i) : e.find(i)
        },
        disableFormElements: function(e) {
            i.formElements(e, i.disableSelector).each(function() {
                i.disableFormElement(t(this))
            })
        },
        disableFormElement: function(t) {
            var i, n;
            i = t.is("button") ? "html": "val",
            n = t.data("disable-with"),
            t.data("ujs:enable-with", t[i]()),
            n !== e && t[i](n),
            t.prop("disabled", !0)
        },
        enableFormElements: function(e) {
            i.formElements(e, i.enableSelector).each(function() {
                i.enableFormElement(t(this))
            })
        },
        enableFormElement: function(t) {
            var e = t.is("button") ? "html": "val";
            t.data("ujs:enable-with") && t[e](t.data("ujs:enable-with")),
            t.prop("disabled", !1)
        },
        allowAction: function(t) {
            var e, n = t.data("confirm"),
            s = !1;
            return n ? (i.fire(t, "confirm") && (s = i.confirm(n), e = i.fire(t, "confirm:complete", [s])), s && e) : !0
        },
        blankInputs: function(e, i, n) {
            var s, o, a = t(),
            r = i || "input,textarea",
            l = e.find(r);
            return l.each(function() {
                if (s = t(this), o = s.is("input[type=checkbox],input[type=radio]") ? s.is(":checked") : s.val(), !o == !n) {
                    if (s.is("input[type=radio]") && l.filter('input[type=radio]:checked[name="' + s.attr("name") + '"]').length) return ! 0;
                    a = a.add(s)
                }
            }),
            a.length ? a: !1
        },
        nonBlankInputs: function(t, e) {
            return i.blankInputs(t, e, !0)
        },
        stopEverything: function(e) {
            return t(e.target).trigger("ujs:everythingStopped"),
            e.stopImmediatePropagation(),
            !1
        },
        disableElement: function(t) {
            var n = t.data("disable-with");
            t.data("ujs:enable-with", t.html()),
            n !== e && t.html(n),
            t.bind("click.railsDisable",
            function(t) {
                return i.stopEverything(t)
            })
        },
        enableElement: function(t) {
            t.data("ujs:enable-with") !== e && (t.html(t.data("ujs:enable-with")), t.removeData("ujs:enable-with")),
            t.unbind("click.railsDisable")
        }
    },
    i.fire(n, "rails:attachBindings") && (t.ajaxPrefilter(function(t, e, n) {
        t.crossDomain || i.CSRFProtection(n)
    }), n.delegate(i.linkDisableSelector, "ajax:complete",
    function() {
        i.enableElement(t(this))
    }), n.delegate(i.buttonDisableSelector, "ajax:complete",
    function() {
        i.enableFormElement(t(this))
    }), n.delegate(i.linkClickSelector, "click.rails",
    function(n) {
        var s = t(this),
        o = s.data("method"),
        a = s.data("params"),
        r = n.metaKey || n.ctrlKey;
        if (!i.allowAction(s)) return i.stopEverything(n);
        if (!r && s.is(i.linkDisableSelector) && i.disableElement(s), s.data("remote") !== e) {
            if (r && (!o || "GET" === o) && !a) return ! 0;
            var l = i.handleRemote(s);
            return l === !1 ? i.enableElement(s) : l.error(function() {
                i.enableElement(s)
            }),
            !1
        }
        return s.data("method") ? (i.handleMethod(s), !1) : void 0
    }), n.delegate(i.buttonClickSelector, "click.rails",
    function(e) {
        var n = t(this);
        if (!i.allowAction(n)) return i.stopEverything(e);
        n.is(i.buttonDisableSelector) && i.disableFormElement(n);
        var s = i.handleRemote(n);
        return s === !1 ? i.enableFormElement(n) : s.error(function() {
            i.enableFormElement(n)
        }),
        !1
    }), n.delegate(i.inputChangeSelector, "change.rails",
    function(e) {
        var n = t(this);
        return i.allowAction(n) ? (i.handleRemote(n), !1) : i.stopEverything(e)
    }), n.delegate(i.formSubmitSelector, "submit.rails",
    function(n) {
        var s, o, a = t(this),
        r = a.data("remote") !== e;
        if (!i.allowAction(a)) return i.stopEverything(n);
        if (a.attr("novalidate") == e && (s = i.blankInputs(a, i.requiredInputSelector), s && i.fire(a, "ajax:aborted:required", [s]))) return i.stopEverything(n);
        if (r) {
            if (o = i.nonBlankInputs(a, i.fileInputSelector)) {
                setTimeout(function() {
                    i.disableFormElements(a)
                },
                13);
                var l = i.fire(a, "ajax:aborted:file", [o]);
                return l || setTimeout(function() {
                    i.enableFormElements(a)
                },
                13),
                l
            }
            return i.handleRemote(a),
            !1
        }
        setTimeout(function() {
            i.disableFormElements(a)
        },
        13)
    }), n.delegate(i.formInputClickSelector, "click.rails",
    function(e) {
        var n = t(this);
        if (!i.allowAction(n)) return i.stopEverything(e);
        var s = n.attr("name"),
        o = s ? {
            name: s,
            value: n.val()
        }: null;
        n.closest("form").data("ujs:submit-button", o)
    }), n.delegate(i.formSubmitSelector, "ajax:send.rails",
    function(e) {
        this == e.target && i.disableFormElements(t(this))
    }), n.delegate(i.formSubmitSelector, "ajax:complete.rails",
    function(e) {
        this == e.target && i.enableFormElements(t(this))
    }), t(function() {
        i.refreshCSRFTokens()
    }))
} (jQuery);
!function(t) {
    t.extend({
        debounce: function(t, e, i, n) {
            3 == arguments.length && "boolean" != typeof i && (n = i, i = !1);
            var s;
            return function() {
                var o = arguments;
                n = n || this,
                i && !s && t.apply(n, o),
                clearTimeout(s),
                s = setTimeout(function() {
                    i || t.apply(n, o),
                    s = null
                },
                e)
            }
        },
        throttle: function(t, e, i) {
            var n, s, o;
            return function() {
                s = arguments,
                o = !0,
                i = i || this,
                n ||
                function() {
                    o ? (t.apply(i, s), o = !1, n = setTimeout(arguments.callee, e)) : n = null
                } ()
            }
        }
    })
} (jQuery);
jQuery.easing.jswing = jQuery.easing.swing,
jQuery.extend(jQuery.easing, {
    def: "easeOutQuad",
    swing: function(t, e, i, n, s) {
        return jQuery.easing[jQuery.easing.def](t, e, i, n, s)
    },
    easeInQuad: function(t, e, i, n, s) {
        return n * (e /= s) * e + i
    },
    easeOutQuad: function(t, e, i, n, s) {
        return - n * (e /= s) * (e - 2) + i
    },
    easeInOutQuad: function(t, e, i, n, s) {
        return (e /= s / 2) < 1 ? n / 2 * e * e + i: -n / 2 * (--e * (e - 2) - 1) + i
    },
    easeInCubic: function(t, e, i, n, s) {
        return n * (e /= s) * e * e + i
    },
    easeOutCubic: function(t, e, i, n, s) {
        return n * ((e = e / s - 1) * e * e + 1) + i
    },
    easeInOutCubic: function(t, e, i, n, s) {
        return (e /= s / 2) < 1 ? n / 2 * e * e * e + i: n / 2 * ((e -= 2) * e * e + 2) + i
    },
    easeInQuart: function(t, e, i, n, s) {
        return n * (e /= s) * e * e * e + i
    },
    easeOutQuart: function(t, e, i, n, s) {
        return - n * ((e = e / s - 1) * e * e * e - 1) + i
    },
    easeInOutQuart: function(t, e, i, n, s) {
        return (e /= s / 2) < 1 ? n / 2 * e * e * e * e + i: -n / 2 * ((e -= 2) * e * e * e - 2) + i
    },
    easeInQuint: function(t, e, i, n, s) {
        return n * (e /= s) * e * e * e * e + i
    },
    easeOutQuint: function(t, e, i, n, s) {
        return n * ((e = e / s - 1) * e * e * e * e + 1) + i
    },
    easeInOutQuint: function(t, e, i, n, s) {
        return (e /= s / 2) < 1 ? n / 2 * e * e * e * e * e + i: n / 2 * ((e -= 2) * e * e * e * e + 2) + i
    },
    easeInSine: function(t, e, i, n, s) {
        return - n * Math.cos(e / s * (Math.PI / 2)) + n + i
    },
    easeOutSine: function(t, e, i, n, s) {
        return n * Math.sin(e / s * (Math.PI / 2)) + i
    },
    easeInOutSine: function(t, e, i, n, s) {
        return - n / 2 * (Math.cos(Math.PI * e / s) - 1) + i
    },
    easeInExpo: function(t, e, i, n, s) {
        return 0 == e ? i: n * Math.pow(2, 10 * (e / s - 1)) + i
    },
    easeOutExpo: function(t, e, i, n, s) {
        return e == s ? i + n: n * ( - Math.pow(2, -10 * e / s) + 1) + i
    },
    easeInOutExpo: function(t, e, i, n, s) {
        return 0 == e ? i: e == s ? i + n: (e /= s / 2) < 1 ? n / 2 * Math.pow(2, 10 * (e - 1)) + i: n / 2 * ( - Math.pow(2, -10 * --e) + 2) + i
    },
    easeInCirc: function(t, e, i, n, s) {
        return - n * (Math.sqrt(1 - (e /= s) * e) - 1) + i
    },
    easeOutCirc: function(t, e, i, n, s) {
        return n * Math.sqrt(1 - (e = e / s - 1) * e) + i
    },
    easeInOutCirc: function(t, e, i, n, s) {
        return (e /= s / 2) < 1 ? -n / 2 * (Math.sqrt(1 - e * e) - 1) + i: n / 2 * (Math.sqrt(1 - (e -= 2) * e) + 1) + i
    },
    easeInElastic: function(t, e, i, n, s) {
        var o = 1.70158,
        a = 0,
        r = n;
        if (0 == e) return i;
        if (1 == (e /= s)) return i + n;
        if (a || (a = .3 * s), r < Math.abs(n)) {
            r = n;
            var o = a / 4
        } else var o = a / (2 * Math.PI) * Math.asin(n / r);
        return - (r * Math.pow(2, 10 * (e -= 1)) * Math.sin(2 * (e * s - o) * Math.PI / a)) + i
    },
    easeOutElastic: function(t, e, i, n, s) {
        var o = 1.70158,
        a = 0,
        r = n;
        if (0 == e) return i;
        if (1 == (e /= s)) return i + n;
        if (a || (a = .3 * s), r < Math.abs(n)) {
            r = n;
            var o = a / 4
        } else var o = a / (2 * Math.PI) * Math.asin(n / r);
        return r * Math.pow(2, -10 * e) * Math.sin(2 * (e * s - o) * Math.PI / a) + n + i
    },
    easeInOutElastic: function(t, e, i, n, s) {
        var o = 1.70158,
        a = 0,
        r = n;
        if (0 == e) return i;
        if (2 == (e /= s / 2)) return i + n;
        if (a || (a = .3 * s * 1.5), r < Math.abs(n)) {
            r = n;
            var o = a / 4
        } else var o = a / (2 * Math.PI) * Math.asin(n / r);
        return 1 > e ? -.5 * r * Math.pow(2, 10 * (e -= 1)) * Math.sin(2 * (e * s - o) * Math.PI / a) + i: r * Math.pow(2, -10 * (e -= 1)) * Math.sin(2 * (e * s - o) * Math.PI / a) * .5 + n + i
    },
    easeInBack: function(t, e, i, n, s, o) {
        return void 0 == o && (o = 1.70158),
        n * (e /= s) * e * ((o + 1) * e - o) + i
    },
    easeOutBack: function(t, e, i, n, s, o) {
        return void 0 == o && (o = 1.70158),
        n * ((e = e / s - 1) * e * ((o + 1) * e + o) + 1) + i
    },
    easeInOutBack: function(t, e, i, n, s, o) {
        return void 0 == o && (o = 1.70158),
        (e /= s / 2) < 1 ? n / 2 * e * e * (((o *= 1.525) + 1) * e - o) + i: n / 2 * ((e -= 2) * e * (((o *= 1.525) + 1) * e + o) + 2) + i
    },
    easeInBounce: function(t, e, i, n, s) {
        return n - jQuery.easing.easeOutBounce(t, s - e, 0, n, s) + i
    },
    easeOutBounce: function(t, e, i, n, s) {
        return (e /= s) < 1 / 2.75 ? 7.5625 * n * e * e + i: 2 / 2.75 > e ? n * (7.5625 * (e -= 1.5 / 2.75) * e + .75) + i: 2.5 / 2.75 > e ? n * (7.5625 * (e -= 2.25 / 2.75) * e + .9375) + i: n * (7.5625 * (e -= 2.625 / 2.75) * e + .984375) + i
    },
    easeInOutBounce: function(t, e, i, n, s) {
        return s / 2 > e ? .5 * jQuery.easing.easeInBounce(t, 2 * e, 0, n, s) + i: .5 * jQuery.easing.easeOutBounce(t, 2 * e - s, 0, n, s) + .5 * n + i
    }
});
!function() {
    var t, e, i, n, s, o, a, r, l, d, c, h, u, p, m, f, g, v, b, S = [].slice,
    y = [].indexOf ||
    function(t) {
        for (var e = 0,
        i = this.length; i > e; e++) if (e in this && this[e] === t) return e;
        return - 1
    };
    t = jQuery,
    t.payment = {},
    t.payment.fn = {},
    t.fn.payment = function() {
        var e, i;
        return i = arguments[0],
        e = 2 <= arguments.length ? S.call(arguments, 1) : [],
        t.payment.fn[i].apply(this, e)
    },
    s = /(\d{1,4})/g,
    n = [{
        type: "maestro",
        pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
        format: s,
        length: [12, 13, 14, 15, 16, 17, 18, 19],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "dinersclub",
        pattern: /^(36|38|30[0-5])/,
        format: s,
        length: [14],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "laser",
        pattern: /^(6706|6771|6709)/,
        format: s,
        length: [16, 17, 18, 19],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "jcb",
        pattern: /^35/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "unionpay",
        pattern: /^62/,
        format: s,
        length: [16, 17, 18, 19],
        cvcLength: [3],
        luhn: !1
    },
    {
        type: "discover",
        pattern: /^(6011|65|64[4-9]|622)/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "mastercard",
        pattern: /^5[1-5]/,
        format: s,
        length: [16],
        cvcLength: [3],
        luhn: !0
    },
    {
        type: "amex",
        pattern: /^3[47]/,
        format: /(\d{1,4})(\d{1,6})?(\d{1,5})?/,
        length: [15],
        cvcLength: [3, 4],
        luhn: !0
    },
    {
        type: "visa",
        pattern: /^4/,
        format: s,
        length: [13, 14, 15, 16],
        cvcLength: [3],
        luhn: !0
    }],
    e = function(t) {
        var e, i, s;
        for (t = (t + "").replace(/\D/g, ""), i = 0, s = n.length; s > i; i++) if (e = n[i], e.pattern.test(t)) return e
    },
    i = function(t) {
        var e, i, s;
        for (i = 0, s = n.length; s > i; i++) if (e = n[i], e.type === t) return e
    },
    u = function(t) {
        var e, i, n, s, o, a;
        for (n = !0, s = 0, i = (t + "").split("").reverse(), o = 0, a = i.length; a > o; o++) e = i[o],
        e = parseInt(e, 10),
        (n = !n) && (e *= 2),
        e > 9 && (e -= 9),
        s += e;
        return s % 10 === 0
    },
    h = function(t) {
        var e;
        return null != t.prop("selectionStart") && t.prop("selectionStart") !== t.prop("selectionEnd") ? !0 : ("undefined" != typeof document && null !== document && null != (e = document.selection) && "function" == typeof e.createRange ? e.createRange().text: void 0) ? !0 : !1
    },
    p = function(e) {
        return setTimeout(function() {
            var i, n;
            return i = t(e.currentTarget),
            n = i.val(),
            n = t.payment.formatCardNumber(n),
            i.val(n)
        })
    },
    r = function(i) {
        var n, s, o, a, r, l, d;
        return o = String.fromCharCode(i.which),
        !/^\d+$/.test(o) || (n = t(i.currentTarget), d = n.val(), s = e(d + o), a = (d.replace(/\D/g, "") + o).length, l = 16, s && (l = s.length[s.length.length - 1]), a >= l || null != n.prop("selectionStart") && n.prop("selectionStart") !== d.length) ? void 0 : (r = s && "amex" === s.type ? /^(\d{4}|\d{4}\s\d{6})$/: /(?:^|\s)(\d{4})$/, r.test(d) ? (i.preventDefault(), n.val(d + " " + o)) : r.test(d + o) ? (i.preventDefault(), n.val(d + o + " ")) : void 0)
    },
    o = function(e) {
        var i, n;
        return i = t(e.currentTarget),
        n = i.val(),
        e.meta || null != i.prop("selectionStart") && i.prop("selectionStart") !== n.length ? void 0 : 8 === e.which && /\s\d?$/.test(n) ? (e.preventDefault(), i.val(n.replace(/\s\d?$/, ""))) : void 0
    },
    l = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (i = t(e.currentTarget), s = i.val() + n, /^\d$/.test(s) && "0" !== s && "1" !== s ? (e.preventDefault(), i.val("0" + s + " / ")) : /^\d\d$/.test(s) ? (e.preventDefault(), i.val("" + s + " / ")) : void 0) : void 0
    },
    d = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (i = t(e.currentTarget), s = i.val(), /^\d\d$/.test(s) ? i.val("" + s + " / ") : void 0) : void 0
    },
    c = function(e) {
        var i, n, s;
        return n = String.fromCharCode(e.which),
        "/" === n ? (i = t(e.currentTarget), s = i.val(), /^\d$/.test(s) && "0" !== s ? i.val("0" + s + " / ") : void 0) : void 0
    },
    a = function(e) {
        var i, n;
        if (!e.meta && (i = t(e.currentTarget), n = i.val(), 8 === e.which && (null == i.prop("selectionStart") || i.prop("selectionStart") === n.length))) return /\s\/\s?\d?$/.test(n) ? (e.preventDefault(), i.val(n.replace(/\s\/\s?\d?$/, ""))) : void 0
    },
    v = function(t) {
        var e;
        return t.metaKey || t.ctrlKey ? !0 : 32 === t.which ? !1 : 0 === t.which ? !0 : t.which < 33 ? !0 : (e = String.fromCharCode(t.which), !!/[\d\s]/.test(e))
    },
    f = function(i) {
        var n, s, o, a;
        return n = t(i.currentTarget),
        o = String.fromCharCode(i.which),
        /^\d+$/.test(o) && !h(n) ? (a = (n.val() + o).replace(/\D/g, ""), s = e(a), s ? a.length <= s.length[s.length.length - 1] : a.length <= 16) : void 0
    },
    g = function(e) {
        var i, n, s;
        return i = t(e.currentTarget),
        n = String.fromCharCode(e.which),
        /^\d+$/.test(n) && !h(i) ? (s = i.val() + n, s = s.replace(/\D/g, ""), s.length > 6 ? !1 : void 0) : void 0
    },
    m = function(e) {
        var i, n, s;
        return i = t(e.currentTarget),
        n = String.fromCharCode(e.which),
        /^\d+$/.test(n) ? (s = i.val() + n, s.length <= 4) : void 0
    },
    b = function(e) {
        var i, s, o, a, r;
        return i = t(e.currentTarget),
        r = i.val(),
        a = t.payment.cardType(r) || "unknown",
        i.hasClass(a) ? void 0 : (s = function() {
            var t, e, i;
            for (i = [], t = 0, e = n.length; e > t; t++) o = n[t],
            i.push(o.type);
            return i
        } (), i.removeClass("unknown"), i.removeClass(s.join(" ")), i.addClass(a), i.toggleClass("identified", "unknown" !== a), i.trigger("payment.cardType", a))
    },
    t.payment.fn.formatCardCVC = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", m),
        this
    },
    t.payment.fn.formatCardExpiry = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", g),
        this.on("keypress", l),
        this.on("keypress", c),
        this.on("keypress", d),
        this.on("keydown", a),
        this
    },
    t.payment.fn.formatCardNumber = function() {
        return this.payment("restrictNumeric"),
        this.on("keypress", f),
        this.on("keypress", r),
        this.on("keydown", o),
        this.on("keyup", b),
        this.on("paste", p),
        this
    },
    t.payment.fn.restrictNumeric = function() {
        return this.on("keypress", v),
        this
    },
    t.payment.fn.cardExpiryVal = function() {
        return t.payment.cardExpiryVal(t(this).val())
    },
    t.payment.cardExpiryVal = function(t) {
        var e, i, n, s;
        return t = t.replace(/\s/g, ""),
        s = t.split("/", 2),
        e = s[0],
        n = s[1],
        2 === (null != n ? n.length: void 0) && /^\d+$/.test(n) && (i = (new Date).getFullYear(), i = i.toString().slice(0, 2), n = i + n),
        e = parseInt(e, 10),
        n = parseInt(n, 10),
        {
            month: e,
            year: n
        }
    },
    t.payment.validateCardNumber = function(t) {
        var i, n;
        return t = (t + "").replace(/\s+|-/g, ""),
        /^\d+$/.test(t) ? (i = e(t), i ? (n = t.length, y.call(i.length, n) >= 0 && (i.luhn === !1 || u(t))) : !1) : !1
    },
    t.payment.validateCardExpiry = function(e, i) {
        var n, s, o, a;
        return "object" == typeof e && "month" in e && (a = e, e = a.month, i = a.year),
        e && i ? (e = t.trim(e), i = t.trim(i), /^\d+$/.test(e) && /^\d+$/.test(i) && parseInt(e, 10) <= 12 ? (2 === i.length && (o = (new Date).getFullYear(), o = o.toString().slice(0, 2), i = o + i), s = new Date(i, e), n = new Date, s.setMonth(s.getMonth() - 1), s.setMonth(s.getMonth() + 1, 1), s > n) : !1) : !1
    },
    t.payment.validateCardCVC = function(e, n) {
        var s, o;
        return e = t.trim(e),
        /^\d+$/.test(e) ? n ? (s = e.length, y.call(null != (o = i(n)) ? o.cvcLength: void 0, s) >= 0) : e.length >= 3 && e.length <= 4 : !1
    },
    t.payment.cardType = function(t) {
        var i;
        return t ? (null != (i = e(t)) ? i.type: void 0) || null: null
    },
    t.payment.formatCardNumber = function(t) {
        var i, n, s, o;
        return (i = e(t)) ? (s = i.length[i.length.length - 1], t = t.replace(/\D/g, ""), t = t.slice(0, +s + 1 || 9e9), i.format.global ? null != (o = t.match(i.format)) ? o.join(" ") : void 0 : (n = i.format.exec(t), null != n && n.shift(), null != n ? n.join(" ") : void 0)) : t
    }
}.call(this);
!function(t) {
    t.fn.changeElementType = function(e) {
        this.each(function(i, n) {
            var s = {};
            t.each(n.attributes,
            function(t, e) {
                s[e.nodeName] = e.nodeValue
            });
            var o = t("<" + e + "/>", s).append(t(n).contents());
            return t(n).replaceWith(o),
            o
        })
    }
} (jQuery);
!function(t, e, i) {
    "function" == typeof define && define.amd ? define(["jquery"],
    function(n) {
        return i(n, t, e),
        n.mobile
    }) : i(t.jQuery, t, e)
} (this, document,
function(t, e, i) { !
    function(t, e, i, n) {
        function s(t) {
            for (; t && "undefined" != typeof t.originalEvent;) t = t.originalEvent;
            return t
        }
        function o(e, i) {
            var o, a, r, l, d, c, h, u, p, m = e.type;
            if (e = t.Event(e), e.type = i, o = e.originalEvent, a = t.event.props, m.search(/^(mouse|click)/) > -1 && (a = I), o) for (h = a.length, l; h;) l = a[--h],
            e[l] = o[l];
            if (m.search(/mouse(down|up)|click/) > -1 && !e.which && (e.which = 1), -1 !== m.search(/^touch/) && (r = s(o), m = r.touches, d = r.changedTouches, c = m && m.length ? m[0] : d && d.length ? d[0] : n)) for (u = 0, p = A.length; p > u; u++) l = A[u],
            e[l] = c[l];
            return e
        }
        function a(e) {
            for (var i, n, s = {}; e;) {
                i = t.data(e, _);
                for (n in i) i[n] && (s[n] = s.hasVirtualBinding = !0);
                e = e.parentNode
            }
            return s
        }
        function r(e, i) {
            for (var n; e;) {
                if (n = t.data(e, _), n && (!i || n[i])) return e;
                e = e.parentNode
            }
            return null
        }
        function l() {
            U = !1
        }
        function d() {
            U = !0
        }
        function c() {
            j = 0,
            P.length = 0,
            $ = !1,
            d()
        }
        function h() {
            l()
        }
        function u() {
            p(),
            M = setTimeout(function() {
                M = 0,
                c()
            },
            t.vmouse.resetTimerDuration)
        }
        function p() {
            M && (clearTimeout(M), M = 0)
        }
        function m(e, i, n) {
            var s;
            return (n && n[e] || !n && r(i.target, e)) && (s = o(i, e), t(i.target).trigger(s)),
            s
        }
        function f(e) {
            var i, n = t.data(e.target, k);
            $ || j && j === n || (i = m("v" + e.type, e), i && (i.isDefaultPrevented() && e.preventDefault(), i.isPropagationStopped() && e.stopPropagation(), i.isImmediatePropagationStopped() && e.stopImmediatePropagation()))
        }
        function g(e) {
            var i, n, o, r = s(e).touches;
            r && 1 === r.length && (i = e.target, n = a(i), n.hasVirtualBinding && (j = H++, t.data(i, k, j), p(), h(), N = !1, o = s(e).touches[0], R = o.pageX, O = o.pageY, m("vmouseover", e, n), m("vmousedown", e, n)))
        }
        function v(t) {
            U || (N || m("vmousecancel", t, a(t.target)), N = !0, u())
        }
        function b(e) {
            if (!U) {
                var i = s(e).touches[0],
                n = N,
                o = t.vmouse.moveDistanceThreshold,
                r = a(e.target);
                N = N || Math.abs(i.pageX - R) > o || Math.abs(i.pageY - O) > o,
                N && !n && m("vmousecancel", e, r),
                m("vmousemove", e, r),
                u()
            }
        }
        function S(t) {
            if (!U) {
                d();
                var e, i, n = a(t.target);
                m("vmouseup", t, n),
                N || (e = m("vclick", t, n), e && e.isDefaultPrevented() && (i = s(t).changedTouches[0], P.push({
                    touchID: j,
                    x: i.clientX,
                    y: i.clientY
                }), $ = !0)),
                m("vmouseout", t, n),
                N = !1,
                u()
            }
        }
        function y(e) {
            var i, n = t.data(e, _);
            if (n) for (i in n) if (n[i]) return ! 0;
            return ! 1
        }
        function E() {}
        function T(e) {
            var i = e.substr(1);
            return {
                setup: function() {
                    y(this) || t.data(this, _, {});
                    var n = t.data(this, _);
                    n[e] = !0,
                    x[e] = (x[e] || 0) + 1,
                    1 === x[e] && B.bind(i, f),
                    t(this).bind(i, E),
                    F && (x.touchstart = (x.touchstart || 0) + 1, 1 === x.touchstart && B.bind("touchstart", g).bind("touchend", S).bind("touchmove", b).bind("scroll", v))
                },
                teardown: function() {--x[e],
                    x[e] || B.unbind(i, f),
                    F && (--x.touchstart, x.touchstart || B.unbind("touchstart", g).unbind("touchmove", b).unbind("touchend", S).unbind("scroll", v));
                    var n = t(this),
                    s = t.data(this, _);
                    s && (s[e] = !1),
                    n.unbind(i, E),
                    y(this) || n.removeData(_)
                }
            }
        }
        var L, w, _ = "virtualMouseBindings",
        k = "virtualTouchID",
        C = "vmouseover vmousedown vmousemove vmouseup vclick vmouseout vmousecancel".split(" "),
        A = "clientX clientY pageX pageY screenX screenY".split(" "),
        D = t.event.mouseHooks ? t.event.mouseHooks.props: [],
        I = t.event.props.concat(D),
        x = {},
        M = 0,
        R = 0,
        O = 0,
        N = !1,
        P = [],
        $ = !1,
        U = !1,
        F = "addEventListener" in i,
        B = t(i),
        H = 1,
        j = 0;
        for (t.vmouse = {
            moveDistanceThreshold: 10,
            clickDistanceThreshold: 10,
            resetTimerDuration: 1500
        },
        w = 0; w < C.length; w++) t.event.special[C[w]] = T(C[w]);
        F && i.addEventListener("click",
        function(e) {
            var i, n, s, o, a, r, l = P.length,
            d = e.target;
            if (l) for (i = e.clientX, n = e.clientY, L = t.vmouse.clickDistanceThreshold, s = d; s;) {
                for (o = 0; l > o; o++) if (a = P[o], r = 0, s === d && Math.abs(a.x - i) < L && Math.abs(a.y - n) < L || t.data(s, k) === a.touchID) return e.preventDefault(),
                void e.stopPropagation();
                s = s.parentNode
            }
        },
        !0)
    } (t, e, i)
});
jQuery.extend({
    highlight: function(t, e, i, n) {
        if (3 === t.nodeType) {
            var s = t.data.match(e);
            if (s) {
                var o = document.createElement(i || "span");
                o.className = n || "highlight";
                var a = t.splitText(s.index);
                a.splitText(s[0].length);
                var r = a.cloneNode(!0);
                return o.appendChild(r),
                a.parentNode.replaceChild(o, a),
                1
            }
        } else if (1 === t.nodeType && t.childNodes && !/(script|style)/i.test(t.tagName) && (t.tagName !== i.toUpperCase() || t.className !== n)) for (var l = 0; l < t.childNodes.length; l++) l += jQuery.highlight(t.childNodes[l], e, i, n);
        return 0
    }
});

jQuery.fn.unhighlight = function(t) {
    var e = {
        className: "highlight",
        element: "span"
    };
    return jQuery.extend(e, t),
    this.find(e.element + "." + e.className).each(function() {
        var t = this.parentNode;
        t.replaceChild(this.firstChild, this),
        t.normalize()
    }).end()
};

jQuery.fn.highlight = function(t, e) {
    var i = {
        className: "highlight",
        element: "span",
        caseSensitive: !1,
        wordsOnly: !1
    };
    if (jQuery.extend(i, e), t.constructor === String && (t = [t]), t = jQuery.grep(t,
    function(t) {
        return "" != t
    }), t = jQuery.map(t,
    function(t) {
        return t.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&")
    }), 0 == t.length) return this;
    var n = i.caseSensitive ? "": "i",
    s = "(" + t.join("|") + ")";
    i.wordsOnly && (s = "\\b" + s + "\\b");
    var o = new RegExp(s, n);
    return this.each(function() {
        jQuery.highlight(this, o, i.element, i.className)
    })
};