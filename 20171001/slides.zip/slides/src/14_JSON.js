var JSON;
JSON || (JSON = {}),
function() {
    "use strict";
    function f(t) {
        return 10 > t ? "0" + t: t
    }
    function quote(t) {
        return escapable.lastIndex = 0,
        escapable.test(t) ? '"' + t.replace(escapable,
        function(t) {
            var e = meta[t];
            return "string" == typeof e ? e: "\\u" + ("0000" + t.charCodeAt(0).toString(16)).slice( - 4)
        }) + '"': '"' + t + '"'
    }
    function str(t, e) {
        var i, n, s, o, a, r = gap,
        l = e[t];
        switch (l && "object" == typeof l && "function" == typeof l.toJSON && (l = l.toJSON(t)), "function" == typeof rep && (l = rep.call(e, t, l)), typeof l) {
        case "string":
            return quote(l);
        case "number":
            return isFinite(l) ? String(l) : "null";
        case "boolean":
        case "null":
            return String(l);
        case "object":
            if (!l) return "null";
            if (gap += indent, a = [], "[object Array]" === Object.prototype.toString.apply(l)) {
                for (o = l.length, i = 0; o > i; i += 1) a[i] = str(i, l) || "null";
                return s = 0 === a.length ? "[]": gap ? "[\n" + gap + a.join(",\n" + gap) + "\n" + r + "]": "[" + a.join(",") + "]",
                gap = r,
                s
            }
            if (rep && "object" == typeof rep) for (o = rep.length, i = 0; o > i; i += 1)"string" == typeof rep[i] && (n = rep[i], s = str(n, l), s && a.push(quote(n) + (gap ? ": ": ":") + s));
            else for (n in l) Object.prototype.hasOwnProperty.call(l, n) && (s = str(n, l), s && a.push(quote(n) + (gap ? ": ": ":") + s));
            return s = 0 === a.length ? "{}": gap ? "{\n" + gap + a.join(",\n" + gap) + "\n" + r + "}": "{" + a.join(",") + "}",
            gap = r,
            s
        }
    }
    "function" != typeof Date.prototype.toJSON && (Date.prototype.toJSON = function() {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z": null
    },
    String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function() {
        return this.valueOf()
    });
    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
    escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
    gap, indent, meta = {
        "\b": "\\b",
        "	": "\\t",
        "\n": "\\n",
        "\f": "\\f",
        "\r": "\\r",
        '"': '\\"',
        "\\": "\\\\"
    },
    rep;
    "function" != typeof JSON.stringify && (JSON.stringify = function(t, e, i) {
        var n;
        if (gap = "", indent = "", "number" == typeof i) for (n = 0; i > n; n += 1) indent += " ";
        else "string" == typeof i && (indent = i);
        if (rep = e, e && "function" != typeof e && ("object" != typeof e || "number" != typeof e.length)) throw new Error("JSON.stringify");
        return str("", {
            "": t
        })
    }),
    "function" != typeof JSON.parse && (JSON.parse = function(text, reviver) {
        function walk(t, e) {
            var i, n, s = t[e];
            if (s && "object" == typeof s) for (i in s) Object.prototype.hasOwnProperty.call(s, i) && (n = walk(s, i), void 0 !== n ? s[i] = n: delete s[i]);
            return reviver.call(t, e, s)
        }
        var j;
        if (text = String(text), cx.lastIndex = 0, cx.test(text) && (text = text.replace(cx,
        function(t) {
            return "\\u" + ("0000" + t.charCodeAt(0).toString(16)).slice( - 4)
        })), /^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return j = eval("(" + text + ")"),
        "function" == typeof reviver ? walk({
            "": j
        },
        "") : j;
        throw new SyntaxError("JSON.parse")
    })
} (),
function(t) {
    function e(t, e) {
        return function(i) {
            return l(t.call(this, i), e)
        }
    }
    function i(t, e) {
        return function(i) {
            return this.lang().ordinal(t.call(this, i), e)
        }
    }
    function n() {}
    function s(t) {
        a(this, t)
    }
    function o(t) {
        var e = t.years || t.year || t.y || 0,
        i = t.months || t.month || t.M || 0,
        n = t.weeks || t.week || t.w || 0,
        s = t.days || t.day || t.d || 0,
        o = t.hours || t.hour || t.h || 0,
        a = t.minutes || t.minute || t.m || 0,
        r = t.seconds || t.second || t.s || 0,
        l = t.milliseconds || t.millisecond || t.ms || 0;
        this._input = t,
        this._milliseconds = +l + 1e3 * r + 6e4 * a + 36e5 * o,
        this._days = +s + 7 * n,
        this._months = +i + 12 * e,
        this._data = {},
        this._bubble()
    }
    function a(t, e) {
        for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
        return t
    }
    function r(t) {
        return 0 > t ? Math.ceil(t) : Math.floor(t)
    }
    function l(t, e) {
        for (var i = t + ""; i.length < e;) i = "0" + i;
        return i
    }
    function d(t, e, i, n) {
        var s, o, a = e._milliseconds,
        r = e._days,
        l = e._months;
        a && t._d.setTime( + t._d + a * i),
        (r || l) && (s = t.minute(), o = t.hour()),
        r && t.date(t.date() + r * i),
        l && t.month(t.month() + l * i),
        a && !n && $.updateOffset(t),
        (r || l) && (t.minute(s), t.hour(o))
    }
    function c(t) {
        return "[object Array]" === Object.prototype.toString.call(t)
    }
    function h(t, e) {
        var i, n = Math.min(t.length, e.length),
        s = Math.abs(t.length - e.length),
        o = 0;
        for (i = 0; n > i; i++)~~t[i] !== ~~e[i] && o++;
        return o + s
    }
    function u(t) {
        return t ? le[t] || t.toLowerCase().replace(/(.)s$/, "$1") : t
    }
    function p(t, e) {
        return e.abbr = t,
        H[t] || (H[t] = new n),
        H[t].set(e),
        H[t]
    }
    function m(t) {
        delete H[t]
    }
    function f(t) {
        if (!t) return $.fn._lang;
        if (!H[t] && j) try {
            require("./lang/" + t)
        } catch(e) {
            return $.fn._lang
        }
        return H[t] || $.fn._lang
    }
    function g(t) {
        return t.match(/\[.*\]/) ? t.replace(/^\[|\]$/g, "") : t.replace(/\\/g, "")
    }
    function v(t) {
        var e, i, n = t.match(X);
        for (e = 0, i = n.length; i > e; e++) n[e] = ue[n[e]] ? ue[n[e]] : g(n[e]);
        return function(s) {
            var o = "";
            for (e = 0; i > e; e++) o += n[e] instanceof Function ? n[e].call(s, t) : n[e];
            return o
        }
    }
    function b(t, e) {
        return e = S(e, t.lang()),
        de[e] || (de[e] = v(e)),
        de[e](t)
    }
    function S(t, e) {
        function i(t) {
            return e.longDateFormat(t) || t
        }
        for (var n = 5; n--&&(G.lastIndex = 0, G.test(t));) t = t.replace(G, i);
        return t
    }
    function y(t, e) {
        switch (t) {
        case "DDDD":
            return Y;
        case "YYYY":
            return K;
        case "YYYYY":
            return q;
        case "S":
        case "SS":
        case "SSS":
        case "DDD":
            return J;
        case "MMM":
        case "MMMM":
        case "dd":
        case "ddd":
        case "dddd":
            return Q;
        case "a":
        case "A":
            return f(e._l)._meridiemParse;
        case "X":
            return ee;
        case "Z":
        case "ZZ":
            return Z;
        case "T":
            return te;
        case "MM":
        case "DD":
        case "YY":
        case "HH":
        case "hh":
        case "mm":
        case "ss":
        case "M":
        case "D":
        case "d":
        case "H":
        case "h":
        case "m":
        case "s":
            return W;
        default:
            return new RegExp(t.replace("\\", ""))
        }
    }
    function E(t) {
        var e = (Z.exec(t) || [])[0],
        i = (e + "").match(oe) || ["-", 0, 0],
        n = +(60 * i[1]) + ~~i[2];
        return "+" === i[0] ? -n: n
    }
    function T(t, e, i) {
        var n, s = i._a;
        switch (t) {
        case "M":
        case "MM":
            null != e && (s[1] = ~~e - 1);
            break;
        case "MMM":
        case "MMMM":
            n = f(i._l).monthsParse(e),
            null != n ? s[1] = n: i._isValid = !1;
            break;
        case "D":
        case "DD":
            null != e && (s[2] = ~~e);
            break;
        case "DDD":
        case "DDDD":
            null != e && (s[1] = 0, s[2] = ~~e);
            break;
        case "YY":
            s[0] = ~~e + (~~e > 68 ? 1900 : 2e3);
            break;
        case "YYYY":
        case "YYYYY":
            s[0] = ~~e;
            break;
        case "a":
        case "A":
            i._isPm = f(i._l).isPM(e);
            break;
        case "H":
        case "HH":
        case "h":
        case "hh":
            s[3] = ~~e;
            break;
        case "m":
        case "mm":
            s[4] = ~~e;
            break;
        case "s":
        case "ss":
            s[5] = ~~e;
            break;
        case "S":
        case "SS":
        case "SSS":
            s[6] = ~~ (1e3 * ("0." + e));
            break;
        case "X":
            i._d = new Date(1e3 * parseFloat(e));
            break;
        case "Z":
        case "ZZ":
            i._useUTC = !0,
            i._tzm = E(e)
        }
        null == e && (i._isValid = !1)
    }
    function L(t) {
        var e, i, n, s = [];
        if (!t._d) {
            for (n = _(t), e = 0; 3 > e && null == t._a[e]; ++e) t._a[e] = s[e] = n[e];
            for (; 7 > e; e++) t._a[e] = s[e] = null == t._a[e] ? 2 === e ? 1 : 0 : t._a[e];
            s[3] += ~~ ((t._tzm || 0) / 60),
            s[4] += ~~ ((t._tzm || 0) % 60),
            i = new Date(0),
            t._useUTC ? (i.setUTCFullYear(s[0], s[1], s[2]), i.setUTCHours(s[3], s[4], s[5], s[6])) : (i.setFullYear(s[0], s[1], s[2]), i.setHours(s[3], s[4], s[5], s[6])),
            t._d = i
        }
    }
    function w(t) {
        var e = t._i;
        t._d || (t._a = [e.years || e.year || e.y, e.months || e.month || e.M, e.days || e.day || e.d, e.hours || e.hour || e.h, e.minutes || e.minute || e.m, e.seconds || e.second || e.s, e.milliseconds || e.millisecond || e.ms], L(t))
    }
    function _(t) {
        var e = new Date;
        return t._useUTC ? [e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate()] : [e.getFullYear(), e.getMonth(), e.getDate()]
    }
    function k(t) {
        var e, i, n, s = f(t._l),
        o = "" + t._i;
        for (n = S(t._f, s).match(X), t._a = [], e = 0; e < n.length; e++) i = (y(n[e], t).exec(o) || [])[0],
        i && (o = o.slice(o.indexOf(i) + i.length)),
        ue[n[e]] && T(n[e], i, t);
        o && (t._il = o),
        t._isPm && t._a[3] < 12 && (t._a[3] += 12),
        t._isPm === !1 && 12 === t._a[3] && (t._a[3] = 0),
        L(t)
    }
    function C(t) {
        var e, i, n, o, r, l = 99;
        for (o = 0; o < t._f.length; o++) e = a({},
        t),
        e._f = t._f[o],
        k(e),
        i = new s(e),
        r = h(e._a, i.toArray()),
        i._il && (r += i._il.length),
        l > r && (l = r, n = i);
        a(t, n)
    }
    function A(t) {
        var e, i = t._i,
        n = ie.exec(i);
        if (n) {
            for (t._f = "YYYY-MM-DD" + (n[2] || " "), e = 0; 4 > e; e++) if (se[e][1].exec(i)) {
                t._f += se[e][0];
                break
            }
            Z.exec(i) && (t._f += " Z"),
            k(t)
        } else t._d = new Date(i)
    }
    function D(e) {
        var i = e._i,
        n = z.exec(i);
        i === t ? e._d = new Date: n ? e._d = new Date( + n[1]) : "string" == typeof i ? A(e) : c(i) ? (e._a = i.slice(0), L(e)) : i instanceof Date ? e._d = new Date( + i) : "object" == typeof i ? w(e) : e._d = new Date(i)
    }
    function I(t, e, i, n, s) {
        return s.relativeTime(e || 1, !!i, t, n)
    }
    function x(t, e, i) {
        var n = B(Math.abs(t) / 1e3),
        s = B(n / 60),
        o = B(s / 60),
        a = B(o / 24),
        r = B(a / 365),
        l = 45 > n && ["s", n] || 1 === s && ["m"] || 45 > s && ["mm", s] || 1 === o && ["h"] || 22 > o && ["hh", o] || 1 === a && ["d"] || 25 >= a && ["dd", a] || 45 >= a && ["M"] || 345 > a && ["MM", B(a / 30)] || 1 === r && ["y"] || ["yy", r];
        return l[2] = e,
        l[3] = t > 0,
        l[4] = i,
        I.apply({},
        l)
    }
    function M(t, e, i) {
        var n, s = i - e,
        o = i - t.day();
        return o > s && (o -= 7),
        s - 7 > o && (o += 7),
        n = $(t).add("d", o),
        {
            week: Math.ceil(n.dayOfYear() / 7),
            year: n.year()
        }
    }
    function R(t) {
        var e = t._i,
        i = t._f;
        return null === e || "" === e ? null: ("string" == typeof e && (t._i = e = f().preparse(e)), $.isMoment(e) ? (t = a({},
        e), t._d = new Date( + e._d)) : i ? c(i) ? C(t) : k(t) : D(t), new s(t))
    }
    function O(t, e) {
        $.fn[t] = $.fn[t + "s"] = function(t) {
            var i = this._isUTC ? "UTC": "";
            return null != t ? (this._d["set" + i + e](t), $.updateOffset(this), this) : this._d["get" + i + e]()
        }
    }
    function N(t) {
        $.duration.fn[t] = function() {
            return this._data[t]
        }
    }
    function P(t, e) {
        $.duration.fn["as" + t] = function() {
            return + this / e
        }
    }
    for (var $, U, F = "2.2.1",
    B = Math.round,
    H = {},
    j = "undefined" != typeof module && module.exports,
    z = /^\/?Date\((\-?\d+)/i,
    V = /(\-)?(?:(\d*)\.)?(\d+)\:(\d+)\:(\d+)\.?(\d{3})?/,
    X = /(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|SS?S?|X|zz?|ZZ?|.)/g,
    G = /(\[[^\[]*\])|(\\)?(LT|LL?L?L?|l{1,4})/g,
    W = /\d\d?/,
    J = /\d{1,3}/,
    Y = /\d{3}/,
    K = /\d{1,4}/,
    q = /[+\-]?\d{1,6}/,
    Q = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,
    Z = /Z|[\+\-]\d\d:?\d\d/i,
    te = /T/i,
    ee = /[\+\-]?\d+(\.\d{1,3})?/,
    ie = /^\s*\d{4}-\d\d-\d\d((T| )(\d\d(:\d\d(:\d\d(\.\d\d?\d?)?)?)?)?([\+\-]\d\d:?\d\d)?)?/,
    ne = "YYYY-MM-DDTHH:mm:ssZ",
    se = [["HH:mm:ss.S", /(T| )\d\d:\d\d:\d\d\.\d{1,3}/], ["HH:mm:ss", /(T| )\d\d:\d\d:\d\d/], ["HH:mm", /(T| )\d\d:\d\d/], ["HH", /(T| )\d\d/]], oe = /([\+\-]|\d\d)/gi, ae = "Date|Hours|Minutes|Seconds|Milliseconds".split("|"), re = {
        Milliseconds: 1,
        Seconds: 1e3,
        Minutes: 6e4,
        Hours: 36e5,
        Days: 864e5,
        Months: 2592e6,
        Years: 31536e6
    },
    le = {
        ms: "millisecond",
        s: "second",
        m: "minute",
        h: "hour",
        d: "day",
        w: "week",
        W: "isoweek",
        M: "month",
        y: "year"
    },
    de = {},
    ce = "DDD w W M D d".split(" "), he = "M D H h m s w W".split(" "), ue = {
        M: function() {
            return this.month() + 1
        },
        MMM: function(t) {
            return this.lang().monthsShort(this, t)
        },
        MMMM: function(t) {
            return this.lang().months(this, t)
        },
        D: function() {
            return this.date()
        },
        DDD: function() {
            return this.dayOfYear()
        },
        d: function() {
            return this.day()
        },
        dd: function(t) {
            return this.lang().weekdaysMin(this, t)
        },
        ddd: function(t) {
            return this.lang().weekdaysShort(this, t)
        },
        dddd: function(t) {
            return this.lang().weekdays(this, t)
        },
        w: function() {
            return this.week()
        },
        W: function() {
            return this.isoWeek()
        },
        YY: function() {
            return l(this.year() % 100, 2)
        },
        YYYY: function() {
            return l(this.year(), 4)
        },
        YYYYY: function() {
            return l(this.year(), 5)
        },
        gg: function() {
            return l(this.weekYear() % 100, 2)
        },
        gggg: function() {
            return this.weekYear()
        },
        ggggg: function() {
            return l(this.weekYear(), 5)
        },
        GG: function() {
            return l(this.isoWeekYear() % 100, 2)
        },
        GGGG: function() {
            return this.isoWeekYear()
        },
        GGGGG: function() {
            return l(this.isoWeekYear(), 5)
        },
        e: function() {
            return this.weekday()
        },
        E: function() {
            return this.isoWeekday()
        },
        a: function() {
            return this.lang().meridiem(this.hours(), this.minutes(), !0)
        },
        A: function() {
            return this.lang().meridiem(this.hours(), this.minutes(), !1)
        },
        H: function() {
            return this.hours()
        },
        h: function() {
            return this.hours() % 12 || 12
        },
        m: function() {
            return this.minutes()
        },
        s: function() {
            return this.seconds()
        },
        S: function() {
            return~~ (this.milliseconds() / 100)
        },
        SS: function() {
            return l(~~ (this.milliseconds() / 10), 2)
        },
        SSS: function() {
            return l(this.milliseconds(), 3)
        },
        Z: function() {
            var t = -this.zone(),
            e = "+";
            return 0 > t && (t = -t, e = "-"),
            e + l(~~ (t / 60), 2) + ":" + l(~~t % 60, 2)
        },
        ZZ: function() {
            var t = -this.zone(),
            e = "+";
            return 0 > t && (t = -t, e = "-"),
            e + l(~~ (10 * t / 6), 4)
        },
        z: function() {
            return this.zoneAbbr()
        },
        zz: function() {
            return this.zoneName()
        },
        X: function() {
            return this.unix()
        }
    }; ce.length;) U = ce.pop(),
    ue[U + "o"] = i(ue[U], U);
    for (; he.length;) U = he.pop(),
    ue[U + U] = e(ue[U], 2);
    for (ue.DDDD = e(ue.DDD, 3), a(n.prototype, {
        set: function(t) {
            var e, i;
            for (i in t) e = t[i],
            "function" == typeof e ? this[i] = e: this["_" + i] = e
        },
        _months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
        months: function(t) {
            return this._months[t.month()]
        },
        _monthsShort: "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
        monthsShort: function(t) {
            return this._monthsShort[t.month()]
        },
        monthsParse: function(t) {
            var e, i, n;
            for (this._monthsParse || (this._monthsParse = []), e = 0; 12 > e; e++) if (this._monthsParse[e] || (i = $.utc([2e3, e]), n = "^" + this.months(i, "") + "|^" + this.monthsShort(i, ""), this._monthsParse[e] = new RegExp(n.replace(".", ""), "i")), this._monthsParse[e].test(t)) return e
        },
        _weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
        weekdays: function(t) {
            return this._weekdays[t.day()]
        },
        _weekdaysShort: "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
        weekdaysShort: function(t) {
            return this._weekdaysShort[t.day()]
        },
        _weekdaysMin: "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
        weekdaysMin: function(t) {
            return this._weekdaysMin[t.day()]
        },
        weekdaysParse: function(t) {
            var e, i, n;
            for (this._weekdaysParse || (this._weekdaysParse = []), e = 0; 7 > e; e++) if (this._weekdaysParse[e] || (i = $([2e3, 1]).day(e), n = "^" + this.weekdays(i, "") + "|^" + this.weekdaysShort(i, "") + "|^" + this.weekdaysMin(i, ""), this._weekdaysParse[e] = new RegExp(n.replace(".", ""), "i")), this._weekdaysParse[e].test(t)) return e
        },
        _longDateFormat: {
            LT: "h:mm A",
            L: "MM/DD/YYYY",
            LL: "MMMM D YYYY",
            LLL: "MMMM D YYYY LT",
            LLLL: "dddd, MMMM D YYYY LT"
        },
        longDateFormat: function(t) {
            var e = this._longDateFormat[t];
            return ! e && this._longDateFormat[t.toUpperCase()] && (e = this._longDateFormat[t.toUpperCase()].replace(/MMMM|MM|DD|dddd/g,
            function(t) {
                return t.slice(1)
            }), this._longDateFormat[t] = e),
            e
        },
        isPM: function(t) {
            return "p" === (t + "").toLowerCase().charAt(0)
        },
        _meridiemParse: /[ap]\.?m?\.?/i,
        meridiem: function(t, e, i) {
            return t > 11 ? i ? "pm": "PM": i ? "am": "AM"
        },
        _calendar: {
            sameDay: "[Today at] LT",
            nextDay: "[Tomorrow at] LT",
            nextWeek: "dddd [at] LT",
            lastDay: "[Yesterday at] LT",
            lastWeek: "[Last] dddd [at] LT",
            sameElse: "L"
        },
        calendar: function(t, e) {
            var i = this._calendar[t];
            return "function" == typeof i ? i.apply(e) : i
        },
        _relativeTime: {
            future: "in %s",
            past: "%s ago",
            s: "a few seconds",
            m: "a minute",
            mm: "%d minutes",
            h: "an hour",
            hh: "%d hours",
            d: "a day",
            dd: "%d days",
            M: "a month",
            MM: "%d months",
            y: "a year",
            yy: "%d years"
        },
        relativeTime: function(t, e, i, n) {
            var s = this._relativeTime[i];
            return "function" == typeof s ? s(t, e, i, n) : s.replace(/%d/i, t)
        },
        pastFuture: function(t, e) {
            var i = this._relativeTime[t > 0 ? "future": "past"];
            return "function" == typeof i ? i(e) : i.replace(/%s/i, e)
        },
        ordinal: function(t) {
            return this._ordinal.replace("%d", t)
        },
        _ordinal: "%d",
        preparse: function(t) {
            return t
        },
        postformat: function(t) {
            return t
        },
        week: function(t) {
            return M(t, this._week.dow, this._week.doy).week
        },
        _week: {
            dow: 0,
            doy: 6
        }
    }), $ = function(t, e, i) {
        return R({
            _i: t,
            _f: e,
            _l: i,
            _isUTC: !1
        })
    },
    $.utc = function(t, e, i) {
        return R({
            _useUTC: !0,
            _isUTC: !0,
            _l: i,
            _i: t,
            _f: e
        }).utc()
    },
    $.unix = function(t) {
        return $(1e3 * t)
    },
    $.duration = function(t, e) {
        var i, n, s = $.isDuration(t),
        a = "number" == typeof t,
        r = s ? t._input: a ? {}: t,
        l = V.exec(t);
        return a ? e ? r[e] = t: r.milliseconds = t: l && (i = "-" === l[1] ? -1 : 1, r = {
            y: 0,
            d: ~~l[2] * i,
            h: ~~l[3] * i,
            m: ~~l[4] * i,
            s: ~~l[5] * i,
            ms: ~~l[6] * i
        }),
        n = new o(r),
        s && t.hasOwnProperty("_lang") && (n._lang = t._lang),
        n
    },
    $.version = F, $.defaultFormat = ne, $.updateOffset = function() {},
    $.lang = function(t, e) {
        return t ? (t = t.toLowerCase(), t = t.replace("_", "-"), e ? p(t, e) : null === e ? (m(t), t = "en") : H[t] || f(t), void($.duration.fn._lang = $.fn._lang = f(t))) : $.fn._lang._abbr
    },
    $.langData = function(t) {
        return t && t._lang && t._lang._abbr && (t = t._lang._abbr),
        f(t)
    },
    $.isMoment = function(t) {
        return t instanceof s
    },
    $.isDuration = function(t) {
        return t instanceof o
    },
    a($.fn = s.prototype, {
        clone: function() {
            return $(this)
        },
        valueOf: function() {
            return + this._d + 6e4 * (this._offset || 0)
        },
        unix: function() {
            return Math.floor( + this / 1e3)
        },
        toString: function() {
            return this.format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
        },
        toDate: function() {
            return this._offset ? new Date( + this) : this._d
        },
        toISOString: function() {
            return b($(this).utc(), "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]")
        },
        toArray: function() {
            var t = this;
            return [t.year(), t.month(), t.date(), t.hours(), t.minutes(), t.seconds(), t.milliseconds()]
        },
        isValid: function() {
            return null == this._isValid && (this._isValid = this._a ? !h(this._a, (this._isUTC ? $.utc(this._a) : $(this._a)).toArray()) : !isNaN(this._d.getTime())),
            !!this._isValid
        },
        invalidAt: function() {
            var t, e = this._a,
            i = (this._isUTC ? $.utc(this._a) : $(this._a)).toArray();
            for (t = 6; t >= 0 && e[t] === i[t]; --t);
            return t
        },
        utc: function() {
            return this.zone(0)
        },
        local: function() {
            return this.zone(0),
            this._isUTC = !1,
            this
        },
        format: function(t) {
            var e = b(this, t || $.defaultFormat);
            return this.lang().postformat(e)
        },
        add: function(t, e) {
            var i;
            return i = "string" == typeof t ? $.duration( + e, t) : $.duration(t, e),
            d(this, i, 1),
            this
        },
        subtract: function(t, e) {
            var i;
            return i = "string" == typeof t ? $.duration( + e, t) : $.duration(t, e),
            d(this, i, -1),
            this
        },
        diff: function(t, e, i) {
            var n, s, o = this._isUTC ? $(t).zone(this._offset || 0) : $(t).local(),
            a = 6e4 * (this.zone() - o.zone());
            return e = u(e),
            "year" === e || "month" === e ? (n = 432e5 * (this.daysInMonth() + o.daysInMonth()), s = 12 * (this.year() - o.year()) + (this.month() - o.month()), s += (this - $(this).startOf("month") - (o - $(o).startOf("month"))) / n, s -= 6e4 * (this.zone() - $(this).startOf("month").zone() - (o.zone() - $(o).startOf("month").zone())) / n, "year" === e && (s /= 12)) : (n = this - o, s = "second" === e ? n / 1e3: "minute" === e ? n / 6e4: "hour" === e ? n / 36e5: "day" === e ? (n - a) / 864e5: "week" === e ? (n - a) / 6048e5: n),
            i ? s: r(s)
        },
        from: function(t, e) {
            return $.duration(this.diff(t)).lang(this.lang()._abbr).humanize(!e)
        },
        fromNow: function(t) {
            return this.from($(), t)
        },
        calendar: function() {
            var t = this.diff($().zone(this.zone()).startOf("day"), "days", !0),
            e = -6 > t ? "sameElse": -1 > t ? "lastWeek": 0 > t ? "lastDay": 1 > t ? "sameDay": 2 > t ? "nextDay": 7 > t ? "nextWeek": "sameElse";
            return this.format(this.lang().calendar(e, this))
        },
        isLeapYear: function() {
            var t = this.year();
            return 0 === t % 4 && 0 !== t % 100 || 0 === t % 400
        },
        isDST: function() {
            return this.zone() < this.clone().month(0).zone() || this.zone() < this.clone().month(5).zone()
        },
        day: function(t) {
            var e = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
            return null != t ? "string" == typeof t && (t = this.lang().weekdaysParse(t), "number" != typeof t) ? this: this.add({
                d: t - e
            }) : e
        },
        month: function(t) {
            var e, i = this._isUTC ? "UTC": "";
            return null != t ? "string" == typeof t && (t = this.lang().monthsParse(t), "number" != typeof t) ? this: (e = this.date(), this.date(1), this._d["set" + i + "Month"](t), this.date(Math.min(e, this.daysInMonth())), $.updateOffset(this), this) : this._d["get" + i + "Month"]()
        },
        startOf: function(t) {
            switch (t = u(t)) {
            case "year":
                this.month(0);
            case "month":
                this.date(1);
            case "week":
            case "isoweek":
            case "day":
                this.hours(0);
            case "hour":
                this.minutes(0);
            case "minute":
                this.seconds(0);
            case "second":
                this.milliseconds(0)
            }
            return "week" === t ? this.weekday(0) : "isoweek" === t && this.isoWeekday(1),
            this
        },
        endOf: function(t) {
            return t = u(t),
            this.startOf(t).add("isoweek" === t ? "week": t, 1).subtract("ms", 1)
        },
        isAfter: function(t, e) {
            return e = "undefined" != typeof e ? e: "millisecond",
            +this.clone().startOf(e) > +$(t).startOf(e)
        },
        isBefore: function(t, e) {
            return e = "undefined" != typeof e ? e: "millisecond",
            +this.clone().startOf(e) < +$(t).startOf(e)
        },
        isSame: function(t, e) {
            return e = "undefined" != typeof e ? e: "millisecond",
            +this.clone().startOf(e) === +$(t).startOf(e)
        },
        min: function(t) {
            return t = $.apply(null, arguments),
            this > t ? this: t
        },
        max: function(t) {
            return t = $.apply(null, arguments),
            t > this ? this: t
        },
        zone: function(t) {
            var e = this._offset || 0;
            return null == t ? this._isUTC ? e: this._d.getTimezoneOffset() : ("string" == typeof t && (t = E(t)), Math.abs(t) < 16 && (t = 60 * t), this._offset = t, this._isUTC = !0, e !== t && d(this, $.duration(e - t, "m"), 1, !0), this)
        },
        zoneAbbr: function() {
            return this._isUTC ? "UTC": ""
        },
        zoneName: function() {
            return this._isUTC ? "Coordinated Universal Time": ""
        },
        hasAlignedHourOffset: function(t) {
            return t = t ? $(t).zone() : 0,
            0 === (this.zone() - t) % 60
        },
        daysInMonth: function() {
            return $.utc([this.year(), this.month() + 1, 0]).date()
        },
        dayOfYear: function(t) {
            var e = B(($(this).startOf("day") - $(this).startOf("year")) / 864e5) + 1;
            return null == t ? e: this.add("d", t - e)
        },
        weekYear: function(t) {
            var e = M(this, this.lang()._week.dow, this.lang()._week.doy).year;
            return null == t ? e: this.add("y", t - e)
        },
        isoWeekYear: function(t) {
            var e = M(this, 1, 4).year;
            return null == t ? e: this.add("y", t - e)
        },
        week: function(t) {
            var e = this.lang().week(this);
            return null == t ? e: this.add("d", 7 * (t - e))
        },
        isoWeek: function(t) {
            var e = M(this, 1, 4).week;
            return null == t ? e: this.add("d", 7 * (t - e))
        },
        weekday: function(t) {
            var e = (this._d.getDay() + 7 - this.lang()._week.dow) % 7;
            return null == t ? e: this.add("d", t - e)
        },
        isoWeekday: function(t) {
            return null == t ? this.day() || 7 : this.day(this.day() % 7 ? t: t - 7)
        },
        get: function(t) {
            return t = u(t),
            this[t.toLowerCase()]()
        },
        set: function(t, e) {
            t = u(t),
            this[t.toLowerCase()](e)
        },
        lang: function(e) {
            return e === t ? this._lang: (this._lang = f(e), this)
        }
    }), U = 0; U < ae.length; U++) O(ae[U].toLowerCase().replace(/s$/, ""), ae[U]);
    O("year", "FullYear"),
    $.fn.days = $.fn.day,
    $.fn.months = $.fn.month,
    $.fn.weeks = $.fn.week,
    $.fn.isoWeeks = $.fn.isoWeek,
    $.fn.toJSON = $.fn.toISOString,
    a($.duration.fn = o.prototype, {
        _bubble: function() {
            var t, e, i, n, s = this._milliseconds,
            o = this._days,
            a = this._months,
            l = this._data;
            l.milliseconds = s % 1e3,
            t = r(s / 1e3),
            l.seconds = t % 60,
            e = r(t / 60),
            l.minutes = e % 60,
            i = r(e / 60),
            l.hours = i % 24,
            o += r(i / 24),
            l.days = o % 30,
            a += r(o / 30),
            l.months = a % 12,
            n = r(a / 12),
            l.years = n
        },
        weeks: function() {
            return r(this.days() / 7)
        },
        valueOf: function() {
            return this._milliseconds + 864e5 * this._days + 2592e6 * (this._months % 12) + 31536e6 * ~~ (this._months / 12)
        },
        humanize: function(t) {
            var e = +this,
            i = x(e, !t, this.lang());
            return t && (i = this.lang().pastFuture(e, i)),
            this.lang().postformat(i)
        },
        add: function(t, e) {
            var i = $.duration(t, e);
            return this._milliseconds += i._milliseconds,
            this._days += i._days,
            this._months += i._months,
            this._bubble(),
            this
        },
        subtract: function(t, e) {
            var i = $.duration(t, e);
            return this._milliseconds -= i._milliseconds,
            this._days -= i._days,
            this._months -= i._months,
            this._bubble(),
            this
        },
        get: function(t) {
            return t = u(t),
            this[t.toLowerCase() + "s"]()
        },
        as: function(t) {
            return t = u(t),
            this["as" + t.charAt(0).toUpperCase() + t.slice(1) + "s"]()
        },
        lang: $.fn.lang
    });
    for (U in re) re.hasOwnProperty(U) && (P(U, re[U]), N(U.toLowerCase()));
    P("Weeks", 6048e5),
    $.duration.fn.asMonths = function() {
        return ( + this - 31536e6 * this.years()) / 2592e6 + 12 * this.years()
    },
    $.lang("en", {
        ordinal: function(t) {
            var e = t % 10,
            i = 1 === ~~ (t % 100 / 10) ? "th": 1 === e ? "st": 2 === e ? "nd": 3 === e ? "rd": "th";
            return t + i
        }
    }),
    j && (module.exports = $),
    "undefined" == typeof ender && (this.moment = $),
    "function" == typeof define && define.amd && define("moment", [],
    function() {
        return $
    })
}.call(this),
function(t, e) {
    "object" == typeof exports ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : t.Spinner = e()
} (this,
function() {
    "use strict";
    function t(t, e) {
        var i, n = document.createElement(t || "div");
        for (i in e) n[i] = e[i];
        return n
    }
    function e(t) {
        for (var e = 1,
        i = arguments.length; i > e; e++) t.appendChild(arguments[e]);
        return t
    }
    function i(t, e, i, n) {
        var s = ["opacity", e, ~~ (100 * t), i, n].join("-"),
        o = .01 + i / n * 100,
        a = Math.max(1 - (1 - t) / e * (100 - o), t),
        r = d.substring(0, d.indexOf("Animation")).toLowerCase(),
        l = r && "-" + r + "-" || "";
        return h[s] || (u.insertRule("@" + l + "keyframes " + s + "{0%{opacity:" + a + "}" + o + "%{opacity:" + t + "}" + (o + .01) + "%{opacity:1}" + (o + e) % 100 + "%{opacity:" + t + "}100%{opacity:" + a + "}}", u.cssRules.length), h[s] = 1),
        s
    }
    function n(t, e) {
        var i, n, s = t.style;
        if (void 0 !== s[e]) return e;
        for (e = e.charAt(0).toUpperCase() + e.slice(1), n = 0; n < c.length; n++) if (i = c[n] + e, void 0 !== s[i]) return i
    }
    function s(t, e) {
        for (var i in e) t.style[n(t, i) || i] = e[i];
        return t
    }
    function o(t) {
        for (var e = 1; e < arguments.length; e++) {
            var i = arguments[e];
            for (var n in i) void 0 === t[n] && (t[n] = i[n])
        }
        return t
    }
    function a(t) {
        for (var e = {
            x: t.offsetLeft,
            y: t.offsetTop
        }; t = t.offsetParent;) e.x += t.offsetLeft,
        e.y += t.offsetTop;
        return e
    }
    function r(t) {
        return "undefined" == typeof this ? new r(t) : void(this.opts = o(t || {},
        r.defaults, p))
    }
    function l() {
        function i(e, i) {
            return t("<" + e + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', i)
        }
        u.addRule(".spin-vml", "behavior:url(#default#VML)"),
        r.prototype.lines = function(t, n) {
            function o() {
                return s(i("group", {
                    coordsize: d + " " + d,
                    coordorigin: -l + " " + -l
                }), {
                    width: d,
                    height: d
                })
            }
            function a(t, a, r) {
                e(h, e(s(o(), {
                    rotation: 360 / n.lines * t + "deg",
                    left: ~~a
                }), e(s(i("roundrect", {
                    arcsize: n.corners
                }), {
                    width: l,
                    height: n.width,
                    left: n.radius,
                    top: -n.width >> 1,
                    filter: r
                }), i("fill", {
                    color: n.color,
                    opacity: n.opacity
                }), i("stroke", {
                    opacity: 0
                }))))
            }
            var r, l = n.length + n.width,
            d = 2 * l,
            c = 2 * -(n.width + n.length) + "px",
            h = s(o(), {
                position: "absolute",
                top: c,
                left: c
            });
            if (n.shadow) for (r = 1; r <= n.lines; r++) a(r, -2, "progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");
            for (r = 1; r <= n.lines; r++) a(r);
            return e(t, h)
        },
        r.prototype.opacity = function(t, e, i, n) {
            var s = t.firstChild;
            n = n.shadow && n.lines || 0,
            s && e + n < s.childNodes.length && (s = s.childNodes[e + n], s = s && s.firstChild, s = s && s.firstChild, s && (s.opacity = i))
        }
    }
    var d, c = ["webkit", "Moz", "ms", "O"],
    h = {},
    u = function() {
        var i = t("style", {
            type: "text/css"
        });
        return e(document.getElementsByTagName("head")[0], i),
        i.sheet || i.styleSheet
    } (),
    p = {
        lines: 12,
        length: 7,
        width: 5,
        radius: 10,
        rotate: 0,
        corners: 1,
        color: "#000",
        direction: 1,
        speed: 1,
        trail: 100,
        opacity: .25,
        fps: 20,
        zIndex: 2e9,
        className: "spinner",
        top: "auto",
        left: "auto",
        position: "relative"
    };
    r.defaults = {},
    o(r.prototype, {
        spin: function(e) {
            this.stop();
            var i, n, o = this,
            r = o.opts,
            l = o.el = s(t(0, {
                className: r.className
            }), {
                position: r.position,
                width: 0,
                zIndex: r.zIndex
            }),
            c = r.radius + r.length + r.width;
            if (e && (e.insertBefore(l, e.firstChild || null), n = a(e), i = a(l), s(l, {
                left: ("auto" == r.left ? n.x - i.x + (e.offsetWidth >> 1) : parseInt(r.left, 10) + c) + "px",
                top: ("auto" == r.top ? n.y - i.y + (e.offsetHeight >> 1) : parseInt(r.top, 10) + c) + "px"
            })), l.setAttribute("role", "progressbar"), o.lines(l, o.opts), !d) {
                var h, u = 0,
                p = (r.lines - 1) * (1 - r.direction) / 2,
                m = r.fps,
                f = m / r.speed,
                g = (1 - r.opacity) / (f * r.trail / 100),
                v = f / r.lines; !
                function b() {
                    u++;
                    for (var t = 0; t < r.lines; t++) h = Math.max(1 - (u + (r.lines - t) * v) % f * g, r.opacity),
                    o.opacity(l, t * r.direction + p, h, r);
                    o.timeout = o.el && setTimeout(b, ~~ (1e3 / m))
                } ()
            }
            return o
        },
        stop: function() {
            var t = this.el;
            return t && (clearTimeout(this.timeout), t.parentNode && t.parentNode.removeChild(t), this.el = void 0),
            this
        },
        lines: function(n, o) {
            function a(e, i) {
                return s(t(), {
                    position: "absolute",
                    width: o.length + o.width + "px",
                    height: o.width + "px",
                    background: e,
                    boxShadow: i,
                    transformOrigin: "left",
                    transform: "rotate(" + ~~ (360 / o.lines * l + o.rotate) + "deg) translate(" + o.radius + "px,0)",
                    borderRadius: (o.corners * o.width >> 1) + "px"
                })
            }
            for (var r, l = 0,
            c = (o.lines - 1) * (1 - o.direction) / 2; l < o.lines; l++) r = s(t(), {
                position: "absolute",
                top: 1 + ~ (o.width / 2) + "px",
                transform: o.hwaccel ? "translate3d(0,0,0)": "",
                opacity: o.opacity,
                animation: d && i(o.opacity, o.trail, c + l * o.direction, o.lines) + " " + 1 / o.speed + "s linear infinite"
            }),
            o.shadow && e(r, s(a("#000", "0 0 4px #000"), {
                top: "2px"
            })),
            e(n, e(r, a(o.color, "0 0 1px rgba(0,0,0,.1)")));
            return n
        },
        opacity: function(t, e, i) {
            e < t.childNodes.length && (t.childNodes[e].style.opacity = i)
        }
    });
    var m = s(t("group"), {
        behavior: "url(#default#VML)"
    });
    return ! n(m, "transform") && m.adj ? l() : d = n(m, "animation"),
    r
}),
function(t, e) {
    "object" == typeof exports ? module.exports = e(require("spin.js")) : "function" == typeof define && define.amd ? define(["spin"], e) : t.Ladda = e(t.Spinner)
} (this,
function(t) {
    "use strict";
    function e(t) {
        if ("undefined" == typeof t) return void console.warn("Ladda button target must be defined.");
        t.querySelector(".ladda-label") || (t.innerHTML = '<span class="ladda-label">' + t.innerHTML + "</span>");
        var e, i = t.querySelector(".ladda-spinner");
        i || (i = document.createElement("span"), i.className = "ladda-spinner"),
        t.appendChild(i);
        var n, s = {
            start: function() {
                return e || (e = a(t)),
                t.setAttribute("disabled", ""),
                t.setAttribute("data-loading", ""),
                clearTimeout(n),
                e.spin(i),
                this.setProgress(0),
                this
            },
            startAfter: function(t) {
                return clearTimeout(n),
                n = setTimeout(function() {
                    s.start()
                },
                t),
                this
            },
            stop: function() {
                return t.removeAttribute("disabled"),
                t.removeAttribute("data-loading"),
                clearTimeout(n),
                e && (n = setTimeout(function() {
                    e.stop()
                },
                1e3)),
                this
            },
            toggle: function() {
                return this.isLoading() ? this.stop() : this.start(),
                this
            },
            setProgress: function(e) {
                e = Math.max(Math.min(e, 1), 0);
                var i = t.querySelector(".ladda-progress");
                0 === e && i && i.parentNode ? i.parentNode.removeChild(i) : (i || (i = document.createElement("div"), i.className = "ladda-progress", t.appendChild(i)), i.style.width = (e || 0) * t.offsetWidth + "px")
            },
            enable: function() {
                return this.stop(),
                this
            },
            disable: function() {
                return this.stop(),
                t.setAttribute("disabled", ""),
                this
            },
            isLoading: function() {
                return t.hasAttribute("data-loading")
            },
            remove: function() {
                clearTimeout(n),
                t.removeAttribute("disabled", ""),
                t.removeAttribute("data-loading", ""),
                e && (e.stop(), e = null);
                for (var i = 0,
                o = l.length; o > i; i++) if (s === l[i]) {
                    l.splice(i, 1);
                    break
                }
            }
        };
        return l.push(s),
        s
    }
    function i(t, e) {
        for (; t.parentNode && t.tagName !== e;) t = t.parentNode;
        return e === t.tagName ? t: void 0
    }
    function n(t) {
        for (var e = ["input", "textarea", "select"], i = [], n = 0; n < e.length; n++) for (var s = t.getElementsByTagName(e[n]), o = 0; o < s.length; o++) s[o].hasAttribute("required") && i.push(s[o]);
        return i
    }
    function s(t, s) {
        s = s || {};
        var o = [];
        "string" == typeof t ? o = r(document.querySelectorAll(t)) : "object" == typeof t && "string" == typeof t.nodeName && (o = [t]);
        for (var a = 0,
        l = o.length; l > a; a++) !
        function() {
            var t = o[a];
            if ("function" == typeof t.addEventListener) {
                var r = e(t),
                l = -1;
                t.addEventListener("click",
                function() {
                    var e = !0,
                    o = i(t, "FORM");
                    if ("undefined" != typeof o) for (var a = n(o), d = 0; d < a.length; d++)"" === a[d].value.replace(/^\s+|\s+$/g, "") && (e = !1),
                    "checkbox" !== a[d].type && "radio" !== a[d].type || a[d].checked || (e = !1);
                    e && (r.startAfter(1), "number" == typeof s.timeout && (clearTimeout(l), l = setTimeout(r.stop, s.timeout)), "function" == typeof s.callback && s.callback.apply(null, [r]))
                },
                !1)
            }
        } ()
    }
    function o() {
        for (var t = 0,
        e = l.length; e > t; t++) l[t].stop()
    }
    function a(e) {
        var i, n = e.offsetHeight;
        0 === n && (n = parseFloat(window.getComputedStyle(e).height)),
        n > 32 && (n *= .8),
        e.hasAttribute("data-spinner-size") && (n = parseInt(e.getAttribute("data-spinner-size"), 10)),
        e.hasAttribute("data-spinner-color") && (i = e.getAttribute("data-spinner-color"));
        var s = 12,
        o = .2 * n,
        a = .6 * o,
        r = 7 > o ? 2 : 3;
        return new t({
            color: i || "#fff",
            lines: s,
            radius: o,
            length: a,
            width: r,
            zIndex: "auto",
            top: "auto",
            left: "auto",
            className: ""
        })
    }
    function r(t) {
        for (var e = [], i = 0; i < t.length; i++) e.push(t[i]);
        return e
    }
    var l = [];
    return {
        bind: s,
        create: e,
        stopAll: o
    }
}),
function(t, e) {
    function i(t, e, i) {
        return t.addEventListener ? void t.addEventListener(e, i, !1) : void t.attachEvent("on" + e, i)
    }
    function n(t) {
        if ("keypress" == t.type) {
            var e = String.fromCharCode(t.which);
            return t.shiftKey || (e = e.toLowerCase()),
            e
        }
        return w[t.which] ? w[t.which] : _[t.which] ? _[t.which] : String.fromCharCode(t.which).toLowerCase()
    }
    function s(t, e) {
        return t.sort().join(",") === e.sort().join(",")
    }
    function o(t) {
        t = t || {};
        var e, i = !1;
        for (e in I) t[e] ? i = !0 : I[e] = 0;
        i || (R = !1)
    }
    function a(t, e, i, n, o, a) {
        var r, l, d = [],
        c = i.type;
        if (!A[t]) return [];
        for ("keyup" == c && p(t) && (e = [t]), r = 0; r < A[t].length; ++r) if (l = A[t][r], (n || !l.seq || I[l.seq] == l.level) && c == l.action && ("keypress" == c && !i.metaKey && !i.ctrlKey || s(e, l.modifiers))) {
            var h = !n && l.combo == o,
            u = n && l.seq == n && l.level == a; (h || u) && A[t].splice(r, 1),
            d.push(l)
        }
        return d
    }
    function r(t) {
        var e = [];
        return t.shiftKey && e.push("shift"),
        t.altKey && e.push("alt"),
        t.ctrlKey && e.push("ctrl"),
        t.metaKey && e.push("meta"),
        e
    }
    function l(t) {
        return t.preventDefault ? void t.preventDefault() : void(t.returnValue = !1)
    }
    function d(t) {
        return t.stopPropagation ? void t.stopPropagation() : void(t.cancelBubble = !0)
    }
    function c(t, e, i, n) {
        N.stopCallback(e, e.target || e.srcElement, i, n) || t(e, i) === !1 && (l(e), d(e))
    }
    function h(t, e, i) {
        var n, s = a(t, e, i),
        r = {},
        l = 0,
        d = !1;
        for (n = 0; n < s.length; ++n) s[n].seq && (l = Math.max(l, s[n].level));
        for (n = 0; n < s.length; ++n) if (s[n].seq) {
            if (s[n].level != l) continue;
            d = !0,
            r[s[n].seq] = 1,
            c(s[n].callback, i, s[n].combo, s[n].seq)
        } else d || c(s[n].callback, i, s[n].combo);
        var h = "keypress" == i.type && M;
        i.type != R || p(t) || h || o(r),
        M = d && "keydown" == i.type
    }
    function u(t) {
        "number" != typeof t.which && (t.which = t.keyCode);
        var e = n(t);
        if (e) return "keyup" == t.type && x === e ? void(x = !1) : void N.handleKey(e, r(t), t)
    }
    function p(t) {
        return "shift" == t || "ctrl" == t || "alt" == t || "meta" == t
    }
    function m() {
        clearTimeout(L),
        L = setTimeout(o, 1e3)
    }
    function f() {
        if (!T) {
            T = {};
            for (var t in w) t > 95 && 112 > t || w.hasOwnProperty(t) && (T[w[t]] = t)
        }
        return T
    }
    function g(t, e, i) {
        return i || (i = f()[t] ? "keydown": "keypress"),
        "keypress" == i && e.length && (i = "keydown"),
        i
    }
    function v(t, e, i, s) {
        function a(e) {
            return function() {
                R = e,
                ++I[t],
                m()
            }
        }
        function r(e) {
            c(i, e, t),
            "keyup" !== s && (x = n(e)),
            setTimeout(o, 10)
        }
        I[t] = 0;
        for (var l = 0; l < e.length; ++l) {
            var d = l + 1 === e.length,
            h = d ? r: a(s || S(e[l + 1]).action);
            y(e[l], h, s, t, l)
        }
    }
    function b(t) {
        return "+" === t ? ["+"] : t.split("+")
    }
    function S(t, e) {
        var i, n, s, o = [];
        for (i = b(t), s = 0; s < i.length; ++s) n = i[s],
        C[n] && (n = C[n]),
        e && "keypress" != e && k[n] && (n = k[n], o.push("shift")),
        p(n) && o.push(n);
        return e = g(n, o, e),
        {
            key: n,
            modifiers: o,
            action: e
        }
    }
    function y(t, e, i, n, s) {
        D[t + ":" + i] = e,
        t = t.replace(/\s+/g, " ");
        var o, r = t.split(" ");
        return r.length > 1 ? void v(t, r, e, i) : (o = S(t, i), A[o.key] = A[o.key] || [], a(o.key, o.modifiers, {
            type: o.action
        },
        n, t, s), void A[o.key][n ? "unshift": "push"]({
            callback: e,
            modifiers: o.modifiers,
            action: o.action,
            seq: n,
            level: s,
            combo: t
        }))
    }
    function E(t, e, i) {
        for (var n = 0; n < t.length; ++n) y(t[n], e, i)
    }
    for (var T, L, w = {
        8 : "backspace",
        9 : "tab",
        13 : "enter",
        16 : "shift",
        17 : "ctrl",
        18 : "alt",
        20 : "capslock",
        27 : "esc",
        32 : "space",
        33 : "pageup",
        34 : "pagedown",
        35 : "end",
        36 : "home",
        37 : "left",
        38 : "up",
        39 : "right",
        40 : "down",
        45 : "ins",
        46 : "del",
        91 : "meta",
        93 : "meta",
        224 : "meta"
    },
    _ = {
        106 : "*",
        107 : "+",
        109 : "-",
        110 : ".",
        111 : "/",
        186 : ";",
        187 : "=",
        188 : ",",
        189 : "-",
        190 : ".",
        191 : "/",
        192 : "`",
        219 : "[",
        220 : "\\",
        221 : "]",
        222 : "'"
    },
    k = {
        "~": "`",
        "!": "1",
        "@": "2",
        "#": "3",
        $: "4",
        "%": "5",
        "^": "6",
        "&": "7",
        "*": "8",
        "(": "9",
        ")": "0",
        _: "-",
        "+": "=",
        ":": ";",
        '"': "'",
        "<": ",",
        ">": ".",
        "?": "/",
        "|": "\\"
    },
    C = {
        option: "alt",
        command: "meta",
        "return": "enter",
        escape: "esc",
        mod: /Mac|iPod|iPhone|iPad/.test(navigator.platform) ? "meta": "ctrl"
    },
    A = {},
    D = {},
    I = {},
    x = !1, M = !1, R = !1, O = 1; 20 > O; ++O) w[111 + O] = "f" + O;
    for (O = 0; 9 >= O; ++O) w[O + 96] = O;
    i(e, "keypress", u),
    i(e, "keydown", u),
    i(e, "keyup", u);
    var N = {
        bind: function(t, e, i) {
            return t = t instanceof Array ? t: [t],
            E(t, e, i),
            this
        },
        unbind: function(t, e) {
            return N.bind(t,
            function() {},
            e)
        },
        trigger: function(t, e) {
            return D[t + ":" + e] && D[t + ":" + e]({},
            t),
            this
        },
        reset: function() {
            return A = {},
            D = {},
            this
        },
        stopCallback: function(t, e) {
            return (" " + e.className + " ").indexOf(" mousetrap ") > -1 ? !1 : "INPUT" == e.tagName || "SELECT" == e.tagName || "TEXTAREA" == e.tagName || e.isContentEditable
        },
        handleKey: h
    };
    t.Mousetrap = N,
    "function" == typeof define && define.amd && define(N)
} (window, document),
function(t, e, i, n) {
    "use strict";
    function s(t, e, i) {
        return setTimeout(c(t, i), e)
    }
    function o(t, e, i) {
        return Array.isArray(t) ? (a(t, i[e], i), !0) : !1
    }
    function a(t, e, i) {
        var s;
        if (t) if (t.forEach) t.forEach(e, i);
        else if (t.length !== n) for (s = 0; s < t.length;) e.call(i, t[s], s, t),
        s++;
        else for (s in t) t.hasOwnProperty(s) && e.call(i, t[s], s, t)
    }
    function r(t, e, i) {
        for (var s = Object.keys(e), o = 0; o < s.length;)(!i || i && t[s[o]] === n) && (t[s[o]] = e[s[o]]),
        o++;
        return t
    }
    function l(t, e) {
        return r(t, e, !0)
    }
    function d(t, e, i) {
        var n, s = e.prototype;
        n = t.prototype = Object.create(s),
        n.constructor = t,
        n._super = s,
        i && r(n, i)
    }
    function c(t, e) {
        return function() {
            return t.apply(e, arguments)
        }
    }
    function h(t, e) {
        return typeof t == ce ? t.apply(e ? e[0] || n: n, e) : t
    }
    function u(t, e) {
        return t === n ? e: t
    }
    function p(t, e, i) {
        a(v(e),
        function(e) {
            t.addEventListener(e, i, !1)
        })
    }
    function m(t, e, i) {
        a(v(e),
        function(e) {
            t.removeEventListener(e, i, !1)
        })
    }
    function f(t, e) {
        for (; t;) {
            if (t == e) return ! 0;
            t = t.parentNode
        }
        return ! 1
    }
    function g(t, e) {
        return t.indexOf(e) > -1
    }
    function v(t) {
        return t.trim().split(/\s+/g)
    }
    function b(t, e, i) {
        if (t.indexOf && !i) return t.indexOf(e);
        for (var n = 0; n < t.length;) {
            if (i && t[n][i] == e || !i && t[n] === e) return n;
            n++
        }
        return - 1
    }
    function S(t) {
        return Array.prototype.slice.call(t, 0)
    }
    function y(t, e, i) {
        for (var n = [], s = [], o = 0; o < t.length;) {
            var a = e ? t[o][e] : t[o];
            b(s, a) < 0 && n.push(t[o]),
            s[o] = a,
            o++
        }
        return i && (n = e ? n.sort(function(t, i) {
            return t[e] > i[e]
        }) : n.sort()),
        n
    }
    function E(t, e) {
        for (var i, s, o = e[0].toUpperCase() + e.slice(1), a = 0; a < le.length;) {
            if (i = le[a], s = i ? i + o: e, s in t) return s;
            a++
        }
        return n
    }
    function T() {
        return me++
    }
    function L(t) {
        var e = t.ownerDocument;
        return e.defaultView || e.parentWindow
    }
    function w(t, e) {
        var i = this;
        this.manager = t,
        this.callback = e,
        this.element = t.element,
        this.target = t.options.inputTarget,
        this.domHandler = function(e) {
            h(t.options.enable, [t]) && i.handler(e)
        },
        this.init()
    }
    function _(t) {
        var e, i = t.options.inputClass;
        return new(e = i ? i: ve ? F: be ? j: ge ? V: U)(t, k)
    }
    function k(t, e, i) {
        var n = i.pointers.length,
        s = i.changedPointers.length,
        o = e & we && n - s === 0,
        a = e & (ke | Ce) && n - s === 0;
        i.isFirst = !!o,
        i.isFinal = !!a,
        o && (t.session = {}),
        i.eventType = e,
        C(t, i),
        t.emit("hammer.input", i),
        t.recognize(i),
        t.session.prevInput = i
    }
    function C(t, e) {
        var i = t.session,
        n = e.pointers,
        s = n.length;
        i.firstInput || (i.firstInput = I(e)),
        s > 1 && !i.firstMultiple ? i.firstMultiple = I(e) : 1 === s && (i.firstMultiple = !1);
        var o = i.firstInput,
        a = i.firstMultiple,
        r = a ? a.center: o.center,
        l = e.center = x(n);
        e.timeStamp = pe(),
        e.deltaTime = e.timeStamp - o.timeStamp,
        e.angle = N(r, l),
        e.distance = O(r, l),
        A(i, e),
        e.offsetDirection = R(e.deltaX, e.deltaY),
        e.scale = a ? $(a.pointers, n) : 1,
        e.rotation = a ? P(a.pointers, n) : 0,
        D(i, e);
        var d = t.element;
        f(e.srcEvent.target, d) && (d = e.srcEvent.target),
        e.target = d
    }
    function A(t, e) {
        var i = e.center,
        n = t.offsetDelta || {},
        s = t.prevDelta || {},
        o = t.prevInput || {}; (e.eventType === we || o.eventType === ke) && (s = t.prevDelta = {
            x: o.deltaX || 0,
            y: o.deltaY || 0
        },
        n = t.offsetDelta = {
            x: i.x,
            y: i.y
        }),
        e.deltaX = s.x + (i.x - n.x),
        e.deltaY = s.y + (i.y - n.y)
    }
    function D(t, e) {
        var i, s, o, a, r = t.lastInterval || e,
        l = e.timeStamp - r.timeStamp;
        if (e.eventType != Ce && (l > Le || r.velocity === n)) {
            var d = r.deltaX - e.deltaX,
            c = r.deltaY - e.deltaY,
            h = M(l, d, c);
            s = h.x,
            o = h.y,
            i = ue(h.x) > ue(h.y) ? h.x: h.y,
            a = R(d, c),
            t.lastInterval = e
        } else i = r.velocity,
        s = r.velocityX,
        o = r.velocityY,
        a = r.direction;
        e.velocity = i,
        e.velocityX = s,
        e.velocityY = o,
        e.direction = a
    }
    function I(t) {
        for (var e = [], i = 0; i < t.pointers.length;) e[i] = {
            clientX: he(t.pointers[i].clientX),
            clientY: he(t.pointers[i].clientY)
        },
        i++;
        return {
            timeStamp: pe(),
            pointers: e,
            center: x(e),
            deltaX: t.deltaX,
            deltaY: t.deltaY
        }
    }
    function x(t) {
        var e = t.length;
        if (1 === e) return {
            x: he(t[0].clientX),
            y: he(t[0].clientY)
        };
        for (var i = 0,
        n = 0,
        s = 0; e > s;) i += t[s].clientX,
        n += t[s].clientY,
        s++;
        return {
            x: he(i / e),
            y: he(n / e)
        }
    }
    function M(t, e, i) {
        return {
            x: e / t || 0,
            y: i / t || 0
        }
    }
    function R(t, e) {
        return t === e ? Ae: ue(t) >= ue(e) ? t > 0 ? De: Ie: e > 0 ? xe: Me
    }
    function O(t, e, i) {
        i || (i = Pe);
        var n = e[i[0]] - t[i[0]],
        s = e[i[1]] - t[i[1]];
        return Math.sqrt(n * n + s * s)
    }
    function N(t, e, i) {
        i || (i = Pe);
        var n = e[i[0]] - t[i[0]],
        s = e[i[1]] - t[i[1]];
        return 180 * Math.atan2(s, n) / Math.PI
    }
    function P(t, e) {
        return N(e[1], e[0], $e) - N(t[1], t[0], $e)
    }
    function $(t, e) {
        return O(e[0], e[1], $e) / O(t[0], t[1], $e)
    }
    function U() {
        this.evEl = Fe,
        this.evWin = Be,
        this.allow = !0,
        this.pressed = !1,
        w.apply(this, arguments)
    }
    function F() {
        this.evEl = ze,
        this.evWin = Ve,
        w.apply(this, arguments),
        this.store = this.manager.session.pointerEvents = []
    }
    function B() {
        this.evTarget = Ge,
        this.evWin = We,
        this.started = !1,
        w.apply(this, arguments)
    }
    function H(t, e) {
        var i = S(t.touches),
        n = S(t.changedTouches);
        return e & (ke | Ce) && (i = y(i.concat(n), "identifier", !0)),
        [i, n]
    }
    function j() {
        this.evTarget = Ye,
        this.targetIds = {},
        w.apply(this, arguments)
    }
    function z(t, e) {
        var i = S(t.touches),
        n = this.targetIds;
        if (e & (we | _e) && 1 === i.length) return n[i[0].identifier] = !0,
        [i, i];
        var s, o, a = S(t.changedTouches),
        r = [],
        l = this.target;
        if (o = i.filter(function(t) {
            return f(t.target, l)
        }), e === we) for (s = 0; s < o.length;) n[o[s].identifier] = !0,
        s++;
        for (s = 0; s < a.length;) n[a[s].identifier] && r.push(a[s]),
        e & (ke | Ce) && delete n[a[s].identifier],
        s++;
        return r.length ? [y(o.concat(r), "identifier", !0), r] : void 0
    }
    function V() {
        w.apply(this, arguments);
        var t = c(this.handler, this);
        this.touch = new j(this.manager, t),
        this.mouse = new U(this.manager, t)
    }
    function X(t, e) {
        this.manager = t,
        this.set(e)
    }
    function G(t) {
        if (g(t, ei)) return ei;
        var e = g(t, ii),
        i = g(t, ni);
        return e && i ? ii + " " + ni: e || i ? e ? ii: ni: g(t, ti) ? ti: Ze
    }
    function W(t) {
        this.id = T(),
        this.manager = null,
        this.options = l(t || {},
        this.defaults),
        this.options.enable = u(this.options.enable, !0),
        this.state = si,
        this.simultaneous = {},
        this.requireFail = []
    }
    function J(t) {
        return t & di ? "cancel": t & ri ? "end": t & ai ? "move": t & oi ? "start": ""
    }
    function Y(t) {
        return t == Me ? "down": t == xe ? "up": t == De ? "left": t == Ie ? "right": ""
    }
    function K(t, e) {
        var i = e.manager;
        return i ? i.get(t) : t
    }
    function q() {
        W.apply(this, arguments)
    }
    function Q() {
        q.apply(this, arguments),
        this.pX = null,
        this.pY = null
    }
    function Z() {
        q.apply(this, arguments)
    }
    function te() {
        W.apply(this, arguments),
        this._timer = null,
        this._input = null
    }
    function ee() {
        q.apply(this, arguments)
    }
    function ie() {
        q.apply(this, arguments)
    }
    function ne() {
        W.apply(this, arguments),
        this.pTime = !1,
        this.pCenter = !1,
        this._timer = null,
        this._input = null,
        this.count = 0
    }
    function se(t, e) {
        return e = e || {},
        e.recognizers = u(e.recognizers, se.defaults.preset),
        new oe(t, e)
    }
    function oe(t, e) {
        e = e || {},
        this.options = l(e, se.defaults),
        this.options.inputTarget = this.options.inputTarget || t,
        this.handlers = {},
        this.session = {},
        this.recognizers = [],
        this.element = t,
        this.input = _(this),
        this.touchAction = new X(this, this.options.touchAction),
        ae(this, !0),
        a(e.recognizers,
        function(t) {
            var e = this.add(new t[0](t[1]));
            t[2] && e.recognizeWith(t[2]),
            t[3] && e.requireFailure(t[3])
        },
        this)
    }
    function ae(t, e) {
        var i = t.element;
        a(t.options.cssProps,
        function(t, n) {
            i.style[E(i.style, n)] = e ? t: ""
        })
    }
    function re(t, i) {
        var n = e.createEvent("Event");
        n.initEvent(t, !0, !0),
        n.gesture = i,
        i.target.dispatchEvent(n)
    }
    var le = ["", "webkit", "moz", "MS", "ms", "o"],
    de = e.createElement("div"),
    ce = "function",
    he = Math.round,
    ue = Math.abs,
    pe = Date.now,
    me = 1,
    fe = /mobile|tablet|ip(ad|hone|od)|android/i,
    ge = "ontouchstart" in t,
    ve = E(t, "PointerEvent") !== n,
    be = ge && fe.test(navigator.userAgent),
    Se = "touch",
    ye = "pen",
    Ee = "mouse",
    Te = "kinect",
    Le = 25,
    we = 1,
    _e = 2,
    ke = 4,
    Ce = 8,
    Ae = 1,
    De = 2,
    Ie = 4,
    xe = 8,
    Me = 16,
    Re = De | Ie,
    Oe = xe | Me,
    Ne = Re | Oe,
    Pe = ["x", "y"],
    $e = ["clientX", "clientY"];
    w.prototype = {
        handler: function() {},
        init: function() {
            this.evEl && p(this.element, this.evEl, this.domHandler),
            this.evTarget && p(this.target, this.evTarget, this.domHandler),
            this.evWin && p(L(this.element), this.evWin, this.domHandler)
        },
        destroy: function() {
            this.evEl && m(this.element, this.evEl, this.domHandler),
            this.evTarget && m(this.target, this.evTarget, this.domHandler),
            this.evWin && m(L(this.element), this.evWin, this.domHandler)
        }
    };
    var Ue = {
        mousedown: we,
        mousemove: _e,
        mouseup: ke
    },
    Fe = "mousedown",
    Be = "mousemove mouseup";
    d(U, w, {
        handler: function(t) {
            var e = Ue[t.type];
            e & we && 0 === t.button && (this.pressed = !0),
            e & _e && 1 !== t.which && (e = ke),
            this.pressed && this.allow && (e & ke && (this.pressed = !1), this.callback(this.manager, e, {
                pointers: [t],
                changedPointers: [t],
                pointerType: Ee,
                srcEvent: t
            }))
        }
    });
    var He = {
        pointerdown: we,
        pointermove: _e,
        pointerup: ke,
        pointercancel: Ce,
        pointerout: Ce
    },
    je = {
        2 : Se,
        3 : ye,
        4 : Ee,
        5 : Te
    },
    ze = "pointerdown",
    Ve = "pointermove pointerup pointercancel";
    t.MSPointerEvent && (ze = "MSPointerDown", Ve = "MSPointerMove MSPointerUp MSPointerCancel"),
    d(F, w, {
        handler: function(t) {
            var e = this.store,
            i = !1,
            n = t.type.toLowerCase().replace("ms", ""),
            s = He[n],
            o = je[t.pointerType] || t.pointerType,
            a = o == Se,
            r = b(e, t.pointerId, "pointerId");
            s & we && (0 === t.button || a) ? 0 > r && (e.push(t), r = e.length - 1) : s & (ke | Ce) && (i = !0),
            0 > r || (e[r] = t, this.callback(this.manager, s, {
                pointers: e,
                changedPointers: [t],
                pointerType: o,
                srcEvent: t
            }), i && e.splice(r, 1))
        }
    });
    var Xe = {
        touchstart: we,
        touchmove: _e,
        touchend: ke,
        touchcancel: Ce
    },
    Ge = "touchstart",
    We = "touchstart touchmove touchend touchcancel";
    d(B, w, {
        handler: function(t) {
            var e = Xe[t.type];
            if (e === we && (this.started = !0), this.started) {
                var i = H.call(this, t, e);
                e & (ke | Ce) && i[0].length - i[1].length === 0 && (this.started = !1),
                this.callback(this.manager, e, {
                    pointers: i[0],
                    changedPointers: i[1],
                    pointerType: Se,
                    srcEvent: t
                })
            }
        }
    });
    var Je = {
        touchstart: we,
        touchmove: _e,
        touchend: ke,
        touchcancel: Ce
    },
    Ye = "touchstart touchmove touchend touchcancel";
    d(j, w, {
        handler: function(t) {
            var e = Je[t.type],
            i = z.call(this, t, e);
            i && this.callback(this.manager, e, {
                pointers: i[0],
                changedPointers: i[1],
                pointerType: Se,
                srcEvent: t
            })
        }
    }),
    d(V, w, {
        handler: function(t, e, i) {
            var n = i.pointerType == Se,
            s = i.pointerType == Ee;
            if (n) this.mouse.allow = !1;
            else if (s && !this.mouse.allow) return;
            e & (ke | Ce) && (this.mouse.allow = !0),
            this.callback(t, e, i)
        },
        destroy: function() {
            this.touch.destroy(),
            this.mouse.destroy()
        }
    });
    var Ke = E(de.style, "touchAction"),
    qe = Ke !== n,
    Qe = "compute",
    Ze = "auto",
    ti = "manipulation",
    ei = "none",
    ii = "pan-x",
    ni = "pan-y";
    X.prototype = {
        set: function(t) {
            t == Qe && (t = this.compute()),
            qe && (this.manager.element.style[Ke] = t),
            this.actions = t.toLowerCase().trim()
        },
        update: function() {
            this.set(this.manager.options.touchAction)
        },
        compute: function() {
            var t = [];
            return a(this.manager.recognizers,
            function(e) {
                h(e.options.enable, [e]) && (t = t.concat(e.getTouchAction()))
            }),
            G(t.join(" "))
        },
        preventDefaults: function(t) {
            if (!qe) {
                var e = t.srcEvent,
                i = t.offsetDirection;
                if (this.manager.session.prevented) return void e.preventDefault();
                var n = this.actions,
                s = g(n, ei),
                o = g(n, ni),
                a = g(n, ii);
                return s || o && i & Re || a && i & Oe ? this.preventSrc(e) : void 0
            }
        },
        preventSrc: function(t) {
            this.manager.session.prevented = !0,
            t.preventDefault()
        }
    };
    var si = 1,
    oi = 2,
    ai = 4,
    ri = 8,
    li = ri,
    di = 16,
    ci = 32;
    W.prototype = {
        defaults: {},
        set: function(t) {
            return r(this.options, t),
            this.manager && this.manager.touchAction.update(),
            this
        },
        recognizeWith: function(t) {
            if (o(t, "recognizeWith", this)) return this;
            var e = this.simultaneous;
            return t = K(t, this),
            e[t.id] || (e[t.id] = t, t.recognizeWith(this)),
            this
        },
        dropRecognizeWith: function(t) {
            return o(t, "dropRecognizeWith", this) ? this: (t = K(t, this), delete this.simultaneous[t.id], this)
        },
        requireFailure: function(t) {
            if (o(t, "requireFailure", this)) return this;
            var e = this.requireFail;
            return t = K(t, this),
            -1 === b(e, t) && (e.push(t), t.requireFailure(this)),
            this
        },
        dropRequireFailure: function(t) {
            if (o(t, "dropRequireFailure", this)) return this;
            t = K(t, this);
            var e = b(this.requireFail, t);
            return e > -1 && this.requireFail.splice(e, 1),
            this
        },
        hasRequireFailures: function() {
            return this.requireFail.length > 0
        },
        canRecognizeWith: function(t) {
            return !! this.simultaneous[t.id]
        },
        emit: function(t) {
            function e(e) {
                i.manager.emit(i.options.event + (e ? J(n) : ""), t)
            }
            var i = this,
            n = this.state;
            ri > n && e(!0),
            e(),
            n >= ri && e(!0)
        },
        tryEmit: function(t) {
            return this.canEmit() ? this.emit(t) : void(this.state = ci)
        },
        canEmit: function() {
            for (var t = 0; t < this.requireFail.length;) {
                if (! (this.requireFail[t].state & (ci | si))) return ! 1;
                t++
            }
            return ! 0
        },
        recognize: function(t) {
            var e = r({},
            t);
            return h(this.options.enable, [this, e]) ? (this.state & (li | di | ci) && (this.state = si), this.state = this.process(e), void(this.state & (oi | ai | ri | di) && this.tryEmit(e))) : (this.reset(), void(this.state = ci))
        },
        process: function() {},
        getTouchAction: function() {},
        reset: function() {}
    },
    d(q, W, {
        defaults: {
            pointers: 1
        },
        attrTest: function(t) {
            var e = this.options.pointers;
            return 0 === e || t.pointers.length === e
        },
        process: function(t) {
            var e = this.state,
            i = t.eventType,
            n = e & (oi | ai),
            s = this.attrTest(t);
            return n && (i & Ce || !s) ? e | di: n || s ? i & ke ? e | ri: e & oi ? e | ai: oi: ci
        }
    }),
    d(Q, q, {
        defaults: {
            event: "pan",
            threshold: 10,
            pointers: 1,
            direction: Ne
        },
        getTouchAction: function() {
            var t = this.options.direction,
            e = [];
            return t & Re && e.push(ni),
            t & Oe && e.push(ii),
            e
        },
        directionTest: function(t) {
            var e = this.options,
            i = !0,
            n = t.distance,
            s = t.direction,
            o = t.deltaX,
            a = t.deltaY;
            return s & e.direction || (e.direction & Re ? (s = 0 === o ? Ae: 0 > o ? De: Ie, i = o != this.pX, n = Math.abs(t.deltaX)) : (s = 0 === a ? Ae: 0 > a ? xe: Me, i = a != this.pY, n = Math.abs(t.deltaY))),
            t.direction = s,
            i && n > e.threshold && s & e.direction
        },
        attrTest: function(t) {
            return q.prototype.attrTest.call(this, t) && (this.state & oi || !(this.state & oi) && this.directionTest(t))
        },
        emit: function(t) {
            this.pX = t.deltaX,
            this.pY = t.deltaY;
            var e = Y(t.direction);
            e && this.manager.emit(this.options.event + e, t),
            this._super.emit.call(this, t)
        }
    }),
    d(Z, q, {
        defaults: {
            event: "pinch",
            threshold: 0,
            pointers: 2
        },
        getTouchAction: function() {
            return [ei]
        },
        attrTest: function(t) {
            return this._super.attrTest.call(this, t) && (Math.abs(t.scale - 1) > this.options.threshold || this.state & oi)
        },
        emit: function(t) {
            if (this._super.emit.call(this, t), 1 !== t.scale) {
                var e = t.scale < 1 ? "in": "out";
                this.manager.emit(this.options.event + e, t)
            }
        }
    }),
    d(te, W, {
        defaults: {
            event: "press",
            pointers: 1,
            time: 500,
            threshold: 5
        },
        getTouchAction: function() {
            return [Ze]
        },
        process: function(t) {
            var e = this.options,
            i = t.pointers.length === e.pointers,
            n = t.distance < e.threshold,
            o = t.deltaTime > e.time;
            if (this._input = t, !n || !i || t.eventType & (ke | Ce) && !o) this.reset();
            else if (t.eventType & we) this.reset(),
            this._timer = s(function() {
                this.state = li,
                this.tryEmit()
            },
            e.time, this);
            else if (t.eventType & ke) return li;
            return ci
        },
        reset: function() {
            clearTimeout(this._timer)
        },
        emit: function(t) {
            this.state === li && (t && t.eventType & ke ? this.manager.emit(this.options.event + "up", t) : (this._input.timeStamp = pe(), this.manager.emit(this.options.event, this._input)))
        }
    }),
    d(ee, q, {
        defaults: {
            event: "rotate",
            threshold: 0,
            pointers: 2
        },
        getTouchAction: function() {
            return [ei]
        },
        attrTest: function(t) {
            return this._super.attrTest.call(this, t) && (Math.abs(t.rotation) > this.options.threshold || this.state & oi)
        }
    }),
    d(ie, q, {
        defaults: {
            event: "swipe",
            threshold: 10,
            velocity: .65,
            direction: Re | Oe,
            pointers: 1
        },
        getTouchAction: function() {
            return Q.prototype.getTouchAction.call(this)
        },
        attrTest: function(t) {
            var e, i = this.options.direction;
            return i & (Re | Oe) ? e = t.velocity: i & Re ? e = t.velocityX: i & Oe && (e = t.velocityY),
            this._super.attrTest.call(this, t) && i & t.direction && t.distance > this.options.threshold && ue(e) > this.options.velocity && t.eventType & ke
        },
        emit: function(t) {
            var e = Y(t.direction);
            e && this.manager.emit(this.options.event + e, t),
            this.manager.emit(this.options.event, t)
        }
    }),
    d(ne, W, {
        defaults: {
            event: "tap",
            pointers: 1,
            taps: 1,
            interval: 300,
            time: 250,
            threshold: 2,
            posThreshold: 10
        },
        getTouchAction: function() {
            return [ti]
        },
        process: function(t) {
            var e = this.options,
            i = t.pointers.length === e.pointers,
            n = t.distance < e.threshold,
            o = t.deltaTime < e.time;
            if (this.reset(), t.eventType & we && 0 === this.count) return this.failTimeout();
            if (n && o && i) {
                if (t.eventType != ke) return this.failTimeout();
                var a = this.pTime ? t.timeStamp - this.pTime < e.interval: !0,
                r = !this.pCenter || O(this.pCenter, t.center) < e.posThreshold;
                this.pTime = t.timeStamp,
                this.pCenter = t.center,
                r && a ? this.count += 1 : this.count = 1,
                this._input = t;
                var l = this.count % e.taps;
                if (0 === l) return this.hasRequireFailures() ? (this._timer = s(function() {
                    this.state = li,
                    this.tryEmit()
                },
                e.interval, this), oi) : li
            }
            return ci
        },
        failTimeout: function() {
            return this._timer = s(function() {
                this.state = ci
            },
            this.options.interval, this),
            ci
        },
        reset: function() {
            clearTimeout(this._timer)
        },
        emit: function() {
            this.state == li && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input))
        }
    }),
    se.VERSION = "2.0.4",
    se.defaults = {
        domEvents: !1,
        touchAction: Qe,
        enable: !0,
        inputTarget: null,
        inputClass: null,
        preset: [[ee, {
            enable: !1
        }], [Z, {
            enable: !1
        },
        ["rotate"]], [ie, {
            direction: Re
        }], [Q, {
            direction: Re
        },
        ["swipe"]], [ne], [ne, {
            event: "doubletap",
            taps: 2
        },
        ["tap"]], [te]],
        cssProps: {
            userSelect: "none",
            touchSelect: "none",
            touchCallout: "none",
            contentZooming: "none",
            userDrag: "none",
            tapHighlightColor: "rgba(0,0,0,0)"
        }
    };
    var hi = 1,
    ui = 2;
    oe.prototype = {
        set: function(t) {
            return r(this.options, t),
            t.touchAction && this.touchAction.update(),
            t.inputTarget && (this.input.destroy(), this.input.target = t.inputTarget, this.input.init()),
            this
        },
        stop: function(t) {
            this.session.stopped = t ? ui: hi
        },
        recognize: function(t) {
            var e = this.session;
            if (!e.stopped) {
                this.touchAction.preventDefaults(t);
                var i, n = this.recognizers,
                s = e.curRecognizer; (!s || s && s.state & li) && (s = e.curRecognizer = null);
                for (var o = 0; o < n.length;) i = n[o],
                e.stopped === ui || s && i != s && !i.canRecognizeWith(s) ? i.reset() : i.recognize(t),
                !s && i.state & (oi | ai | ri) && (s = e.curRecognizer = i),
                o++
            }
        },
        get: function(t) {
            if (t instanceof W) return t;
            for (var e = this.recognizers,
            i = 0; i < e.length; i++) if (e[i].options.event == t) return e[i];
            return null
        },
        add: function(t) {
            if (o(t, "add", this)) return this;
            var e = this.get(t.options.event);
            return e && this.remove(e),
            this.recognizers.push(t),
            t.manager = this,
            this.touchAction.update(),
            t
        },
        remove: function(t) {
            if (o(t, "remove", this)) return this;
            var e = this.recognizers;
            return t = this.get(t),
            e.splice(b(e, t), 1),
            this.touchAction.update(),
            this
        },
        on: function(t, e) {
            var i = this.handlers;
            return a(v(t),
            function(t) {
                i[t] = i[t] || [],
                i[t].push(e)
            }),
            this
        },
        off: function(t, e) {
            var i = this.handlers;
            return a(v(t),
            function(t) {
                e ? i[t].splice(b(i[t], e), 1) : delete i[t]
            }),
            this
        },
        emit: function(t, e) {
            this.options.domEvents && re(t, e);
            var i = this.handlers[t] && this.handlers[t].slice();
            if (i && i.length) {
                e.type = t,
                e.preventDefault = function() {
                    e.srcEvent.preventDefault()
                };
                for (var n = 0; n < i.length;) i[n](e),
                n++
            }
        },
        destroy: function() {
            this.element && ae(this, !1),
            this.handlers = {},
            this.session = {},
            this.input.destroy(),
            this.element = null
        }
    },
    r(se, {
        INPUT_START: we,
        INPUT_MOVE: _e,
        INPUT_END: ke,
        INPUT_CANCEL: Ce,
        STATE_POSSIBLE: si,
        STATE_BEGAN: oi,
        STATE_CHANGED: ai,
        STATE_ENDED: ri,
        STATE_RECOGNIZED: li,
        STATE_CANCELLED: di,
        STATE_FAILED: ci,
        DIRECTION_NONE: Ae,
        DIRECTION_LEFT: De,
        DIRECTION_RIGHT: Ie,
        DIRECTION_UP: xe,
        DIRECTION_DOWN: Me,
        DIRECTION_HORIZONTAL: Re,
        DIRECTION_VERTICAL: Oe,
        DIRECTION_ALL: Ne,
        Manager: oe,
        Input: w,
        TouchAction: X,
        TouchInput: j,
        MouseInput: U,
        PointerEventInput: F,
        TouchMouseInput: V,
        SingleTouchInput: B,
        Recognizer: W,
        AttrRecognizer: q,
        Tap: ne,
        Pan: Q,
        Swipe: ie,
        Pinch: Z,
        Rotate: ee,
        Press: te,
        on: p,
        off: m,
        each: a,
        merge: l,
        extend: r,
        inherit: d,
        bindFn: c,
        prefixed: E
    }),
    typeof define == ce && define.amd ? define(function() {
        return se
    }) : "undefined" != typeof module && module.exports ? module.exports = se: t[i] = se
} (window, document, "Hammer");