!
function(t, e, i) {
    function n(t, e) {
        return typeof t === e
    }
    function s() {
        var t, e, i, s, o, a, r;
        for (var l in b) {
            if (t = [], e = b[l], e.name && (t.push(e.name.toLowerCase()), e.options && e.options.aliases && e.options.aliases.length)) for (i = 0; i < e.options.aliases.length; i++) t.push(e.options.aliases[i].toLowerCase());
            for (s = n(e.fn, "function") ? e.fn() : e.fn, o = 0; o < t.length; o++) a = t[o],
            r = a.split("."),
            1 === r.length ? y[r[0]] = s: 2 === r.length && (!y[r[0]] || y[r[0]] instanceof Boolean || (y[r[0]] = new Boolean(y[r[0]])), y[r[0]][r[1]] = s),
            v.push((s ? "": "no-") + r.join("-"))
        }
    }
    function o(t) {
        var e = T.className,
        i = y._config.classPrefix || "",
        n = new RegExp("(^|\\s)" + i + "no-js(\\s|$)");
        e = e.replace(n, "$1" + i + "js$2"),
        y._config.enableClasses && (e += " " + i + t.join(" " + i), T.className = e)
    }
    function a() {
        var t = e.body;
        return t || (t = _("body"), t.fake = !0),
        t
    }
    function r(t, e, i, n) {
        var s, o, r, l, d = "modernizr",
        c = _("div"),
        h = a();
        if (parseInt(i, 10)) for (; i--;) r = _("div"),
        r.id = n ? n[i] : d + (i + 1),
        c.appendChild(r);
        return s = ["\xad", '<style id="s', d, '">', t, "</style>"].join(""),
        c.id = d,
        (h.fake ? h: c).innerHTML += s,
        h.appendChild(c),
        h.fake && (h.style.background = "", h.style.overflow = "hidden", l = T.style.overflow, T.style.overflow = "hidden", T.appendChild(h)),
        o = e(c, t),
        h.fake ? (h.parentNode.removeChild(h), T.style.overflow = l, T.offsetHeight) : c.parentNode.removeChild(c),
        !!o
    }
    function l(t, e) {
        return !! ~ ("" + t).indexOf(e)
    }
    function d(t) {
        return t.replace(/([a-z])-([a-z])/g,
        function(t, e, i) {
            return e + i.toUpperCase()
        }).replace(/^-/, "")
    }
    function c(t) {
        return t.replace(/([A-Z])/g,
        function(t, e) {
            return "-" + e.toLowerCase()
        }).replace(/^ms-/, "-ms-")
    }
    function h(e, n) {
        var s = e.length;
        if ("CSS" in t && "supports" in t.CSS) {
            for (; s--;) if (t.CSS.supports(c(e[s]), n)) return ! 0;
            return ! 1
        }
        if ("CSSSupportsRule" in t) {
            for (var o = []; s--;) o.push("(" + c(e[s]) + ":" + n + ")");
            return o = o.join(" or "),
            r("@supports (" + o + ") { #modernizr { position: absolute; } }",
            function(e) {
                return "absolute" == (t.getComputedStyle ? getComputedStyle(e, null) : e.currentStyle).position
            })
        }
        return i
    }
    function u(t, e, s, o) {
        function a() {
            d && (delete D.style, delete D.modElem)
        }
        if (o = n(o, "undefined") ? !1 : o, !n(s, "undefined")) {
            var r = h(t, s);
            if (!n(r, "undefined")) return r
        }
        var d, c, u, p;
        D.style || (d = !0, D.modElem = _("modernizr"), D.style = D.modElem.style);
        for (c in t) if (u = t[c], p = D.style[u], !l(u, "-") && D.style[u] !== i) {
            if (o || n(s, "undefined")) return a(),
            "pfx" == e ? u: !0;
            try {
                D.style[u] = s
            } catch(m) {}
            if (D.style[u] != p) return a(),
            "pfx" == e ? u: !0
        }
        return a(),
        !1
    }
    function p(t, e) {
        return function() {
            return t.apply(e, arguments)
        }
    }
    function m(t, e, i) {
        var s;
        for (var o in t) if (t[o] in e) return i === !1 ? t[o] : (s = e[t[o]], n(s, "function") ? p(s, i || e) : s);
        return ! 1
    }
    function f(t, e, i, s, o) {
        var a = t.charAt(0).toUpperCase() + t.slice(1),
        r = (t + " " + C.join(a + " ") + a).split(" ");
        return n(e, "string") || n(e, "undefined") ? u(r, e, s, o) : (r = (t + " " + w.join(a + " ") + a).split(" "), m(r, e, i))
    }
    function g(t, e, n) {
        return f(t, i, i, e, n)
    }
    var v = [],
    b = [],
    S = {
        _version: "v3.0.0pre",
        _config: {
            classPrefix: "mz-",
            enableClasses: !0,
            usePrefixes: !0
        },
        _q: [],
        on: function(t, e) {
            setTimeout(function() {
                e(this[t])
            },
            0)
        },
        addTest: function(t, e, i) {
            b.push({
                name: t,
                fn: e,
                options: i
            })
        },
        addAsyncTest: function(t) {
            b.push({
                name: null,
                fn: t
            })
        }
    },
    y = function() {};
    y.prototype = S,
    y = new y,
    y.addTest("applicationcache", "applicationCache" in t),
    y.addTest("history",
    function() {
        var e = navigator.userAgent;
        return - 1 === e.indexOf("Android 2.") && -1 === e.indexOf("Android 4.0") || -1 === e.indexOf("Mobile Safari") || -1 !== e.indexOf("Chrome") ? t.history && "pushState" in t.history: !1
    }),
    y.addTest("localstorage",
    function() {
        var t = "modernizr";
        try {
            return localStorage.setItem(t, t),
            localStorage.removeItem(t),
            !0
        } catch(e) {
            return ! 1
        }
    }),
    y.addTest("svg", !!e.createElementNS && !!e.createElementNS("http://www.w3.org/2000/svg", "svg").createSVGRect);
    var E = S._config.usePrefixes ? " -webkit- -moz- -o- -ms- ".split(" ") : [];
    S._prefixes = E;
    var T = e.documentElement,
    L = "Webkit Moz O ms",
    w = S._config.usePrefixes ? L.toLowerCase().split(" ") : [];
    S._domPrefixes = w;
    var _ = function() {
        return e.createElement.apply(e, arguments)
    };
    y.addTest("opacity",
    function() {
        var t = _("div"),
        e = t.style;
        return e.cssText = E.join("opacity:.55;"),
        /^0.55$/.test(e.opacity)
    }),
    y.addTest("rgba",
    function() {
        var t = _("div"),
        e = t.style;
        return e.cssText = "background-color:rgba(150,255,150,.5)",
        ("" + e.backgroundColor).indexOf("rgba") > -1
    });
    var k = S.testStyles = r,
    C = S._config.usePrefixes ? L.split(" ") : [];
    S._cssomPrefixes = C;
    var A = {
        elem: _("modernizr")
    };
    y._q.push(function() {
        delete A.elem
    });
    var D = {
        style: A.elem.style
    };
    y._q.unshift(function() {
        delete D.style
    });
    S.testProp = function(t, e, n) {
        return u([t], i, e, n)
    };
    S.testAllProps = f,
    S.testAllProps = g,
    y.addTest("backgroundsize", g("backgroundSize", "100%", !0)),
    y.addTest("cssanimations", g("animationName", "a", !0)),
    y.addTest("csstransforms", g("transform", "scale(1)", !0)),
    y.addTest("csstransforms3d",
    function() {
        var t = !!g("perspective", "1px", !0),
        e = y._config.usePrefixes;
        if (t && (!e || "webkitPerspective" in T.style)) {
            var i = "@media (transform-3d)";
            e && (i += ",(-webkit-transform-3d)"),
            i += "{#modernizr{left:9px;position:absolute;height:5px;margin:0;padding:0;border:0}}",
            k(i,
            function(e) {
                t = 9 === e.offsetLeft && 5 === e.offsetHeight
            })
        }
        return t
    }),
    y.addTest("csstransitions", g("transition", "all", !0)),
    y.addTest("flexbox", g("flexBasis", "1px", !0)),
    y.addTest("flexboxlegacy", g("boxDirection", "reverse", !0));
    var I = S.prefixed = function(t, e, i) {
        return - 1 != t.indexOf("-") && (t = d(t)),
        e ? f(t, e, i) : f(t, "pfx")
    };
    y.addTest("fullscreen", !(!I("exitFullscreen", e, !1) && !I("cancelFullScreen", e, !1))),
    s(),
    o(v),
    delete S.addTest,
    delete S.addAsyncTest;
    for (var x = 0; x < y._q.length; x++) y._q[x]();
    t.Modernizr = y
} (this, document);