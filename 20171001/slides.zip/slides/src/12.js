"undefined" == typeof document || "classList" in document.createElement("a") || !
function(t) {
    var e = "classList",
    i = "prototype",
    n = (t.HTMLElement || t.Element)[i],
    s = Object,
    o = String[i].trim ||
    function() {
        return this.replace(/^\s+|\s+$/g, "")
    },
    a = Array[i].indexOf ||
    function(t) {
        for (var e = 0,
        i = this.length; i > e; e++) if (e in this && this[e] === t) return e;
        return - 1
    },
    r = function(t, e) {
        this.name = t,
        this.code = DOMException[t],
        this.message = e
    },
    l = function(t, e) {
        if ("" === e) throw new r("SYNTAX_ERR", "An invalid or illegal string was specified");
        if (/\s/.test(e)) throw new r("INVALID_CHARACTER_ERR", "String contains an invalid character");
        return a.call(t, e)
    },
    d = function(t) {
        for (var e = o.call(t.className), i = e ? e.split(/\s+/) : [], n = 0, s = i.length; s > n; n++) this.push(i[n]);
        this._updateClassName = function() {
            t.className = this.toString()
        }
    },
    c = d[i] = [],
    h = function() {
        return new d(this)
    };
    if (r[i] = Error[i], c.item = function(t) {
        return this[t] || null
    },
    c.contains = function(t) {
        return t += "",
        -1 !== l(this, t)
    },
    c.add = function(t) {
        t += "",
        -1 === l(this, t) && (this.push(t), this._updateClassName())
    },
    c.remove = function(t) {
        t += "";
        var e = l(this, t); - 1 !== e && (this.splice(e, 1), this._updateClassName())
    },
    c.toggle = function(t) {
        t += "",
        -1 === l(this, t) ? this.add(t) : this.remove(t)
    },
    c.toString = function() {
        return this.join(" ")
    },
    s.defineProperty) {
        var u = {
            get: h,
            enumerable: !0,
            configurable: !0
        };
        try {
            s.defineProperty(n, e, u)
        } catch(p) { - 2146823252 === p.number && (u.enumerable = !1, s.defineProperty(n, e, u))
        }
    } else s[i].__defineGetter__ && n.__defineGetter__(e, h)
} (self);