!function(t) {
    "function" == typeof define ? define(function() {
        t()
    }) : t()
} (function(t) {
    if (!Function.prototype.bind) {
        var e = Array.prototype.slice;
        Function.prototype.bind = function() {
            function t() {
                if (this instanceof t) {
                    var s = Object.create(i.prototype);
                    return i.apply(s, n.concat(e.call(arguments))),
                    s
                }
                return i.call.apply(i, n.concat(e.call(arguments)))
            }
            var i = this;
            if ("function" != typeof i.apply || "function" != typeof i.call) return new TypeError;
            var n = e.call(arguments);
            return t.length = "function" == typeof i ? Math.max(i.length - n.length, 0) : 0,
            t
        }
    }
    var i, n, s, o, a, r = Function.prototype.call,
    l = Object.prototype,
    d = r.bind(l.hasOwnProperty); (a = d(l, "__defineGetter__")) && (i = r.bind(l.__defineGetter__), n = r.bind(l.__defineSetter__), s = r.bind(l.__lookupGetter__), o = r.bind(l.__lookupSetter__)),
    Array.isArray || (Array.isArray = function(t) {
        return "[object Array]" === Object.prototype.toString.call(t)
    }),
    Array.prototype.forEach || (Array.prototype.forEach = function(t, e) {
        for (var i = +this.length,
        n = 0; i > n; n++) n in this && t.call(e, this[n], n, this)
    }),
    Array.prototype.map || (Array.prototype.map = function(t, e) {
        var i = +this.length;
        if ("function" != typeof t) throw new TypeError;
        for (var n = Array(i), s = 0; i > s; s++) s in this && (n[s] = t.call(e, this[s], s, this));
        return n
    }),
    Array.prototype.filter || (Array.prototype.filter = function(t, e) {
        for (var i = [], n = 0; n < this.length; n++) t.call(e, this[n]) && i.push(this[n]);
        return i
    }),
    Array.prototype.every || (Array.prototype.every = function(t, e) {
        for (var i = 0; i < this.length; i++) if (!t.call(e, this[i])) return ! 1;
        return ! 0
    }),
    Array.prototype.some || (Array.prototype.some = function(t, e) {
        for (var i = 0; i < this.length; i++) if (t.call(e, this[i])) return ! 0;
        return ! 1
    }),
    Array.prototype.reduce || (Array.prototype.reduce = function(t) {
        var e = +this.length;
        if ("function" != typeof t) throw new TypeError;
        if (0 === e && 1 === arguments.length) throw new TypeError;
        var i = 0;
        if (arguments.length >= 2) var n = arguments[1];
        else for (;;) {
            if (i in this) {
                n = this[i++];
                break
            }
            if (++i >= e) throw new TypeError
        }
        for (; e > i; i++) i in this && (n = t.call(null, n, this[i], i, this));
        return n
    }),
    Array.prototype.reduceRight || (Array.prototype.reduceRight = function(t) {
        var e = +this.length;
        if ("function" != typeof t) throw new TypeError;
        if (0 === e && 1 === arguments.length) throw new TypeError;
        var i;
        if (e -= 1, arguments.length >= 2) i = arguments[1];
        else for (;;) {
            if (e in this) {
                i = this[e--];
                break
            }
            if (--e < 0) throw new TypeError
        }
        for (; e >= 0; e--) e in this && (i = t.call(null, i, this[e], e, this));
        return i
    }),
    Array.prototype.indexOf || (Array.prototype.indexOf = function(t, e) {
        var i = this.length;
        if (!i) return - 1;
        var n = e || 0;
        if (n >= i) return - 1;
        for (0 > n && (n += i); i > n; n++) if (n in this && t === this[n]) return n;
        return - 1
    }),
    Array.prototype.lastIndexOf || (Array.prototype.lastIndexOf = function(t, e) {
        var i = this.length;
        if (!i) return - 1;
        var n = e || i;
        for (0 > n && (n += i), n = Math.min(n, i - 1); n >= 0; n--) if (n in this && t === this[n]) return n;
        return - 1
    }),
    Object.getPrototypeOf || (Object.getPrototypeOf = function(t) {
        return t.__proto__ || t.constructor.prototype
    }),
    Object.getOwnPropertyDescriptor || (Object.getOwnPropertyDescriptor = function(e, i) {
        if ("object" != typeof e && "function" != typeof e || null === e) throw new TypeError("Object.getOwnPropertyDescriptor called on a non-object: " + e);
        if (!d(e, i)) return t;
        var n, r, c;
        if (n = {
            enumerable: !0,
            configurable: !0
        },
        a) {
            var h = e.__proto__;
            if (e.__proto__ = l, r = s(e, i), c = o(e, i), e.__proto__ = h, r || c) return r && (n.get = r),
            c && (n.set = c),
            n
        }
        return n.value = e[i],
        n
    }),
    Object.getOwnPropertyNames || (Object.getOwnPropertyNames = function(t) {
        return Object.keys(t)
    }),
    Object.create || (Object.create = function(t, e) {
        var i;
        if (null === t) i = {
            __proto__: null
        };
        else {
            if ("object" != typeof t) throw new TypeError("typeof prototype[" + typeof t + "] != 'object'");
            i = function() {},
            i.prototype = t,
            i = new i,
            i.__proto__ = t
        }
        return "undefined" != typeof e && Object.defineProperties(i, e),
        i
    }),
    Object.defineProperty || (Object.defineProperty = function(t, e, r) {
        if ("object" != typeof t && "function" != typeof t) throw new TypeError("Object.defineProperty called on non-object: " + t);
        if ("object" != typeof r || null === r) throw new TypeError("Property description must be an object: " + r);
        if (d(r, "value")) a && (s(t, e) || o(t, e)) && (t.__proto__ = l, delete t[e]),
        t[e] = r.value;
        else {
            if (!a) throw new TypeError("getters & setters can not be defined on this javascript engine");
            d(r, "get") && i(t, e, r.get),
            d(r, "set") && n(t, e, r.set)
        }
        return t
    }),
    Object.defineProperties || (Object.defineProperties = function(t, e) {
        for (var i in e) d(e, i) && Object.defineProperty(t, i, e[i]);
        return t
    }),
    Object.seal || (Object.seal = function(t) {
        return t
    }),
    Object.freeze || (Object.freeze = function(t) {
        return t
    });
    try {
        Object.freeze(function() {})
    } catch(c) {
        Object.freeze = function(t) {
            return function(e) {
                return "function" == typeof e ? e: t(e)
            }
        } (Object.freeze)
    }
    if (Object.preventExtensions || (Object.preventExtensions = function(t) {
        return t
    }), Object.isSealed || (Object.isSealed = function() {
        return ! 1
    }), Object.isFrozen || (Object.isFrozen = function() {
        return ! 1
    }), Object.isExtensible || (Object.isExtensible = function() {
        return ! 0
    }), !Object.keys) {
        var h, u = !0,
        p = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
        m = p.length;
        for (h in {
            toString: null
        }) u = !1;
        Object.keys = function v(t) {
            if ("object" != typeof t && "function" != typeof t || null === t) throw new TypeError("Object.keys called on a non-object");
            var e, v = [];
            for (e in t) d(t, e) && v.push(e);
            if (u) for (e = 0; m > e; e++) {
                var i = p[e];
                d(t, i) && v.push(i)
            }
            return v
        }
    }
    if (Date.prototype.toISOString || (Date.prototype.toISOString = function() {
        return this.getUTCFullYear() + "-" + (this.getUTCMonth() + 1) + "-" + this.getUTCDate() + "T" + this.getUTCHours() + ":" + this.getUTCMinutes() + ":" + this.getUTCSeconds() + "Z"
    }), Date.now || (Date.now = function() {
        return (new Date).getTime()
    }), Date.prototype.toJSON || (Date.prototype.toJSON = function() {
        if ("function" != typeof this.toISOString) throw new TypeError;
        return this.toISOString()
    }), isNaN(Date.parse("T00:00")) && (Date = function(e) {
        var i, n = function(t, i, s, o, a, r, l) {
            var d = arguments.length;
            return this instanceof e ? (d = 1 === d && String(t) === t ? new e(n.parse(t)) : d >= 7 ? new e(t, i, s, o, a, r, l) : d >= 6 ? new e(t, i, s, o, a, r) : d >= 5 ? new e(t, i, s, o, a) : d >= 4 ? new e(t, i, s, o) : d >= 3 ? new e(t, i, s) : d >= 2 ? new e(t, i) : d >= 1 ? new e(t) : new e, d.constructor = n, d) : e.apply(this, arguments)
        },
        s = RegExp("^(?:((?:[+-]\\d\\d)?\\d\\d\\d\\d)(?:-(\\d\\d)(?:-(\\d\\d))?)?)?(?:T(\\d\\d):(\\d\\d)(?::(\\d\\d)(?:\\.(\\d\\d\\d))?)?)?(?:Z|([+-])(\\d\\d):(\\d\\d))?$");
        for (i in e) n[i] = e[i];
        return n.now = e.now,
        n.UTC = e.UTC,
        n.prototype = e.prototype,
        n.prototype.constructor = n,
        n.parse = function(i) {
            var n = s.exec(i);
            if (n) {
                n.shift();
                for (var o = n[0] === t, a = 0; 10 > a; a++) 7 !== a && (n[a] = +(n[a] || (3 > a ? 1 : 0)), 1 === a && n[a]--);
                return o ? 1e3 * (60 * (60 * n[3] + n[4]) + n[5]) + n[6] : (o = 6e4 * (60 * n[8] + n[9]), "-" === n[6] && (o = -o), e.UTC.apply(this, n.slice(0, 7)) + o)
            }
            return e.parse.apply(this, arguments)
        },
        n
    } (Date)), !String.prototype.trim) {
        var f = /^\s\s*/,
        g = /\s\s*$/;
        String.prototype.trim = function() {
            return String(this).replace(f, "").replace(g, "")
        }
    }
});