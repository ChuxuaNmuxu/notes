var CryptoJS = CryptoJS ||
function(t, e) {
    var i = {},
    n = i.lib = {},
    s = function() {},
    o = n.Base = {
        extend: function(t) {
            s.prototype = this;
            var e = new s;
            return t && e.mixIn(t),
            e.hasOwnProperty("init") || (e.init = function() {
                e.$super.init.apply(this, arguments)
            }),
            e.init.prototype = e,
            e.$super = this,
            e
        },
        create: function() {
            var t = this.extend();
            return t.init.apply(t, arguments),
            t
        },
        init: function() {},
        mixIn: function(t) {
            for (var e in t) t.hasOwnProperty(e) && (this[e] = t[e]);
            t.hasOwnProperty("toString") && (this.toString = t.toString)
        },
        clone: function() {
            return this.init.prototype.extend(this)
        }
    },
    a = n.WordArray = o.extend({
        init: function(t, i) {
            t = this.words = t || [],
            this.sigBytes = i != e ? i: 4 * t.length
        },
        toString: function(t) {
            return (t || l).stringify(this)
        },
        concat: function(t) {
            var e = this.words,
            i = t.words,
            n = this.sigBytes;
            if (t = t.sigBytes, this.clamp(), n % 4) for (var s = 0; t > s; s++) e[n + s >>> 2] |= (i[s >>> 2] >>> 24 - 8 * (s % 4) & 255) << 24 - 8 * ((n + s) % 4);
            else if (65535 < i.length) for (s = 0; t > s; s += 4) e[n + s >>> 2] = i[s >>> 2];
            else e.push.apply(e, i);
            return this.sigBytes += t,
            this
        },
        clamp: function() {
            var e = this.words,
            i = this.sigBytes;
            e[i >>> 2] &= 4294967295 << 32 - 8 * (i % 4),
            e.length = t.ceil(i / 4)
        },
        clone: function() {
            var t = o.clone.call(this);
            return t.words = this.words.slice(0),
            t
        },
        random: function(e) {
            for (var i = [], n = 0; e > n; n += 4) i.push(4294967296 * t.random() | 0);
            return new a.init(i, e)
        }
    }),
    r = i.enc = {},
    l = r.Hex = {
        stringify: function(t) {
            var e = t.words;
            t = t.sigBytes;
            for (var i = [], n = 0; t > n; n++) {
                var s = e[n >>> 2] >>> 24 - 8 * (n % 4) & 255;
                i.push((s >>> 4).toString(16)),
                i.push((15 & s).toString(16))
            }
            return i.join("")
        },
        parse: function(t) {
            for (var e = t.length,
            i = [], n = 0; e > n; n += 2) i[n >>> 3] |= parseInt(t.substr(n, 2), 16) << 24 - 4 * (n % 8);
            return new a.init(i, e / 2)
        }
    },
    d = r.Latin1 = {
        stringify: function(t) {
            var e = t.words;
            t = t.sigBytes;
            for (var i = [], n = 0; t > n; n++) i.push(String.fromCharCode(e[n >>> 2] >>> 24 - 8 * (n % 4) & 255));
            return i.join("")
        },
        parse: function(t) {
            for (var e = t.length,
            i = [], n = 0; e > n; n++) i[n >>> 2] |= (255 & t.charCodeAt(n)) << 24 - 8 * (n % 4);
            return new a.init(i, e)
        }
    },
    c = r.Utf8 = {
        stringify: function(t) {
            try {
                return decodeURIComponent(escape(d.stringify(t)))
            } catch(e) {
                throw Error("Malformed UTF-8 data")
            }
        },
        parse: function(t) {
            return d.parse(unescape(encodeURIComponent(t)))
        }
    },
    h = n.BufferedBlockAlgorithm = o.extend({
        reset: function() {
            this._data = new a.init,
            this._nDataBytes = 0
        },
        _append: function(t) {
            "string" == typeof t && (t = c.parse(t)),
            this._data.concat(t),
            this._nDataBytes += t.sigBytes
        },
        _process: function(e) {
            var i = this._data,
            n = i.words,
            s = i.sigBytes,
            o = this.blockSize,
            r = s / (4 * o),
            r = e ? t.ceil(r) : t.max((0 | r) - this._minBufferSize, 0);
            if (e = r * o, s = t.min(4 * e, s), e) {
                for (var l = 0; e > l; l += o) this._doProcessBlock(n, l);
                l = n.splice(0, e),
                i.sigBytes -= s
            }
            return new a.init(l, s)
        },
        clone: function() {
            var t = o.clone.call(this);
            return t._data = this._data.clone(),
            t
        },
        _minBufferSize: 0
    });
    n.Hasher = h.extend({
        cfg: o.extend(),
        init: function(t) {
            this.cfg = this.cfg.extend(t),
            this.reset()
        },
        reset: function() {
            h.reset.call(this),
            this._doReset()
        },
        update: function(t) {
            return this._append(t),
            this._process(),
            this
        },
        finalize: function(t) {
            return t && this._append(t),
            this._doFinalize()
        },
        blockSize: 16,
        _createHelper: function(t) {
            return function(e, i) {
                return new t.init(i).finalize(e)
            }
        },
        _createHmacHelper: function(t) {
            return function(e, i) {
                return new u.HMAC.init(t, i).finalize(e)
            }
        }
    });
    var u = i.algo = {};
    return i
} (Math);