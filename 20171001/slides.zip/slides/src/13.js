!function(t) {
    function e(t, e, i, n, s) {
        this._listener = e,
        this._isOnce = i,
        this.context = n,
        this._signal = t,
        this._priority = s || 0
    }
    function i(t, e) {
        if ("function" != typeof t) throw new Error("listener is a required param of {fn}() and should be a Function.".replace("{fn}", e))
    }
    function n() {
        this._bindings = [],
        this._prevParams = null;
        var t = this;
        this.dispatch = function() {
            n.prototype.dispatch.apply(t, arguments)
        }
    }
    e.prototype = {
        active: !0,
        params: null,
        execute: function(t) {
            var e, i;
            return this.active && this._listener && (i = this.params ? this.params.concat(t) : t, e = this._listener.apply(this.context, i), this._isOnce && this.detach()),
            e
        },
        detach: function() {
            return this.isBound() ? this._signal.remove(this._listener, this.context) : null
        },
        isBound: function() {
            return !! this._signal && !!this._listener
        },
        isOnce: function() {
            return this._isOnce
        },
        getListener: function() {
            return this._listener
        },
        getSignal: function() {
            return this._signal
        },
        _destroy: function() {
            delete this._signal,
            delete this._listener,
            delete this.context
        },
        toString: function() {
            return "[SignalBinding isOnce:" + this._isOnce + ", isBound:" + this.isBound() + ", active:" + this.active + "]"
        }
    },
    n.prototype = {
        VERSION: "1.0.0",
        memorize: !1,
        _shouldPropagate: !0,
        active: !0,
        _registerListener: function(t, i, n, s) {
            var o, a = this._indexOfListener(t, n);
            if ( - 1 !== a) {
                if (o = this._bindings[a], o.isOnce() !== i) throw new Error("You cannot add" + (i ? "": "Once") + "() then add" + (i ? "Once": "") + "() the same listener without removing the relationship first.")
            } else o = new e(this, t, i, n, s),
            this._addBinding(o);
            return this.memorize && this._prevParams && o.execute(this._prevParams),
            o
        },
        _addBinding: function(t) {
            var e = this._bindings.length;
            do--e;
            while (this._bindings[e] && t._priority <= this._bindings[e]._priority);
            this._bindings.splice(e + 1, 0, t)
        },
        _indexOfListener: function(t, e) {
            for (var i, n = this._bindings.length; n--;) if (i = this._bindings[n], i._listener === t && i.context === e) return n;
            return - 1
        },
        has: function(t, e) {
            return - 1 !== this._indexOfListener(t, e)
        },
        add: function(t, e, n) {
            return i(t, "add"),
            this._registerListener(t, !1, e, n)
        },
        addOnce: function(t, e, n) {
            return i(t, "addOnce"),
            this._registerListener(t, !0, e, n)
        },
        remove: function(t, e) {
            i(t, "remove");
            var n = this._indexOfListener(t, e);
            return - 1 !== n && (this._bindings[n]._destroy(), this._bindings.splice(n, 1)),
            t
        },
        removeAll: function() {
            for (var t = this._bindings.length; t--;) this._bindings[t]._destroy();
            this._bindings.length = 0
        },
        getNumListeners: function() {
            return this._bindings.length
        },
        halt: function() {
            this._shouldPropagate = !1
        },
        dispatch: function() {
            if (this.active) {
                var t, e = Array.prototype.slice.call(arguments),
                i = this._bindings.length;
                if (this.memorize && (this._prevParams = e), i) {
                    t = this._bindings.slice(),
                    this._shouldPropagate = !0;
                    do i--;
                    while (t[i] && this._shouldPropagate && t[i].execute(e) !== !1)
                }
            }
        },
        forget: function() {
            this._prevParams = null
        },
        dispose: function() {
            this.removeAll(),
            delete this._bindings,
            delete this._prevParams
        },
        toString: function() {
            return "[Signal active:" + this.active + " numListeners:" + this.getNumListeners() + "]"
        }
    };
    var s = n;
    s.Signal = n,
    "function" == typeof define && define.amd ? define(function() {
        return s
    }) : "undefined" != typeof module && module.exports ? module.exports = s: t.signals = s
} (this);