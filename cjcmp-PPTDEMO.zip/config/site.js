const site = {
    cjbis: {
        name: '云平台',
        host: '10.0.0.123',
        port: 9501
    },
    cjcmp: {
        name: '云课件平台',
        host: '10.0.3.115',
        port: 9502,
        needLogin: true
    },
    cjhmp: {
        name: '云作业平台',
        host: '10.0.0.123',
        port: '9503',
        needLogin: true
    },
    cjtlis: {
        name: '学情管理系统',
        host: '10.0.0.200',
        port: 80
    }
}

module.exports = site;
