const path = require('path');

const site = require('./site');

var _root = path.resolve(__dirname, '..');
function pathResolve () {
    const args = [_root].concat([].slice.call(arguments))
    return path.resolve.apply(path, args)
}

const config = {
    site_name: 'cjcmp',

    root: _root,
    dir_src: pathResolve('src'),
    dir_dist: pathResolve('dist'),
    dir_test: pathResolve('tests'),
    dir_components: pathResolve('src/components'),

    showDevTools: false,    // 是否显示devTools

    compiler_babel: {
        cacheDirectory: true,
        plugins: ['transform-runtime'],
        presets: ['es2015', 'react', 'stage-0']
    },

    site: site,

    vendors: [              // 希望打包到vendor.js中的第三方插件配置到这里
        'react',
        'react-redux',
        'react-router',
        'redux',
        'react-dom'
    ]
};

config.site.current = config.site[config.site_name];

config.pathResolve = {
    root: pathResolve,
    src: pathResolve.bind(null, config.dir_src),
    dist: pathResolve.bind(null, config.dir_dist),
    components: pathResolve.bind(null, config.dir_components)
};

config.siteResolve = (siteName, path) => {
    const {host, port} = config.site[siteName || 'current'];
    return 'http://' + host + (port && (':' + port)) + '/' + (path || '');
};

module.exports = config;
