import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';
import { browserHistory } from 'react-router';
import { Spin } from 'antd';
import CSSModules from 'react-css-modules';
import {Base64} from 'js-base64';

import config from '../../../config';
import Utils from '../../utils';
import styles from './login.scss';
import { login } from '../../actions/account';

class Login extends Component {
    componentDidMount () {
        this.checkLogin();
    }

    checkLogin () {
        const { t, u, url, relogin } = this.props.location.query;
        let directUrl = url || '/';
        if (relogin) {
            this.redirectToLogin(directUrl, relogin);
            return;
        }

        let token = t || Utils.getCookie('token') || (this.props.token && Base64.encode(this.props.token));
        let visitor = u || Utils.getCookie('visitor') || Base64.encode(JSON.stringify(this.props.visitor));
        if (token) {
            if (!this.props.isLoggedIn || (token !== Base64.encode(this.props.token))) {
                const { dispatch } = this.props;
                dispatch(login(token, visitor));
            }
            if (window.top !== window) {
                window.top.test();
            } else {
                browserHistory.push(directUrl);
            }
        } else {
            this.redirectToLogin(directUrl);
        }
    }

    redirectToLogin (directUrl, relogin = '') {
        if (relogin || this.props.isLoggedOut) {
            relogin = 'relogin=true&'
        } else {
            relogin = '';
        }
        window.location.href = config.siteResolve('cjbis', 'login') + `?${relogin}url=` + config.siteResolve('current', 'account/login') + '?url=' + directUrl;
    }

    render () {
        return (
            <div className='login' styleName='login'>
                <Spin size='large' className='login-spin' />
            </div>
        )
    }
}

Login.propTypes = {
    dispatch: PropTypes.func,
    location: PropTypes.object,
    isLoggedIn: PropTypes.bool.isRequired,
    isLoggedOut: PropTypes.bool,
    visitor: PropTypes.object,
    token: PropTypes.string
}

const mapStateToProps = (state, ownProps) => {
    const {account: {isLoggedIn, isLoggedOut, token, visitor}} = state;
    return {
        isLoggedIn,
        isLoggedOut,
        visitor,
        token
    };
}

export default connect(mapStateToProps)(CSSModules(Login, styles));
