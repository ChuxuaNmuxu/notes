import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import CSSModules from 'react-css-modules';
import styles from './pptSlide.scss';
import Rnd from 'react-rnd';

import Editor, { createEditorStateWithText } from 'draft-js-plugins-editor';
import createInlineToolbarPlugin, { Separator } from 'draft-js-inline-toolbar-plugin';


import {
  ItalicButton,
  BoldButton,
  UnderlineButton,
  CodeButton,
  HeadlineOneButton,
  HeadlineTwoButton,
  HeadlineThreeButton,
  UnorderedListButton,
  OrderedListButton,
  BlockquoteButton,
  CodeBlockButton
} from 'draft-js-buttons';

const inlineToolbarPlugin = createInlineToolbarPlugin({
    structure: [
        BoldButton,
        ItalicButton,
        UnderlineButton,
        CodeButton,
        Separator,
        // HeadlineOneButton,
        // HeadlineTwoButton,
        // HeadlineThreeButton,
        // UnorderedListButton,
        // OrderedListButton,
        // BlockquoteButton,
        // CodeBlockButton
    ]
});
import 'draft-js-inline-toolbar-plugin/lib/plugin.css'; // eslint-disable-line import/no-unresolved
const { InlineToolbar } = inlineToolbarPlugin;
const plugins = [inlineToolbarPlugin];
const text = 'hello world';

const style = {
    textAlign: 'center',
    borderRadius: '5px',
    display: 'flex',
    border: 'dashed 3px #999',
    alignItems: 'center',
    justifyContent: 'center'
};

class Slide extends Component {
    constructor (props) {
        super(props);
        this.state = {
            text: 'Text Title',
            isEdit: false,
            editorState: createEditorStateWithText(text)
        }
        this.handleClick = this.handleClick.bind(this);
    }
    // Editor
    onChange = (editorState) => {
        this.setState({
            editorState
        });
    };

    focus = () => {
        this.editor.focus();
    };
    handleChange (value) {
        this.setState({ text: value })
    }
    handleClick () {
        console.log(1);
    }

    render () {
        const { slides } = this.props;
        const curSlide = this.props.index;
        const { items } = slides[curSlide];
        let slideContent = [];
        for (let key in items) {
            switch (items[key].type) {
            case 'titleText':
            case '':
                slideContent.push(
                    <div key={key}>
                        <Rnd
                          ref={c => { this.rnd = c; }}
                          initial={{
                              x: window.innerWidth / 2 - 350,
                              y: 0,
                              width: '500px',
                              height: '100px'
                          }}
                          style={style}
                          onDblclick={this.handleClick}
                        >
                            {/* <div style={{height: '100%', width: '100%'}}>
                           {this.isEdit?<ReactQuill value={this.state.text}
                  onChange={this.handleChange} />: this.state.text} styleName='editor'
                  </div> */}
                            <div  style={{marginBottom:'0px'}} onClick={this.focus}>
                                <Editor
                                  editorState={this.state.editorState}
                                  onChange={this.onChange.bind(this)}
                                  plugins={plugins}
                                  ref={(element) => { this.editor = element; }}
                                />
                                <InlineToolbar />
                            </div>
                        </Rnd>
                    </div>
                            )
                break;
            case 'rect':
                slideContent.push(<div key={key} style={{height: '50px', width: '50px', background: 'red'}}>{this.props.index}</div>);
                break;
            default:
            //     slideContent.push(<div key={key}>Title Text {this.props.index}</div>);
            }
        }
        return (
            <div>
                {slideContent}
            </div>
        )
    }
}

Slide.propTypes = {
    index: PropTypes.any.isRequired,
    slides: PropTypes.array.isRequired
}

function mapStateToProps (state) {
    const { pptEditor } = state;
    return {
        slides: pptEditor.slides
    }
}

export default connect(mapStateToProps)(CSSModules(Slide, styles))
