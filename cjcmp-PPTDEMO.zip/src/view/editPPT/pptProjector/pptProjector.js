import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import CSSModules from 'react-css-modules';
import Reveal from 'reveal.js';
import 'reveal.js/css/reveal.css';
import 'reveal.js/css/theme/moon.css';
import styles from './pptProjector.scss';

import PPTSlide from './pptSlides/pptSlide';

class Projector extends Component {
    constructor (props) {
        super(props);
        this.state = {
            slides: []
        }
    }
    componentDidMount () {
        Reveal.initialize({
            width: '100%',
            height: 700,
            embedded: true,
            controls: false,
            progress: true,
            history: true,
            fragments: true,
            center: true,
            transition: 'linear' // default/cube/page/concave/zoom/linear/fade/none
        });
    }
    componentDidUpdate () {
        if (this.props.shouldSlideEnd) {
            Reveal.slide(Reveal.getTotalSlides());
        }
    }
    render () {
        const { slides } = this.props;
        let curSlides = [];
        for (let i = 0; i < slides.length; i++) {
            curSlides.push(<section key={i}>
                <PPTSlide key={i} index={i} />
            </section>)
        }

        return <div styleName='revealContainer'>
            <div className='reveal'>
                <div className='slides'>
                    {curSlides}
                </div>
            </div>
        </div>
    }
};

Projector.propTypes = {
    slides: PropTypes.array.isRequired,
    shouldSlideEnd: PropTypes.bool.isRequired
}

function mapStateToProps (props) {
    const { pptEditor } = props;
    return {
        slides: pptEditor.slides,
        shouldSlideEnd: pptEditor.shouldSlideEnd
    };
}
export default connect(mapStateToProps)(CSSModules(Projector, styles));
