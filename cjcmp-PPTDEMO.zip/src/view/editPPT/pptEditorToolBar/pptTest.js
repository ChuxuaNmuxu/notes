import React,{Component} from "react";

class PptTest extends Component{
    render(){
        return (<div>

		<div class="page-loader visible">
			<div class="page-loader-inner">
				<div class="page-loader-spinner"></div>
				<p class="page-loader-message">Loading</p>
			</div>
		</div>

		<div class="page-wrapper">

			<div class="preview-controls">
				<button class="button preview-controls-button preview-controls-exit grey l" data-tooltip="Resume editing" data-tooltip-direction="b" data-tooltip-delay="1000">
					<span class="icon i-pen-alt2"></span>
				</button>
				<a class="button preview-controls-button preview-controls-external grey l" href="#" target="_blank" data-tooltip="Present this deck" data-tooltip-direction="b">
					<span class="icon i-play"></span>
				</a>
			</div>

			<div class="sidebar">

				<div class="primary">
					<button class="button preview" data-tooltip-delay="500" data-tooltip-alignment="r"><span class="icon i-eye"></span></button>
					<button class="button undo" data-tooltip-delay="500" data-tooltip-alignment="r"><span class="icon i-undo"></span></button>
					<button class="button save disabled is-saved" data-tooltip-delay="500" data-tooltip-alignment="r">
						<span class="icon download i-disk"></span>
						<span class="icon check i-checkmark"></span>
						<span class="spinner centered" data-spinner-radius="7" data-spinner-length="4" data-spinner-width="2" data-spinner-color="#bbbbbb"></span>
					</button>
				</div>

				<div class="secondary">
					<button class="button publish" data-tooltip="Visibility" data-tooltip-alignment="r"><span class="icon i-unlock-stroke"></span></button>
					<button class="button settings" data-tooltip="Settings" data-tooltip-alignment="r"><span class="icon i-cog"></span><span class="close icon i-x"></span></button>
					<button class="button style" data-tooltip="Style" data-tooltip-alignment="r"><span class="icon i-brush"></span><span class="close icon i-x"></span></button>
					<button class="button arrange no-arrow" data-tooltip="Arrange slides" data-tooltip-alignment="r"><span class="icon i-layers"></span><span class="close icon i-x"></span></button>
					<button class="button revisions" data-tooltip="Revision history" data-tooltip-alignment="r"><span class="icon i-clock"></span><span class="close icon i-x"></span></button>
					<button class="button import" data-tooltip="Import" data-tooltip-alignment="r"><span class="icon i-cloud-upload"></span><span class="close icon i-x"></span></button>
					<button class="button export" data-tooltip="Export" data-tooltip-alignment="r"><span class="icon i-cloud-download"></span><span class="close icon i-x"></span></button>
					<button class="button medialibrary" data-tooltip="Media library" data-tooltip-alignment="r"><span class="icon i-photo-library"></span></button>
					<button class="button share" data-tooltip="Share" data-tooltip-alignment="r"><span class="icon i-share"></span><span class="close icon i-x"></span></button>
					<a class="button present" data-tooltip="Present" data-tooltip-alignment="r" href="#" target="_blank"><span class="icon i-play"></span></a>

					<button class="button more-options"><span class="more-options-dot"></span><span class="more-options-dot"></span><span class="more-options-dot"></span></button>
				</div>

				<div class="scroll-shadow-top"></div>
				<div class="scroll-shadow-bottom"></div>

				<header class="global-header ">
  <div class="wrapper">
    <h1 class="logo-animation">
      <a class="symbol" href="/">
        <div class="box-1"></div>
        <div class="box-2"></div>
        <div class="box-3"></div>
      </a>
      <a class="word" href="/"></a>
    </h1>
    <ul class="nav ">
        <li class="nav-item" data-page-id="home/explore">
          <a class="nav-item-anchor" href="/explore"><span class="nav-item-label">Explore</span></a>
        </li>
        <li class="nav-item profile-button">
          <a class="nav-item-anchor" href="/xuxueloulan">
            <span class="nav-item-label">xuxueloulan</span>
            <span class="nav-item-burger">
              <span class="nav-item-burger-1"></span>
              <span class="nav-item-burger-2"></span>
              <span class="nav-item-burger-3"></span>
            </span>
          </a>
        </li>
    </ul>
  </div>
</header>


			</div>

			<div class="sidebar-panel">

				<section class="settings">
					<div class="panel-body sl-form">
						<h2>Settings</h2>

						<div class="unit text title">
							<label for="deck[title]">Title</label>
							<input id="deck-input-title" name="deck[title]" size="30" type="text" placeholder="Title" class="xl" maxlength="200" />
						</div>

						<div class="unit text slug">
							<div class="prefixed-input">
								<div class="prefix text-faded"><span class="text-prefix"></span></div>
								<input id="deck-input-slug" name="deck[slug]" size="30" type="text" placeholder="URL" class="l" maxlength="200" />
							</div>
						</div>

						<div class="unit text description">
							<label for="deck[description]">Description</label>
							<textarea id="deck-input-description" name="deck[description]" rows="4" maxlength="1400" placeholder="This will appear next to your deck"></textarea>
						</div>

						<div class="unit text autoslide">
							<label for="deck[autoslide]">Auto-slide</label>
							<select class="sl-select" id="deck-input-autoslide" name="deck[autoslide]"></select>
						</div>

						<div class="toggles">

							<div class="sl-checkbox outline">
								<input id="settings-slide_number" value="slide_number" type="checkbox">
								<label for="settings-slide_number" data-tooltip="Show slide numbers in the bottom right corner of the presentation" data-tooltip-maxwidth="220" data-tooltip-delay="500">Slide numbers</label>
							</div>

							<div class="sl-checkbox outline">
								<input id="settings-share_notes" value="share_notes" type="checkbox">
								<label for="settings-share_notes" data-tooltip="Let viewers see your speaker notes by overlaying them on top of the deck" data-tooltip-maxwidth="220" data-tooltip-delay="500">Share notes</label>
							</div>

							<div class="sl-checkbox outline">
								<input id="settings-loop" value="should_loop" type="checkbox">
								<label for="settings-loop" data-tooltip="Make the last slide loop back to the first" data-tooltip-maxwidth="220" data-tooltip-delay="500">Loop presentation</label>
							</div>

							<div class="sl-checkbox outline rtl-wrapper">
								<input id="settings-rtl" value="rtl" type="checkbox">
								<label for="settings-rtl" data-tooltip="Make content flow right-to-left" data-tooltip-maxwidth="220" data-tooltip-delay="500">Right-to-left</label>
							</div>

							<div class="sl-checkbox outline hide-when-visibility-self hide-when-visibility-team">
								<input id="settings-comments_enabled" value="comments_enabled" type="checkbox">
								<label for="settings-comments_enabled" data-tooltip="Allow comments on this deck" data-tooltip-maxwidth="220" data-tooltip-delay="500">Comments</label>
							</div>

							<div class="sl-checkbox outline hide-when-visibility-self hide-when-visibility-team">
								<input id="settings-forking_enabled" value="forking_enabled" type="checkbox">
								<label for="settings-forking_enabled" data-tooltip="Allow others to make copies of this deck" data-tooltip-maxwidth="220" data-tooltip-delay="500">Forking</label>
							</div>
						</div>
					</div>

					<footer class="panel-footer">
						<button class="button cancel grey xl">Cancel</button>
						<button class="button save xl">OK</button>
					</footer>
				</section>

				<section class="style">
					<div class="panel-body">

					</div>
					<footer class="panel-footer">
						<a class="button left black-30 xl" href="/pricing" data-tooltip="Upgrade to Pro to gain access to the CSS editor. Click to learn more about our plans." data-tooltip-maxwidth="290">CSS editor (Pro)</a>
						<button class="button cancel grey xl">Cancel</button>
						<button class="button save xl">OK</button>
					</footer>
				</section>

				<section class="export">
					<div class="panel-body sl-form">
						<div class="section promotion">
							<h2>ZIP, PDF and Dropbox Sync</h2>
							<p>
								With a paid account you can export your decks to PDF or ZIP. ZIP exports contain everything you need to run the presentation offline, including speaker notes and animations, while PDF is great for printing.
							</p>
							<p>
								You can also sync your work to Dropbox, giving you automated offline access.
							</p>
							<a class="button l upgrade-button" href="/pricing">View plans &amp; upgrade</a>
						</div>
						<div class="section download-html">
							<h2>Export HTML</h2>
							<p>
								Download the HTML source of your deck. The exported file does not include external assets, such as images, and is not suitable for offline use.
							</p>
							<button class="button download-html-button l">Download HTML</button>
						</div>
						<div class="section download-reveal">
							<h2>Export to reveal.js</h2>
							<p>
								This includes the markup for your content as well as the Slides theme CSS. To export, download a copy of the <a href="https://github.com/hakimel/reveal.js" target="_blank">reveal.js</a> framework and make the following edits to its index.
							</p>
							1. In the &lt;head&gt;, replace the theme CSS &lt;link&gt; with:
							<textarea class="deck-css-contents" readonly></textarea>
							2. In the &lt;body&gt;, replace the &lt;div class="reveal"&gt; node with:
							<textarea class="deck-html-contents" readonly></textarea>
							3. In the Reveal.initialize call towards the bottom of index.html, specify "center: false".
						</div>
					</div>
					<footer class="panel-footer">
						<button class="button close xl grey">Close</button>
					</footer>
				</section>

				<section class="import">
					<div class="panel-body sl-form">
						<div class="section import-from-file">
							<h2>Import from PDF or PowerPoint</h2>
							<p>
								Upload a PDF or PPT document to import all contained pages. Imported slides are converted to images, meaning inner content such as text can not be edited.
							</p>
							<div class="import-browse-button button disabled l">Loading...</div>
						</div>
						<div class="section import-from-reveal">
							<h2>Import from reveal.js</h2>
							<p>
								Paste the HTML source of a <a href="http://github.com/hakimel/reveal.js" target="_blank">reveal.js</a> presentation below to import all contained slides. Note that the formatting of imported content can differ since Slides and reveal.js use different themes.
							</p>
							<textarea class="import-input" placeholder="Insert reveal.js markup..."></textarea>
							<div class="import-status">
								<span class="icon"></span>
								<span class="text"></span>
								<button class="button outline white l proceed">Import</button>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<button class="button close xl grey">Close</button>
					</footer>
				</section>

				<section class="share">
					<div class="panel-body sl-form">
						<div class="contents"></div>
					</div>
					<footer class="panel-footer">
						<button class="button close xl grey">Close</button>
					</footer>
				</section>

				<section class="revisions">
					<div class="panel-body">
						<h2>Revision History</h2>
						<ul class="version-list"></ul>
						<p class="loading"><span class="spinner" data-spinner-color="#222222"></span></p>
						<p class="empty">Once your deck has been saved a few times you'll see a record of each saved version here. You'll be able to preview or roll back to any of those versions.</p>
						<p class="error">Please try again by closing and re-opening this panel.</p>
					</div>
					<footer class="panel-footer">
						<div class="panel-info" data-tooltip="Revisions are automatically deleted after six months." data-tooltip-maxwidth="300"><span class="icon i-info"></span></div>
						<button class="button close xl grey">Close</button>
					</footer>
				</section>
			</div>

			<article class="projector">
				<div class="reveal-viewport theme-font-montserrat theme-color-white-blue">
					<div class="reveal">
						<div class="slides">
							<section data-id="ac80a42973e9d96ae4f953f2f3d2b03c">
<div class="sl-block" data-block-type="text" style="height: auto; min-width: 30px; min-height: 30px; width: 600px; left: 0px; top: 0px;" data-block-id="22e6a6d66acf088162d03f177f42ffda"><div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Text" style="z-index: 11;"><p>Text</p></div></div>
<div class="sl-block" data-block-type="shape" style="min-width: 4px; min-height: 4px; width: 300px; height: 300px; left: 330px; top: 200px;" data-block-id="02f33bccf8aaa4d0c9dd62af2f28a4f8"><div class="sl-block-content" data-shape-type="rect" data-shape-fill-color="#000000" data-shape-stretch="true" style="z-index: 12;"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100%" preserveaspectratio="none" viewbox="0 0 300 300"><rect width="300" height="300" class="shape-element" fill="#000000"></rect></svg></div></div>
<div class="sl-block" data-block-type="image" style="min-width: 30px; min-height: 30px; width: 360px; height: 300px; left: 110px; top: 288px;" data-block-id="72a1b0c5835481a1abf3883f3bdcbfdc"><div class="sl-block-content" style="z-index: 13;"></div></div>
<div class="sl-block" data-block-type="text" style="height: auto; min-width: 30px; min-height: 30px; width: 600px; left: 180px; top: 331px;" data-block-id="11847141328011b26eb25e3dcda62f51"><div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Text" style="z-index: 14;"><p>Text</p></div></div>
<div class="sl-block" data-block-type="code" style="min-width: 30px; min-height: 30px; width: 500px; height: 300px; left: 40px; top: 39px;" data-block-id="2b719e2b3d133811b6e72ded2a7ab963"><div class="sl-block-content" style="z-index: 15;"><pre><code></code></pre></div></div></section><section data-id="4858afc26baa12b3dd0673a73697617a"><div class="sl-block" data-block-type="text" style="width: 384px; left: 48px; top: 105px; height: auto;" data-block-id="473382f2f08d7ea1abbecbef4de61226"><div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text" style="text-align: left; z-index: 11;"><h2>Title Text</h2></div></div>
<div class="sl-block" data-block-type="text" style="width: 417px; left: 15px; top: 22px; height: auto;" data-block-id="f9f6f51e88b65c6cc6cfcafa17a811c2"><div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis." style="text-align: left; z-index: 12;"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis.</p></div></div>
<div class="sl-block" data-block-type="text" style="width: 384px; left: 528px; top: 105px; height: auto;" data-block-id="7b715bd4bb461d23530870d8bb46e62c"><div class="sl-block-content" data-placeholder-tag="h2" data-placeholder-text="Title Text" style="text-align: left; z-index: 13;"><h2>Title Text</h2></div></div>
<div class="sl-block" data-block-type="text" style="width: 384px; left: 528px; top: 210px; height: auto;" data-block-id="948713b5c4f29e554b72233c48b6e7d4"><div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis." style="text-align: left; z-index: 14;"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin urna odio, aliquam vulputate faucibus id, elementum lobortis felis. Mauris urna dolor, placerat ac sagittis quis.</p></div></div>
<div class="sl-block" data-block-type="table" style="height: auto; min-width: 120px; min-height: 30px; width: 800px; left: 80px; top: 275px;" data-block-id="7a028065a0ca7ee7bfd67c54e027b4b6"><div class="sl-block-content" style="z-index: 15;"><table><tbody>
<tr>
<th></th>
<th></th>
<th></th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</tbody></table></div></div>
<div class="sl-block" data-block-type="shape" style="min-width: 4px; min-height: 4px; width: 284px; height: 187px; left: 0px; top: 429px;" data-block-id="72372d0b76a50fa5e613924c25363eef"><div class="sl-block-style" style="z-index: 16; transform: rotate(360deg);"><div class="sl-block-content" data-shape-type="rect" data-shape-fill-color="#000000" data-shape-stretch="true" style="z-index: 16;"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100%" preserveaspectratio="none" viewbox="0 0 284 187"><rect width="284" height="187" class="shape-element" fill="#000000"></rect></svg></div></div></div>
<div class="sl-block" data-block-type="text" style="height: auto; min-width: 30px; min-height: 30px; width: 600px; left: 160px; top: 630px;" data-block-id="211b22b23322001b0b6af291db65b5cf"><div class="sl-block-content" data-placeholder-tag="p" data-placeholder-text="Text" style="z-index: 17;">
<p>jjjj</p>
</div></div></section>
						</div>
					</div>
				</div>

				<div class="icon add-horizontal-slide" data-tooltip="Add new slide<br>(Hold shift for blank)" data-tooltip-alignment="l" data-tooltip-delay="1500">
					<span class="icon i-plus"></span>
				</div>
				<div class="icon add-vertical-slide" data-tooltip="Add new slide<br>(Hold shift for blank)" data-tooltip-alignment="t" data-tooltip-delay="1500">
					<span class="icon i-plus"></span>
				</div>
			</article>

		</div>

            
        </div>)
    }
}