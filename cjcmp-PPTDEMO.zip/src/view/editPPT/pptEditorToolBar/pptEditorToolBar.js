import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
// import CSSModules from 'react-css-modules';
import { Button } from 'antd';
import Reveal from 'reveal.js';
import 'reveal.js/css/reveal.css';
import 'reveal.js/css/theme/moon.css';
import { addItem } from '../../../actions/pptEditor'

import Editor from 'draft-js-plugins-editor';
import createHashtagPlugin from 'draft-js-hashtag-plugin';
import createLinkifyPlugin from 'draft-js-linkify-plugin';
import { EditorState } from 'draft-js';

const hashtagPlugin = createHashtagPlugin();
const linkifyPlugin = createLinkifyPlugin();

const plugins = [
    hashtagPlugin,
    linkifyPlugin
];

class ToolBar extends Component {
    constructor (props) {
        super(props);
        this.addSlide = this.addSlide.bind(this);
        this.addPPTItem = this.addPPTItem.bind(this);
    }

    addSlide (e) {
        const { dispatch, slides } = this.props;
        const curKey = Reveal.getTotalSlides() + 1;
        slides.push({
            key: curKey,
            items: [
                {
                    key: 0,
                    type: ''
                }
            ]
        })
        dispatch(addItem({
            shouldSlideEnd: true,
            slides
        }))
    }
    addPPTItem (e) {
        const { dispatch, slides } = this.props;
        const type = e.target.getAttribute('data-type') || e.target.parentElement.getAttribute('data-type');
        let curKey = Reveal.getIndices().h + ''; // h表示横向ppt张数 v表示纵向
        for (let key in slides) {
            if (key === curKey) {
                slides[key].items.push({
                    key: slides[key].items.length + 1,
                    type
                })
            }
        }
        dispatch(addItem({
            shouldSlideEnd: false,
            slides
        }))
    }
    render () {
        return <div style={{display: 'flex', height: '100%'}}>
            <div style={{display: 'inline-flex', flexDirection: 'column'}}>
                <Button type='primary' onClick={this.addSlide}>addSlide</Button>
                <Button type='primary' icon='plus' data-type='titleText' onClick={this.addPPTItem}>
                    addTitle
                </Button>
                <Button type='primary' icon='plus' data-type='rect' onClick={this.addPPTItem}>addRect</Button>
            </div>
        </div>
    }
}

ToolBar.propTypes = {
    slides: PropTypes.array.isRequired,
    dispatch: PropTypes.any.isRequired
}

function mapStateToProps (props) {
    const { pptEditor } = props;
    return {
        slides: pptEditor.slides
    };
}

export default connect(mapStateToProps)(ToolBar)
