import React, { Component } from 'react';
import { connect } from 'react-redux';
import CSSModules from 'react-css-modules';
import { Layout } from 'antd';
const { Content, Sider } = Layout;
// import Reveal from 'reveal.js';
// import 'reveal.js/css/reveal.css';
// import 'reveal.js/css/theme/moon.css';

import ToolBar from './pptEditorToolBar/pptEditorToolBar';
import Projector from './pptProjector/pptProjector';

class Editor extends Component {
    shouldComponentUpdate() {
        return false;
    }
    render () {
        return (
            <iframe style={{width:'100%',height:'700'}} src='https://ppt.baomitu.com/editor#/' />
            /*<Layout>
                <Sider width={200} style={{ background: '#fff' }}>
                    <ToolBar />
                </Sider>
                <Content>
                    <Projector />
                </Content>
                
            </Layout>*/
            
        )
    }
};

export default connect()(CSSModules(Editor));
