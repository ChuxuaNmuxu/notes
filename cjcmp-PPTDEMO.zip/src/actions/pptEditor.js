import {
    PPT_EDITOR_ADD_ITEM
} from './actionTypes';

export const addItem = (data) => {
    return {
        type: PPT_EDITOR_ADD_ITEM,
        data: data
    }
}

