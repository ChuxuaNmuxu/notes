import Home from '../view/home/layout';

export default Home;
