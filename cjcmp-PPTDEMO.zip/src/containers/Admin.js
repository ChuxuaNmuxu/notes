import Admin from '../view/admin/layout';

export default Admin;
