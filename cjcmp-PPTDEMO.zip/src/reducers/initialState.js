import Utils from '../utils';
import { Base64 } from 'js-base64';

const token = Utils.getCookie('token');
let visitor = Utils.getCookie('visitor');
visitor = visitor && JSON.parse(Base64.decode(visitor.replace(/ /g, '+')));
window.visitor = visitor;
export default {
    // 账号
    account: {
        isLoggedIn: !!token,
        isLoggedOut: false,
        token: token && Base64.decode(token),
        visitor: visitor
    },

    course: {
        // 这里存放科目
        subject: {
            isFetching: false,
            meta: {
                firstValue: undefined,
                firstValueId: undefined
            },
            data: []
        },
        // 对应科目的章节
        knowledge: {
            isFetching: false,
            meta: {
                subjectId: 0
            },
            data: []
        },
        // 这里存放具体的课件,内容是根据所选科目的章节确定的(具体实现应该传对应科目的ID,和对应具体节的ID)
        courseData: {
            isFetching: false,
            meta: {
                subjectId: 0
            },
            data: {
                items: []
            }
        },
        // 这里存放上传课件所需的知识点数据，在第一次请求时拿到所有的知识点数据，处理后供上传课件部分使用
        uploadKnowledge: {
            isFetching: false,
            data: [],
            lastKnowledge: []
        },
        // 这里放上传课件后的返回情况
        uploadCourse: {
            isFetching: false,
            data: null
        }
    },

    pptEditor: {
        shouldSlideEnd: false,
        slides: [
            {
                key: 0,
                items: [
                    {
                        key: 0,
                        type: ''
                    }
                ]
            }
        ]
    }

};
