import { combineReducers } from 'redux';
import { routerReducer as routing } from 'react-router-redux';

import account from './account';
import course from './course';
import pptEditor from './pptEditor';

const rootReducer = combineReducers({
    account,
    course,
    routing,
    pptEditor
})

export default rootReducer;
