import merge from 'lodash/merge';
import { PPT_EDITOR_ADD_ITEM } from '../actions/actionTypes';
import initialState from './initialState';

const pptEditor = (state = initialState.pptEditor, action) => {
    let type = action.type;
    if (type === PPT_EDITOR_ADD_ITEM) {
        return merge({}, state, {
            shouldSlideEnd: action.data.shouldSlideEnd,
            slides: action.data.slides
        });
    }
    return state;
}

export default pptEditor;
